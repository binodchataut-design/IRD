package com.example

import com.example.utils.QrInvoiceParser
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testExtractVendorPan() {
    // Direct 9-digit PAN
    assertEquals("301234567", QrInvoiceParser.extractVendorPan("301234567"))
    // Formatted with prefix
    assertEquals("301234567", QrInvoiceParser.extractVendorPan("PAN: 301234567"))
    assertEquals("609876543", QrInvoiceParser.extractVendorPan("Seller_PAN=609876543"))
    // In URL query
    assertEquals("301234567", QrInvoiceParser.extractVendorPan("https://merchant.fonepay.com/pay?pan=301234567&store=BhatBhateni"))
    // Invalid PAN (less than 9 digits or not valid)
    assertNull(QrInvoiceParser.extractVendorPan("12345"))
  }

  @Test
  fun testParseInvoiceQr_KeyValue() {
    val qrText = """
      PAN: 301234567
      InvoiceNo: INV-2081-998
      Amount: 1450.50
      Date: 2024-05-15
      Seller: Bhat-Bhateni Supermarket
    """.trimIndent()

    val parsed = QrInvoiceParser.parseInvoiceQr(qrText)
    assertTrue(parsed.isRecognized)
    assertEquals("301234567", parsed.sellerPan)
    assertEquals("INV-2081-998", parsed.invoiceNumber)
    assertEquals(1450.50, parsed.amount ?: 0.0, 0.001)
    assertEquals("2024-05-15", parsed.date)
    assertEquals("Bhat-Bhateni Supermarket", parsed.sellerName)
  }

  @Test
  fun testParseInvoiceQr_Json() {
    val json = """{"pan":"301234567","invoice_no":"BB-8812","total":2500.0,"seller":"Big Mart","date":"2024-06-01"}"""
    val parsed = QrInvoiceParser.parseInvoiceQr(json)
    assertTrue(parsed.isRecognized)
    assertEquals("301234567", parsed.sellerPan)
    assertEquals("BB-8812", parsed.invoiceNumber)
    assertEquals(2500.0, parsed.amount ?: 0.0, 0.001)
    assertEquals("Big Mart", parsed.sellerName)
    assertEquals("2024-06-01", parsed.date)
  }

  @Test
  fun testParseInvoiceQr_Delimited() {
    val delimited = "301234567,INV-1029,890.00,2024-05-10,Valley Express"
    val parsed = QrInvoiceParser.parseInvoiceQr(delimited)
    assertTrue(parsed.isRecognized)
    assertEquals("301234567", parsed.sellerPan)
    assertEquals("INV-1029", parsed.invoiceNumber)
    assertEquals(890.0, parsed.amount ?: 0.0, 0.001)
    assertEquals("2024-05-10", parsed.date)
    assertEquals("Valley Express", parsed.sellerName)
  }

  @Test
  fun testExtractBillDataFromOcrText() {
    val sampleBillOcr = """
        Bhat-Bhateni Supermarket Pvt Ltd
        VAT / PAN: 301234567
        TAX INVOICE
        Invoice No: BBS-2081-0099
        Date: 2024-05-20
        Item 1: Milk Rs 120
        Item 2: Bread Rs 80
        Grand Total: NPR 2,150.00
        Thank you for visiting!
    """.trimIndent()

    val billData = com.example.utils.BillDataUtils.extractFromText(sampleBillOcr)
    assertEquals("PAN mismatch: ${billData.pan}", "301234567", billData.pan)
    assertEquals("Invoice mismatch: ${billData.invoiceNumber}", "BBS-2081-0099", billData.invoiceNumber)
    assertEquals("Date mismatch: ${billData.date}", "2024-05-20", billData.date)
    assertEquals("Amount mismatch: ${billData.amount}", "2150.00", billData.amount)
    assertEquals("Seller mismatch: ${billData.sellerName}", "Bhat-Bhateni Supermarket Pvt Ltd", billData.sellerName)
  }
}
