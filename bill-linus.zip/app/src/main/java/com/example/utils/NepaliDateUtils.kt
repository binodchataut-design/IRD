package com.example.utils

import com.example.model.AppLanguage
import java.time.LocalDate
import java.time.ZoneOffset

data class DrawPeriodInfo(
    val drawPeriod: String,
    val drawPeriodId: String,
    val expectedAnnouncement: String,
    val cycleName: String,
    val isExact: Boolean
)

data class BSDate(
    val year: Int,
    val month: Int,
    val day: Int
)

object NepaliDateUtils {

    private val BS_MONTHS_EN = listOf(
        "", "Baisakh", "Jestha", "Ashadh", "Shrawan", "Bhadra",
        "Ashwin", "Kartik", "Mangsir", "Poush", "Magh", "Falgun", "Chaitra"
    )

    private val BS_MONTHS_NE = listOf(
        "", "बैशाख", "जेठ", "असार", "साउन", "भदौ",
        "असोज", "कार्तिक", "मंसिर", "पुष", "माघ", "फागुन", "चैत"
    )

    // Days in each BS month for years 2000–2090 BS
    private val BS_CALENDAR = listOf(
        intArrayOf(2000,30,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2001,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2002,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2003,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2004,30,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2005,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2006,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2007,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2008,31,31,31,32,31,31,29,30,30,29,29,31),
        intArrayOf(2009,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2010,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2011,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2012,31,31,31,32,31,31,29,30,30,29,30,30),
        intArrayOf(2013,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2014,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2015,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2016,31,31,31,32,31,31,29,30,30,29,30,30),
        intArrayOf(2017,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2018,31,32,31,32,31,30,30,29,30,29,30,30),
        intArrayOf(2019,31,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2020,31,31,31,32,31,31,30,29,30,29,30,30),
        intArrayOf(2021,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2022,31,32,31,32,31,30,30,30,29,29,30,30),
        intArrayOf(2023,31,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2024,31,31,31,32,31,31,30,29,30,29,30,30),
        intArrayOf(2025,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2026,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2027,30,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2028,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2029,31,31,32,31,32,30,30,29,30,29,30,30),
        intArrayOf(2030,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2031,30,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2032,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2033,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2034,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2035,30,32,31,32,31,31,29,30,30,29,29,31),
        intArrayOf(2036,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2037,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2038,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2039,31,31,31,32,31,31,29,30,30,29,30,30),
        intArrayOf(2040,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2041,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2042,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2043,31,31,31,32,31,31,29,30,30,29,30,30),
        intArrayOf(2044,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2045,31,32,31,32,31,30,30,29,30,29,30,30),
        intArrayOf(2046,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2047,31,31,31,32,31,31,30,29,30,29,30,30),
        intArrayOf(2048,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2049,31,32,31,32,31,30,30,30,29,29,30,30),
        intArrayOf(2050,31,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2051,31,31,31,32,31,31,30,29,30,29,30,30),
        intArrayOf(2052,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2053,31,32,31,32,31,30,30,30,29,29,30,30),
        intArrayOf(2054,31,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2055,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2056,31,31,32,31,32,30,30,29,30,29,30,30),
        intArrayOf(2057,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2058,30,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2059,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2060,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2061,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2062,30,32,31,32,31,31,29,30,29,30,29,31),
        intArrayOf(2063,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2064,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2065,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2066,31,31,31,32,31,31,29,30,30,29,29,31),
        intArrayOf(2067,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2068,31,31,32,32,31,30,30,29,30,29,30,30),
        intArrayOf(2069,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2070,31,31,31,32,31,31,29,30,30,29,30,30),
        intArrayOf(2071,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2072,31,32,31,32,31,30,30,29,30,29,30,30),
        intArrayOf(2073,31,32,31,32,31,30,30,30,29,29,30,31),
        intArrayOf(2074,31,31,31,32,31,31,30,29,30,29,30,30),
        intArrayOf(2075,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2076,31,32,31,32,31,30,30,30,29,29,30,30),
        intArrayOf(2077,31,32,31,32,31,30,30,30,29,30,29,31),
        intArrayOf(2078,31,31,31,32,31,31,30,29,30,29,30,30),
        intArrayOf(2079,31,31,32,31,31,31,30,29,30,29,30,30),
        intArrayOf(2080,31,32,31,32,31,30,30,30,29,29,30,30),
        intArrayOf(2081,31,31,32,32,31,30,30,30,29,30,30,30),
        intArrayOf(2082,30,32,31,32,31,30,30,30,29,30,30,30),
        intArrayOf(2083,31,31,32,31,31,30,30,30,29,30,30,30),
        intArrayOf(2084,31,31,32,31,31,30,30,30,29,30,30,30),
        intArrayOf(2085,31,32,31,32,30,31,30,30,29,30,30,30),
        intArrayOf(2086,30,32,31,32,31,30,30,30,29,30,30,30),
        intArrayOf(2087,31,31,32,31,31,31,30,30,29,30,30,30),
        intArrayOf(2088,30,31,32,32,30,31,30,30,29,30,30,30),
        intArrayOf(2089,30,32,31,32,31,30,30,30,29,30,30,30),
        intArrayOf(2090,30,32,31,32,31,30,30,30,29,30,30,30)
    )

    // Reference: 1 Baisakh 2000 BS = April 14, 1943 AD
    private val REF_AD_EPOCH_DAY = LocalDate.of(1943, 4, 14).toEpochDay()

    private fun getYearIndex(bsYear: Int): Int? {
        for (i in BS_CALENDAR.indices) {
            if (BS_CALENDAR[i][0] == bsYear) return i
        }
        return null
    }

    private fun daysInBSYear(yearIdx: Int): Int {
        var total = 0
        for (m in 1..12) total += BS_CALENDAR[yearIdx][m]
        return total
    }

    private fun getMonthName(month: Int, lang: AppLanguage): String {
        val names = if (lang == AppLanguage.NE) BS_MONTHS_NE else BS_MONTHS_EN
        return if (month in 1..12) names[month] else ""
    }

    fun adToBS(adYear: Int, adMonth: Int, adDay: Int): BSDate? {
        try {
            val target = LocalDate.of(adYear, adMonth, adDay).toEpochDay()
            var totalDays = (target - REF_AD_EPOCH_DAY).toInt()
            if (totalDays < 0) return null

            var yearIdx = 0
            while (yearIdx < BS_CALENDAR.size && totalDays >= daysInBSYear(yearIdx)) {
                totalDays -= daysInBSYear(yearIdx)
                yearIdx++
            }
            if (yearIdx >= BS_CALENDAR.size) return null

            val bsYear = BS_CALENDAR[yearIdx][0]
            var bsMonth = 1
            while (bsMonth <= 12 && totalDays >= BS_CALENDAR[yearIdx][bsMonth]) {
                totalDays -= BS_CALENDAR[yearIdx][bsMonth]
                bsMonth++
            }
            return BSDate(year = bsYear, month = bsMonth, day = totalDays + 1)
        } catch (e: Exception) {
            return null
        }
    }

    fun dateStrToBS(dateStr: String): BSDate? {
        return try {
            val parts = dateStr.trim().split("-")
            if (parts.size == 3) {
                adToBS(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
            } else null
        } catch (e: Exception) {
            null
        }
    }

    fun getDrawPeriodId(dateStr: String): String {
        val bs = dateStrToBS(dateStr) ?: return "unknown"
        val half = if (bs.day <= 15) 1 else 2
        return "${bs.year}-${bs.month}-$half"
    }

    fun parseDrawPeriodId(periodStr: String?): String? {
        if (periodStr == null) return null
        val lower = periodStr.lowercase()
        for (m in 1..12) {
            val enName = BS_MONTHS_EN[m].lowercase()
            val neName = BS_MONTHS_NE[m]
            if (lower.contains(enName) || periodStr.contains(neName)) {
                val yearRegex = "\\b(\\d{4})\\b".toRegex()
                val match = yearRegex.find(periodStr)
                val year = match?.groupValues?.get(1) ?: ""
                val half = if (periodStr.contains("16") || periodStr.contains("दोस्रो") || periodStr.contains("2nd")) 2 else 1
                return "$year-$m-$half"
            }
        }
        return null
    }

    private fun formatPeriod(bs: BSDate, lang: AppLanguage): String {
        val monthName = getMonthName(bs.month, lang)
        val first = bs.day <= 15
        val half = if (first) "1–15" else "16–30"
        return "$monthName $half, ${bs.year}"
    }

    private fun formatCycleName(bs: BSDate, lang: AppLanguage): String {
        val monthName = getMonthName(bs.month, lang)
        val first = bs.day <= 15
        return if (lang == AppLanguage.NE) {
            "$monthName ${if (first) "पहिलो" else "दोस्रो"} हाफ ड्र"
        } else {
            "$monthName ${if (first) "1st" else "2nd"} Half Draw"
        }
    }

    private fun formatExpectedAnnouncement(bs: BSDate, lang: AppLanguage): String {
        val first = bs.day <= 15
        if (first) {
            return "${getMonthName(bs.month, lang)} 22, ${bs.year}"
        }
        val nextMonth = if (bs.month == 12) 1 else bs.month + 1
        val nextYear = if (bs.month == 12) bs.year + 1 else bs.year
        return "${getMonthName(nextMonth, lang)} 7, $nextYear"
    }

    fun getDrawPeriodForDate(dateStr: String, lang: AppLanguage = AppLanguage.EN): DrawPeriodInfo {
        val bs = dateStrToBS(dateStr) ?: return DrawPeriodInfo(
            drawPeriod = if (lang == AppLanguage.NE) "हालको योजना चक्र" else "Current Scheme Cycle",
            drawPeriodId = "unknown",
            expectedAnnouncement = if (lang == AppLanguage.NE) "१५ दिने बिलिङ चक्र अनुसार" else "Following the 15-day billing cycle",
            cycleName = if (lang == AppLanguage.NE) "पाक्षिक उपभोक्ता ड्र" else "Fortnightly consumer draw",
            isExact = false
        )
        val half = if (bs.day <= 15) 1 else 2
        return DrawPeriodInfo(
            drawPeriod = formatPeriod(bs, lang),
            drawPeriodId = "${bs.year}-${bs.month}-$half",
            expectedAnnouncement = formatExpectedAnnouncement(bs, lang),
            cycleName = formatCycleName(bs, lang),
            isExact = true
        )
    }

    fun getCurrentDrawPeriod(lang: AppLanguage = AppLanguage.EN): DrawPeriodInfo {
        val now = LocalDate.now()
        val iso = String.format("%04d-%02d-%02d", now.year, now.monthValue, now.dayOfMonth)
        return getDrawPeriodForDate(iso, lang)
    }
}
