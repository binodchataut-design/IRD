package com.example.utils

import com.example.model.BulkParseResult

object CouponUtils {

    fun normalizeCouponNumber(input: String?): String {
        return (input ?: "").filter { it.isDigit() }
    }

    fun isValidCouponNumber(input: String?): Boolean {
        val digits = normalizeCouponNumber(input)
        return digits.length == 12
    }

    fun formatCouponNumber(input: String?): String {
        val d = normalizeCouponNumber(input)
        if (d.isEmpty()) return ""
        return d.chunked(3).joinToString(" ")
    }

    fun isValidPanNumber(input: String?): Boolean {
        val d = normalizeCouponNumber(input)
        return d.length == 9
    }

    fun parseBulkCouponsText(raw: String, existing: Set<String>): BulkParseResult {
        val validNew = mutableListOf<String>()
        val duplicateInBatch = mutableListOf<String>()
        val alreadySaved = mutableListOf<String>()
        val invalidTokens = mutableListOf<String>()
        val seen = mutableSetOf<String>()

        val tokens = raw.split(Regex("[\\r\\n;,\\s]+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        for (rawToken in tokens) {
            val normalized = normalizeCouponNumber(rawToken)
            if (normalized.length == 12 && isValidCouponNumber(normalized)) {
                when {
                    existing.contains(normalized) -> alreadySaved.add(normalized)
                    seen.contains(normalized) -> duplicateInBatch.add(normalized)
                    else -> {
                        seen.add(normalized)
                        validNew.add(normalized)
                    }
                }
            } else {
                invalidTokens.add(rawToken)
            }
        }

        return BulkParseResult(
            totalExtracted = validNew.size + duplicateInBatch.size + alreadySaved.size,
            validNew = validNew,
            duplicateInBatch = duplicateInBatch,
            alreadySaved = alreadySaved,
            invalidTokens = invalidTokens
        )
    }
}
