package com.example.utils

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URI

data class ParsedInvoiceQr(
    val sellerPan: String? = null,
    val invoiceNumber: String? = null,
    val amount: Double? = null,
    val sellerName: String? = null,
    val date: String? = null,
    val rawText: String,
    val isRecognized: Boolean
)

object QrInvoiceParser {

    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    /**
     * Extracts a 9-digit PAN number from scanned Vendor QR text.
     */
    fun extractVendorPan(rawText: String?): String? {
        if (rawText.isNullOrBlank()) return null
        val trimmed = rawText.trim()

        // 1. Direct raw PAN (e.g., "301234567" or with formatting)
        val normalized = CouponUtils.normalizeCouponNumber(trimmed)
        if (normalized.length == 9 && CouponUtils.isValidPanNumber(normalized)) {
            return normalized
        }

        // 2. Look for labeled PAN/VAT patterns (e.g., "PAN: 301234567", "pan=301234567", "seller_pan: 301234567")
        val panRegex = Regex("""(?i)(?:seller_?pan|seller_?vat|pan_?vat|pan_?no|vat_?no|pan|vat)[\s:=_-]*([0-9]{9})""")
        val panMatch = panRegex.find(trimmed)
        if (panMatch != null) {
            val candidate = panMatch.groupValues[1]
            if (CouponUtils.isValidPanNumber(candidate)) {
                return candidate
            }
        }

        // 3. Try URL parsing if it's a URL
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            try {
                val uri = URI(trimmed)
                val query = uri.query
                if (!query.isNullOrBlank()) {
                    val params = parseQueryString(query)
                    for (key in listOf("pan", "sellerpan", "sellervat", "vat", "pan_no", "panno", "seller_pan")) {
                        val v = params[key]
                        if (v != null) {
                            val norm = CouponUtils.normalizeCouponNumber(v)
                            if (CouponUtils.isValidPanNumber(norm)) {
                                return norm
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // Ignore URL parsing failure
            }
        }

        // 4. Look for any standalone 9-digit number sequence
        val standalonePanRegex = Regex("""\b([0-9]{9})\b""")
        val match = standalonePanRegex.find(trimmed)
        if (match != null) {
            val candidate = match.groupValues[1]
            if (CouponUtils.isValidPanNumber(candidate)) {
                return candidate
            }
        }

        return null
    }

    /**
     * Attempts best-effort parsing of an Invoice QR code to extract seller PAN,
     * invoice number, amount, date, and seller name.
     */
    fun parseInvoiceQr(rawText: String?): ParsedInvoiceQr {
        if (rawText.isNullOrBlank()) {
            return ParsedInvoiceQr(rawText = "", isRecognized = false)
        }

        val trimmed = rawText.trim()
        var pan: String? = null
        var invoiceNo: String? = null
        var amount: Double? = null
        var sellerName: String? = null
        var date: String? = null

        // Strategy A: JSON format
        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            try {
                val element = jsonParser.parseToJsonElement(trimmed)
                if (element is JsonObject) {
                    pan = findJsonString(element, "pan", "seller_pan", "sellerPan", "vat", "pan_vat", "seller_vat", "pan_no")
                    invoiceNo = findJsonString(element, "invoice_no", "invoiceNo", "invoice_number", "invoiceNumber", "bill_no", "billNo", "inv_no", "receipt_no")
                    sellerName = findJsonString(element, "seller_name", "sellerName", "seller", "merchant_name", "merchant", "vendor", "store_name")
                    date = findJsonString(element, "date", "invoice_date", "invoiceDate", "bill_date", "miti")

                    val amtVal = findJsonDouble(element, "amount", "total", "grand_total", "grandTotal", "total_amount", "totalAmount", "net_amount")
                    if (amtVal != null) amount = amtVal
                }
            } catch (_: Exception) {
                // Fall back to text parsing
            }
        }

        // Strategy B: URL with Query Parameters
        if (pan == null && (trimmed.startsWith("http://") || trimmed.startsWith("https://"))) {
            try {
                val uri = URI(trimmed)
                val query = uri.query
                if (!query.isNullOrBlank()) {
                    val params = parseQueryString(query)
                    pan = findParam(params, "pan", "sellerpan", "sellervat", "vat", "pan_no", "panno", "seller_pan")
                    invoiceNo = findParam(params, "inv", "invoice", "invoiceno", "bill", "billno", "receipt", "inv_no")
                    sellerName = findParam(params, "seller", "merchant", "vendor", "name", "seller_name")
                    date = findParam(params, "date", "dt", "miti", "invoicedate")
                    val amtStr = findParam(params, "amt", "amount", "total", "grandtotal", "net")
                    if (amtStr != null) {
                        amount = amtStr.toDoubleOrNull()
                    }
                }
            } catch (_: Exception) {
                // Ignore URL parsing error
            }
        }

        // Strategy C: Key-Value text matching (e.g. PAN: ..., INV: ..., AMT: ...)
        if (pan == null) {
            val panRegex = Regex("""(?i)(?:seller_?pan|seller_?vat|pan_?vat|pan_?no|vat_?no|pan|vat)[\s:=_-]*([0-9]{9})""")
            panRegex.find(trimmed)?.let {
                val p = it.groupValues[1]
                if (CouponUtils.isValidPanNumber(p)) pan = p
            }
        }

        if (invoiceNo == null) {
            val invRegex = Regex("""(?i)(?:invoice_?no|invoice_?number|inv_?no|bill_?no|receipt_?no|invoice|bill|receipt|chalani)[\s:=_-]*([A-Za-z0-9\-_/]+)""")
            invRegex.find(trimmed)?.let {
                val rawInv = it.groupValues[1].trim()
                if (rawInv.isNotEmpty() && rawInv.lowercase() !in listOf("no", "num", "number")) {
                    invoiceNo = rawInv
                }
            }
        }

        if (amount == null) {
            val amtRegex = Regex("""(?i)(?:grand_?total|total_?amount|net_?amount|amount|total|npr|rs|amt)[\s:=_-]*([0-9]+(?:\.[0-9]{1,2})?)""")
            amtRegex.find(trimmed)?.let {
                amount = it.groupValues[1].toDoubleOrNull()
            }
        }

        if (date == null) {
            val dateRegex = Regex("""(?i)(?:invoice_?date|bill_?date|miti|date|dt)[\s:=_-]*([0-9]{4}[-/][0-9]{1,2}[-/][0-9]{1,2})""")
            dateRegex.find(trimmed)?.let {
                date = it.groupValues[1]
            }
        }

        if (sellerName == null) {
            val sellerRegex = Regex("""(?i)(?:seller_?name|merchant_?name|vendor_?name|store_?name|seller|merchant|vendor)[\s:=_-]*([^\n,;|]+)""")
            sellerRegex.find(trimmed)?.let {
                val s = it.groupValues[1].trim()
                if (s.isNotEmpty()) sellerName = s
            }
        }

        // Strategy D: Delimited tokens (comma, semicolon, or pipe separated e.g. "301234567,INV-102,1500.00,2024-05-12,ABC Mart")
        if (pan == null && (trimmed.contains(",") || trimmed.contains("|") || trimmed.contains(";"))) {
            val delimiter = when {
                trimmed.contains("|") -> "|"
                trimmed.contains(";") -> ";"
                else -> ","
            }
            val tokens = trimmed.split(delimiter).map { it.trim() }.filter { it.isNotEmpty() }
            for (token in tokens) {
                val normToken = CouponUtils.normalizeCouponNumber(token)
                if (pan == null && normToken.length == 9 && CouponUtils.isValidPanNumber(normToken)) {
                    pan = normToken
                } else if (amount == null && token.toDoubleOrNull() != null && token.toDoubleOrNull()!! > 0) {
                    amount = token.toDoubleOrNull()
                } else if (date == null && Regex("""^[0-9]{4}[-/][0-9]{1,2}[-/][0-9]{1,2}$""").matches(token)) {
                    date = token
                } else if (invoiceNo == null && Regex("""^[A-Za-z0-9\-_/]{3,}$""").matches(token) && token.toDoubleOrNull() == null) {
                    invoiceNo = token
                } else if (sellerName == null && token.length > 2 && token.toDoubleOrNull() == null && !token.all { it.isDigit() }) {
                    sellerName = token
                }
            }
        }

        // Fallback for PAN: any 9-digit standalone number
        if (pan == null) {
            pan = extractVendorPan(trimmed)
        }

        val isRecognized = pan != null || invoiceNo != null || (amount != null && amount > 0.0)

        return ParsedInvoiceQr(
            sellerPan = pan,
            invoiceNumber = invoiceNo,
            amount = amount,
            sellerName = sellerName,
            date = date,
            rawText = trimmed,
            isRecognized = isRecognized
        )
    }

    private fun findJsonString(json: JsonObject, vararg keys: String): String? {
        for (k in keys) {
            val element = json[k]
            if (element != null) {
                val s = try { element.jsonPrimitive.content.trim() } catch (_: Exception) { "" }
                if (s.isNotEmpty() && s != "null") return s
            }
        }
        return null
    }

    private fun findJsonDouble(json: JsonObject, vararg keys: String): Double? {
        for (k in keys) {
            val element = json[k]
            if (element != null) {
                val parsed = try {
                    element.jsonPrimitive.content.toDoubleOrNull()
                } catch (_: Exception) {
                    null
                }
                if (parsed != null) return parsed
            }
        }
        return null
    }

    private fun parseQueryString(query: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        val pairs = query.split("&")
        for (pair in pairs) {
            val idx = pair.indexOf("=")
            if (idx > 0) {
                val key = pair.substring(0, idx).trim().lowercase()
                val value = pair.substring(idx + 1).trim()
                map[key] = value
            }
        }
        return map
    }

    private fun findParam(params: Map<String, String>, vararg keys: String): String? {
        for (k in keys) {
            val v = params[k.lowercase()]
            if (!v.isNullOrBlank()) return v
        }
        return null
    }
}
