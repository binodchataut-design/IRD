package com.example.utils

data class BillData(
    val sellerName: String = "",
    val pan: String = "",
    val invoiceNumber: String = "",
    val date: String = "",
    val amount: String = ""
)

object BillDataUtils {

    fun normalizeAmount(value: String): String {
        if (value.isBlank()) return ""
        var cleaned = value.lowercase()
        cleaned = cleaned.replace("rs.", "").replace("rs", "").replace("npr.", "").replace("npr", "")
        cleaned = cleaned.replace("रू", "").replace("रु", "").replace("।", "")
        cleaned = cleaned.replace(",", "").replace(" ", "")
        val match = Regex("\\d+(?:\\.\\d{1,2})?").find(cleaned)
        return match?.value ?: ""
    }

    fun normalizeDate(value: String): String {
        if (value.isBlank()) return ""
        val isoMatch = Regex("(\\d{4})-(\\d{2})-(\\d{2})").find(value)
        if (isoMatch != null) return isoMatch.value
        val slashMatch = Regex("(\\d{1,2})[/.](\\d{1,2})[/.](\\d{2,4})").find(value)
        if (slashMatch != null) {
            val (d, m, y) = slashMatch.destructured
            val year = if (y.length == 2) "20$y" else y
            val mm = m.padStart(2, '0')
            val dd = d.padStart(2, '0')
            return "$year-$mm-$dd"
        }
        return ""
    }

    fun normalizePan(value: String): String {
        return value.filter { it.isDigit() }
    }

    fun normalizeBillData(data: BillData): BillData {
        return BillData(
            sellerName = data.sellerName.trim(),
            pan = normalizePan(data.pan),
            invoiceNumber = data.invoiceNumber.trim(),
            date = normalizeDate(data.date),
            amount = normalizeAmount(data.amount)
        )
    }

    fun isFieldConflict(current: String, candidate: String): Boolean {
        val c = current.trim()
        val cand = candidate.trim()
        return c.isNotEmpty() && cand.isNotEmpty() && !c.equals(cand, ignoreCase = true)
    }

    fun hasAnyConflict(current: BillData, candidate: BillData): Boolean {
        return isFieldConflict(current.sellerName, candidate.sellerName) ||
                isFieldConflict(current.pan, candidate.pan) ||
                isFieldConflict(current.invoiceNumber, candidate.invoiceNumber) ||
                isFieldConflict(current.date, candidate.date) ||
                isFieldConflict(current.amount, candidate.amount)
    }

    /**
     * Extracts best-effort structured BillData fields from raw OCR recognized text.
     */
    fun extractFromText(rawText: String): BillData {
        if (rawText.isBlank()) return BillData()

        val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
        var pan = ""
        var invoiceNo = ""
        var date = ""
        var amount = ""
        var sellerName = ""

        // 1. Find 9-digit PAN/VAT
        val panRegexWithLabel = Regex("""(?:PAN|VAT|प्यान|भ्याट)\s*[:#.-]?\s*([0-9]{9})""", RegexOption.IGNORE_CASE)
        val standalonePanRegex = Regex("""\b([1-9][0-9]{8})\b""")

        val panMatchLabeled = panRegexWithLabel.find(rawText)
        if (panMatchLabeled != null) {
            pan = panMatchLabeled.groupValues[1]
        } else {
            for (line in lines) {
                if (line.contains("PAN", ignoreCase = true) || line.contains("VAT", ignoreCase = true) || line.contains("प्यान")) {
                    val digits = line.filter { it.isDigit() }
                    if (digits.length == 9) {
                        pan = digits
                        break
                    }
                }
            }
            if (pan.isEmpty()) {
                val panMatch = standalonePanRegex.find(rawText)
                if (panMatch != null) {
                    pan = panMatch.groupValues[1]
                }
            }
        }

        // 2. Find Invoice / Bill Number
        val invLineRegex = Regex("""(?:Invoice|Bill|Inv|Receipt|चलानी|बिल)\s*(?:No|#|Num|Number|नं)?\s*[:.#-]\s*([A-Za-z0-9_\-/]+)""", RegexOption.IGNORE_CASE)
        val fallbackInvRegex = Regex("""(?:Invoice|Bill|Inv|Receipt|चलानी|बिल)\s+(?:No|#|Num|Number|नं)\s+([A-Za-z0-9_\-/]+)""", RegexOption.IGNORE_CASE)
        val invalidTokens = setOf("tax", "invoice", "vat", "bill", "date", "cash", "memo", "receipt", "original", "copy", "total", "no", "num", "number")
        for (line in lines) {
            val match = invLineRegex.find(line) ?: fallbackInvRegex.find(line)
            if (match != null) {
                val candidate = match.groupValues[1].trim()
                if (candidate.isNotEmpty() && candidate.lowercase() !in invalidTokens && (candidate.any { it.isDigit() } || candidate.length >= 3)) {
                    invoiceNo = candidate
                    break
                }
            }
        }

        // 3. Find Date (ISO YYYY-MM-DD or DD/MM/YYYY or YYYY/MM/DD)
        val dateLabelRegex = Regex("""(?:Date|Miti|मिति|Bill\s*Date|Invoice\s*Date)\s*[:.#-]?\s*(\d{2,4}[-/. ]\d{1,2}[-/. ]\d{2,4})""", RegexOption.IGNORE_CASE)
        val dateLabelMatch = dateLabelRegex.find(rawText)
        if (dateLabelMatch != null) {
            date = dateLabelMatch.groupValues[1].trim()
        } else {
            val generalDateRegex = Regex("""\b(20[2-9][0-9][-/.][0-1]?[0-9][-/.][0-3]?[0-9])\b|\b([0-3]?[0-9][-/.][0-1]?[0-9][-/.](?:20)?[2-9][0-9])\b""")
            val generalMatch = generalDateRegex.find(rawText)
            if (generalMatch != null) {
                date = generalMatch.value
            }
        }

        // 4. Find Amount (Grand Total, Total, Net Payable, etc.)
        val amountRegexes = listOf(
            Regex("""(?:Grand\s*Total|Net\s*Total|Net\s*Payable|Total\s*Amount|Total|कुल\s*रकम|जम्मा|Net\s*Amt)\s*[:=]?\s*(?:NPR|Rs\.?|रु\.?)?\s*([0-9,]+(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE),
            Regex("""(?:NPR|Rs\.?|रु\.?)\s*([0-9,]+(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
        )
        for (rgx in amountRegexes) {
            val match = rgx.find(rawText)
            if (match != null) {
                val candidateAmt = match.groupValues[1].replace(",", "").trim()
                if (candidateAmt.toDoubleOrNull() != null && (candidateAmt.toDoubleOrNull() ?: 0.0) > 0) {
                    amount = candidateAmt
                    break
                }
            }
        }

        // 5. Candidate Seller Name (First prominent non-boilerplate line near top)
        val boilerplateWords = setOf(
            "tax invoice", "vat invoice", "abbreviated tax invoice", "cash receipt",
            "invoice", "bill", "estimate", "pan", "vat", "phone", "tel", "welcome",
            "cash memo", "receipt", "original", "customer copy", "duplicate",
            "कर बिजक", "मूल्य अभिवृद्धि कर", "रसिद", "प्यान"
        )
        for (line in lines.take(6)) {
            val lower = line.lowercase().trim()
            val isBoilerplate = boilerplateWords.any { lower == it || lower.startsWith("$it:") || (lower.startsWith("$it ") && lower.length < 25) }
            val isDigitsOnly = line.filter { it.isLetterOrDigit() }.all { it.isDigit() }
            val isDateOrPan = lower.contains("date") || lower.contains("pan:") || lower.contains("vat:") || lower.contains("tel:")
            if (!isBoilerplate && !isDigitsOnly && !isDateOrPan && line.length >= 3) {
                sellerName = line.trim()
                break
            }
        }

        val rawData = BillData(
            sellerName = sellerName,
            pan = pan,
            invoiceNumber = invoiceNo,
            date = date,
            amount = amount
        )

        return normalizeBillData(rawData)
    }
}
