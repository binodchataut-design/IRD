package com.example.utils

import com.example.model.Coupon
import com.example.model.EligibilityStatus
import com.example.model.PaymentMethod
import com.example.model.Transaction
import java.util.UUID

object SampleData {

    fun generateId(): String {
        return UUID.randomUUID().toString().take(12)
    }

    fun getSampleTransactions(): List<Transaction> {
        return listOf(
            Transaction(
                id = "sample-tx-1",
                date = "2026-08-15",
                sellerName = "Bhatbhateni Supermarket",
                amount = 2500.0,
                paymentMethod = PaymentMethod.QR_PAYMENT,
                panVat = "601928374",
                invoiceNumber = "INV-2083-001",
                couponNumber = "007315254493",
                eligibilityStatus = EligibilityStatus.COUPON_ADDED,
                notes = "Monthly groceries",
                photoReference = null,
                createdAt = "2026-08-15T10:00:00Z"
            ),
            Transaction(
                id = "sample-tx-2",
                date = "2026-08-10",
                sellerName = "Daraz Nepal",
                amount = 1500.0,
                paymentMethod = PaymentMethod.DIGITAL_WALLET,
                panVat = "602345671",
                invoiceNumber = "INV-2083-002",
                couponNumber = "007315254494",
                eligibilityStatus = EligibilityStatus.COUPON_ADDED,
                notes = "Online order - kitchen items",
                photoReference = null,
                createdAt = "2026-08-10T14:30:00Z"
            ),
            Transaction(
                id = "sample-tx-3",
                date = "2026-08-05",
                sellerName = "Kathmandu Mall",
                amount = 800.0,
                paymentMethod = PaymentMethod.CARD,
                panVat = "603456782",
                invoiceNumber = "INV-2083-003",
                couponNumber = null,
                eligibilityStatus = EligibilityStatus.AWAITING_COUPON,
                notes = "Clothing purchase - awaiting coupon from seller",
                photoReference = null,
                createdAt = "2026-08-05T16:00:00Z"
            ),
            Transaction(
                id = "sample-tx-4",
                date = "2026-07-28",
                sellerName = "Local Tea Shop",
                amount = 50.0,
                paymentMethod = PaymentMethod.CASH,
                panVat = null,
                invoiceNumber = null,
                couponNumber = null,
                eligibilityStatus = EligibilityStatus.LIKELY_NOT_ELIGIBLE,
                notes = "Cash payment, below minimum amount",
                photoReference = null,
                createdAt = "2026-07-28T09:00:00Z"
            )
        )
    }

    fun getSampleCoupons(): List<Coupon> {
        return listOf(
            Coupon(
                id = "sample-cp-1",
                couponNumber = "007315254493",
                date = "2026-08-15",
                drawPeriod = "Bhadra 1–15, 2083",
                merchantName = "Bhatbhateni Supermarket",
                amount = 2500.0,
                paymentMethod = "QR Payment",
                invoiceNumber = "INV-2083-001",
                notes = null,
                createdAt = "2026-08-15T10:05:00Z"
            ),
            Coupon(
                id = "sample-cp-2",
                couponNumber = "007315254494",
                date = "2026-08-10",
                drawPeriod = "Bhadra 1–15, 2083",
                merchantName = "Daraz Nepal",
                amount = 1500.0,
                paymentMethod = "Digital Wallet",
                invoiceNumber = "INV-2083-002",
                notes = null,
                createdAt = "2026-08-10T14:35:00Z"
            ),
            Coupon(
                id = "sample-cp-3",
                couponNumber = "007315254495",
                date = "2026-08-02",
                drawPeriod = "Shrawan 16–30, 2083",
                merchantName = "Online Store",
                amount = 3200.0,
                paymentMethod = "Mobile Banking",
                invoiceNumber = "INV-2083-004",
                notes = null,
                createdAt = "2026-08-02T11:00:00Z"
            )
        )
    }
}
