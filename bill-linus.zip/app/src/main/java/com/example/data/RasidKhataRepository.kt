package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppLanguage
import com.example.model.Coupon
import com.example.model.DarkModePreference
import com.example.model.DrawAnnouncement
import com.example.model.FontScalePreference
import com.example.model.ManualResultCheck
import com.example.model.Transaction
import com.example.utils.SampleData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class RasidKhataRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("rasid_khata_prefs", Context.MODE_PRIVATE)

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = true
        encodeDefaults = true
    }

    private val _language = MutableStateFlow(loadLanguage())
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _darkMode = MutableStateFlow(loadDarkMode())
    val darkMode: StateFlow<DarkModePreference> = _darkMode.asStateFlow()

    private val _fontScale = MutableStateFlow(loadFontScale())
    val fontScale: StateFlow<FontScalePreference> = _fontScale.asStateFlow()

    private val _hasCompletedWelcome = MutableStateFlow(loadWelcomeCompleted())
    val hasCompletedWelcome: StateFlow<Boolean> = _hasCompletedWelcome.asStateFlow()

    private val _transactions = MutableStateFlow(loadTransactions())
    val transactions: StateFlow<List<Transaction>> = _transactions.asStateFlow()

    private val _coupons = MutableStateFlow(loadCoupons())
    val coupons: StateFlow<List<Coupon>> = _coupons.asStateFlow()

    private val _draws = MutableStateFlow(loadDraws())
    val draws: StateFlow<List<DrawAnnouncement>> = _draws.asStateFlow()

    private val _resultChecks = MutableStateFlow(loadResultChecks())
    val resultChecks: StateFlow<List<ManualResultCheck>> = _resultChecks.asStateFlow()

    private fun loadWelcomeCompleted(): Boolean {
        return prefs.getBoolean("has_completed_welcome", false)
    }

    fun completeWelcome() {
        prefs.edit().putBoolean("has_completed_welcome", true).apply()
        _hasCompletedWelcome.value = true
    }

    private fun loadLanguage(): AppLanguage {
        val saved = prefs.getString("app_language", "EN") ?: "EN"
        return try {
            AppLanguage.valueOf(saved)
        } catch (e: Exception) {
            AppLanguage.EN
        }
    }

    fun setLanguage(lang: AppLanguage) {
        prefs.edit().putString("app_language", lang.name).apply()
        _language.value = lang
    }

    fun toggleLanguage() {
        val next = if (_language.value == AppLanguage.EN) AppLanguage.NE else AppLanguage.EN
        setLanguage(next)
    }

    private fun loadDarkMode(): DarkModePreference {
        val saved = prefs.getString("dark_mode_pref", "SYSTEM") ?: "SYSTEM"
        return try {
            DarkModePreference.valueOf(saved)
        } catch (e: Exception) {
            DarkModePreference.SYSTEM
        }
    }

    fun setDarkMode(mode: DarkModePreference) {
        prefs.edit().putString("dark_mode_pref", mode.name).apply()
        _darkMode.value = mode
    }

    private fun loadFontScale(): FontScalePreference {
        val saved = prefs.getString("font_scale_pref", "MEDIUM") ?: "MEDIUM"
        return try {
            FontScalePreference.valueOf(saved)
        } catch (e: Exception) {
            FontScalePreference.MEDIUM
        }
    }

    fun setFontScale(scale: FontScalePreference) {
        prefs.edit().putString("font_scale_pref", scale.name).apply()
        _fontScale.value = scale
    }

    private fun loadTransactions(): List<Transaction> {
        val str = prefs.getString("transactions_json", null)
        if (str.isNullOrBlank()) {
            return emptyList()
        }
        return try {
            json.decodeFromString<List<Transaction>>(str)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveTransactions(list: List<Transaction>) {
        try {
            val str = json.encodeToString(list)
            prefs.edit().putString("transactions_json", str).apply()
            _transactions.value = list
        } catch (e: Exception) {
            // ignore
        }
    }

    fun addTransaction(tx: Transaction) {
        val current = _transactions.value.toMutableList()
        current.add(0, tx)
        saveTransactions(current)
    }

    fun updateTransaction(tx: Transaction) {
        val current = _transactions.value.toMutableList()
        val index = current.indexOfFirst { it.id == tx.id }
        if (index != -1) {
            current[index] = tx
        } else {
            current.add(0, tx)
        }
        saveTransactions(current)
    }

    fun deleteTransaction(id: String) {
        val current = _transactions.value.filter { it.id != id }
        saveTransactions(current)
    }

    fun getTransaction(id: String): Transaction? {
        return _transactions.value.find { it.id == id }
    }

    private fun loadCoupons(): List<Coupon> {
        val str = prefs.getString("coupons_json", null)
        if (str.isNullOrBlank()) {
            return emptyList()
        }
        return try {
            json.decodeFromString<List<Coupon>>(str)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveCoupons(list: List<Coupon>) {
        try {
            val str = json.encodeToString(list)
            prefs.edit().putString("coupons_json", str).apply()
            _coupons.value = list
        } catch (e: Exception) {
            // ignore
        }
    }

    fun addCoupon(coupon: Coupon) {
        val current = _coupons.value.toMutableList()
        current.add(0, coupon)
        saveCoupons(current)
    }

    fun updateCoupon(coupon: Coupon) {
        val current = _coupons.value.toMutableList()
        val index = current.indexOfFirst { it.id == coupon.id }
        if (index != -1) {
            current[index] = coupon
        } else {
            current.add(0, coupon)
        }
        saveCoupons(current)
    }

    fun addBulkCoupons(newCoupons: List<Coupon>) {
        val current = _coupons.value.toMutableList()
        current.addAll(0, newCoupons)
        saveCoupons(current)
    }

    fun deleteCoupon(id: String) {
        val current = _coupons.value.filter { it.id != id }
        saveCoupons(current)
    }

    private fun loadDraws(): List<DrawAnnouncement> {
        val str = prefs.getString("draws_json", null) ?: return emptyList()
        return try {
            json.decodeFromString<List<DrawAnnouncement>>(str)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun loadResultChecks(): List<ManualResultCheck> {
        val str = prefs.getString("result_checks_json", null) ?: return emptyList()
        return try {
            json.decodeFromString<List<ManualResultCheck>>(str)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveResultChecks(list: List<ManualResultCheck>) {
        try {
            val str = json.encodeToString(list)
            prefs.edit().putString("result_checks_json", str).apply()
            _resultChecks.value = list
        } catch (e: Exception) {
            // ignore
        }
    }

    fun addResultCheck(check: ManualResultCheck) {
        val current = _resultChecks.value.toMutableList()
        current.removeAll {
            it.drawTitle == check.drawTitle &&
                    it.enteredResults == check.enteredResults
        }
        current.add(0, check)
        val trimmed = current.take(50)
        saveResultChecks(trimmed)
    }

    fun updateResultCheckWonAmount(checkId: String, wonAmount: Double?) {
        val current = _resultChecks.value.toMutableList()
        val index = current.indexOfFirst { it.id == checkId }
        if (index != -1) {
            current[index] = current[index].copy(wonAmount = wonAmount)
            saveResultChecks(current)
        }
    }

    fun clearResultChecks() {
        prefs.edit().remove("result_checks_json").apply()
        _resultChecks.value = emptyList()
    }

    fun exportJson(): String {
        return json.encodeToString(
            mapOf(
                "transactions" to json.encodeToString(_transactions.value),
                "coupons" to json.encodeToString(_coupons.value),
                "draws" to json.encodeToString(_draws.value)
            )
        )
    }

    fun importJson(raw: String): Boolean {
        return try {
            val map = json.decodeFromString<Map<String, String>>(raw)
            val txStr = map["transactions"]
            val cpStr = map["coupons"]
            if (txStr != null) {
                val txs = json.decodeFromString<List<Transaction>>(txStr)
                saveTransactions(txs)
            }
            if (cpStr != null) {
                val cps = json.decodeFromString<List<Coupon>>(cpStr)
                saveCoupons(cps)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun clearAllData() {
        saveTransactions(emptyList())
        saveCoupons(emptyList())
        clearResultChecks()
    }

    fun loadSampleData() {
        val sampleTxs = SampleData.getSampleTransactions()
        val sampleCps = SampleData.getSampleCoupons()
        saveTransactions(sampleTxs)
        saveCoupons(sampleCps)
    }
}
