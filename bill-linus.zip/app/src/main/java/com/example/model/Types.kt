package com.example.model

import kotlinx.serialization.Serializable

@Serializable
enum class AppLanguage {
    EN, NE
}

@Serializable
enum class PaymentMethod {
    DIGITAL_WALLET,
    QR_PAYMENT,
    MOBILE_BANKING,
    CARD,
    CASH,
    BANK_TRANSFER,
    OTHER
}

@Serializable
enum class EligibilityStatus {
    COUPON_ADDED,
    AWAITING_COUPON,
    LIKELY_ELIGIBLE,
    NEEDS_VERIFICATION,
    LIKELY_NOT_ELIGIBLE,
    NOT_CHECKED
}

@Serializable
enum class PurchasePurpose {
    PERSONAL,
    BUSINESS,
    GOVERNMENT,
    UNKNOWN
}

@Serializable
enum class SellerPanOption {
    YES,
    NO,
    DONT_KNOW
}

@Serializable
enum class TransactionCategory {
    NORMAL_GOODS,
    FOOD_RESTAURANT,
    ELECTRONICS,
    CLOTHING,
    ELECTRICITY,
    TELEPHONE_INTERNET,
    AIRLINE,
    TRANSPORT_FREIGHT,
    VEHICLE,
    OTHER,
    DONT_KNOW
}

@Serializable
data class Transaction(
    val id: String,
    val date: String,
    val sellerName: String,
    val amount: Double,
    val paymentMethod: PaymentMethod,
    val panVat: String? = null,
    val invoiceNumber: String? = null,
    val couponNumber: String? = null,
    val eligibilityStatus: EligibilityStatus,
    val notes: String? = null,
    val photoReference: String? = null,
    val createdAt: String,
    val category: TransactionCategory = TransactionCategory.NORMAL_GOODS,
    val hasWarranty: Boolean = false,
    val warrantyMonths: Int? = null
)

@Serializable
data class Coupon(
    val id: String,
    val couponNumber: String,
    val date: String? = null,
    val drawPeriod: String? = null,
    val merchantName: String? = null,
    val amount: Double? = null,
    val paymentMethod: String? = null,
    val invoiceNumber: String? = null,
    val notes: String? = null,
    val createdAt: String
)

@Serializable
data class DrawAnnouncement(
    val id: String,
    val title: String,
    val drawPeriod: String,
    val announcementDate: String,
    val winningNumbers: List<String>,
    val sourceUrl: String,
    val sourceName: String,
    val notes: String? = null,
    val createdAt: String
)

@Serializable
data class ClaimReportData(
    val coupon: Coupon,
    val transaction: Transaction? = null,
    val drawTitle: String? = null,
    val drawPeriod: String? = null,
    val announcementDate: String? = null
)

@Serializable
data class EligibilityPrefillData(
    val amount: Double,
    val paymentMethod: PaymentMethod,
    val panVat: String? = null,
    val sellerName: String,
    val invoiceNumber: String? = null,
    val date: String? = null,
    val photoReference: String? = null
)

@Serializable
data class CouponPrefillData(
    val merchantName: String? = null,
    val drawPeriod: String? = null,
    val invoiceNumber: String? = null,
    val amount: Double? = null
)

data class BulkParseResult(
    val totalExtracted: Int,
    val validNew: List<String>,
    val duplicateInBatch: List<String>,
    val alreadySaved: List<String>,
    val invalidTokens: List<String>
)

@Serializable
enum class DarkModePreference {
    SYSTEM,
    LIGHT,
    DARK
}

@Serializable
enum class FontScalePreference(val factor: Float) {
    SMALL(0.85f),
    MEDIUM(1.0f),
    LARGE(1.15f)
}

@Serializable
data class ManualResultCheck(
    val id: String,
    val drawTitle: String? = null,
    val drawPeriod: String? = null,
    val enteredResults: List<String>,
    val matchedCouponNumbers: List<String>,
    val matched: Boolean,
    val checkedAt: String,
    val source: String = "USER_ENTERED",
    val wonAmount: Double? = null
)

enum class ScreenName {
    WELCOME,
    HOME,
    INVOICES,
    ADD_INVOICE,
    INVOICE_DETAIL,
    COUPONS,
    ADD_COUPON,
    BULK_ADD_COUPONS,
    WINNER_CHECKER,
    CLAIM_REPORT,
    CHECK_ELIGIBILITY,
    VERIFY_VENDOR,
    IRD_INFO,
    DATA_BACKUP,
    SCAN,
    EXPENSES,
    PROFILE
}
