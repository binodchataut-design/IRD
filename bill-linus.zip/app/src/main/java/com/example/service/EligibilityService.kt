package com.example.service

import com.example.model.EligibilityStatus
import com.example.model.PaymentMethod
import com.example.model.PurchasePurpose
import com.example.model.SellerPanOption
import com.example.model.TransactionCategory
import com.example.utils.CouponUtils

data class TransactionEligibilityInput(
    val amount: Double,
    val paymentMethod: PaymentMethod,
    val purpose: PurchasePurpose = PurchasePurpose.PERSONAL,
    val sellerPan: SellerPanOption = SellerPanOption.YES,
    val sellerPanNumber: String? = null,
    val sellerName: String = "",
    val category: TransactionCategory = TransactionCategory.NORMAL_GOODS,
    val date: String = "",
    val invoiceNumber: String? = null
)

data class EligibilityReason(
    val key: String,
    val params: Map<String, String> = emptyMap()
)

data class EligibilityResult(
    val status: EligibilityStatus,
    val reasons: List<EligibilityReason>,
    val confidence: String
)

object EligibilityService {

    const val MIN_AMOUNT = 100.0

    private val DIGITAL_METHODS = listOf(
        PaymentMethod.DIGITAL_WALLET,
        PaymentMethod.QR_PAYMENT,
        PaymentMethod.MOBILE_BANKING,
        PaymentMethod.CARD,
        PaymentMethod.BANK_TRANSFER
    )

    private val EXEMPT_CATEGORIES = listOf(
        TransactionCategory.ELECTRICITY,
        TransactionCategory.TELEPHONE_INTERNET,
        TransactionCategory.AIRLINE,
        TransactionCategory.TRANSPORT_FREIGHT,
        TransactionCategory.VEHICLE
    )

    fun checkEligibility(input: TransactionEligibilityInput): EligibilityResult {
        val reasons = mutableListOf<EligibilityReason>()
        var likelyEligible = true

        if (input.amount < MIN_AMOUNT) {
            reasons.add(
                EligibilityReason(
                    key = "eligibility.reason_min_amount",
                    params = mapOf("minAmount" to MIN_AMOUNT.toInt().toString(), "currentAmount" to input.amount.toInt().toString())
                )
            )
            likelyEligible = false
        }

        if (input.purpose == PurchasePurpose.BUSINESS || input.purpose == PurchasePurpose.GOVERNMENT) {
            reasons.add(EligibilityReason(key = "eligibility.reason_business_gov"))
            likelyEligible = false
        }

        if (input.paymentMethod == PaymentMethod.CASH) {
            reasons.add(EligibilityReason(key = "eligibility.reason_cash"))
        } else if (input.paymentMethod == PaymentMethod.OTHER) {
            reasons.add(EligibilityReason(key = "eligibility.reason_other_payment"))
            likelyEligible = false
        } else if (!DIGITAL_METHODS.contains(input.paymentMethod)) {
            reasons.add(EligibilityReason(key = "eligibility.reason_non_digital"))
            likelyEligible = false
        }

        if (EXEMPT_CATEGORIES.contains(input.category)) {
            reasons.add(EligibilityReason(key = "eligibility.reason_exempt_category"))
            likelyEligible = false
        }

        if (input.sellerPan == SellerPanOption.NO) {
            reasons.add(EligibilityReason(key = "eligibility.reason_no_pan"))
            likelyEligible = false
        } else if (input.sellerPan == SellerPanOption.DONT_KNOW) {
            reasons.add(EligibilityReason(key = "eligibility.reason_pan_unknown"))
        }

        if (input.sellerPan == SellerPanOption.YES && !input.sellerPanNumber.isNullOrBlank()) {
            val panDigits = CouponUtils.normalizeCouponNumber(input.sellerPanNumber)
            if (panDigits.length != 9) {
                reasons.add(
                    EligibilityReason(
                        key = "eligibility.reason_pan_digits",
                        params = mapOf("currentDigits" to panDigits.length.toString())
                    )
                )
            }
        }

        val status: EligibilityStatus
        val confidence: String

        if (likelyEligible && input.sellerPan == SellerPanOption.YES) {
            status = EligibilityStatus.LIKELY_ELIGIBLE
            confidence = "HIGH"
            if (reasons.isEmpty()) {
                reasons.add(EligibilityReason(key = "eligibility.reason_all_met"))
            }
        } else if (likelyEligible && input.sellerPan == SellerPanOption.DONT_KNOW) {
            status = EligibilityStatus.NEEDS_VERIFICATION
            confidence = "MEDIUM"
            reasons.add(0, EligibilityReason(key = "eligibility.reason_verify_pan"))
        } else {
            status = EligibilityStatus.LIKELY_NOT_ELIGIBLE
            confidence = "HIGH"
        }

        return EligibilityResult(status, reasons, confidence)
    }
}
