package com.example.service

object DrawResultService {
    const val IRD_PRIZE_PORTAL_URL = "https://prize.ird.gov.np/"
    const val IRD_MAIN_URL = "https://ird.gov.np"
    const val IRD_PAN_SEARCH_URL = "https://ird.gov.np/pan-search"

    fun isAutomaticResultCheckingAvailable(): Boolean {
        return false
    }
}
