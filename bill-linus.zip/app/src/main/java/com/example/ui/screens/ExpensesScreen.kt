package com.example.ui.screens

import android.graphics.BitmapFactory
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.Transaction
import com.example.model.TransactionCategory
import com.example.ui.MainViewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatCard
import com.example.ui.theme.Amber100
import com.example.ui.theme.Amber600
import com.example.ui.theme.BrandGreenDark
import com.example.ui.theme.BrandGreenLight
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Indigo100
import com.example.ui.theme.Indigo600
import com.example.ui.theme.Red100
import com.example.ui.theme.Red600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate700
import com.example.utils.NepaliDateUtils
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.time.temporal.WeekFields
import java.util.Locale

@Composable
fun ExpensesScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var selectedCategoryFilter by remember { mutableStateOf<TransactionCategory?>(null) }
    var showPhotoDialogTx by remember { mutableStateOf<Transaction?>(null) }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("expenses.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = currentScreen,
                lang = lang,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Three-section Tabs
            val tabs = listOf(
                Pair(AppStrings.get("expenses.tab_categories", lang), Icons.Default.PieChart),
                Pair(AppStrings.get("expenses.tab_digest", lang), Icons.Default.DateRange),
                Pair(AppStrings.get("expenses.tab_warranty", lang), Icons.Default.VerifiedUser)
            )

            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    indicator = { tabPositions ->
                        if (selectedTabIndex < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                ) {
                    tabs.forEachIndexed { index, (label, icon) ->
                        val selected = selectedTabIndex == index
                        Tab(
                            selected = selected,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selected) MaterialTheme.colorScheme.primary else Slate400
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            },
                            modifier = Modifier.testTag("tab_expenses_${index}")
                        )
                    }
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> CategorySpendingView(
                    transactions = transactions,
                    lang = lang,
                    selectedFilter = selectedCategoryFilter,
                    onSelectFilter = { selectedCategoryFilter = it },
                    onInvoiceClick = { viewModel.selectInvoice(it) },
                    onAddInvoiceClick = { viewModel.openAddInvoice() }
                )
                1 -> SpendDigestView(
                    transactions = transactions,
                    lang = lang,
                    onInvoiceClick = { viewModel.selectInvoice(it) },
                    onAddInvoiceClick = { viewModel.openAddInvoice() }
                )
                2 -> WarrantyTrackerView(
                    transactions = transactions,
                    lang = lang,
                    onInvoiceClick = { viewModel.selectInvoice(it) },
                    onViewPhotoClick = { showPhotoDialogTx = it },
                    onAddInvoiceClick = { viewModel.openAddInvoice() }
                )
            }
        }
    }

    // Receipt Photo Dialog
    showPhotoDialogTx?.let { tx ->
        ReceiptPhotoDialog(
            transaction = tx,
            lang = lang,
            onDismiss = { showPhotoDialogTx = null },
            onOpenDetails = {
                showPhotoDialogTx = null
                viewModel.selectInvoice(tx.id)
            }
        )
    }
}

// ---------------------------------------------------------------------------
// TAB 1: CATEGORY-WISE SPENDING VIEW
// ---------------------------------------------------------------------------
data class CategorySpendItem(
    val category: TransactionCategory,
    val totalAmount: Double,
    val count: Int,
    val percentage: Float
)

@Composable
fun CategorySpendingView(
    transactions: List<Transaction>,
    lang: AppLanguage,
    selectedFilter: TransactionCategory?,
    onSelectFilter: (TransactionCategory?) -> Unit,
    onInvoiceClick: (String) -> Unit,
    onAddInvoiceClick: () -> Unit
) {
    if (transactions.isEmpty()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                EmptyStateView(
                    title = AppStrings.get("expenses.empty_categories_title", lang),
                    description = AppStrings.get("expenses.empty_categories_desc", lang),
                    actionText = AppStrings.get("home.add_invoice", lang),
                    onActionClick = onAddInvoiceClick,
                    icon = Icons.Default.Category
                )
            }
        }
        return
    }

    val totalSpent = remember(transactions) { transactions.sumOf { it.amount } }

    val categoryList = remember(transactions, totalSpent) {
        val grouped = transactions.groupBy { it.category }
        grouped.map { (cat, list) ->
            val catTotal = list.sumOf { it.amount }
            val pct = if (totalSpent > 0) (catTotal / totalSpent * 100).toFloat() else 0f
            CategorySpendItem(
                category = cat,
                totalAmount = catTotal,
                count = list.size,
                percentage = pct
            )
        }.sortedByDescending { it.totalAmount }
    }

    val topCategory = categoryList.firstOrNull()

    val filteredTransactions = remember(transactions, selectedFilter) {
        if (selectedFilter == null) {
            transactions.take(10)
        } else {
            transactions.filter { it.category == selectedFilter }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("expenses_category_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Summary Stat Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = AppStrings.get("expenses.total_spending", lang),
                    value = "NPR ${totalSpent.toInt()}",
                    icon = Icons.Default.Paid,
                    iconBgColor = Emerald100,
                    iconTint = Emerald600,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = AppStrings.get("expenses.top_category", lang),
                    value = topCategory?.let { AppStrings.getCategoryLabel(it.category, lang) } ?: "—",
                    icon = Icons.Default.PieChart,
                    iconBgColor = Indigo100,
                    iconTint = Indigo600,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Category Breakdown Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AppStrings.get("expenses.category_breakdown", lang),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                )
                if (selectedFilter != null) {
                    TextButton(onClick = { onSelectFilter(null) }) {
                        Text(
                            text = AppStrings.get("expenses.clear_filter", lang),
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // List of Category Progress Bars
        items(categoryList) { item ->
            val isSelected = selectedFilter == item.category
            CategoryCardBarItem(
                item = item,
                lang = lang,
                isSelected = isSelected,
                onClick = {
                    if (isSelected) onSelectFilter(null) else onSelectFilter(item.category)
                }
            )
        }

        // Transaction Header for Filtered or Recent
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (selectedFilter != null) {
                        "${AppStrings.get("expenses.showing_category", lang)} ${AppStrings.getCategoryLabel(selectedFilter, lang)}"
                    } else {
                        AppStrings.get("home.recent_invoices", lang)
                    },
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                )
                Text(
                    text = "${filteredTransactions.size} ${if (lang == AppLanguage.NE) "कारोबार" else "items"}",
                    style = MaterialTheme.typography.labelSmall.copy(color = Slate500)
                )
            }
        }

        // Invoices list
        items(filteredTransactions) { tx ->
            InvoiceCardItem(
                transaction = tx,
                lang = lang,
                onClick = { onInvoiceClick(tx.id) }
            )
        }
    }
}

@Composable
fun CategoryCardBarItem(
    item: CategorySpendItem,
    lang: AppLanguage,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val categoryLabel = AppStrings.getCategoryLabel(item.category, lang)
    val icon = getCategoryIcon(item.category)
    val categoryColor = getCategoryColor(item.category)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
        ),
        border = if (isSelected) {
            BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
        } else {
            CardDefaults.outlinedCardBorder()
        },
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("category_card_${item.category.name.lowercase()}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(categoryColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = categoryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = categoryLabel,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${item.count} ${if (lang == AppLanguage.NE) "बिल" else "bills"}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Slate500,
                            fontSize = 11.sp
                        )
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "NPR ${item.totalAmount.toInt()}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    )
                    Text(
                        text = String.format(Locale.US, "%.1f%%", item.percentage),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Slate600,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            // Custom horizontal progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(100.dp))
                    .background(Slate100)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction = (item.percentage / 100f).coerceIn(0.02f, 1f))
                        .clip(RoundedCornerShape(100.dp))
                        .background(categoryColor)
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// TAB 2: SPEND DIGEST VIEW (Monthly / Weekly breakdown & period-over-period)
// ---------------------------------------------------------------------------
data class PeriodDigestItem(
    val periodId: String,
    val periodTitle: String,
    val subtitle: String,
    val totalAmount: Double,
    val count: Int,
    val percentChangeVsPrev: Double?,
    val isIncrease: Boolean,
    val transactions: List<Transaction>
)

@Composable
fun SpendDigestView(
    transactions: List<Transaction>,
    lang: AppLanguage,
    onInvoiceClick: (String) -> Unit,
    onAddInvoiceClick: () -> Unit
) {
    if (transactions.isEmpty()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                EmptyStateView(
                    title = AppStrings.get("expenses.empty_digest_title", lang),
                    description = AppStrings.get("expenses.empty_digest_desc", lang),
                    actionText = AppStrings.get("home.add_invoice", lang),
                    onActionClick = onAddInvoiceClick,
                    icon = Icons.Default.DateRange
                )
            }
        }
        return
    }

    var isMonthlyMode by remember { mutableStateOf(true) }
    var expandedPeriodId by remember { mutableStateOf<String?>(null) }

    val digests = remember(transactions, isMonthlyMode, lang) {
        if (isMonthlyMode) {
            buildMonthlyDigests(transactions, lang)
        } else {
            buildWeeklyDigests(transactions, lang)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("expenses_digest_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Toggle Monthly / Weekly selector
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Slate100,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isMonthlyMode) MaterialTheme.colorScheme.surface else Color.Transparent,
                        shadowElevation = if (isMonthlyMode) 2.dp else 0.dp,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { isMonthlyMode = true }
                            .testTag("toggle_digest_monthly")
                    ) {
                        Text(
                            text = AppStrings.get("expenses.view_monthly", lang),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isMonthlyMode) FontWeight.Bold else FontWeight.Normal,
                                color = if (isMonthlyMode) MaterialTheme.colorScheme.onSurface else Slate500
                            ),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (!isMonthlyMode) MaterialTheme.colorScheme.surface else Color.Transparent,
                        shadowElevation = if (!isMonthlyMode) 2.dp else 0.dp,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { isMonthlyMode = false }
                            .testTag("toggle_digest_weekly")
                    ) {
                        Text(
                            text = AppStrings.get("expenses.view_weekly", lang),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (!isMonthlyMode) FontWeight.Bold else FontWeight.Normal,
                                color = if (!isMonthlyMode) MaterialTheme.colorScheme.onSurface else Slate500
                            ),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Section Title
        item {
            Text(
                text = if (isMonthlyMode) {
                    AppStrings.get("expenses.monthly_digest", lang)
                } else {
                    AppStrings.get("expenses.weekly_digest", lang)
                },
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            )
        }

        // Digest Cards
        items(digests) { digest ->
            val isExpanded = expandedPeriodId == digest.periodId
            PeriodDigestCard(
                digest = digest,
                lang = lang,
                isExpanded = isExpanded,
                onToggleExpand = {
                    expandedPeriodId = if (isExpanded) null else digest.periodId
                },
                onInvoiceClick = onInvoiceClick
            )
        }
    }
}

@Composable
fun PeriodDigestCard(
    digest: PeriodDigestItem,
    lang: AppLanguage,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onInvoiceClick: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("digest_card_${digest.periodId}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Title and comparison trend badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = digest.periodTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    )
                    if (digest.subtitle.isNotBlank()) {
                        Text(
                            text = digest.subtitle,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Slate500,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Comparison badge
                if (digest.percentChangeVsPrev != null) {
                    val pct = digest.percentChangeVsPrev
                    val isUp = digest.isIncrease
                    val (badgeBg, badgeText, icon) = if (isUp) {
                        Triple(Red100, Red600, Icons.Default.TrendingUp)
                    } else {
                        Triple(Emerald100, Emerald600, Icons.Default.TrendingDown)
                    }
                    Surface(
                        shape = RoundedCornerShape(100.dp),
                        color = badgeBg
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = badgeText,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format(Locale.US, "%s%.1f%%", if (isUp) "+" else "", pct),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = badgeText,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(100.dp),
                        color = Slate100
                    ) {
                        Text(
                            text = AppStrings.get("expenses.first_period", lang),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Slate600,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // Amount Spotlight and Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "NPR ${digest.totalAmount.toInt()}",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = BrandNavy,
                            fontSize = 20.sp
                        )
                    )
                    val avg = if (digest.count > 0) digest.totalAmount / digest.count else 0.0
                    Text(
                        text = "${AppStrings.get("expenses.avg_per_bill", lang)}: NPR ${avg.toInt()} • ${digest.count} ${if (lang == AppLanguage.NE) "बिल" else "bills"}",
                        style = MaterialTheme.typography.bodySmall.copy(color = Slate500)
                    )
                }

                // Expand / Collapse affordance
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Slate100,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onToggleExpand() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = if (isExpanded) AppStrings.get("expenses.hide_transactions", lang) else AppStrings.get("expenses.view_transactions", lang),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Slate700,
                                fontSize = 11.sp
                            )
                        )
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = Slate700,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Expanded Transaction Items
            if (isExpanded) {
                HorizontalDivider(color = Slate100, modifier = Modifier.padding(vertical = 4.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    digest.transactions.forEach { tx ->
                        InvoiceCardItem(
                            transaction = tx,
                            lang = lang,
                            onClick = { onInvoiceClick(tx.id) }
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// TAB 3: WARRANTY & RECEIPT TRACKER
// ---------------------------------------------------------------------------
enum class WarrantyExpiryState {
    EXPIRING_SOON,
    ACTIVE,
    EXPIRED
}

data class WarrantyItemDisplay(
    val transaction: Transaction,
    val purchaseDateStr: String,
    val expiryDateStr: String,
    val warrantyMonths: Int,
    val daysRemaining: Long,
    val state: WarrantyExpiryState
)

@Composable
fun WarrantyTrackerView(
    transactions: List<Transaction>,
    lang: AppLanguage,
    onInvoiceClick: (String) -> Unit,
    onViewPhotoClick: (Transaction) -> Unit,
    onAddInvoiceClick: () -> Unit
) {
    val warrantyItems = remember(transactions) {
        val today = LocalDate.now()
        transactions.filter { it.hasWarranty }.map { tx ->
            val wMonths = tx.warrantyMonths ?: 12
            val purchaseDate = try {
                LocalDate.parse(tx.date)
            } catch (e: Exception) {
                today
            }
            val expiryDate = purchaseDate.plusMonths(wMonths.toLong())
            val daysRem = ChronoUnit.DAYS.between(today, expiryDate)

            val state = when {
                daysRem < 0 -> WarrantyExpiryState.EXPIRED
                daysRem in 0..30 -> WarrantyExpiryState.EXPIRING_SOON
                else -> WarrantyExpiryState.ACTIVE
            }

            WarrantyItemDisplay(
                transaction = tx,
                purchaseDateStr = tx.date,
                expiryDateStr = expiryDate.toString(),
                warrantyMonths = wMonths,
                daysRemaining = daysRem,
                state = state
            )
        }.sortedWith(
            compareBy<WarrantyItemDisplay> {
                // Priority order: Expiring Soon first (0), Active next (1), Expired last (2)
                when (it.state) {
                    WarrantyExpiryState.EXPIRING_SOON -> 0
                    WarrantyExpiryState.ACTIVE -> 1
                    WarrantyExpiryState.EXPIRED -> 2
                }
            }.thenBy { it.daysRemaining }
        )
    }

    if (warrantyItems.isEmpty()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                EmptyStateView(
                    title = AppStrings.get("expenses.empty_warranty_title", lang),
                    description = AppStrings.get("expenses.empty_warranty_desc", lang),
                    actionText = AppStrings.get("home.add_invoice", lang),
                    onActionClick = onAddInvoiceClick,
                    icon = Icons.Default.VerifiedUser
                )
            }
        }
        return
    }

    val activeCount = warrantyItems.count { it.state == WarrantyExpiryState.ACTIVE }
    val expiringSoonCount = warrantyItems.count { it.state == WarrantyExpiryState.EXPIRING_SOON }
    val expiredCount = warrantyItems.count { it.state == WarrantyExpiryState.EXPIRED }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("expenses_warranty_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Summary Counts
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    title = AppStrings.get("expenses.active_warranties", lang),
                    value = "$activeCount",
                    icon = Icons.Default.CheckCircle,
                    iconBgColor = Emerald100,
                    iconTint = Emerald600,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = AppStrings.get("expenses.expiring_soon_count", lang),
                    value = "$expiringSoonCount",
                    icon = Icons.Default.Warning,
                    iconBgColor = Amber100,
                    iconTint = Amber600,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = AppStrings.get("expenses.expired_count", lang),
                    value = "$expiredCount",
                    icon = Icons.Default.Info,
                    iconBgColor = Slate100,
                    iconTint = Slate600,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section Title
        item {
            Text(
                text = AppStrings.get("expenses.warranty_tracker", lang),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            )
        }

        // Warranty Cards
        items(warrantyItems) { item ->
            WarrantyCardItem(
                item = item,
                lang = lang,
                onClick = { onInvoiceClick(item.transaction.id) },
                onViewPhoto = { onViewPhotoClick(item.transaction) }
            )
        }
    }
}

@Composable
fun WarrantyCardItem(
    item: WarrantyItemDisplay,
    lang: AppLanguage,
    onClick: () -> Unit,
    onViewPhoto: () -> Unit
) {
    val tx = item.transaction
    val categoryLabel = AppStrings.getCategoryLabel(tx.category, lang)
    val hasPhoto = !tx.photoReference.isNullOrBlank() && File(tx.photoReference).exists()

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("warranty_card_${tx.id}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row: Seller + Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tx.sellerName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$categoryLabel • NPR ${tx.amount.toInt()}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Slate500,
                            fontSize = 12.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Expiry status badge
                when (item.state) {
                    WarrantyExpiryState.EXPIRING_SOON -> {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Amber100
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Amber600,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = String.format(Locale.US, AppStrings.get("expenses.days_left_badge", lang), item.daysRemaining),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Amber600,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                    WarrantyExpiryState.ACTIVE -> {
                        val monthsLeft = (item.daysRemaining / 30).coerceAtLeast(1)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Emerald100
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Emerald600,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = String.format(Locale.US, AppStrings.get("expenses.months_left_badge", lang), monthsLeft),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Emerald600,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                    WarrantyExpiryState.EXPIRED -> {
                        val daysAgo = (-item.daysRemaining).coerceAtLeast(1)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Slate100
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = Slate500,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = String.format(Locale.US, AppStrings.get("expenses.expired_days_ago_badge", lang), daysAgo),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Slate600,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Dates & Duration Bar
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Slate100,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = AppStrings.get("expenses.purchased_on", lang),
                            style = MaterialTheme.typography.labelSmall.copy(color = Slate400, fontSize = 10.sp)
                        )
                        Text(
                            text = item.purchaseDateStr,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(100.dp),
                        color = Color.White
                    ) {
                        Text(
                            text = String.format(Locale.US, AppStrings.get("expenses.warranty_months_label", lang), item.warrantyMonths),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = BrandNavy,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = AppStrings.get("expenses.expires_on", lang),
                            style = MaterialTheme.typography.labelSmall.copy(color = Slate400, fontSize = 10.sp)
                        )
                        Text(
                            text = item.expiryDateStr,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = if (item.state == WarrantyExpiryState.EXPIRING_SOON) Amber600 else MaterialTheme.colorScheme.onSurface,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }

            // Photo and Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (hasPhoto) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = BrandGreenLight,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onViewPhoto() }
                            .testTag("btn_view_photo_${tx.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = BrandGreenDark,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = AppStrings.get("expenses.view_receipt", lang),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = BrandGreenDark,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                } else {
                    Text(
                        text = AppStrings.get("expenses.no_receipt_photo", lang),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Slate400,
                            fontSize = 11.sp
                        )
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onClick() }
                ) {
                    Text(
                        text = AppStrings.get("invoice_detail.title", lang),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// RECEIPT PHOTO FULL DIALOG
// ---------------------------------------------------------------------------
@Composable
fun ReceiptPhotoDialog(
    transaction: Transaction,
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onOpenDetails: () -> Unit
) {
    val photoPath = transaction.photoReference
    val bitmap = remember(photoPath) {
        if (!photoPath.isNullOrBlank()) {
            val file = File(photoPath)
            if (file.exists()) {
                BitmapFactory.decodeFile(file.absolutePath)
            } else null
        } else null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AppStrings.get("expenses.receipt_dialog_title", lang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header details
                Text(
                    text = "${transaction.sellerName} • NPR ${transaction.amount.toInt()}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(
                    text = "${AppStrings.get("invoice_detail.date", lang)}: ${transaction.date}",
                    style = MaterialTheme.typography.labelSmall.copy(color = Slate500)
                )

                // Image display
                if (bitmap != null) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Slate100,
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                    ) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Bill Photo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(Slate100, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = AppStrings.get("expenses.no_receipt_photo", lang),
                            style = MaterialTheme.typography.bodyMedium.copy(color = Slate500)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onOpenDetails,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(AppStrings.get("invoice_detail.title", lang), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(AppStrings.get("common.close", lang))
            }
        }
    )
}

// ---------------------------------------------------------------------------
// HELPER FUNCTIONS: Grouping and Trends
// ---------------------------------------------------------------------------
private fun buildMonthlyDigests(transactions: List<Transaction>, lang: AppLanguage): List<PeriodDigestItem> {
    val grouped = transactions.groupBy { tx ->
        try {
            val date = LocalDate.parse(tx.date)
            String.format(Locale.US, "%04d-%02d", date.year, date.monthValue)
        } catch (e: Exception) {
            "Unknown"
        }
    }.filterKeys { it != "Unknown" }

    val sortedAscKeys = grouped.keys.sorted()
    val digestMap = mutableMapOf<String, PeriodDigestItem>()

    var prevMonthSpend: Double? = null

    for (key in sortedAscKeys) {
        val txs = grouped[key] ?: emptyList()
        val total = txs.sumOf { it.amount }

        val parts = key.split("-")
        val year = parts.getOrNull(0)?.toIntOrNull() ?: 2024
        val month = parts.getOrNull(1)?.toIntOrNull() ?: 1

        val dateObj = LocalDate.of(year, month, 1)
        val engMonthName = dateObj.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US))

        val bsDate = NepaliDateUtils.dateStrToBS("$key-15")
        val nepaliPeriod = if (bsDate != null) {
            val bsMonthName = if (lang == AppLanguage.NE) {
                listOf("", "बैशाख", "जेठ", "असार", "साउन", "भदौ", "असोज", "कार्तिक", "मंसिर", "पुष", "माघ", "फागुन", "चैत").getOrElse(bsDate.month) { "" }
            } else {
                listOf("", "Baisakh", "Jestha", "Ashadh", "Shrawan", "Bhadra", "Ashwin", "Kartik", "Mangsir", "Poush", "Magh", "Falgun", "Chaitra").getOrElse(bsDate.month) { "" }
            }
            "$bsMonthName ${bsDate.year} BS ($engMonthName)"
        } else {
            engMonthName
        }

        val pctChange: Double?
        val isInc: Boolean
        if (prevMonthSpend != null && prevMonthSpend > 0) {
            val diff = total - prevMonthSpend
            pctChange = (diff / prevMonthSpend) * 100
            isInc = diff >= 0
        } else {
            pctChange = null
            isInc = false
        }

        prevMonthSpend = total

        digestMap[key] = PeriodDigestItem(
            periodId = key,
            periodTitle = nepaliPeriod,
            subtitle = if (lang == AppLanguage.NE) "मासिक कुल खर्च" else "Monthly Spend Total",
            totalAmount = total,
            count = txs.size,
            percentChangeVsPrev = pctChange,
            isIncrease = isInc,
            transactions = txs.sortedByDescending { it.date }
        )
    }

    return sortedAscKeys.reversed().mapNotNull { digestMap[it] }
}

private fun buildWeeklyDigests(transactions: List<Transaction>, lang: AppLanguage): List<PeriodDigestItem> {
    val weekFields = WeekFields.of(Locale.getDefault())
    val grouped = transactions.groupBy { tx ->
        try {
            val date = LocalDate.parse(tx.date)
            val week = date.get(weekFields.weekOfWeekBasedYear())
            val year = date.get(weekFields.weekBasedYear())
            String.format(Locale.US, "%04d-W%02d", year, week)
        } catch (e: Exception) {
            "Unknown"
        }
    }.filterKeys { it != "Unknown" }

    val sortedAscKeys = grouped.keys.sorted()
    val digestMap = mutableMapOf<String, PeriodDigestItem>()

    var prevWeekSpend: Double? = null

    for (key in sortedAscKeys) {
        val txs = grouped[key] ?: emptyList()
        val total = txs.sumOf { it.amount }

        val earliestDate = txs.minOfOrNull { it.date } ?: ""
        val latestDate = txs.maxOfOrNull { it.date } ?: ""

        val pctChange: Double?
        val isInc: Boolean
        if (prevWeekSpend != null && prevWeekSpend > 0) {
            val diff = total - prevWeekSpend
            pctChange = (diff / prevWeekSpend) * 100
            isInc = diff >= 0
        } else {
            pctChange = null
            isInc = false
        }

        prevWeekSpend = total

        digestMap[key] = PeriodDigestItem(
            periodId = key,
            periodTitle = "${if (lang == AppLanguage.NE) "हप्ता" else "Week"} ${key.substringAfter("-W")}, ${key.substringBefore("-")}",
            subtitle = "$earliestDate — $latestDate",
            totalAmount = total,
            count = txs.size,
            percentChangeVsPrev = pctChange,
            isIncrease = isInc,
            transactions = txs.sortedByDescending { it.date }
        )
    }

    return sortedAscKeys.reversed().mapNotNull { digestMap[it] }
}

private fun getCategoryIcon(category: TransactionCategory): ImageVector {
    return when (category) {
        TransactionCategory.FOOD_RESTAURANT -> Icons.Default.Restaurant
        TransactionCategory.ELECTRONICS -> Icons.Default.Devices
        TransactionCategory.CLOTHING -> Icons.Default.Checkroom
        TransactionCategory.ELECTRICITY -> Icons.Default.ElectricBolt
        TransactionCategory.TELEPHONE_INTERNET -> Icons.Default.Wifi
        TransactionCategory.AIRLINE -> Icons.Default.Flight
        TransactionCategory.TRANSPORT_FREIGHT -> Icons.Default.LocalShipping
        TransactionCategory.VEHICLE -> Icons.Default.DirectionsCar
        TransactionCategory.NORMAL_GOODS -> Icons.Default.ShoppingBag
        TransactionCategory.OTHER -> Icons.Default.ReceiptLong
        TransactionCategory.DONT_KNOW -> Icons.Default.HelpOutline
    }
}

private fun getCategoryColor(category: TransactionCategory): Color {
    return when (category) {
        TransactionCategory.FOOD_RESTAURANT -> Color(0xFFE65100)
        TransactionCategory.ELECTRONICS -> Color(0xFF1E88E5)
        TransactionCategory.CLOTHING -> Color(0xFF8E24AA)
        TransactionCategory.ELECTRICITY -> Color(0xFFF59E0B)
        TransactionCategory.TELEPHONE_INTERNET -> Color(0xFF0284C7)
        TransactionCategory.AIRLINE -> Color(0xFF0D9488)
        TransactionCategory.TRANSPORT_FREIGHT -> Color(0xFF475569)
        TransactionCategory.VEHICLE -> Color(0xFFD97706)
        TransactionCategory.NORMAL_GOODS -> Color(0xFF059669)
        TransactionCategory.OTHER -> Color(0xFF64748B)
        TransactionCategory.DONT_KNOW -> Color(0xFF94A3B8)
    }
}
