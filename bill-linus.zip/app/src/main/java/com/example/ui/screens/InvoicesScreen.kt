package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.EligibilityStatus
import com.example.model.ScreenName
import com.example.ui.MainViewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.Slate500

@Composable
fun InvoicesScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()

    var selectedFilter by remember { mutableStateOf<EligibilityStatus?>(null) }

    val filteredList = remember(transactions, selectedFilter) {
        if (selectedFilter == null) transactions
        else transactions.filter { it.eligibilityStatus == selectedFilter }
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("invoices.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = currentScreen,
                lang = lang,
                onNavigate = { viewModel.navigateTo(it) }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddInvoice() },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_invoice")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Invoice")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Filter Tabs
            ScrollableTabRow(
                selectedTabIndex = if (selectedFilter == null) 0 else {
                    when (selectedFilter) {
                        EligibilityStatus.COUPON_ADDED -> 1
                        EligibilityStatus.AWAITING_COUPON -> 2
                        EligibilityStatus.LIKELY_ELIGIBLE -> 3
                        EligibilityStatus.NEEDS_VERIFICATION -> 4
                        EligibilityStatus.LIKELY_NOT_ELIGIBLE -> 5
                        else -> 0
                    }
                },
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedFilter == null,
                    onClick = { selectedFilter = null },
                    text = {
                        Text(
                            text = if (lang == AppLanguage.NE) "सबै (${transactions.size})" else "All (${transactions.size})",
                            fontWeight = if (selectedFilter == null) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedFilter == EligibilityStatus.COUPON_ADDED,
                    onClick = { selectedFilter = EligibilityStatus.COUPON_ADDED },
                    text = {
                        val c = transactions.count { it.eligibilityStatus == EligibilityStatus.COUPON_ADDED }
                        Text(
                            text = "${AppStrings.getStatusLabel(EligibilityStatus.COUPON_ADDED, lang)} ($c)",
                            fontWeight = if (selectedFilter == EligibilityStatus.COUPON_ADDED) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedFilter == EligibilityStatus.AWAITING_COUPON,
                    onClick = { selectedFilter = EligibilityStatus.AWAITING_COUPON },
                    text = {
                        val c = transactions.count { it.eligibilityStatus == EligibilityStatus.AWAITING_COUPON }
                        Text(
                            text = "${AppStrings.getStatusLabel(EligibilityStatus.AWAITING_COUPON, lang)} ($c)",
                            fontWeight = if (selectedFilter == EligibilityStatus.AWAITING_COUPON) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedFilter == EligibilityStatus.LIKELY_ELIGIBLE,
                    onClick = { selectedFilter = EligibilityStatus.LIKELY_ELIGIBLE },
                    text = {
                        val c = transactions.count { it.eligibilityStatus == EligibilityStatus.LIKELY_ELIGIBLE }
                        Text(
                            text = "${AppStrings.getStatusLabel(EligibilityStatus.LIKELY_ELIGIBLE, lang)} ($c)",
                            fontWeight = if (selectedFilter == EligibilityStatus.LIKELY_ELIGIBLE) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }

            if (filteredList.isEmpty()) {
                EmptyStateView(
                    title = AppStrings.get("invoices.empty_title", lang),
                    description = AppStrings.get("invoices.empty_desc", lang),
                    actionText = AppStrings.get("invoices.add", lang),
                    onActionClick = { viewModel.openAddInvoice() }
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredList) { tx ->
                        InvoiceCardItem(
                            transaction = tx,
                            lang = lang,
                            onClick = { viewModel.selectInvoice(tx.id) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }
}
