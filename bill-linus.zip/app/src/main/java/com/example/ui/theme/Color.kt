package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bill Linus Brand Colors
val BrandNavy = Color(0xFF1E3A5F)
val BrandNavyDark = Color(0xFF162F4E)
val BrandNavyLight = Color(0xFFE8EDF3)
val BrandNavyMuted = Color(0xFF55708E)

val BrandGreen = Color(0xFF16803C)
val BrandGreenDark = Color(0xFF15803D)
val BrandGreenAccent = Color(0xFF16A34A)
val BrandGreenLight = Color(0xFFDCFCE7)
val BrandGreenBg = Color(0xFFF0FDF4)

val PageBackground = Color(0xFFF5F7FB)
val CardBackground = Color(0xFFFFFFFF)

val Slate950 = Color(0xFF0F172A)
val Slate900 = Color(0xFF1E293B)
val Slate800 = Color(0xFF334155)
val Slate700 = Color(0xFF475569)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val Emerald600 = Color(0xFF16803C)
val Emerald500 = Color(0xFF16A34A)
val Emerald400 = Color(0xFF34D399)
val Emerald100 = Color(0xFFDCFCE7)
val Emerald50 = Color(0xFFF0FDF4)

val Amber600 = Color(0xFFB45309)
val Amber500 = Color(0xFFD97706)
val Amber400 = Color(0xFFFBBF24)
val Amber100 = Color(0xFFFEF3C7)
val Amber50 = Color(0xFFFFFBEB)

val Indigo600 = Color(0xFF1E3A5F)
val Indigo500 = Color(0xFF335A80)
val Indigo100 = Color(0xFFE8EDF3)

val Red900 = Color(0xFF7F1D1D)
val Red600 = Color(0xFFB91C1C)
val Red500 = Color(0xFFDC2626)
val Red400 = Color(0xFFF87171)
val Red100 = Color(0xFFFEE2E2)
val Red50 = Color(0xFFFEF2F2)

val Blue600 = Color(0xFF1E3A5F)
val Blue500 = Color(0xFF2563EB)
val Blue100 = Color(0xFFE8EDF3)
val Blue50 = Color(0xFFEFF6FF)

