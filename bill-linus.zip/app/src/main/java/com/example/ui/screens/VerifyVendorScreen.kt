package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.EligibilityPrefillData
import com.example.model.PaymentMethod
import com.example.service.DrawResultService
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Red600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.utils.CouponUtils

@Composable
fun VerifyVendorScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val vendorPanPrefill by viewModel.vendorPanPrefill.collectAsState()
    val context = LocalContext.current

    var panInput by remember(vendorPanPrefill) { mutableStateOf(vendorPanPrefill ?: "") }
    val cleanPan = CouponUtils.normalizeCouponNumber(panInput)
    val isValidPan = CouponUtils.isValidPanNumber(cleanPan)

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("verify_vendor.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Track A: Official IRD PAN Search
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppStrings.get("verify_vendor.track_a_header", lang),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Text(
                        text = AppStrings.get("verify_vendor.track_a_desc", lang),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Slate500,
                            fontSize = 12.sp
                        )
                    )

                    OutlinedTextField(
                        value = panInput,
                        onValueChange = { panInput = it.filter { c -> c.isDigit() }.take(9) },
                        label = { Text(AppStrings.get("verify_vendor.pan_label", lang)) },
                        placeholder = { Text(AppStrings.get("verify_vendor.pan_placeholder", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        trailingIcon = {
                            if (cleanPan.isNotEmpty()) {
                                Text(
                                    text = "${cleanPan.length}/9",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isValidPan) Emerald600 else Slate500,
                                        fontWeight = if (isValidPan) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    modifier = Modifier.padding(end = 12.dp)
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_vendor_pan"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (cleanPan.isNotEmpty() && !isValidPan) {
                        Text(
                            text = AppStrings.get("verify_vendor.invalid_pan", lang),
                            style = MaterialTheme.typography.labelSmall.copy(color = Red600)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Vendor PAN", cleanPan)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, AppStrings.get("verify_vendor.pan_copied", lang), Toast.LENGTH_SHORT).show()
                            },
                            enabled = cleanPan.isNotEmpty(),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_copy_pan"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(AppStrings.get("verify_vendor.copy_pan", lang))
                        }

                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DrawResultService.IRD_PAN_SEARCH_URL))
                                context.startActivity(intent)
                            },
                            modifier = Modifier
                                .weight(1.4f)
                                .height(44.dp)
                                .testTag("btn_search_ird_portal"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Slate900)
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Search on IRD",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Track B: Test Purchase Scheme Rules
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Emerald600,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppStrings.get("verify_vendor.track_b_header", lang),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Text(
                        text = AppStrings.get("verify_vendor.track_b_desc", lang),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Slate500,
                            fontSize = 12.sp
                        )
                    )

                    Button(
                        onClick = {
                            viewModel.openEligibilityChecker(
                                EligibilityPrefillData(
                                    amount = 1000.0,
                                    paymentMethod = PaymentMethod.QR_PAYMENT,
                                    panVat = cleanPan.ifBlank { null },
                                    sellerName = ""
                                )
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_verify_vendor_eligibility"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = AppStrings.get("verify_vendor.check_eligibility", lang),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Official System Note
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Slate100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Slate500,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = AppStrings.get("verify_vendor.disclaimer", lang),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Slate700,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }
    }
}
