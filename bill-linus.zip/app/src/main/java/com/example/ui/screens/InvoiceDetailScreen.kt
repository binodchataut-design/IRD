package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Info
import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.ui.platform.LocalContext
import com.example.service.DrawResultService
import com.example.model.PaymentMethod
import com.example.ui.theme.BrandGreenDark
import com.example.ui.theme.BrandGreenLight
import com.example.ui.theme.BrandNavy
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.Coupon
import com.example.model.CouponPrefillData
import com.example.model.EligibilityPrefillData
import com.example.model.EligibilityStatus
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Indigo100
import com.example.ui.theme.Indigo600
import com.example.ui.theme.Red600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate950
import com.example.utils.CouponUtils
import com.example.utils.NepaliDateUtils

@Composable
fun InvoiceDetailScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    val selectedId by viewModel.selectedInvoiceId.collectAsState()

    val transaction = transactions.find { it.id == selectedId }
    var showDeleteDialog by remember { mutableStateOf(false) }

    val drawInfo = remember(transaction?.date, lang) {
        transaction?.date?.let { NepaliDateUtils.getDrawPeriodForDate(it, lang) }
    }

    if (showDeleteDialog && transaction != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(AppStrings.get("common.delete", lang)) },
            text = {
                Text(
                    if (lang == AppLanguage.NE) "के तपाईं यो चलानी मेटाउन निश्चित हुनुहुन्छ?"
                    else "Are you sure you want to delete this invoice record?"
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        viewModel.deleteTransaction(transaction.id)
                    },
                    modifier = Modifier.testTag("confirm_delete_invoice")
                ) {
                    Text(AppStrings.get("common.delete", lang), color = Red600)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(AppStrings.get("common.cancel", lang))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("invoice_detail.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() },
                actions = {
                    if (transaction != null) {
                        IconButton(
                            onClick = { viewModel.openEditInvoice(transaction.id) },
                            modifier = Modifier.testTag("edit_invoice_topbar_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = { showDeleteDialog = true },
                            modifier = Modifier.testTag("delete_invoice_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = Red600
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (transaction == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(AppStrings.get("invoice_detail.not_found", lang))
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = transaction.sellerName,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 22.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${AppStrings.get("invoice_detail.date", lang)}: ${transaction.date}",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate500)
                                )
                            }
                            StatusBadge(status = transaction.eligibilityStatus, lang = lang)
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = Slate100)
                        Spacer(modifier = Modifier.height(16.dp))

                        // Amount Spotlight
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = AppStrings.get("invoice_detail.amount", lang),
                                style = MaterialTheme.typography.titleMedium.copy(color = Slate500)
                            )
                            Text(
                                text = "NPR ${transaction.amount.toInt()}",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Emerald600,
                                    fontSize = 24.sp
                                )
                            )
                        }
                    }
                }

                // Metadata Details Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        DetailRow(
                            label = AppStrings.get("invoice_detail.payment", lang),
                            value = AppStrings.getPaymentMethodLabel(transaction.paymentMethod, lang)
                        )
                        DetailRow(
                            label = AppStrings.get("invoice_detail.draw_period", lang),
                            value = drawInfo?.drawPeriod ?: "—"
                        )
                        DetailRow(
                            label = AppStrings.get("invoice_detail.pan", lang),
                            value = transaction.panVat ?: AppStrings.get("common.not_provided", lang)
                        )
                        DetailRow(
                            label = AppStrings.get("invoice_detail.invoice_no", lang),
                            value = transaction.invoiceNumber ?: AppStrings.get("common.not_provided", lang)
                        )
                        DetailRow(
                            label = AppStrings.get("invoice_detail.coupon_number", lang),
                            value = if (transaction.couponNumber != null)
                                CouponUtils.formatCouponNumber(transaction.couponNumber)
                            else AppStrings.get("invoice_detail.awaiting_coupon", lang)
                        )
                        if (!transaction.notes.isNullOrBlank()) {
                            DetailRow(
                                label = AppStrings.get("invoice_detail.notes", lang),
                                value = transaction.notes
                            )
                        }
                    }
                }

                if (transaction.paymentMethod == PaymentMethod.CASH && transaction.couponNumber.isNullOrBlank()) {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = BrandGreenLight),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_detail_cash_info")
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = BrandGreenDark,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = AppStrings.get("eligibility.cash_info_title", lang),
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = BrandGreenDark
                                    )
                                )
                            }

                            Text(
                                text = AppStrings.get("eligibility.cash_info_desc", lang),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Slate700,
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                )
                            )

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BrandNavy,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DrawResultService.IRD_PRIZE_PORTAL_URL))
                                        context.startActivity(intent)
                                    }
                                    .testTag("btn_detail_open_ird")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = AppStrings.get("eligibility.open_ird_portal", lang),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    )
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Action Buttons
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Edit Invoice details button
                    Button(
                        onClick = { viewModel.openEditInvoice(transaction.id) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_edit_invoice_detail"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (lang == AppLanguage.NE) "खरिद विवरण सम्पादन गर्नुहोस्" else "Edit Purchase Details",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (transaction.couponNumber.isNullOrBlank()) {
                        Button(
                            onClick = {
                                viewModel.openAddCoupon(
                                    prefill = CouponPrefillData(
                                        merchantName = transaction.sellerName,
                                        drawPeriod = drawInfo?.drawPeriod,
                                        invoiceNumber = transaction.invoiceNumber,
                                        amount = transaction.amount
                                    ),
                                    linkedInvoiceId = transaction.id
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_attach_coupon"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald600)
                        ) {
                            Icon(Icons.Default.CardGiftcard, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(AppStrings.get("home.add_coupon", lang), fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val matchingCoupon = coupons.find {
                                it.couponNumber == transaction.couponNumber ||
                                        (transaction.invoiceNumber != null && it.invoiceNumber == transaction.invoiceNumber)
                            }
                            Button(
                                onClick = {
                                    if (matchingCoupon != null) {
                                        viewModel.openEditCoupon(matchingCoupon.id)
                                    } else {
                                        viewModel.openAddCoupon(
                                            prefill = CouponPrefillData(
                                                merchantName = transaction.sellerName,
                                                drawPeriod = drawInfo?.drawPeriod,
                                                invoiceNumber = transaction.invoiceNumber,
                                                amount = transaction.amount
                                            ),
                                            linkedInvoiceId = transaction.id
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_edit_linked_coupon"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Slate100)
                            ) {
                                Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = Slate700, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    if (lang == AppLanguage.NE) "कुपन सम्पादन" else "Edit Coupon",
                                    color = Slate700,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Button(
                                onClick = {
                                    val claimCoupon = matchingCoupon ?: Coupon(
                                        id = transaction.id,
                                        couponNumber = transaction.couponNumber,
                                        date = transaction.date,
                                        drawPeriod = drawInfo?.drawPeriod,
                                        merchantName = transaction.sellerName,
                                        amount = transaction.amount,
                                        paymentMethod = AppStrings.getPaymentMethodLabel(transaction.paymentMethod, AppLanguage.EN),
                                        invoiceNumber = transaction.invoiceNumber,
                                        notes = transaction.notes,
                                        createdAt = transaction.createdAt
                                    )
                                    viewModel.openClaimReport(claimCoupon)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_view_claim_report"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Emerald600)
                            ) {
                                Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(AppStrings.get("common.claim_report", lang), fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.openEligibilityChecker(
                                EligibilityPrefillData(
                                    amount = transaction.amount,
                                    paymentMethod = transaction.paymentMethod,
                                    panVat = transaction.panVat,
                                    sellerName = transaction.sellerName,
                                    invoiceNumber = transaction.invoiceNumber,
                                    date = transaction.date
                                )
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_check_eligibility_detail"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(AppStrings.get("ird_info.check_eligibility_link", lang), fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(color = Slate500),
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            ),
            modifier = Modifier.weight(1.5f)
        )
    }
}
