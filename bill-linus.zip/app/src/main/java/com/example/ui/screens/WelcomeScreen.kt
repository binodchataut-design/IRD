package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Indigo100
import com.example.ui.theme.Indigo600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@Composable
fun WelcomeScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Language Switcher Chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = lang == AppLanguage.NE,
                    onClick = { viewModel.setLanguage(AppLanguage.NE) },
                    label = { Text("नेपाली", fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("welcome_lang_ne")
                )
                FilterChip(
                    selected = lang == AppLanguage.EN,
                    onClick = { viewModel.setLanguage(AppLanguage.EN) },
                    label = { Text("English", fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("welcome_lang_en")
                )
            }

            // Logo Icon & Title
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(72.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Receipt,
                        contentDescription = "Bill Linus",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = AppStrings.get("app.name", lang),
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 28.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = AppStrings.get("welcome.subtitle", lang),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Slate500,
                        fontSize = 14.sp
                    )
                )
            }

            // Feature Highlights
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                WelcomeFeatureCard(
                    icon = Icons.Default.QrCodeScanner,
                    iconBg = Emerald100,
                    iconColor = Emerald600,
                    title = if (lang == AppLanguage.NE) "डिजिटल कर बिल तथा रसिद ट्र्याकिङ" else "Digital Tax Invoice Tracking",
                    desc = if (lang == AppLanguage.NE) "QR, ई-सेवा, खल्ती वा कार्ड भुक्तानीका रसिदहरू सुरक्षित राख्नुहोस्।" else "Log digital payments via QR, Fonepay, eSewa, Khalti, or cards."
                )

                WelcomeFeatureCard(
                    icon = Icons.Default.CardGiftcard,
                    iconBg = Indigo100,
                    iconColor = Indigo600,
                    title = if (lang == AppLanguage.NE) "१२ अंकको कुपन तथा लटरी म्याचिङ" else "12-Digit Coupon & Draw Matcher",
                    desc = if (lang == AppLanguage.NE) "दैनिक १ लाख र पाक्षिक १० लाख बम्पर लटरीका १२-अंकीय कुपनहरू सुरक्षित राख्नुहोस् र नतिजा जाँच्नुहोस्।" else "Save 12-digit prize coupons for Daily Rs 1 Lakh & Fortnightly Rs 10 Lakh draws."
                )

                WelcomeFeatureCard(
                    icon = Icons.Default.CheckCircle,
                    iconBg = Emerald100,
                    iconColor = Emerald600,
                    title = if (lang == AppLanguage.NE) "१०% फिर्ता योग्यता क्यालकुलेटर" else "10% Cash Refund Eligibility",
                    desc = if (lang == AppLanguage.NE) "आफ्नो खरिद लटरी र १०% भ्याट फिर्ताको लागि योग्य छ कि छैन तुरुन्त जाँच्नुहोस्।" else "Instantly verify if your purchase meets IRD lottery rules & 10% refund."
                )

                WelcomeFeatureCard(
                    icon = Icons.Default.Lock,
                    iconBg = Slate100,
                    iconColor = Slate700,
                    title = if (lang == AppLanguage.NE) "१००% निजी तथा अफलाइन" else "100% Offline & Private",
                    desc = if (lang == AppLanguage.NE) "तपाईंको सम्पूर्ण डाटा तपाईंको आफ्नै फोनमा मात्र सुरक्षित रहन्छ।" else "Your financial records stay exclusively on your device with JSON backup."
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Get Started Button
            Button(
                onClick = { viewModel.completeWelcome() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_welcome_get_started"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = AppStrings.get("welcome.get_started", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun WelcomeFeatureCard(
    icon: ImageVector,
    iconBg: Color,
    iconColor: Color,
    title: String,
    desc: String
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = iconBg,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Slate500,
                        fontSize = 12.sp
                    )
                )
            }
        }
    }
}
