package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.Coupon
import com.example.model.ScreenName
import com.example.ui.MainViewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppHeader
import com.example.ui.components.DrawPeriodBanner
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Red600

@Composable
fun CouponsScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentDrawInfo by viewModel.currentDrawInfo.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var couponToDelete by remember { mutableStateOf<Coupon?>(null) }

    val filteredCoupons = remember(coupons, searchQuery) {
        if (searchQuery.isBlank()) coupons
        else {
            val q = searchQuery.trim().lowercase()
            coupons.filter {
                it.couponNumber.contains(q) ||
                        (it.merchantName?.lowercase()?.contains(q) == true) ||
                        (it.drawPeriod?.lowercase()?.contains(q) == true)
            }
        }
    }

    if (couponToDelete != null) {
        AlertDialog(
            onDismissRequest = { couponToDelete = null },
            title = { Text(AppStrings.get("common.delete", lang)) },
            text = {
                Text(
                    if (lang == AppLanguage.NE) "के तपाईं यो कुपन मेटाउन चाहनुहुन्छ?"
                    else "Are you sure you want to delete this coupon?"
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val c = couponToDelete
                        couponToDelete = null
                        if (c != null) viewModel.deleteCoupon(c.id)
                    },
                    modifier = Modifier.testTag("confirm_delete_coupon")
                ) {
                    Text(AppStrings.get("common.delete", lang), color = Red600)
                }
            },
            dismissButton = {
                TextButton(onClick = { couponToDelete = null }) {
                    Text(AppStrings.get("common.cancel", lang))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("coupons.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = currentScreen,
                lang = lang,
                onNavigate = { viewModel.navigateTo(it) }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddCoupon() },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_coupon")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Coupon")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Draw Period Banner
                DrawPeriodBanner(
                    drawInfo = currentDrawInfo,
                    lang = lang,
                    onLearnMoreClick = { viewModel.navigateTo(ScreenName.WINNER_CHECKER) }
                )
            }

            // Quick Actions Bar (Bulk Add & Winner Checker)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.openBulkAddCoupons() },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("btn_bulk_add_coupons"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(
                            Icons.Default.DynamicFeed,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = AppStrings.get("coupons.bulk_add", lang),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.navigateTo(ScreenName.WINNER_CHECKER) },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("btn_check_coupons_winner"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = AppStrings.get("coupons.check_my_coupons", lang),
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Search Bar (if has items)
            if (coupons.size > 2) {
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(if (lang == AppLanguage.NE) "कुपन वा व्यापारी खोज्नुहोस्..." else "Search coupon number or merchant...") },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_coupons_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            // Coupon List Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${AppStrings.get("coupons.saved_coupons", lang)} (${filteredCoupons.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            if (filteredCoupons.isEmpty()) {
                item {
                    EmptyStateView(
                        title = AppStrings.get("coupons.empty_title", lang),
                        description = AppStrings.get("coupons.empty_desc", lang),
                        actionText = AppStrings.get("coupons.add", lang),
                        onActionClick = { viewModel.openAddCoupon() },
                        icon = Icons.Default.CardGiftcard
                    )
                }
            } else {
                items(filteredCoupons) { coupon ->
                    CouponCardItem(
                        coupon = coupon,
                        lang = lang,
                        onEditClick = { viewModel.openEditCoupon(coupon.id) },
                        onClaimClick = { viewModel.openClaimReport(coupon) },
                        onDeleteClick = { couponToDelete = coupon }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }
}
