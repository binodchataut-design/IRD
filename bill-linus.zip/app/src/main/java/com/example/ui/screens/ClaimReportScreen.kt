package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.theme.Amber400
import com.example.ui.theme.Amber500
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.utils.CouponUtils

@Composable
fun ClaimReportScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val claimData by viewModel.claimReportData.collectAsState()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("claim.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        if (claimData == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(AppStrings.get("claim.no_report_desc", lang))
            }
        } else {
            val item = claimData!!
            val coupon = item.coupon
            val tx = item.transaction

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Official Claim Document Style Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("claim_report_dossier")
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Header Badge
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Emerald100
                            ) {
                                Text(
                                    text = AppStrings.get("claim.report_record", lang),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Emerald600,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = Amber500,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Winning Number Box
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Slate900,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = AppStrings.get("claim.winning_coupon_number", lang),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Amber400,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = CouponUtils.formatCouponNumber(coupon.couponNumber),
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 24.sp,
                                        letterSpacing = 2.sp
                                    )
                                )
                            }
                        }

                        HorizontalDivider(color = Slate100)

                        // Particulars
                        Text(
                            text = AppStrings.get("claim.purchase_details", lang),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        DetailRow(
                            label = AppStrings.get("claim.draw_period", lang),
                            value = item.drawTitle ?: item.drawPeriod ?: coupon.drawPeriod ?: AppStrings.get("claim.default_draw", lang)
                        )

                        DetailRow(
                            label = AppStrings.get("claim.seller", lang),
                            value = coupon.merchantName ?: tx?.sellerName ?: AppStrings.get("common.not_specified", lang)
                        )

                        if (coupon.amount != null || tx != null) {
                            val amt = coupon.amount ?: tx?.amount
                            if (amt != null) {
                                DetailRow(
                                    label = AppStrings.get("claim.amount", lang),
                                    value = "NPR ${amt.toInt()}"
                                )
                            }
                        }

                        DetailRow(
                            label = AppStrings.get("claim.date", lang),
                            value = coupon.date ?: tx?.date ?: AppStrings.get("common.not_specified", lang)
                        )

                        if (tx?.paymentMethod != null) {
                            DetailRow(
                                label = AppStrings.get("claim.payment", lang),
                                value = AppStrings.getPaymentMethodLabel(tx.paymentMethod, lang)
                            )
                        }

                        if (tx?.panVat != null) {
                            DetailRow(
                                label = AppStrings.get("claim.pan", lang),
                                value = tx.panVat
                            )
                        }

                        if (coupon.invoiceNumber != null || tx?.invoiceNumber != null) {
                            DetailRow(
                                label = AppStrings.get("claim.invoice_no", lang),
                                value = coupon.invoiceNumber ?: tx?.invoiceNumber ?: ""
                            )
                        }
                    }
                }

                // Disclaimer Notice Card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Slate500,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = AppStrings.get("claim.disclaimer", lang),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Slate700,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        )
                    }
                }

                // Share / Print Button
                Button(
                    onClick = {
                        val shareText = buildString {
                            appendLine("--- BILL LINUS CLAIM SUMMARY ---")
                            appendLine("Winning 12-Digit Coupon: ${CouponUtils.formatCouponNumber(coupon.couponNumber)}")
                            appendLine("Draw Period: ${item.drawTitle ?: item.drawPeriod ?: coupon.drawPeriod}")
                            appendLine("Merchant: ${coupon.merchantName ?: tx?.sellerName}")
                            appendLine("Amount: NPR ${coupon.amount ?: tx?.amount ?: 0.0}")
                            appendLine("Invoice No: ${coupon.invoiceNumber ?: tx?.invoiceNumber ?: "N/A"}")
                            appendLine("PAN/VAT: ${tx?.panVat ?: "N/A"}")
                            appendLine("Date: ${coupon.date ?: tx?.date}")
                            appendLine("---------------------------------")
                            appendLine("Generated via Bill Linus Helper App")
                        }
                        val sendIntent: Intent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, shareText)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share Claim Summary"))
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_share_claim_report"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = AppStrings.get("claim.print", lang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
