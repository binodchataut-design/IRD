package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.EligibilityPrefillData
import com.example.model.PaymentMethod
import com.example.model.ScreenName
import com.example.ui.MainViewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppHeader
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Indigo100
import com.example.ui.theme.Indigo600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.utils.BillDataUtils
import com.example.utils.CouponUtils
import com.example.utils.QrInvoiceParser
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

enum class ScanTargetMode {
    VENDOR_QR,
    INVOICE_QR,
    BILL_OCR
}

@Composable
fun ScanScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val context = LocalContext.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    var selectedMode by remember { mutableStateOf(ScanTargetMode.VENDOR_QR) }
    var isTorchOn by remember { mutableStateOf(false) }
    var isProcessingScan by remember { mutableStateOf(false) }
    var isOcrProcessing by remember { mutableStateOf(false) }
    var imageCaptureRef by remember { mutableStateOf<ImageCapture?>(null) }
    var showPoorQualityDialog by remember { mutableStateOf(false) }
    var pendingPhotoPath by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("scan.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = ScreenName.SCAN,
                lang = lang,
                onNavigate = { screen -> viewModel.navigateTo(screen) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mode Selector Header
            Text(
                text = AppStrings.get("scan.select_mode", lang),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            )

            // Mode Selector Cards (3 modes)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ScanModeCard(
                    title = AppStrings.get("scan.mode_vendor_title", lang),
                    description = if (lang == AppLanguage.NE) "प्यान (PAN) जाँच्नुहोस्" else "Verify 9-digit PAN",
                    icon = Icons.Default.VerifiedUser,
                    isSelected = selectedMode == ScanTargetMode.VENDOR_QR,
                    activeColor = Emerald600,
                    activeBg = Emerald100,
                    testTag = "mode_vendor_qr",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        selectedMode = ScanTargetMode.VENDOR_QR
                        isProcessingScan = false
                    }
                )

                ScanModeCard(
                    title = AppStrings.get("scan.mode_invoice_title", lang),
                    description = if (lang == AppLanguage.NE) "कर बिजक QR" else "Auto-fill invoice QR",
                    icon = Icons.Default.Receipt,
                    isSelected = selectedMode == ScanTargetMode.INVOICE_QR,
                    activeColor = Indigo600,
                    activeBg = Indigo100,
                    testTag = "mode_invoice_qr",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        selectedMode = ScanTargetMode.INVOICE_QR
                        isProcessingScan = false
                    }
                )

                ScanModeCard(
                    title = AppStrings.get("scan.mode_bill_title", lang),
                    description = if (lang == AppLanguage.NE) "कागजी बिल फोटो" else "Photograph bill OCR",
                    icon = Icons.Default.DocumentScanner,
                    isSelected = selectedMode == ScanTargetMode.BILL_OCR,
                    activeColor = Color(0xFF0F766E),
                    activeBg = Color(0xFFCCFBF1),
                    testTag = "mode_bill_ocr",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        selectedMode = ScanTargetMode.BILL_OCR
                        isProcessingScan = false
                    }
                )
            }

            if (!hasCameraPermission) {
                // Permission Denied / Rationale View
                CameraPermissionCard(
                    lang = lang,
                    onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    onOpenSettings = {
                        val intent = Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", context.packageName, null)
                        )
                        context.startActivity(intent)
                    }
                )
            } else {
                // Camera Scanner View with Viewfinder overlay
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("camera_preview_card")
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(16.dp))
                    ) {
                        CameraPreview(
                            mode = selectedMode,
                            isTorchOn = isTorchOn,
                            onImageCaptureReady = { capture ->
                                imageCaptureRef = capture
                            },
                            onBarcodeScanned = { rawValue ->
                                if (selectedMode != ScanTargetMode.BILL_OCR && !isProcessingScan) {
                                    isProcessingScan = true
                                    handleScannedCode(
                                        rawCode = rawValue,
                                        mode = selectedMode,
                                        viewModel = viewModel,
                                        lang = lang,
                                        context = context,
                                        onReset = { isProcessingScan = false }
                                    )
                                }
                            }
                        )

                        // Viewfinder scanning / capture overlay
                        ScannerOverlay(
                            mode = selectedMode,
                            lang = lang,
                            isTorchOn = isTorchOn,
                            isOcrProcessing = isOcrProcessing,
                            onToggleTorch = { isTorchOn = !isTorchOn },
                            onCaptureClick = {
                                if (selectedMode == ScanTargetMode.BILL_OCR && !isOcrProcessing && imageCaptureRef != null) {
                                    isOcrProcessing = true
                                    isProcessingScan = true
                                    captureAndProcessBillPhoto(
                                        context = context,
                                        imageCapture = imageCaptureRef!!,
                                        viewModel = viewModel,
                                        lang = lang,
                                        onPoorQuality = { savedPath ->
                                            pendingPhotoPath = savedPath
                                            isOcrProcessing = false
                                            showPoorQualityDialog = true
                                        },
                                        onError = {
                                            isOcrProcessing = false
                                            isProcessingScan = false
                                            Toast.makeText(
                                                context,
                                                if (lang == AppLanguage.NE) "फोटो लिन सकिएन। पुनः प्रयास गर्नुहोस्।" else "Failed to capture photo. Please try again.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    )
                                }
                            }
                        )
                    }
                }

                // If in Bill OCR mode, provide prominent Capture Shutter Button below camera
                if (selectedMode == ScanTargetMode.BILL_OCR) {
                    Button(
                        onClick = {
                            if (!isOcrProcessing && imageCaptureRef != null) {
                                isOcrProcessing = true
                                isProcessingScan = true
                                captureAndProcessBillPhoto(
                                    context = context,
                                    imageCapture = imageCaptureRef!!,
                                    viewModel = viewModel,
                                    lang = lang,
                                    onPoorQuality = { savedPath ->
                                        pendingPhotoPath = savedPath
                                        isOcrProcessing = false
                                        showPoorQualityDialog = true
                                    },
                                    onError = {
                                        isOcrProcessing = false
                                        isProcessingScan = false
                                        Toast.makeText(
                                            context,
                                            if (lang == AppLanguage.NE) "फोटो लिन सकिएन। पुनः प्रयास गर्नुहोस्।" else "Failed to capture photo. Please try again.",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                )
                            }
                        },
                        enabled = !isOcrProcessing && imageCaptureRef != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("btn_capture_bill"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E))
                    ) {
                        if (isOcrProcessing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = AppStrings.get("scan.ocr_processing", lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.get("scan.capture_btn", lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }

                // Informational helper below viewfinder
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = when (selectedMode) {
                                ScanTargetMode.VENDOR_QR -> Emerald600
                                ScanTargetMode.INVOICE_QR -> Indigo600
                                ScanTargetMode.BILL_OCR -> Color(0xFF0F766E)
                            },
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = when (selectedMode) {
                                ScanTargetMode.VENDOR_QR -> AppStrings.get("scan.mode_vendor_desc", lang)
                                ScanTargetMode.INVOICE_QR -> AppStrings.get("scan.mode_invoice_desc", lang)
                                ScanTargetMode.BILL_OCR -> AppStrings.get("scan.mode_bill_desc", lang)
                            },
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Slate700,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
        }
    }

    // Poor scan quality / unreadable dialog
    if (showPoorQualityDialog) {
        AlertDialog(
            onDismissRequest = {
                showPoorQualityDialog = false
                isProcessingScan = false
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = AppStrings.get("scan.poor_quality_title", lang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = AppStrings.get("scan.poor_quality_desc", lang),
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPoorQualityDialog = false
                        isProcessingScan = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.testTag("btn_retry_ocr")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(AppStrings.get("scan.retry_capture", lang))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPoorQualityDialog = false
                        isProcessingScan = false
                        val prefill = EligibilityPrefillData(
                            amount = 0.0,
                            paymentMethod = PaymentMethod.QR_PAYMENT,
                            sellerName = "",
                            photoReference = pendingPhotoPath
                        )
                        viewModel.openAddInvoice(prefill = prefill)
                    },
                    modifier = Modifier.testTag("btn_manual_ocr")
                ) {
                    Text(AppStrings.get("scan.proceed_manually", lang))
                }
            }
        )
    }
}

private fun captureAndProcessBillPhoto(
    context: Context,
    imageCapture: ImageCapture,
    viewModel: MainViewModel,
    lang: AppLanguage,
    onPoorQuality: (savedPath: String) -> Unit,
    onError: () -> Unit
) {
    val photoDir = File(context.filesDir, "bill_photos").apply { mkdirs() }
    val photoFile = File(photoDir, "bill_${System.currentTimeMillis()}.jpg")
    val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

    val executor = ContextCompat.getMainExecutor(context)
    imageCapture.takePicture(
        outputOptions,
        executor,
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                val inputImage = try {
                    InputImage.fromFilePath(context, Uri.fromFile(photoFile))
                } catch (e: Exception) {
                    onError()
                    return
                }

                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(inputImage)
                    .addOnSuccessListener { visionText ->
                        val rawText = visionText.text
                        val extractedBill = BillDataUtils.extractFromText(rawText)

                        // Check confidence/quality: at least one core field identified or readable text length
                        val hasRecognizedFields = extractedBill.pan.isNotBlank() ||
                                extractedBill.amount.isNotBlank() ||
                                (extractedBill.sellerName.isNotBlank() && extractedBill.sellerName.length > 3) ||
                                extractedBill.invoiceNumber.isNotBlank()

                        val isUsableText = rawText.isNotBlank() && (hasRecognizedFields || rawText.length >= 20)

                        if (isUsableText) {
                            Toast.makeText(
                                context,
                                AppStrings.get("scan.bill_scanned_success", lang),
                                Toast.LENGTH_SHORT
                            ).show()

                            val prefill = EligibilityPrefillData(
                                amount = extractedBill.amount.toDoubleOrNull() ?: 0.0,
                                paymentMethod = PaymentMethod.QR_PAYMENT,
                                panVat = extractedBill.pan.ifBlank { null },
                                sellerName = extractedBill.sellerName,
                                invoiceNumber = extractedBill.invoiceNumber.ifBlank { null },
                                date = extractedBill.date.ifBlank { null },
                                photoReference = photoFile.absolutePath
                            )
                            viewModel.openAddInvoice(prefill = prefill)
                        } else {
                            onPoorQuality(photoFile.absolutePath)
                        }
                    }
                    .addOnFailureListener {
                        onPoorQuality(photoFile.absolutePath)
                    }
            }

            override fun onError(exception: ImageCaptureException) {
                onError()
            }
        }
    )
}

private fun handleScannedCode(
    rawCode: String,
    mode: ScanTargetMode,
    viewModel: MainViewModel,
    lang: AppLanguage,
    context: Context,
    onReset: () -> Unit
) {
    when (mode) {
        ScanTargetMode.VENDOR_QR -> {
            val pan = QrInvoiceParser.extractVendorPan(rawCode)
            if (pan != null && CouponUtils.isValidPanNumber(pan)) {
                val msg = String.format(AppStrings.get("scan.vendor_pan_detected", lang), pan)
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                viewModel.openVerifyVendor(pan)
            } else {
                Toast.makeText(
                    context,
                    AppStrings.get("scan.pan_not_found", lang),
                    Toast.LENGTH_LONG
                ).show()
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    onReset()
                }, 2000)
            }
        }
        ScanTargetMode.INVOICE_QR -> {
            val parsed = QrInvoiceParser.parseInvoiceQr(rawCode)
            if (parsed.isRecognized) {
                Toast.makeText(
                    context,
                    AppStrings.get("scan.invoice_scanned", lang),
                    Toast.LENGTH_SHORT
                ).show()
                val prefill = EligibilityPrefillData(
                    amount = parsed.amount ?: 0.0,
                    paymentMethod = PaymentMethod.QR_PAYMENT,
                    panVat = parsed.sellerPan,
                    sellerName = parsed.sellerName ?: "",
                    invoiceNumber = parsed.invoiceNumber,
                    date = parsed.date
                )
                viewModel.openAddInvoice(prefill = prefill)
            } else {
                Toast.makeText(
                    context,
                    AppStrings.get("scan.invoice_not_recognized", lang),
                    Toast.LENGTH_LONG
                ).show()
                viewModel.openAddInvoice(prefill = null)
            }
        }
        ScanTargetMode.BILL_OCR -> {
            // Bill OCR mode uses image capture shutter action
        }
    }
}

@Composable
fun ScanModeCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    activeColor: Color,
    activeBg: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.surface else Slate100
        ),
        border = if (isSelected) {
            androidx.compose.foundation.BorderStroke(2.dp, activeColor)
        } else {
            androidx.compose.foundation.BorderStroke(1.dp, Slate400.copy(alpha = 0.3f))
        },
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) activeBg else Slate100),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) activeColor else Slate500,
                    modifier = Modifier.size(18.dp)
                )
            }

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                ),
                color = if (isSelected) MaterialTheme.colorScheme.onSurface else Slate700,
                maxLines = 1
            )

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 10.sp,
                    color = Slate500
                ),
                maxLines = 2
            )
        }
    }
}

@Composable
fun CameraPermissionCard(
    lang: AppLanguage,
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("camera_permission_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Text(
                text = AppStrings.get("scan.permission_title", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center
            )

            Text(
                text = AppStrings.get("scan.permission_desc", lang),
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Slate500,
                    fontSize = 13.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onRequestPermission,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("btn_grant_camera_permission"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = AppStrings.get("scan.grant_permission", lang),
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("btn_open_camera_settings"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(AppStrings.get("scan.open_settings", lang))
            }
        }
    }
}

@Composable
fun CameraPreview(
    mode: ScanTargetMode,
    isTorchOn: Boolean,
    onImageCaptureReady: (ImageCapture) -> Unit,
    onBarcodeScanned: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var camera by remember { mutableStateOf<Camera?>(null) }

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val barcodeScanner = remember {
        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE, Barcode.FORMAT_ALL_FORMATS)
            .build()
        BarcodeScanning.getClient(options)
    }

    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
    }

    LaunchedEffect(imageCapture) {
        onImageCaptureReady(imageCapture)
    }

    LaunchedEffect(isTorchOn, camera) {
        try {
            camera?.cameraControl?.enableTorch(isTorchOn)
        } catch (_: Exception) {
            // Torch control not supported on device
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
            barcodeScanner.close()
        }
    }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }

            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val imageAnalysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()

                    imageAnalysis.setAnalyzer(
                        cameraExecutor,
                        BarcodeAnalyzer(barcodeScanner, onBarcodeScanned)
                    )

                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                    cameraProvider.unbindAll()
                    val boundCamera = cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageAnalysis,
                        imageCapture
                    )
                    camera = boundCamera
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }, ContextCompat.getMainExecutor(ctx))

            previewView
        },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
fun ScannerOverlay(
    mode: ScanTargetMode,
    lang: AppLanguage,
    isTorchOn: Boolean,
    isOcrProcessing: Boolean,
    onToggleTorch: () -> Unit,
    onCaptureClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_laser")
    val laserPosition by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_anim"
    )

    val frameColor = when (mode) {
        ScanTargetMode.VENDOR_QR -> Emerald600
        ScanTargetMode.INVOICE_QR -> Indigo600
        ScanTargetMode.BILL_OCR -> Color(0xFF0F766E)
    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // Flashlight toggle button (top right)
        Surface(
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.55f),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(14.dp)
                .clip(CircleShape)
                .clickable { onToggleTorch() }
                .testTag("btn_toggle_torch")
        ) {
            Icon(
                imageVector = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                contentDescription = AppStrings.get("scan.flash_toggle", lang),
                tint = if (isTorchOn) Color(0xFFFFD700) else Color.White,
                modifier = Modifier
                    .padding(10.dp)
                    .size(22.dp)
            )
        }

        // Active mode indicator tag (top left)
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.Black.copy(alpha = 0.55f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(frameColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = when (mode) {
                        ScanTargetMode.VENDOR_QR -> AppStrings.get("scan.vendor_mode_tag", lang)
                        ScanTargetMode.INVOICE_QR -> AppStrings.get("scan.invoice_mode_tag", lang)
                        ScanTargetMode.BILL_OCR -> AppStrings.get("scan.bill_mode_tag", lang)
                    },
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                )
            }
        }

        // Center Viewfinder Target Box
        val boxHeight = if (mode == ScanTargetMode.BILL_OCR) 280.dp else 240.dp
        val boxWidth = if (mode == ScanTargetMode.BILL_OCR) 220.dp else 240.dp
        Box(
            modifier = Modifier
                .size(width = boxWidth, height = boxHeight)
                .align(Alignment.Center)
                .border(2.dp, frameColor.copy(alpha = 0.85f), RoundedCornerShape(18.dp))
        ) {
            if (mode != ScanTargetMode.BILL_OCR) {
                // Scanning laser line for QR modes
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 8.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    frameColor,
                                    Color.Transparent
                                )
                            )
                        )
                )
            }
        }

        // Shutter Button or Alignment hint at bottom of preview
        if (mode == ScanTargetMode.BILL_OCR) {
            // Viewfinder Shutter circular button
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(4.dp, Color(0xFF0F766E)),
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .clickable(enabled = !isOcrProcessing) { onCaptureClick() }
                        .testTag("btn_overlay_shutter")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isOcrProcessing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color(0xFF0F766E),
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = AppStrings.get("scan.capture_btn", lang),
                                tint = Color(0xFF0F766E),
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }
            }
        } else {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp, start = 20.dp, end = 20.dp)
            ) {
                Text(
                    text = AppStrings.get("scan.align_qr_hint", lang),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
    }
}

private class BarcodeAnalyzer(
    private val barcodeScanner: BarcodeScanner,
    private val onBarcodeDetected: (String) -> Unit
) : ImageAnalysis.Analyzer {
    private val isBusy = AtomicBoolean(false)

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null && !isBusy.get()) {
            val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            isBusy.set(true)
            barcodeScanner.process(inputImage)
                .addOnSuccessListener { barcodes ->
                    for (barcode in barcodes) {
                        val rawValue = barcode.rawValue
                        if (!rawValue.isNullOrBlank()) {
                            onBarcodeDetected(rawValue)
                            break
                        }
                    }
                }
                .addOnCompleteListener {
                    isBusy.set(false)
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }
}
