package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Slate500
import com.example.utils.CouponUtils

@Composable
fun AddCouponScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val prefill by viewModel.couponPrefill.collectAsState()
    val editingCouponId by viewModel.editingCouponId.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    val currentDrawInfo by viewModel.currentDrawInfo.collectAsState()

    val editingCoupon = remember(editingCouponId, coupons) {
        coupons.find { it.id == editingCouponId }
    }

    var couponNumber by remember(editingCoupon, prefill) {
        mutableStateOf(editingCoupon?.couponNumber ?: "")
    }
    var merchantName by remember(editingCoupon, prefill) {
        mutableStateOf(editingCoupon?.merchantName ?: prefill?.merchantName ?: "")
    }
    var drawPeriod by remember(editingCoupon, prefill, currentDrawInfo) {
        mutableStateOf(editingCoupon?.drawPeriod ?: prefill?.drawPeriod ?: currentDrawInfo.drawPeriod)
    }
    var invoiceRef by remember(editingCoupon, prefill) {
        mutableStateOf(editingCoupon?.invoiceNumber ?: prefill?.invoiceNumber ?: "")
    }
    var amountText by remember(editingCoupon, prefill) {
        mutableStateOf(
            editingCoupon?.amount?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() }
                ?: prefill?.amount?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() }
                ?: ""
        )
    }
    var notes by remember(editingCoupon) {
        mutableStateOf(editingCoupon?.notes ?: "")
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val digitsOnly = CouponUtils.normalizeCouponNumber(couponNumber)
    val isValid = CouponUtils.isValidCouponNumber(digitsOnly)

    val screenTitle = if (editingCoupon != null) {
        if (lang == AppLanguage.NE) "कुपन विवरण सम्पादन" else "Edit Lucky Coupon"
    } else {
        AppStrings.get("add_coupon.title", lang)
    }

    val submitButtonText = if (editingCoupon != null) {
        if (lang == AppLanguage.NE) "कुपन अपडेट गर्नुहोस्" else "Update Coupon"
    } else {
        AppStrings.get("add_coupon.save_btn", lang)
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = screenTitle,
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = AppStrings.get("add_coupon.card_title", lang),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    OutlinedTextField(
                        value = couponNumber,
                        onValueChange = {
                            val clean = it.filter { c -> c.isDigit() }.take(12)
                            couponNumber = clean
                            if (errorMessage != null) errorMessage = null
                        },
                        label = { Text(AppStrings.get("add_coupon.coupon_label", lang)) },
                        placeholder = { Text(AppStrings.get("add_coupon.coupon_placeholder", lang)) },
                        trailingIcon = {
                            Text(
                                text = "${digitsOnly.length}/12",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isValid) Emerald600 else Slate500,
                                    fontWeight = if (isValid) FontWeight.Bold else FontWeight.Normal
                                ),
                                modifier = Modifier.padding(end = 12.dp)
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_coupon_12digit"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (digitsOnly.isNotEmpty()) {
                        Text(
                            text = "Formatted: ${CouponUtils.formatCouponNumber(digitsOnly)}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (isValid) Emerald600 else Slate500,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    OutlinedTextField(
                        value = merchantName,
                        onValueChange = { merchantName = it },
                        label = { Text(AppStrings.get("add_coupon.merchant_name", lang)) },
                        placeholder = { Text(AppStrings.get("add_coupon.merchant_placeholder", lang)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_coupon_merchant"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = drawPeriod,
                        onValueChange = { drawPeriod = it },
                        label = { Text(AppStrings.get("add_coupon.draw_period", lang)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_coupon_draw_period"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = invoiceRef,
                        onValueChange = { invoiceRef = it },
                        label = { Text(AppStrings.get("add_coupon.invoice_ref", lang) + " (${AppStrings.get("common.optional", lang)})") },
                        placeholder = { Text(AppStrings.get("add_coupon.invoice_placeholder", lang)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_coupon_invoice_ref"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text(AppStrings.get("add_coupon.amount_npr", lang) + " (${AppStrings.get("common.optional", lang)})") },
                        placeholder = { Text(AppStrings.get("add_coupon.amount_placeholder", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_coupon_amount"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Button(
                onClick = {
                    if (!isValid) {
                        errorMessage = if (lang == AppLanguage.NE) "कुपन नम्बर ठिक १२ अंकको हुनुपर्छ" else "Coupon number must be exactly 12 numeric digits"
                        return@Button
                    }
                    val ok = if (editingCoupon != null) {
                        viewModel.updateCoupon(
                            id = editingCoupon.id,
                            couponNumber = digitsOnly,
                            merchantName = merchantName.ifBlank { null },
                            amount = amountText.toDoubleOrNull(),
                            drawPeriod = drawPeriod.ifBlank { null },
                            invoiceNumber = invoiceRef.ifBlank { null },
                            notes = notes.ifBlank { null }
                        )
                    } else {
                        viewModel.saveCoupon(
                            couponNumber = digitsOnly,
                            merchantName = merchantName.ifBlank { null },
                            amount = amountText.toDoubleOrNull(),
                            drawPeriod = drawPeriod.ifBlank { null },
                            invoiceNumber = invoiceRef.ifBlank { null },
                            notes = notes.ifBlank { null }
                        )
                    }
                    if (ok) {
                        viewModel.navigateBack()
                    } else {
                        errorMessage = if (lang == AppLanguage.NE) "कुपन सुरक्षित गर्न सकिएन" else "Failed to save coupon"
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_save_coupon_submit"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = submitButtonText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}
