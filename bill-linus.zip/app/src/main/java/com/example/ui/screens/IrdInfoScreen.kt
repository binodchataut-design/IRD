package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.ScreenName
import com.example.ui.MainViewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppHeader
import com.example.ui.theme.Amber100
import com.example.ui.theme.Amber500
import com.example.ui.theme.Amber600
import com.example.ui.theme.BrandGreenDark
import com.example.ui.theme.BrandGreenLight
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Indigo100
import com.example.ui.theme.Indigo600
import com.example.ui.theme.Red100
import com.example.ui.theme.Red600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

enum class GuideSection {
    ALL,
    PRIZES,
    CLAIM,
    CASH_GUIDE,
    ELIGIBILITY_RULES,
    VAT_REFUND,
    FAQS
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun IrdInfoScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    var selectedFilter by remember { mutableStateOf(GuideSection.ALL) }

    Scaffold(
        topBar = {
            AppHeader(
                title = if (lang == AppLanguage.NE) "करदाता प्रोत्साहन उपहार गाइड" else "IRD Taxpayer Prize Guide",
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = currentScreen,
                lang = lang,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Official IRD Guideline Banner
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (lang == AppLanguage.NE) "नेपाल सरकार • आन्तरिक राजस्व विभाग" else "Government of Nepal • IRD",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            )
                            Text(
                                text = if (lang == AppLanguage.NE) "करदाता प्रोत्साहन उपहार कार्यक्रम कार्यविधि" else "Taxpayer Incentive Prize Program",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                    }

                    Text(
                        text = if (lang == AppLanguage.NE)
                            "उपभोक्ताहरूलाई वास्तविक कर बिजक (VAT/PAN Bill) लिन र डिजिटल भुक्तानी गर्न प्रोत्साहित गर्न आन्तरिक राजस्व विभागले दैनिक १ लाख र पाक्षिक (१५ दिनमा) १० लाख बम्पर नगद पुरस्कारसहितको आधिकारिक कार्यक्रम सञ्चालन गरेको छ।"
                        else
                            "As per the official IRD guidelines (ird.gov.np/category/prize-program), consumers demanding genuine tax invoices (VAT/PAN bills) can win Daily Prizes of NPR 1 Lakh and Fortnightly Bumper Prizes of NPR 10 Lakhs, plus 10% instant VAT refund on digital payments.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White.copy(alpha = 0.95f),
                            lineHeight = 20.sp
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color.White.copy(alpha = 0.18f),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = if (lang == AppLanguage.NE) "दैनिक उपहार" else "Daily Prize",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = if (lang == AppLanguage.NE) "रु १,००,००० / दिन" else "NPR 1,00,000 / day",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.ExtraBold)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color.White.copy(alpha = 0.18f),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = if (lang == AppLanguage.NE) "बम्पर उपहार (१५ दिनमा)" else "Bumper Prize (15 Days)",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = if (lang == AppLanguage.NE) "रु १०,००,०००" else "NPR 10,00,000",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.ExtraBold)
                                )
                            }
                        }
                    }
                }
            }

            // Quick Filter Chips
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == GuideSection.ALL,
                    onClick = { selectedFilter = GuideSection.ALL },
                    label = { Text(if (lang == AppLanguage.NE) "सबै जानकारी" else "All Details") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedFilter == GuideSection.PRIZES,
                    onClick = { selectedFilter = GuideSection.PRIZES },
                    label = { Text(if (lang == AppLanguage.NE) "🏆 पुरस्कार राशि" else "🏆 Prize Amounts") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedFilter == GuideSection.CLAIM,
                    onClick = { selectedFilter = GuideSection.CLAIM },
                    label = { Text(if (lang == AppLanguage.NE) "📝 दाबी प्रक्रिया (१५ दिन)" else "📝 Claim Process (15 Days)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedFilter == GuideSection.CASH_GUIDE,
                    onClick = { selectedFilter = GuideSection.CASH_GUIDE },
                    label = { Text(if (lang == AppLanguage.NE) "💵 नगद बिल दर्ता" else "💵 Cash Bill Upload") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedFilter == GuideSection.ELIGIBILITY_RULES,
                    onClick = { selectedFilter = GuideSection.ELIGIBILITY_RULES },
                    label = { Text(if (lang == AppLanguage.NE) "⚖️ योग्य / अयोग्य मापदण्ड" else "⚖️ Eligible Items") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedFilter == GuideSection.FAQS,
                    onClick = { selectedFilter = GuideSection.FAQS },
                    label = { Text(if (lang == AppLanguage.NE) "❓ सोधिने प्रश्नहरू" else "❓ FAQs") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    )
                )
            }

            // SECTION 1: Official Prize Amounts (as per ird.gov.np category prize program)
            if (selectedFilter == GuideSection.ALL || selectedFilter == GuideSection.PRIZES) {
                SectionHeader(
                    title = if (lang == AppLanguage.NE) "आधिकारिक पुरस्कार राशि (Prize Scheme)" else "Official Prize Amounts (IRD Guidelines)",
                    subtitle = if (lang == AppLanguage.NE) "आन्तरिक राजस्व विभागद्वारा निर्धारित दैनिक र पाक्षिक नगद पुरस्कार" else "Daily and Fortnightly cash awards declared by IRD Nepal"
                )

                // Bumper Prize
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Amber100,
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = null,
                                    tint = Amber600,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (lang == AppLanguage.NE) "बम्पर उपहार (पाक्षिक)" else "Bumper Prize (Fortnightly)",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "NPR 10,00,000",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Emerald600
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (lang == AppLanguage.NE)
                                    "हरेक १५ दिनमा १ जना भाग्यशाली उपभोक्तालाई १० लाख (कर कट्टी पछि ७ लाख ५० हजार)"
                                else
                                    "One lucky consumer every 15 days wins Rs. 10 Lakhs (Rs. 7,50,000 net after 25% windfall tax)",
                                style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 12.sp)
                            )
                        }
                    }
                }

                // Daily Cash Prize
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Indigo100,
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MilitaryTech,
                                    contentDescription = null,
                                    tint = Indigo600,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (lang == AppLanguage.NE) "दैनिक नगद उपहार" else "Daily Cash Prize",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "NPR 1,00,000",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Indigo600
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (lang == AppLanguage.NE)
                                    "प्रत्येक दिन १ जना विजेतालाई कर कट्टी पछिको नगद रु १,००,०००"
                                else
                                    "Daily winner receives net NPR 1,00,000 cash (Rs. 1,33,334 gross before 25% tax)",
                                style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 12.sp)
                            )
                        }
                    }
                }

                // Draw Schedule Note
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = Slate700,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (lang == AppLanguage.NE)
                                "ड्र तालिका: प्रत्येक महिनाको १६ गते (पहिलो पाक्षिक) र महिनाको अन्तिम दिन (दोस्रो पाक्षिक) स्वचालित कम्प्युटर प्रणालीबाट नतिजा घोषणा गरिन्छ।"
                            else
                                "Draw Announcement: Results are officially declared twice a month on the 16th day and final day of every Nepali month via automated draws.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate700, lineHeight = 16.sp)
                        )
                    }
                }
            }

            // SECTION 2: Step-by-Step Claim Process (15 Days Window)
            if (selectedFilter == GuideSection.ALL || selectedFilter == GuideSection.CLAIM) {
                SectionHeader(
                    title = if (lang == AppLanguage.NE) "पुरस्कार दाबी प्रक्रिया (१५ दिनको म्याद)" else "How to Claim (15-Day Time Limit)",
                    subtitle = if (lang == AppLanguage.NE) "नतिजा सार्वजनिक भएको १५ दिन भित्र यसरी दाबी पेश गर्नुहोस्" else "Mandatory verification and documentation guidelines as per IRD"
                )

                StepCard(
                    stepNumber = "१",
                    title = if (lang == AppLanguage.NE) "१. विजयी नम्बर रुजु गर्नुहोस्" else "Step 1: Verify Winning Coupon",
                    desc = if (lang == AppLanguage.NE)
                        "आन्तरिक राजस्व विभागको आधिकारिक पोर्टल (prize.ird.gov.np वा ird.gov.np/category/prize-program) मा प्रकाशित विजयी १२-अंकीय कुपनसँग आफ्नो कुपन नम्बर जाँच्नुहोस्।"
                    else
                        "Check your 12-digit coupon number against the official winning list on prize.ird.gov.np or ird.gov.np/category/prize-program.",
                    icon = Icons.Default.CheckCircle,
                    color = Emerald600,
                    bg = Emerald100
                )

                StepCard(
                    stepNumber = "२",
                    title = if (lang == AppLanguage.NE) "२. आवश्यक कागजातहरू जुटाउनुहोस्" else "Step 2: Gather Mandatory Documents",
                    desc = if (lang == AppLanguage.NE)
                        "निम्न कागजातहरू अनिवार्य पेश गर्नुपर्छ:\n• सक्कल कर बिजक (Original Computerized Tax Invoice)\n• १२-अंकीय कुपन रेकर्ड / दर्ता प्रमाण\n• नेपाली नागरिकताको प्रमाणपत्र, राष्ट्रिय परिचयपत्र, राहदानी वा सवारी चालक अनुमतिपत्रको प्रतिलिपि\n• आफ्नै नामको बैंक खाता विवरण (Cheque Copy वा Bank Statement)\n• व्यक्तिगत प्यान (PAN) कार्ड"
                    else
                        "Mandatory documents required:\n• Original Tax Invoice (सक्कल कर बिजक)\n• 12-digit coupon record\n• Copy of Nepali Citizenship, National ID, Passport, or Driver's License\n• Bank Account details in your name (Cheque / Statement)\n• Personal PAN Card",
                    icon = Icons.Default.Description,
                    color = Indigo600,
                    bg = Indigo100
                )

                StepCard(
                    stepNumber = "३",
                    title = if (lang == AppLanguage.NE) "३. १५ दिन भित्र दाबी पेश गर्नुहोस्" else "Step 3: Submit Claim within 15 Days",
                    desc = if (lang == AppLanguage.NE)
                        "नतिजा घोषणा भएको मितिले १५ दिन (15 Days) भित्र नजिकको आन्तरिक राजस्व कार्यालय (IRO), करदाता सेवा कार्यालय (TSO) वा prize.ird.gov.np मार्फत दाबी दर्ता गर्नुहोस्।"
                    else
                        "Submit your claim within 15 days of the draw declaration at your nearest Inland Revenue Office (IRO), Taxpayer Service Office (TSO), or directly on prize.ird.gov.np.",
                    icon = Icons.Default.AccountBalance,
                    color = Amber600,
                    bg = Amber100
                )

                StepCard(
                    stepNumber = "४",
                    title = if (lang == AppLanguage.NE) "४. बैंक खातामा सिधै रकम भुक्तानी" else "Step 4: Direct Bank Transfer",
                    desc = if (lang == AppLanguage.NE)
                        "केन्द्रीय बिलिङ अनुगमन प्रणाली (CBMS) सँग बिल प्रमाणीकरण भएपछि आयकर ऐन बमोजिम २५% आकस्मिक लाभ कर कट्टी गरी बाँकी रकम तपाईंको बैंक खातामा पठाइन्छ।"
                    else
                        "Once the original tax invoice is cross-verified with the CBMS system, the net prize amount (after 25% windfall tax deduction) is deposited directly to your bank account.",
                    icon = Icons.Default.MonetizationOn,
                    color = BrandGreenDark,
                    bg = BrandGreenLight
                )
            }

            // SECTION 3: Cash Payment & Upload Guide
            if (selectedFilter == GuideSection.ALL || selectedFilter == GuideSection.CASH_GUIDE) {
                SectionHeader(
                    title = if (lang == AppLanguage.NE) "नगद भुक्तानीमा कसरी सहभागी हुने?" else "Cash Payments: How to Participate",
                    subtitle = if (lang == AppLanguage.NE) "नगदमा तिरे पनि कर बिजक दर्ता गरी लटरी कुपन लिन सकिन्छ" else "Obtain your tax invoice and register on prize.ird.gov.np"
                )

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = BrandGreenLight,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Receipt,
                                        contentDescription = null,
                                        tint = BrandGreenDark,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (lang == AppLanguage.NE) "नगद खरिदकर्ताका लागि कार्यविधि नियम" else "Official Rule for Cash Purchases",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Text(
                            text = if (lang == AppLanguage.NE)
                                "१. रु १०० भन्दा बढीको कुनै पनि सामान वा सेवा किन्दा पसलेसँग अनिवार्य प्यान/भ्याट नम्बर र चलानी नम्बर भएको सक्कल कर बिजक माग्नुहोस्।\n\n२. आधिकारिक पोर्टल prize.ird.gov.np मा जानुहोस् वा IRD को वेबसाइट (ird.gov.np) मा प्रवेश गर्नुहोस्।\n\n३. बिलमा उल्लेखित बिक्रेताको ९-अंकीय प्यान (PAN), चलानी नम्बर, खरिद मिति र कुल रकम प्रविष्ट गर्नुहोस्।\n\n४. प्रणालीले तत्काल १२-अंकीय आधिकारिक कुपन नम्बर उपलब्ध गराउनेछ। उक्त कुपन बिल लिनुहोस् (Bill Linus) मा सुरक्षित राख्नुहोस्।"
                            else
                                "1. When making purchases over Rs. 100 in cash for personal use, demand a computer-printed Tax Invoice showing the 9-digit PAN/VAT and invoice number.\n\n2. Open the official IRD portal: prize.ird.gov.np.\n\n3. Enter the Seller's 9-digit PAN, Invoice Number, Purchase Date, and Total Amount.\n\n4. The system immediately generates your official 12-digit Coupon Number. Save it into Bill Linus to monitor winning draws!",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Slate700,
                                lineHeight = 20.sp
                            )
                        )

                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://prize.ird.gov.np"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandGreenDark)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == AppLanguage.NE) "prize.ird.gov.np मा बिल दर्ता गर्नुहोस्" else "Register Bill on prize.ird.gov.np",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // SECTION 4: Eligibility Criteria (Eligible vs Ineligible as per IRD Guidelines)
            if (selectedFilter == GuideSection.ALL || selectedFilter == GuideSection.ELIGIBILITY_RULES) {
                SectionHeader(
                    title = if (lang == AppLanguage.NE) "योग्य तथा अयोग्य खरिद मापदण्ड" else "Eligible vs Ineligible Criteria",
                    subtitle = if (lang == AppLanguage.NE) "कार्यविधि अनुसार कुन कारोबार योग्य र कुन अयोग्य हुन्छ?" else "Transactions eligible according to IRD Prize Directives"
                )

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Emerald100.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Emerald600, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == AppLanguage.NE) "सहभागी हुन योग्य कारोबारहरू:" else "Eligible Transactions:",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Emerald600)
                            )
                        }
                        Text(
                            text = if (lang == AppLanguage.NE)
                                "• व्यक्तिगत/घरायसी प्रयोजनका लागि रु १०० भन्दा बढीको खरिद\n• प्यान/भ्याट दर्ता भएका बिक्रेताबाट जारी आधिकारिक कर बिजक\n• QR/कार्ड/मोबाइल बैंकिङबाट भुक्तानी (स्वतः दर्ता)\n• नगद भुक्तानी (पोर्टलमा बिजक दर्ता गरी कुपन प्राप्त भएको)"
                            else
                                "• Single purchases exceeding NPR 100 for personal/household consumption\n• Official computerized VAT/PAN tax invoices from registered vendors\n• Digital payments via QR, Cards, Mobile Banking (automatically registered)\n• Cash payments registered on prize.ird.gov.np",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate700, lineHeight = 18.sp)
                        )
                    }
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Red100.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Block, contentDescription = null, tint = Red600, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == AppLanguage.NE) "योजनामा समावेश नहुने (अयोग्य) कारोबारहरू:" else "Ineligible / Excluded Transactions:",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Red600)
                            )
                        }
                        Text(
                            text = if (lang == AppLanguage.NE)
                                "• व्यापारिक तथा व्यावसायिक प्रयोजनका खरिद\n• सरकारी निकाय तथा सार्वजनिक संस्थानका खरिद\n• उपयोगिता सेवा (विद्युत, खानेपानी, टेलिफोन बिल आदि)\n• सवारी साधन (गाडी/मोटरसाइकल) खरिद\n• ढुवानी सेवा तथा हवाइजहाजको टिकट\n• प्यान नम्बर नभएका गैर-दर्ता व्यापारीसँगको कारोबार"
                            else
                                "• Purchases made for commercial / business resale\n• Purchases by government entities or public institutions\n• Utility bill payments (electricity, water, landline)\n• Purchase of motor vehicles\n• Transportation / cargo freight services and airline tickets\n• Purchases from vendors without valid PAN registration",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate700, lineHeight = 18.sp)
                        )
                    }
                }
            }

            // SECTION 5: FAQs Accordion
            if (selectedFilter == GuideSection.ALL || selectedFilter == GuideSection.FAQS) {
                SectionHeader(
                    title = if (lang == AppLanguage.NE) "प्रायः सोधिने प्रश्नहरू (FAQs)" else "Frequently Asked Questions",
                    subtitle = if (lang == AppLanguage.NE) "आन्तरिक राजस्व विभागको उपहार कार्यक्रम सम्बन्धी जिज्ञासाहरू" else "Official answers based on IRD guidelines"
                )

                FaqAccordionItem(
                    question = if (lang == AppLanguage.NE) "पुरस्कार कति कति समयमा घोषणा हुन्छ?" else "How frequently are prizes drawn?",
                    answer = if (lang == AppLanguage.NE)
                        "आन्तरिक राजस्व विभागले महिनाको दुई पटक (प्रत्येक महिनाको १६ गते र महिनाको अन्तिम दिन) स्वचालित प्रणालीबाट नतिजा सार्वजनिक गर्दछ। जसमा दैनिक १ लाख र पाक्षिक १० लाखका विजेता घोषणा हुन्छन्।"
                    else
                        "The Inland Revenue Department conducts automatic draws twice a month (on the 16th and the last day of each Nepali month), declaring Daily Rs. 1 Lakh and Fortnightly Rs. 10 Lakh winners."
                )

                FaqAccordionItem(
                    question = if (lang == AppLanguage.NE) "पुरस्कार दाबी गर्ने म्याद कति दिन हुन्छ?" else "How many days do I have to claim my prize?",
                    answer = if (lang == AppLanguage.NE)
                        "नतिजा घोषणा भएको मितिले १५ दिन (15 days) भित्र आवश्यक कागजातसहित नजिकको आन्तरिक राजस्व कार्यालय, करदाता सेवा कार्यालय वा अनलाइन पोर्टलमा दाबी पेश गर्नुपर्छ।"
                    else
                        "You must submit your claim within 15 days of the official prize declaration at your nearest IRO/TSO tax office or on the prize.ird.gov.np portal."
                )

                FaqAccordionItem(
                    question = if (lang == AppLanguage.NE) "के पुरस्कार रकममा कर लाग्छ?" else "Is tax deducted from the prize money?",
                    answer = if (lang == AppLanguage.NE)
                        "हो, आयकर ऐन २०५८ बमोजिम २५% आकस्मिक लाभ कर (Windfall Tax) कट्टी गरी बाँकी रकम विजेताको बैंक खातामा जम्मा गरिन्छ।"
                    else
                        "Yes, as per the Nepal Income Tax Act 2058, 25% windfall gain tax is deducted at source before depositing the net prize into the winner's verified bank account."
                )

                FaqAccordionItem(
                    question = if (lang == AppLanguage.NE) "डिजिटल भुक्तानी गर्दा स्वतः कुपन आउँछ?" else "Are digital payments automatically entered?",
                    answer = if (lang == AppLanguage.NE)
                        "हो, QR (Fonepay, NepalPay), वालेट वा कार्डबाट रु १०० भन्दा बढीको भुक्तानी गर्दा प्रणालीले स्वतः कुपन दर्ता गर्छ। तर पुरस्कार दाबी गर्न सक्कल कर बिजक सुरक्षित राख्नुपर्छ।"
                    else
                        "Yes, transactions over Rs. 100 via QR codes, mobile banking, wallets, and cards are automatically submitted. However, you must keep the physical tax invoice to claim any prize."
                )

                FaqAccordionItem(
                    question = if (lang == AppLanguage.NE) "पसलेले कर बिजक नदिएमा कहाँ उजुरी गर्ने?" else "Where to complain if a shopkeeper denies a tax invoice?",
                    answer = if (lang == AppLanguage.NE)
                        "मूल्य अभिवृद्धि कर ऐन अनुसार बिक्रेताले कर बिजक दिनैपर्छ। अस्वीकार गरेमा आन्तरिक राजस्व विभागको टोल-फ्री १६६००१००२६० वा info@ird.gov.np मा उजुरी गर्न सकिन्छ।"
                    else
                        "Sellers are legally obligated to issue genuine tax invoices. Refusals can be reported directly to the IRD toll-free helpline at 16600100260 or via email at info@ird.gov.np."
                )
            }

            // Quick Portal Links & Official Guidelines Access
            SectionHeader(
                title = if (lang == AppLanguage.NE) "आधिकारिक लिङ्क तथा स्रोतहरू" else "Official Links & Verification Portals",
                subtitle = if (lang == AppLanguage.NE) "आन्तरिक राजस्व विभागको आधिकारिक सूचना पोर्टल" else "Direct access to IRD official prize pages"
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://prize.ird.gov.np"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_open_prize_portal"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandGreenDark)
                ) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "prize.ird.gov.np",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://ird.gov.np/category/prize-program/"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_open_ird_category"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (lang == AppLanguage.NE) "कार्यविधि सूचना" else "Prize Directives",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            // Official IRD Contact Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Slate100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Call, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == AppLanguage.NE) "आन्तरिक राजस्व विभाग सम्पर्क ठेगाना" else "Inland Revenue Department Contacts",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Text(
                        text = if (lang == AppLanguage.NE)
                            "• टोल-फ्री हटलाइन: 16600100260\n• मुख्य पोर्टल: ird.gov.np\n• उपहार पोर्टल: prize.ird.gov.np\n• केन्द्रीय कार्यालय: लाजिम्पाट, काठमाडौँ\n• ईमेल: info@ird.gov.np"
                        else
                            "• Toll-Free Helpline: 16600100260\n• Main Website: ird.gov.np\n• Prize Portal: prize.ird.gov.np\n• Head Office: Lazimpat, Kathmandu\n• Email: info@ird.gov.np",
                        style = MaterialTheme.typography.bodySmall.copy(color = Slate700, lineHeight = 18.sp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
fun SectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 12.sp)
        )
    }
}

@Composable
fun StepCard(
    stepNumber: String,
    title: String,
    desc: String,
    icon: ImageVector,
    color: Color,
    bg: Color
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                shape = CircleShape,
                color = bg,
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Slate700,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                )
            }
        }
    }
}

@Composable
fun FaqAccordionItem(question: String, answer: String) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = question,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = Slate900
                        )
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = Slate500,
                    modifier = Modifier.size(20.dp)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 10.dp, start = 26.dp)) {
                    HorizontalDivider(color = Slate200, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = answer,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Slate700,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )
                    )
                }
            }
        }
    }
}
