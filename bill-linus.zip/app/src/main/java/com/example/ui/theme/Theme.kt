package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

private val LightColorScheme = lightColorScheme(
    primary = BrandNavy,
    onPrimary = Color.White,
    primaryContainer = BrandNavyLight,
    onPrimaryContainer = BrandNavy,
    secondary = BrandGreen,
    onSecondary = Color.White,
    secondaryContainer = BrandGreenBg,
    onSecondaryContainer = BrandGreen,
    tertiary = Amber500,
    onTertiary = Color.White,
    tertiaryContainer = Amber50,
    onTertiaryContainer = Amber600,
    background = PageBackground,
    onBackground = Slate900,
    surface = CardBackground,
    onSurface = Slate900,
    surfaceVariant = Slate100,
    onSurfaceVariant = Slate700,
    outline = Slate300,
    outlineVariant = Slate200,
    error = Red600,
    onError = Color.White,
    errorContainer = Red50,
    onErrorContainer = Red600
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF93C5FD),
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF1E3A5F),
    onPrimaryContainer = Color(0xFFE2E8F0),
    secondary = Emerald400,
    onSecondary = Color(0xFF064E3B),
    secondaryContainer = Color(0xFF064E3B),
    onSecondaryContainer = Emerald100,
    tertiary = Amber400,
    onTertiary = Color(0xFF78350F),
    tertiaryContainer = Color(0xFF78350F),
    onTertiaryContainer = Amber100,
    background = Color(0xFF0F172A),
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF1E293B),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF475569),
    outlineVariant = Color(0xFF334155),
    error = Red400,
    onError = Color(0xFF7F1D1D),
    errorContainer = Red900,
    onErrorContainer = Red100
)

fun getScaledTypography(scaleFactor: Float): Typography {
    fun scaleStyle(style: TextStyle): TextStyle {
        val newSize = (style.fontSize.value * scaleFactor).sp
        val newLineHeight = if (style.lineHeight.value > 0) {
            (style.lineHeight.value * scaleFactor).sp
        } else {
            style.lineHeight
        }
        return style.copy(
            fontSize = newSize,
            lineHeight = newLineHeight
        )
    }

    return Typography(
        displayLarge = scaleStyle(Typography.displayLarge),
        displayMedium = scaleStyle(Typography.displayMedium),
        displaySmall = scaleStyle(Typography.displaySmall),
        headlineLarge = scaleStyle(Typography.headlineLarge),
        headlineMedium = scaleStyle(Typography.headlineMedium),
        headlineSmall = scaleStyle(Typography.headlineSmall),
        titleLarge = scaleStyle(Typography.titleLarge),
        titleMedium = scaleStyle(Typography.titleMedium),
        titleSmall = scaleStyle(Typography.titleSmall),
        bodyLarge = scaleStyle(Typography.bodyLarge),
        bodyMedium = scaleStyle(Typography.bodyMedium),
        bodySmall = scaleStyle(Typography.bodySmall),
        labelLarge = scaleStyle(Typography.labelLarge),
        labelMedium = scaleStyle(Typography.labelMedium),
        labelSmall = scaleStyle(Typography.labelSmall)
    )
}

@Composable
fun BillLinusTheme(
    darkTheme: Boolean = false,
    fontScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val typography = remember(fontScale) { getScaledTypography(fontScale) }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun RasidKhataTheme(
    darkTheme: Boolean = false,
    fontScale: Float = 1.0f,
    content: @Composable () -> Unit
) = BillLinusTheme(darkTheme = darkTheme, fontScale = fontScale, content = content)
