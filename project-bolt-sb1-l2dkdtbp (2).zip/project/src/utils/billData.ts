import { isValidPanNumber } from '@/utils/couponUtils';

export interface BillData {
  sellerName: string;
  pan: string;
  invoiceNumber: string;
  date: string;
  amount: string;
}

export const EMPTY_BILL_DATA: BillData = {
  sellerName: '',
  pan: '',
  invoiceNumber: '',
  date: '',
  amount: '',
};

export const BILL_DATA_FIELDS: (keyof BillData)[] = [
  'sellerName',
  'pan',
  'invoiceNumber',
  'date',
  'amount',
];

export function normalizeAmount(value: string): string {
  if (!value) return '';
  let cleaned = value;
  cleaned = cleaned.replace(/rs\.?/gi, '').replace(/npr\.?/gi, '');
  cleaned = cleaned.replace(/[रूरु।]/g, '');
  cleaned = cleaned.replace(/[,\s]/g, '');
  const match = cleaned.match(/\d+(?:\.\d{1,2})?/);
  return match ? match[0] : '';
}

export function normalizeDate(value: string): string {
  if (!value) return '';
  const isoMatch = value.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (isoMatch) return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;
  const slashMatch = value.match(/(\d{1,2})[/.](\d{1,2})[/.](\d{2,4})/);
  if (slashMatch) {
    const [, d, m, y] = slashMatch;
    const year = y.length === 2 ? `20${y}` : y;
    const mm = m.padStart(2, '0');
    const dd = d.padStart(2, '0');
    return `${year}-${mm}-${dd}`;
  }
  return '';
}

export function normalizePan(value: string): string {
  if (!value) return '';
  return value.replace(/\D/g, '');
}

export function normalizeBillData(data: Partial<BillData>): BillData {
  return {
    sellerName: (data.sellerName || '').trim(),
    pan: normalizePan(data.pan || ''),
    invoiceNumber: (data.invoiceNumber || '').trim(),
    date: normalizeDate(data.date || ''),
    amount: normalizeAmount(data.amount || ''),
  };
}

export function isFieldConflict(current: string, candidate: string): boolean {
  const c = current.trim();
  const cand = candidate.trim();
  return c !== '' && cand !== '' && c !== cand;
}

export function hasAnyConflict(current: BillData, candidate: BillData): boolean {
  return BILL_DATA_FIELDS.some((f) => isFieldConflict(current[f], candidate[f]));
}
