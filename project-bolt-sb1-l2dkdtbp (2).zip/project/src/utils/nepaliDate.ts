import type { AppLanguage } from '@/types';

export interface DrawPeriodInfo {
  drawPeriod: string;
  drawPeriodId: string;
  expectedAnnouncement: string;
  cycleName: string;
  isExact: boolean;
}

export interface BSDate {
  year: number;
  month: number;
  day: number;
}

const BS_MONTHS_EN = [
  '', 'Baisakh', 'Jestha', 'Ashadh', 'Shrawan', 'Bhadra',
  'Ashwin', 'Kartik', 'Mangsir', 'Poush', 'Magh', 'Falgun', 'Chaitra',
];

const BS_MONTHS_NE = [
  '', 'बैशाख', 'जेठ', 'असार', 'साउन', 'भदौ',
  'असोज', 'कार्तिक', 'मंसिर', 'पुष', 'माघ', 'फागुन', 'चैत',
];

// Days in each BS month for years 2000–2090 BS.
// Each row: [year, Baisakh, Jestha, Ashadh, Shrawan, Bhadra, Ashwin,
//           Kartik, Mangsir, Poush, Magh, Falgun, Chaitra]
const BS_CALENDAR: number[][] = [
  [2000,30,32,31,32,31,30,30,30,29,30,29,31],
  [2001,31,31,32,31,31,31,30,29,30,29,30,30],
  [2002,31,31,32,32,31,30,30,29,30,29,30,30],
  [2003,31,32,31,32,31,30,30,30,29,29,30,31],
  [2004,30,32,31,32,31,30,30,30,29,30,29,31],
  [2005,31,31,32,31,31,31,30,29,30,29,30,30],
  [2006,31,31,32,32,31,30,30,29,30,29,30,30],
  [2007,31,32,31,32,31,30,30,30,29,29,30,31],
  [2008,31,31,31,32,31,31,29,30,30,29,29,31],
  [2009,31,31,32,31,31,31,30,29,30,29,30,30],
  [2010,31,31,32,32,31,30,30,29,30,29,30,30],
  [2011,31,32,31,32,31,30,30,30,29,29,30,31],
  [2012,31,31,31,32,31,31,29,30,30,29,30,30],
  [2013,31,31,32,31,31,31,30,29,30,29,30,30],
  [2014,31,31,32,32,31,30,30,29,30,29,30,30],
  [2015,31,32,31,32,31,30,30,30,29,29,30,31],
  [2016,31,31,31,32,31,31,29,30,30,29,30,30],
  [2017,31,31,32,31,31,31,30,29,30,29,30,30],
  [2018,31,32,31,32,31,30,30,29,30,29,30,30],
  [2019,31,32,31,32,31,30,30,30,29,30,29,31],
  [2020,31,31,31,32,31,31,30,29,30,29,30,30],
  [2021,31,31,32,31,31,31,30,29,30,29,30,30],
  [2022,31,32,31,32,31,30,30,30,29,29,30,30],
  [2023,31,32,31,32,31,30,30,30,29,30,29,31],
  [2024,31,31,31,32,31,31,30,29,30,29,30,30],
  [2025,31,31,32,31,31,31,30,29,30,29,30,30],
  [2026,31,32,31,32,31,30,30,30,29,29,30,31],
  [2027,30,32,31,32,31,30,30,30,29,30,29,31],
  [2028,31,31,32,31,31,31,30,29,30,29,30,30],
  [2029,31,31,32,31,32,30,30,29,30,29,30,30],
  [2030,31,32,31,32,31,30,30,30,29,29,30,31],
  [2031,30,32,31,32,31,30,30,30,29,30,29,31],
  [2032,31,31,32,31,31,31,30,29,30,29,30,30],
  [2033,31,31,32,32,31,30,30,29,30,29,30,30],
  [2034,31,32,31,32,31,30,30,30,29,29,30,31],
  [2035,30,32,31,32,31,31,29,30,30,29,29,31],
  [2036,31,31,32,31,31,31,30,29,30,29,30,30],
  [2037,31,31,32,32,31,30,30,29,30,29,30,30],
  [2038,31,32,31,32,31,30,30,30,29,29,30,31],
  [2039,31,31,31,32,31,31,29,30,30,29,30,30],
  [2040,31,31,32,31,31,31,30,29,30,29,30,30],
  [2041,31,31,32,32,31,30,30,29,30,29,30,30],
  [2042,31,32,31,32,31,30,30,30,29,29,30,31],
  [2043,31,31,31,32,31,31,29,30,30,29,30,30],
  [2044,31,31,32,31,31,31,30,29,30,29,30,30],
  [2045,31,32,31,32,31,30,30,29,30,29,30,30],
  [2046,31,32,31,32,31,30,30,30,29,29,30,31],
  [2047,31,31,31,32,31,31,30,29,30,29,30,30],
  [2048,31,31,32,31,31,31,30,29,30,29,30,30],
  [2049,31,32,31,32,31,30,30,30,29,29,30,30],
  [2050,31,32,31,32,31,30,30,30,29,30,29,31],
  [2051,31,31,31,32,31,31,30,29,30,29,30,30],
  [2052,31,31,32,31,31,31,30,29,30,29,30,30],
  [2053,31,32,31,32,31,30,30,30,29,29,30,30],
  [2054,31,32,31,32,31,30,30,30,29,30,29,31],
  [2055,31,31,32,31,31,31,30,29,30,29,30,30],
  [2056,31,31,32,31,32,30,30,29,30,29,30,30],
  [2057,31,32,31,32,31,30,30,30,29,29,30,31],
  [2058,30,32,31,32,31,30,30,30,29,30,29,31],
  [2059,31,31,32,31,31,31,30,29,30,29,30,30],
  [2060,31,31,32,32,31,30,30,29,30,29,30,30],
  [2061,31,32,31,32,31,30,30,30,29,29,30,31],
  [2062,30,32,31,32,31,31,29,30,29,30,29,31],
  [2063,31,31,32,31,31,31,30,29,30,29,30,30],
  [2064,31,31,32,32,31,30,30,29,30,29,30,30],
  [2065,31,32,31,32,31,30,30,30,29,29,30,31],
  [2066,31,31,31,32,31,31,29,30,30,29,29,31],
  [2067,31,31,32,31,31,31,30,29,30,29,30,30],
  [2068,31,31,32,32,31,30,30,29,30,29,30,30],
  [2069,31,32,31,32,31,30,30,30,29,29,30,31],
  [2070,31,31,31,32,31,31,29,30,30,29,30,30],
  [2071,31,31,32,31,31,31,30,29,30,29,30,30],
  [2072,31,32,31,32,31,30,30,29,30,29,30,30],
  [2073,31,32,31,32,31,30,30,30,29,29,30,31],
  [2074,31,31,31,32,31,31,30,29,30,29,30,30],
  [2075,31,31,32,31,31,31,30,29,30,29,30,30],
  [2076,31,32,31,32,31,30,30,30,29,29,30,30],
  [2077,31,32,31,32,31,30,30,30,29,30,29,31],
  [2078,31,31,31,32,31,31,30,29,30,29,30,30],
  [2079,31,31,32,31,31,31,30,29,30,29,30,30],
  [2080,31,32,31,32,31,30,30,30,29,29,30,30],
  [2081,31,31,32,32,31,30,30,30,29,30,30,30],
  [2082,30,32,31,32,31,30,30,30,29,30,30,30],
  [2083,31,31,32,31,31,30,30,30,29,30,30,30],
  [2084,31,31,32,31,31,30,30,30,29,30,30,30],
  [2085,31,32,31,32,30,31,30,30,29,30,30,30],
  [2086,30,32,31,32,31,30,30,30,29,30,30,30],
  [2087,31,31,32,31,31,31,30,30,29,30,30,30],
  [2088,30,31,32,32,30,31,30,30,29,30,30,30],
  [2089,30,32,31,32,31,30,30,30,29,30,30,30],
  [2090,30,32,31,32,31,30,30,30,29,30,30,30],
];

// Reference: 1 Baisakh 2000 BS = April 14, 1943 AD
const REF_BS = { year: 2000, month: 1, day: 1 };
const REF_AD = Date.UTC(1943, 3, 14); // month is 0-indexed

function getYearIndex(bsYear: number): number | null {
  for (let i = 0; i < BS_CALENDAR.length; i++) {
    if (BS_CALENDAR[i][0] === bsYear) return i;
  }
  return null;
}

function daysInBSYear(yearIdx: number): number {
  let total = 0;
  for (let m = 1; m <= 12; m++) total += BS_CALENDAR[yearIdx][m];
  return total;
}

function getMonthName(month: number, lang: AppLanguage): string {
  const names = lang === 'ne' ? BS_MONTHS_NE : BS_MONTHS_EN;
  return names[month] || '';
}

export function adToBS(adYear: number, adMonth: number, adDay: number): BSDate | null {
  const target = Date.UTC(adYear, adMonth - 1, adDay);
  let totalDays = Math.round((target - REF_AD) / 86400000);
  if (totalDays < 0) return null;

  let yearIdx = 0;
  while (yearIdx < BS_CALENDAR.length && totalDays >= daysInBSYear(yearIdx)) {
    totalDays -= daysInBSYear(yearIdx);
    yearIdx++;
  }
  if (yearIdx >= BS_CALENDAR.length) return null;

  const bsYear = BS_CALENDAR[yearIdx][0];
  let bsMonth = 1;
  while (bsMonth <= 12 && totalDays >= BS_CALENDAR[yearIdx][bsMonth]) {
    totalDays -= BS_CALENDAR[yearIdx][bsMonth];
    bsMonth++;
  }
  return { year: bsYear, month: bsMonth, day: totalDays + 1 };
}

export function bsToAD(bsYear: number, bsMonth: number, bsDay: number): { year: number; month: number; day: number } | null {
  const yearIdx = getYearIndex(bsYear);
  if (yearIdx === null) return null;

  let totalDays = 0;
  for (let i = 0; i < yearIdx; i++) totalDays += daysInBSYear(i);
  for (let m = 1; m < bsMonth; m++) totalDays += BS_CALENDAR[yearIdx][m];
  totalDays += bsDay - 1;

  const result = new Date(REF_AD + totalDays * 86400000);
  return { year: result.getUTCFullYear(), month: result.getUTCMonth() + 1, day: result.getUTCDate() };
}

export function getDrawPeriodId(dateStr: string): string {
  const bs = dateStrToBS(dateStr);
  if (!bs) return 'unknown';
  const half = bs.day <= 15 ? 1 : 2;
  return `${bs.year}-${bs.month}-${half}`;
}

export function parseDrawPeriodId(periodStr: string | null): string | null {
  if (!periodStr) return null;
  for (let m = 1; m <= 12; m++) {
    const enName = BS_MONTHS_EN[m].toLowerCase();
    const neName = BS_MONTHS_NE[m];
    if (periodStr.toLowerCase().includes(enName) || periodStr.includes(neName)) {
      const yearMatch = periodStr.match(/(\d{4})/);
      const year = yearMatch ? yearMatch[1] : '';
      const half = periodStr.includes('16') ? 2 : 1;
      return `${year}-${m}-${half}`;
    }
  }
  return null;
}

function dateStrToBS(dateStr: string): BSDate | null {
  const date = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(date.getTime())) return null;
  return adToBS(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

function formatPeriod(bs: BSDate, lang: AppLanguage): string {
  const monthName = getMonthName(bs.month, lang);
  const first = bs.day <= 15;
  const half = first ? '1–15' : '16–30';
  return `${monthName} ${half}, ${bs.year}`;
}

function formatCycleName(bs: BSDate, lang: AppLanguage): string {
  const monthName = getMonthName(bs.month, lang);
  const first = bs.day <= 15;
  if (lang === 'ne') return `${monthName} ${first ? 'पहिलो' : 'दोस्रो'} हाफ ड्र`;
  return `${monthName} ${first ? '1st' : '2nd'} Half Draw`;
}

function formatExpectedAnnouncement(bs: BSDate, lang: AppLanguage): string {
  const first = bs.day <= 15;
  if (first) {
    return `${getMonthName(bs.month, lang)} 22, ${bs.year}`;
  }
  const nextMonth = bs.month === 12 ? 1 : bs.month + 1;
  const nextYear = bs.month === 12 ? bs.year + 1 : bs.year;
  return `${getMonthName(nextMonth, lang)} 7, ${nextYear}`;
}

export function getDrawPeriodForDate(dateStr: string, lang: AppLanguage = 'en'): DrawPeriodInfo {
  const bs = dateStrToBS(dateStr);
  if (!bs) {
    return {
      drawPeriod: 'Current Scheme Cycle',
      drawPeriodId: 'unknown',
      expectedAnnouncement: 'Following the 15-day billing cycle',
      cycleName: 'Fortnightly consumer draw',
      isExact: false,
    };
  }
  const half = bs.day <= 15 ? 1 : 2;
  return {
    drawPeriod: formatPeriod(bs, lang),
    drawPeriodId: `${bs.year}-${bs.month}-${half}`,
    expectedAnnouncement: formatExpectedAnnouncement(bs, lang),
    cycleName: formatCycleName(bs, lang),
    isExact: true,
  };
}

export function getCurrentDrawPeriod(lang: AppLanguage = 'en'): DrawPeriodInfo {
  return getDrawPeriodForDate(new Date().toISOString().slice(0, 10), lang);
}
