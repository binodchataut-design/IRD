import type { Coupon, Transaction } from '@/types';

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export function getSampleTransactions(): Transaction[] {
  return [
    {
      id: 'sample-tx-1',
      date: '2026-08-15',
      sellerName: 'Bhatbhateni Supermarket',
      amount: 2500,
      paymentMethod: 'QR_PAYMENT',
      panVat: '601928374',
      invoiceNumber: 'INV-2083-001',
      couponNumber: '007315254493',
      eligibilityStatus: 'COUPON_ADDED',
      notes: 'Monthly groceries',
      photoReference: null,
      createdAt: new Date('2026-08-15T10:00:00').toISOString(),
    },
    {
      id: 'sample-tx-2',
      date: '2026-08-10',
      sellerName: 'Daraz Nepal',
      amount: 1500,
      paymentMethod: 'DIGITAL_WALLET',
      panVat: '602345671',
      invoiceNumber: 'INV-2083-002',
      couponNumber: '007315254494',
      eligibilityStatus: 'COUPON_ADDED',
      notes: 'Online order - kitchen items',
      photoReference: null,
      createdAt: new Date('2026-08-10T14:30:00').toISOString(),
    },
    {
      id: 'sample-tx-3',
      date: '2026-08-05',
      sellerName: 'Kathmandu Mall',
      amount: 800,
      paymentMethod: 'CARD',
      panVat: '603456782',
      invoiceNumber: 'INV-2083-003',
      couponNumber: null,
      eligibilityStatus: 'AWAITING_COUPON',
      notes: 'Clothing purchase - awaiting coupon from seller',
      photoReference: null,
      createdAt: new Date('2026-08-05T16:00:00').toISOString(),
    },
    {
      id: 'sample-tx-4',
      date: '2026-07-28',
      sellerName: 'Local Tea Shop',
      amount: 50,
      paymentMethod: 'CASH',
      panVat: null,
      invoiceNumber: null,
      couponNumber: null,
      eligibilityStatus: 'LIKELY_NOT_ELIGIBLE',
      notes: 'Cash payment, below minimum amount',
      photoReference: null,
      createdAt: new Date('2026-07-28T09:00:00').toISOString(),
    },
  ];
}

export function getSampleCoupons(): Coupon[] {
  return [
    {
      id: 'sample-cp-1',
      couponNumber: '007315254493',
      date: '2026-08-15',
      drawPeriod: 'Bhadra 1-15, 2083',
      merchantName: 'Bhatbhateni Supermarket',
      amount: 2500,
      paymentMethod: 'QR Payment',
      invoiceNumber: 'INV-2083-001',
      notes: null,
      createdAt: new Date('2026-08-15T10:05:00').toISOString(),
    },
    {
      id: 'sample-cp-2',
      couponNumber: '007315254494',
      date: '2026-08-10',
      drawPeriod: 'Bhadra 1-15, 2083',
      merchantName: 'Daraz Nepal',
      amount: 1500,
      paymentMethod: 'Digital Wallet',
      invoiceNumber: 'INV-2083-002',
      notes: null,
      createdAt: new Date('2026-08-10T14:35:00').toISOString(),
    },
    {
      id: 'sample-cp-3',
      couponNumber: '007315254495',
      date: '2026-08-02',
      drawPeriod: 'Shrawan 16-32, 2083',
      merchantName: 'Online Store',
      amount: 3200,
      paymentMethod: 'Mobile Banking',
      invoiceNumber: 'INV-2083-004',
      notes: null,
      createdAt: new Date('2026-08-02T11:00:00').toISOString(),
    },
  ];
}
