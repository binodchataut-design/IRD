export const IRD_PRIZE_PORTAL_URL = 'https://prize.ird.gov.np/';

export const IRD_MAIN_URL = 'https://ird.gov.np';

export const IRD_PAN_SEARCH_URL = 'https://ird.gov.np/pan-search';

export type DrawResultStatus = 'NOT_CHECKED' | 'POSSIBLE_MATCH' | 'NOT_MATCHED' | 'OFFICIAL_WINNER_CONFIRMED';

export function openIrdPrizePortal(): void {
  window.open(IRD_PRIZE_PORTAL_URL, '_blank', 'noopener,noreferrer');
}
