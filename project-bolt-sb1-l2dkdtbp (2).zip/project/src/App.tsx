import { useMemo, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import {
  ArrowLeft, ArrowRight, CalendarDays, Camera, Check, CheckCircle2, ChevronRight,
  ClipboardCheck, Clock, Copy, Download, FileJson, FilePlus2, HelpCircle, History, Home, Info, Languages,
  Plus, Receipt, ReceiptText, ShieldCheck, Store, Ticket, Trash2,
  Trophy, Upload, WalletCards, X, Zap, ExternalLink,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { AppStrings } from '@/i18n/strings';
import { checkEligibility } from '@/services/eligibilityService';
import { formatCouponNumber, isValidCouponNumber, isValidPanNumber, normalizeCouponNumber, parseBulkCouponsText } from '@/utils/couponUtils';
import { BillCapture } from '@/components/BillCapture';
import { getCurrentDrawPeriod, getDrawPeriodForDate, getDrawPeriodId, parseDrawPeriodId } from '@/utils/nepaliDate';
import type { AppLanguage, Coupon, DrawResultStatus, EligibilityStatus, ManualResultCheck, PaymentMethod, ScreenName, Transaction } from '@/types';
import { openIrdPrizePortal } from '@/utils/ird';
import { isAutomaticResultCheckingAvailable } from '@/services/drawResultService';

const PAYMENT_METHODS: PaymentMethod[] = ['DIGITAL_WALLET', 'QR_PAYMENT', 'MOBILE_BANKING', 'CARD', 'CASH', 'BANK_TRANSFER', 'OTHER'];

function IconBox({ children, tone = 'navy' }: { children: ReactNode; tone?: 'navy' | 'green' | 'amber' | 'red' }) {
  return <div className={`icon-box icon-box-${tone}`}>{children}</div>;
}

function Button({ children, onClick, variant = 'primary', type = 'button', disabled = false, icon }: { children: ReactNode; onClick?: () => void; variant?: 'primary' | 'outline' | 'ghost' | 'danger'; type?: 'button' | 'submit'; disabled?: boolean; icon?: ReactNode }) {
  return <button type={type} onClick={onClick} disabled={disabled} className={`btn btn-${variant}`}>{icon}{children}</button>;
}

function Header({ title, subtitle, back = false, action }: { title: string; subtitle?: string; back?: boolean; action?: ReactNode }) {
  const { navigateBack, toggleLanguage, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  return <header className="topbar">
    <div className="header-brand-row">
      {back ? <button className="back-button" onClick={navigateBack} aria-label={t('common.back')}><ArrowLeft size={20} /></button> : <div className="brand-mark"><ReceiptText size={22} /></div>}
      <div><div className="eyebrow">{t('app.scheme_tag')}</div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>
    </div>
    <div className="header-actions">{action}<button className="language-button" onClick={toggleLanguage}><Languages size={16} /> {language === 'en' ? 'नेपाली' : 'English'}</button></div>
  </header>;
}

function BottomNav() {
  const { screen, navigate, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const items: Array<{ screen: ScreenName; label: string; icon: ReactNode }> = [
    { screen: 'home', label: t('nav.home'), icon: <Home size={19} /> }, { screen: 'invoices', label: t('nav.invoices'), icon: <Receipt size={19} /> },
    { screen: 'coupons', label: t('nav.coupons'), icon: <Ticket size={19} /> }, { screen: 'winner_checker', label: t('nav.winner'), icon: <Trophy size={19} /> },
    { screen: 'ird_info', label: t('nav.guide'), icon: <Info size={19} /> },
  ];
  return <nav className="bottom-nav">{items.map((item) => <button key={item.screen} className={screen === item.screen ? 'active' : ''} onClick={() => navigate(item.screen)}>{item.icon}<span>{item.label}</span></button>)}</nav>;
}

function Toast() {
  const { toast } = useApp();
  return toast ? <div className="toast"><CheckCircle2 size={18} />{toast}</div> : null;
}

function Welcome() {
  const { navigate, toggleLanguage, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  return <div className="welcome-page"><div className="welcome-card">
    <div className="welcome-logo"><div className="brand-mark large"><ReceiptText size={30} /></div><div><div className="eyebrow">{t('app.scheme_tag')}</div><strong>Rasid <span>Khata</span></strong></div></div>
    <div className="welcome-hero"><div className="hero-orbit"><Ticket size={55} /></div><h1>{t('welcome.hero_title_1')}<br /><span>{t('welcome.hero_title_2')}</span></h1><p>{t('welcome.hero_desc')}</p></div>
    <div className="feature-list"><div><IconBox tone="green"><Receipt size={18} /></IconBox><span>{t('welcome.feature_1')}</span><Check size={16} /></div><div><IconBox tone="amber"><Trophy size={18} /></IconBox><span>{t('welcome.feature_2')}</span><Check size={16} /></div><div><IconBox tone="navy"><ClipboardCheck size={18} /></IconBox><span>{t('welcome.feature_3')}</span><Check size={16} /></div></div>
    <Button onClick={() => navigate('home')} icon={<ArrowRight size={17} />}>{t('welcome.get_started')}</Button>
    <button className="welcome-language" onClick={toggleLanguage}><Languages size={16} /> {language === 'en' ? t('welcome.lang_ne') : t('welcome.lang_en')}</button>
    <p className="welcome-note"><ShieldCheck size={14} /> {t('welcome.note')}</p>
  </div></div>;
}

function StatCard({ label, value, icon, tone }: { label: string; value: string | number; icon: ReactNode; tone: string }) {
  return <div className="stat-card"><IconBox tone={tone as 'navy' | 'green' | 'amber' | 'red'}>{icon}</IconBox><div><strong>{value}</strong><span>{label}</span></div></div>;
}

function StatusBadge({ status, language }: { status: EligibilityStatus; language: AppLanguage }) {
  const toneMap: Record<EligibilityStatus, string> = {
    COUPON_ADDED: 'success', AWAITING_COUPON: 'pending', LIKELY_ELIGIBLE: 'success',
    NEEDS_VERIFICATION: 'pending', LIKELY_NOT_ELIGIBLE: 'error', NOT_CHECKED: 'muted',
  };
  const label = AppStrings.getStatusLabel(status, language);
  return <span className={`status-badge ${toneMap[status]}`}>{status === 'COUPON_ADDED' || status === 'LIKELY_ELIGIBLE' ? <CheckCircle2 size={13} /> : <HelpCircle size={13} />}{label}</span>;
}

function HomeScreen() {
  const { transactions, coupons, navigate, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const eligible = transactions.filter((tx) => tx.eligibilityStatus === 'COUPON_ADDED' || tx.eligibilityStatus === 'LIKELY_ELIGIBLE').length;
  const total = transactions.reduce((sum, tx) => sum + tx.amount, 0);
  const period = getCurrentDrawPeriod(language);
  return <><Header title={t('home.title')} subtitle={t('home.subtitle')} />
    <main className="page-content">
      <section className="primary-cta" onClick={() => navigate('add_invoice')} role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === 'Enter') navigate('add_invoice'); }}>
        <div className="primary-cta-icon"><FilePlus2 size={28} /></div>
        <div className="primary-cta-text"><span className="eyebrow">{t('home.banner_tag')}</span><h2>{t('home.record_purchase')}</h2><p>{t('home.record_purchase_desc')}</p></div>
        <ChevronRight size={22} className="primary-cta-arrow" />
      </section>
      <div className="stats-grid"><StatCard label={t('home.stat_invoices')} value={transactions.length} icon={<Receipt size={20} />} tone="navy" /><StatCard label={t('home.stat_coupons')} value={coupons.length} icon={<Ticket size={20} />} tone="green" /><StatCard label={t('home.stat_eligible')} value={eligible} icon={<CheckCircle2 size={20} />} tone="amber" /><StatCard label={t('home.stat_total_spent')} value={`NPR ${total.toLocaleString()}`} icon={<WalletCards size={20} />} tone="navy" /></div>
      <section className="panel draw-panel"><div className="section-heading"><div><span className="eyebrow">{t('home.current_cycle')}</span><h2>{period.drawPeriod}</h2></div><IconBox tone="amber"><CalendarDays size={20} /></IconBox></div><div className="draw-detail"><span>{t('home.expected_announcement')}</span><strong>{period.expectedAnnouncement}</strong></div><div className="progress-track"><div className="progress-fill" /></div><p className="muted-text">{t('home.draw_hint')}</p></section>
      <section><div className="section-heading compact"><h2>{t('home.quick_actions')}</h2></div><div className="quick-grid"><button onClick={() => navigate('coupons')}><IconBox tone="green"><Ticket size={19} /></IconBox><span>{t('nav.coupons')}</span><ChevronRight size={16} /></button><button onClick={() => navigate('winner_checker')}><IconBox tone="amber"><Trophy size={19} /></IconBox><span>{t('home.check_winner')}</span><ChevronRight size={16} /></button></div></section>
      <section><div className="section-heading compact"><h2>{t('home.more_actions')}</h2></div><div className="quick-grid"><button onClick={() => navigate('add_coupon')}><IconBox tone="green"><Ticket size={19} /></IconBox><span>{t('home.add_coupon')}</span><ChevronRight size={16} /></button><button onClick={() => navigate('verify_vendor')}><IconBox tone="navy"><Store size={19} /></IconBox><span>{t('home.verify_vendor')}</span><ChevronRight size={16} /></button></div></section>
      <section><div className="section-heading compact"><h2>{t('home.recent_invoices')}</h2><button className="text-action" onClick={() => navigate('invoices')}>{t('home.view_all')} <ArrowRight size={14} /></button></div>{transactions.length ? <div className="list-card">{transactions.slice(0, 3).map((tx) => <TransactionRow key={tx.id} tx={tx} language={language} />)}</div> : <EmptyState icon={<Receipt size={24} />} title={t('invoices.empty_title')} description={t('invoices.empty_desc')} action={t('invoices.add')} onClick={() => navigate('add_invoice')} />}</section>
    </main><BottomNav />
  </>;
}

function TransactionRow({ tx, onClick, language }: { tx: Transaction; onClick?: () => void; language: AppLanguage }) {
  return <button className="list-row" onClick={onClick}><IconBox tone="navy"><Receipt size={18} /></IconBox><div className="row-main"><strong>{tx.sellerName}</strong><span>{tx.date} • {AppStrings.getPaymentMethodLabel(tx.paymentMethod, language)}</span></div><div className="row-end"><strong>NPR {tx.amount.toLocaleString()}</strong><StatusBadge status={tx.eligibilityStatus} language={language} /></div><ChevronRight size={16} className="row-chevron" /></button>;
}

function CouponRow({ coupon, onClick, onDelete, language }: { coupon: Coupon; onClick?: () => void; onDelete?: () => void; language: AppLanguage }) {
  const [copied, setCopied] = useState(false);
  const t = (k: string) => AppStrings.get(k, language);
  const copy = () => { navigator.clipboard?.writeText(coupon.couponNumber); setCopied(true); setTimeout(() => setCopied(false), 1500); };
  return <div className="coupon-row"><button className="coupon-main" onClick={onClick}><IconBox tone="green"><Ticket size={18} /></IconBox><div><strong className="coupon-number">{formatCouponNumber(coupon.couponNumber)}</strong><span>{coupon.merchantName || t('coupon.no_merchant')} • {coupon.drawPeriod || t('coupon.current_draw')}</span></div></button><div className="coupon-actions"><button onClick={copy} aria-label={t('common.copy')}>{copied ? <Check size={16} /> : <Copy size={16} />}</button>{onDelete && <button onClick={onDelete} aria-label={t('common.delete')}><Trash2 size={16} /></button>}</div></div>;
}

function EmptyState({ icon, title, description, action, onClick }: { icon: ReactNode; title: string; description: string; action?: string; onClick?: () => void }) {
  return <div className="empty-state"><IconBox tone="navy">{icon}</IconBox><h3>{title}</h3><p>{description}</p>{action && onClick && <Button onClick={onClick} icon={<Plus size={16} />}>{action}</Button>}</div>;
}

function InvoicesScreen() {
  const { transactions, navigate, setSelectedTransactionId, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  return <><Header title={t('invoices.title')} subtitle={t('invoices.subtitle')} action={<Button onClick={() => navigate('add_invoice')} icon={<Plus size={16} />}>{t('invoices.add')}</Button>} /><main className="page-content">{transactions.length ? <div className="list-card">{transactions.map((tx) => <TransactionRow key={tx.id} tx={tx} language={language} onClick={() => { setSelectedTransactionId(tx.id); navigate('invoice_detail'); }} />)}</div> : <EmptyState icon={<Receipt size={24} />} title={t('invoices.empty_title')} description={t('invoices.empty_desc')} action={t('invoices.add')} onClick={() => navigate('add_invoice')} />}</main><BottomNav /></>;
}

function CouponsScreen() {
  const { coupons, navigate, deleteCoupon, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const currentDraw = getCurrentDrawPeriod(language);
  const currentId = currentDraw.drawPeriodId;

  const grouped = useMemo(() => {
    const groups: Record<string, { drawPeriod: string; coupons: Coupon[] }> = {};
    for (const c of coupons) {
      const id = parseDrawPeriodId(c.drawPeriod) ?? getDrawPeriodId(c.date ?? '') ?? 'unknown';
      const label = c.drawPeriod || getDrawPeriodForDate(c.date ?? '', language).drawPeriod || t('coupon.current_draw');
      if (!groups[id]) groups[id] = { drawPeriod: label, coupons: [] };
      groups[id].coupons.push(c);
    }
    const sorted = Object.entries(groups).sort((a, b) => (a[0] === currentId ? -1 : b[0] === currentId ? 1 : b[0].localeCompare(a[0])));
    return sorted;
  }, [coupons, currentId, language, t]);

  const currentCount = grouped.find(([id]) => id === currentId)?.[1].coupons.length ?? 0;

  return <><Header title={t('coupons.title')} subtitle={t('coupons.subtitle')} action={<div className="header-button-group"><Button variant="outline" onClick={() => navigate('bulk_add_coupons')} icon={<Upload size={15} />}>{t('coupons.bulk_add')}</Button><Button onClick={() => navigate('add_coupon')} icon={<Plus size={15} />}>{t('common.add')}</Button></div>} /><main className="page-content">
    <section className="panel draw-panel"><div className="section-heading"><div><span className="eyebrow">{t('coupons.current_draw_label')}</span><h2>{currentDraw.drawPeriod}</h2></div><IconBox tone="amber"><CalendarDays size={20} /></IconBox></div><div className="draw-detail"><span>{t('coupons.expected_announcement')}</span><strong>{currentDraw.expectedAnnouncement}</strong></div><div className="draw-detail"><span>{t('coupons.coupons_in_draw')}</span><strong>{currentCount}</strong></div></section>
    <div className="coupon-summary"><div><strong>{coupons.length}</strong><span>{t('coupons.saved_coupons')}</span></div><div><strong>{currentCount}</strong><span>{t('coupons.current_cycle')}</span></div></div>
    {coupons.length ? <>{grouped.map(([id, group]) => <section key={id} className="coupon-group"><div className="section-heading compact"><h3>{id === currentId ? t('coupons.current_draw_label') : t('coupons.previous_draw_label')} — {group.drawPeriod}</h3><span className="status-badge muted"><Clock size={13} /> {t('coupons.awaiting_result')}</span></div><div className="list-card coupon-list">{group.coupons.map((coupon) => <CouponRow key={coupon.id} coupon={coupon} language={language} onDelete={() => deleteCoupon(coupon.id)} />)}</div></section>)}
    <div className="form-actions"><Button onClick={() => navigate('winner_checker')} icon={<Trophy size={16} />}>{t('coupons.check_my_coupons')}</Button></div>
    </> : <EmptyState icon={<Ticket size={24} />} title={t('coupons.empty_title')} description={t('coupons.empty_hint')} action={t('coupons.add')} onClick={() => navigate('add_coupon')} />}
  </main><BottomNav /></>;
}

function Field({ label, value, onChange, placeholder, type = 'text', required = false, textarea = false }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; type?: string; required?: boolean; textarea?: boolean }) {
  return <label className="field"><span>{label}{required && ' *'}</span>{textarea ? <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={3} /> : <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} required={required} />}</label>;
}

function AddInvoiceScreen() {
  const { addTransaction, navigateBack, showToast, navigate, language, setEligibilityPrefill, setCouponPrefill } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today); const [seller, setSeller] = useState(''); const [amount, setAmount] = useState('');
  const [payment, setPayment] = useState<PaymentMethod>('DIGITAL_WALLET'); const [pan, setPan] = useState(''); const [invoice, setInvoice] = useState(''); const [coupon, setCoupon] = useState(''); const [notes, setNotes] = useState('');
  const [saved, setSaved] = useState(false); const [photoRef, setPhotoRef] = useState<string | null>(null);
  const draw = getDrawPeriodForDate(date, language); const amountValue = Number(amount) || 0;
  const eligibility = useMemo(() => checkEligibility({ amount: amountValue, paymentMethod: payment, purpose: 'PERSONAL', sellerPan: pan ? 'YES' : 'DONT_KNOW', sellerPanNumber: pan || null, sellerName: seller, category: 'NORMAL_GOODS', date, invoiceNumber: invoice || null }), [amountValue, payment, pan, seller, date, invoice]);
  const save = (e: FormEvent) => { e.preventDefault(); addTransaction({ date, sellerName: seller, amount: amountValue, paymentMethod: payment, panVat: pan || null, invoiceNumber: invoice || null, couponNumber: isValidCouponNumber(normalizeCouponNumber(coupon)) ? normalizeCouponNumber(coupon) : null, eligibilityStatus: isValidCouponNumber(normalizeCouponNumber(coupon)) ? 'COUPON_ADDED' : eligibility.status, notes: notes || null, photoReference: photoRef }); showToast(t('add_invoice.save_success')); setSaved(true); };
  const goCheckEligibility = () => { setEligibilityPrefill({ amount: amountValue, paymentMethod: payment, panVat: pan || null, sellerName: seller, invoiceNumber: invoice || null, date }); navigate('check_eligibility'); };
  const goAddCoupon = () => { setCouponPrefill({ merchantName: seller || null, drawPeriod: draw.drawPeriod, invoiceNumber: invoice || null, amount: amountValue || null }); navigate('add_coupon'); };
  if (saved) return <><Header title={t('add_invoice.title')} subtitle={t('add_invoice.saved_title')} back /><main className="page-content form-page"><section className="result-card"><div className="result-icon"><CheckCircle2 size={28} /></div><h2>{t('add_invoice.saved_title')}</h2><p>{t('add_invoice.saved_desc')}</p><div className="form-actions" style={{ flexDirection: 'column', gap: '10px' }}><Button onClick={goCheckEligibility} icon={<ClipboardCheck size={16} />}>{t('add_invoice.next_check_eligibility')}</Button><Button variant="outline" onClick={goAddCoupon} icon={<Ticket size={16} />}>{t('add_invoice.next_add_coupon')}</Button><Button variant="ghost" onClick={() => navigate('invoices')}>{t('add_invoice.next_done')}</Button></div></section></main></>;
  return <><Header title={t('add_invoice.title')} subtitle={t('add_invoice.subtitle')} back /><main className="page-content form-page"><form onSubmit={save}><FormSection icon={<Store size={18} />} title={t('add_invoice.section_purchase')} language={language}><Field label={t('add_invoice.merchant_name')} value={seller} onChange={setSeller} placeholder={t('add_invoice.merchant_placeholder')} required /><Field label={t('add_invoice.amount_npr')} value={amount} onChange={setAmount} placeholder={t('add_invoice.amount_placeholder')} type="number" required /><Field label={t('add_invoice.date_label')} value={date} onChange={setDate} type="date" /><div className="helper-row"><CalendarDays size={14} /> {t('add_invoice.draw_cycle_estimate')}: <strong>{draw.drawPeriod}</strong></div></FormSection><FormSection icon={<WalletCards size={18} />} title={t('add_invoice.section_payment')} language={language}><label className="field"><span>{t('add_invoice.payment_mode')} *</span><select value={payment} onChange={(e) => setPayment(e.target.value as PaymentMethod)}>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{AppStrings.getPaymentMethodLabel(m, language)}</option>)}</select></label></FormSection><FormSection icon={<Receipt size={18} />} title={t('add_invoice.section_tax_coupon')} language={language}><Field label={t('add_invoice.pan_vat')} value={pan} onChange={setPan} placeholder={t('add_invoice.pan_placeholder')} /><Field label={t('add_invoice.invoice_number')} value={invoice} onChange={setInvoice} placeholder={t('add_invoice.invoice_placeholder')} /><Field label={t('add_invoice.coupon_number')} value={coupon} onChange={setCoupon} placeholder={t('add_invoice.coupon_placeholder')} /><Field label={t('add_invoice.notes')} value={notes} onChange={setNotes} placeholder={t('add_invoice.notes_placeholder')} textarea /></FormSection><FormSection icon={<Camera size={18} />} title={t('add_invoice.section_bill_photo')} language={language}><BillCapture language={language} currentPhoto={photoRef} onConfirm={(ref) => setPhotoRef(ref)} onRemove={() => setPhotoRef(null)} currentFormValues={{ sellerName: seller, pan, invoiceNumber: invoice, date, amount }} onApplyBillData={(d) => { if (d.sellerName) setSeller(d.sellerName); if (d.pan) setPan(d.pan); if (d.invoiceNumber) setInvoice(d.invoiceNumber); if (d.date) setDate(d.date); if (d.amount) setAmount(d.amount); showToast(t('bill.apply_success')); }} /></FormSection><section className="eligibility-preview"><div className="section-heading"><h2>{t('add_invoice.eligibility_preview')}</h2><StatusBadge status={eligibility.status} language={language} /></div><ul>{eligibility.reasons.slice(0, 3).map((reason) => <li key={reason.key}>{AppStrings.getReason(reason, language)}</li>)}</ul></section><div className="form-actions"><Button variant="outline" onClick={navigateBack}>{t('common.cancel')}</Button><Button type="submit" icon={<Check size={16} />}>{t('add_invoice.save_btn')}</Button></div></form></main></>;
}

function FormSection({ icon, title, children, language }: { icon: ReactNode; title: string; children: ReactNode; language: AppLanguage }) { return <section className="form-section"><div className="form-section-title"><IconBox tone="navy">{icon}</IconBox><h2>{title}</h2></div>{children}</section>; }

function AddCouponScreen() {
  const { addCoupon, navigateBack, showToast, navigate, language, couponPrefill, setCouponPrefill } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const [number, setNumber] = useState(''); const [merchant, setMerchant] = useState(couponPrefill?.merchantName ?? ''); const [period, setPeriod] = useState(couponPrefill?.drawPeriod ?? getCurrentDrawPeriod(language).drawPeriod); const [invoice, setInvoice] = useState(couponPrefill?.invoiceNumber ?? ''); const [amount, setAmount] = useState(couponPrefill?.amount != null ? String(couponPrefill.amount) : '');
  const normalized = normalizeCouponNumber(number); const valid = isValidCouponNumber(normalized);
  const save = (e: FormEvent) => { e.preventDefault(); if (!valid) return; addCoupon({ couponNumber: normalized, date: new Date().toISOString().slice(0, 10), drawPeriod: period || null, merchantName: merchant || null, amount: amount ? Number(amount) : null, paymentMethod: null, invoiceNumber: invoice || null, notes: null }); showToast(t('add_coupon.save_success')); setCouponPrefill(null); navigate('coupons'); };
  return <><Header title={t('add_coupon.title')} subtitle={t('add_coupon.subtitle')} back /><main className="page-content form-page"><form onSubmit={save}><FormSection icon={<Ticket size={18} />} title={t('add_coupon.card_title')} language={language}><Field label={t('add_coupon.coupon_label')} value={number} onChange={setNumber} placeholder={t('add_coupon.coupon_placeholder')} required /><div className={`digit-counter ${valid ? 'valid' : ''}`}>{normalized.length}{t('add_coupon.digits_counter')} {valid && <Check size={14} />}</div>{normalized && <div className="coupon-preview"><Ticket size={17} /> <strong>{formatCouponNumber(normalized)}</strong><button type="button" onClick={() => setNumber('')}><X size={15} /></button></div>}<Field label={t('add_coupon.merchant_name')} value={merchant} onChange={setMerchant} placeholder={t('add_coupon.merchant_placeholder')} /><Field label={t('add_coupon.draw_period')} value={period} onChange={setPeriod} /><Field label={t('add_coupon.invoice_ref')} value={invoice} onChange={setInvoice} placeholder={t('add_coupon.invoice_placeholder')} /><Field label={t('add_coupon.amount_npr')} value={amount} onChange={setAmount} type="number" placeholder={t('add_coupon.amount_placeholder')} /></FormSection><div className="form-actions"><Button variant="outline" onClick={navigateBack}>{t('common.cancel')}</Button><Button type="submit" disabled={!valid} icon={<Check size={16} />}>{t('add_coupon.save_btn')}</Button></div></form></main></>;
}

function BulkAddCouponsScreen() {
  const { coupons, addBulkCoupons, navigateBack, showToast, navigate, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const [raw, setRaw] = useState(''); const [merchant, setMerchant] = useState(''); const [period, setPeriod] = useState(getCurrentDrawPeriod(language).drawPeriod); const [saved, setSaved] = useState(false);
  const result = useMemo(() => parseBulkCouponsText(raw, new Set(coupons.map((c) => c.couponNumber))), [raw, coupons]);
  const save = () => { if (!result.validNew.length) return; addBulkCoupons(result.validNew, { merchantName: merchant, drawPeriod: period }); setSaved(true); showToast(`${result.validNew.length} ${t('bulk.save_success')}`); navigate('coupons'); };
  return <><Header title={t('bulk.title')} subtitle={t('bulk.subtitle')} back /><main className="page-content form-page"><section className="form-section"><div className="form-section-title"><IconBox tone="green"><Upload size={18} /></IconBox><h2>{t('bulk.card_title')}</h2></div><p className="muted-text">{t('bulk.instruction')}</p><textarea className="bulk-textarea" value={raw} onChange={(e) => setRaw(e.target.value)} placeholder={t('bulk.placeholder')} rows={8} />{raw && <div className="parse-grid"><div><strong>{result.totalExtracted}</strong><span>{t('bulk.total_found')}</span></div><div className="parse-success"><strong>{result.validNew.length}</strong><span>{t('bulk.valid_new')}</span></div><div className="parse-warning"><strong>{result.duplicateInBatch.length}</strong><span>{t('bulk.duplicates')}</span></div><div className="parse-error"><strong>{result.invalidTokens.length}</strong><span>{t('bulk.invalid')}</span></div></div>}<Field label={t('bulk.merchant_label')} value={merchant} onChange={setMerchant} placeholder={t('bulk.merchant_placeholder')} /><Field label={t('add_coupon.draw_period')} value={period} onChange={setPeriod} /></section><div className="form-actions"><Button variant="outline" onClick={navigateBack}>{t('common.cancel')}</Button><Button onClick={save} disabled={!result.validNew.length || saved} icon={<Check size={16} />}>{t('bulk.save_btn')} {result.validNew.length} {t('bulk.coupons_word')}</Button></div></main></>;
}

function WinnerCheckerScreen() {
  const { coupons, transactions, navigate, setClaimData, language, resultChecks, addResultCheck, clearResultChecks, showToast } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const [raw, setRaw] = useState(''); const [title, setTitle] = useState(''); const [checked, setChecked] = useState(false);
  const parsed = useMemo(() => parseBulkCouponsText(raw, new Set()), [raw]);
  const winning = parsed.validNew;
  const hasInvalid = parsed.invalidTokens.length > 0;
  const matches = coupons.filter((c) => winning.includes(normalizeCouponNumber(c.couponNumber)));
  const txFor = (coupon: Coupon) => transactions.find((tx) => tx.couponNumber === coupon.couponNumber) ?? null;
  const runCheck = () => {
    setChecked(true);
    if (winning.length > 0) {
      const matchedNumbers = matches.map((c) => c.couponNumber);
      addResultCheck({
        drawTitle: title.trim() || null,
        drawPeriod: null,
        enteredResults: [...winning],
        matchedCouponNumbers: matchedNumbers,
        matched: matchedNumbers.length > 0,
      });
    }
  };
  const clearHistory = () => {
    if (window.confirm(t('winner.clear_history_confirm'))) {
      clearResultChecks();
      showToast(t('winner.history_cleared'));
    }
  };
  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString(language === 'ne' ? 'ne-NP' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  };
  return <><Header title={t('winner.title')} subtitle={t('winner.subtitle')} /><main className="page-content form-page"><section className="form-section"><div className="form-section-title"><IconBox tone="amber"><Trophy size={18} /></IconBox><h2>{t('winner.manual_section')}</h2></div><p className="muted-text">{t('winner.manual_hint')}</p><Field label={t('winner.draw_title')} value={title} onChange={setTitle} placeholder={t('winner.draw_title_placeholder')} /><textarea className="bulk-textarea" value={raw} onChange={(e) => { setRaw(e.target.value); setChecked(false); }} placeholder={t('winner.paste_placeholder')} rows={6} /><Button onClick={runCheck} disabled={!winning.length} icon={<ClipboardCheck size={16} />}>{t('winner.manual_check_btn')}</Button>{hasInvalid && (raw.trim().length > 0) && <p className="muted-text" style={{ color: '#dc2626', fontSize: '13px', marginTop: '8px' }}>{t('winner.invalid_result')}</p>}</section>{checked && <section className={`result-card ${matches.length ? 'winner' : 'no-winner'}`}>{matches.length ? <><div className="result-icon"><Trophy size={28} /></div><h2>{matches.length === 1 ? t('winner.match_found') : t('winner.matches_found')}</h2><p>{t('winner.result_matches')}</p><div className="match-list">{matches.map((coupon) => <div key={coupon.id}><strong>{formatCouponNumber(coupon.couponNumber)}</strong><span>{coupon.merchantName || t('winner.saved_coupon')}</span><Button onClick={() => { setClaimData({ coupon, transaction: txFor(coupon), drawTitle: title || null, drawPeriod: coupon.drawPeriod, announcementDate: null }); navigate('claim_report'); }} variant="outline" icon={<FileJson size={15} />}>{t('common.claim_report')}</Button></div>)}</div></> : <><div className="result-icon"><ShieldCheck size={28} /></div><h2>{t('winner.no_match')}</h2><p>{t('winner.result_no_match')}</p></>}<div className="ird-handoff-status" style={{ marginTop: '12px' }}><span className="status-badge muted"><ClipboardCheck size={13} /> {t('winner.result_source')}: {t('winner.entered_manually')}</span><p className="muted-text" style={{ fontSize: '13px', marginTop: '6px' }}>{t('winner.verify_official')}</p></div></section>}<div className="checker-stats"><div><strong>{coupons.length}</strong><span>{t('winner.total_checked')}</span></div><div><strong>{winning.length}</strong><span>{t('winner.winning_numbers')}</span></div><div><strong>{matches.length}</strong><span>{t('winner.matches_label')}</span></div></div><section className="form-section"><div className="form-section-title"><IconBox tone="navy"><History size={18} /></IconBox><h2>{t('winner.history_section')}</h2></div>{resultChecks.length === 0 ? <p className="muted-text">{t('winner.history_empty')}</p> : <><div className="result-check-list">{resultChecks.map((rc) => <div key={rc.id} className="result-check-item"><div className="result-check-header"><strong>{rc.drawTitle || t('winner.draw_title')}</strong>{rc.matched ? <span className="status-badge success"><Check size={13} /> {t('winner.matched_coupon')}</span> : <span className="status-badge muted"><X size={13} /> {t('winner.not_matched_coupon')}</span>}</div><div className="result-check-body"><span className="muted-text" style={{ fontSize: '13px' }}>{t('winner.entered_result')}: {rc.enteredResults.map((n) => formatCouponNumber(n)).join(', ')}</span><span className="muted-text" style={{ fontSize: '13px' }}>{t('winner.result_source')}: {t('winner.entered_manually')}</span><span className="muted-text" style={{ fontSize: '13px' }}>{t('winner.checked')}: {formatDate(rc.checkedAt)}</span></div></div>)}</div><Button variant="danger" onClick={clearHistory} icon={<Trash2 size={15} />}>{t('winner.clear_history')}</Button></>}</section><section className="ird-handoff-section"><div className="form-section-title"><IconBox tone="navy"><ShieldCheck size={18} /></IconBox><h2>{t('ird.official_results')}</h2></div><p className="muted-text">{t('ird.results_from_ird')}</p><p className="muted-text" style={{ fontSize: '13px' }}>{t('ird.rasid_not_verify')}</p>{!isAutomaticResultCheckingAvailable() && <div className="ird-handoff-status"><span className="status-badge muted"><Clock size={13} /> {t('ird.result_source_unavailable')}</span><p className="muted-text" style={{ fontSize: '13px', marginTop: '6px' }}>{t('ird.auto_unavailable')}</p><p className="muted-text" style={{ fontSize: '13px', marginTop: '4px' }}>{t('ird.authoritative_source')}</p></div>}{checked && matches.length > 0 && <div className="ird-handoff-status"><span className="status-badge pending"><Clock size={13} /> {t('ird.official_confirmation_required')}</span><p className="muted-text" style={{ fontSize: '13px', marginTop: '6px' }}>{t('ird.check_portal_hint')}</p></div>}{(!checked || matches.length === 0) && isAutomaticResultCheckingAvailable() && <div className="ird-handoff-status"><span className="status-badge muted"><Clock size={13} /> {t('ird.not_checked')}</span></div>}<Button variant="outline" onClick={openIrdPrizePortal} icon={<ExternalLink size={16} />}>{t('ird.open_official_results')}</Button></section></main><BottomNav /></>;
}

function ClaimReportScreen() {
  const { claimData, navigateBack, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  if (!claimData) return <><Header title={t('claim.title')} back /><main className="page-content"><EmptyState icon={<FileJson size={24} />} title={t('claim.no_report')} description={t('claim.no_report_desc')} /></main></>;
  const { coupon, transaction } = claimData;
  return <><Header title={t('claim.title')} subtitle={t('claim.subtitle_alt')} back action={<Button onClick={() => window.print()} icon={<Download size={15} />}>{t('claim.print_short')}</Button>} /><main className="page-content report-page"><div className="print-report"><div className="report-header"><div className="brand-mark"><ReceiptText size={22} /></div><div><strong>{t('app.name')}</strong><span>{t('claim.report_record')}</span></div><div className="report-status"><Trophy size={20} /> {t('claim.winning_coupon')}</div></div><div className="report-number"><span>{t('claim.winning_coupon_number')}</span><strong>{formatCouponNumber(coupon.couponNumber)}</strong></div><div className="report-grid"><ReportItem label={t('claim.draw_title')} value={claimData.drawTitle || t('claim.default_draw')} language={language} /><ReportItem label={t('claim.draw_period')} value={claimData.drawPeriod || t('common.not_specified')} language={language} /><ReportItem label={t('claim.announcement_date')} value={claimData.announcementDate || t('common.not_specified')} language={language} /></div>{transaction && <><h3>{t('claim.purchase_details')}</h3><div className="report-grid"><ReportItem label={t('claim.seller')} value={transaction.sellerName} language={language} /><ReportItem label={t('claim.amount')} value={`NPR ${transaction.amount.toLocaleString()}`} language={language} /><ReportItem label={t('claim.date')} value={transaction.date} language={language} /><ReportItem label={t('claim.payment')} value={AppStrings.getPaymentMethodLabel(transaction.paymentMethod, language)} language={language} /><ReportItem label={t('claim.pan')} value={transaction.panVat || t('common.not_provided')} language={language} /><ReportItem label={t('claim.invoice_no')} value={transaction.invoiceNumber || t('common.not_provided')} language={language} /></div></>}<div className="report-disclaimer"><ShieldCheck size={17} /> {t('claim.disclaimer')}</div></div><div className="form-actions"><Button variant="outline" onClick={navigateBack}>{t('common.back_btn')}</Button><Button onClick={() => window.print()} icon={<Download size={16} />}>{t('claim.print')}</Button></div></main></>;
}

function ReportItem({ label, value, language }: { label: string; value: string; language: AppLanguage }) {
  void language;
  return <div><span>{label}</span><strong>{value}</strong></div>;
}

function IrdInfoScreen() {
  const { navigate, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  return <><Header title={t('ird_info.title')} subtitle={t('ird_info.subtitle')} /><main className="page-content guide-page"><section className="guide-hero"><div className="guide-icon"><ShieldCheck size={35} /></div><div><span className="eyebrow">{t('ird_info.know_your_rights')}</span><h2>{t('ird_info.lottery_title')}</h2><p>{t('ird_info.hero_desc')}</p></div></section><InfoCard icon={<HelpCircle size={19} />} title={t('ird_info.what_is')} language={language}><p>{t('ird_info.what_is_desc')}</p></InfoCard><InfoCard icon={<Zap size={19} />} title={t('ird_info.how_to')} language={language}><ol><li>{t('ird_info.how_to_1')}</li><li>{t('ird_info.how_to_2')}</li><li>{t('ird_info.how_to_3')}</li><li>{t('ird_info.how_to_4')}</li><li>{t('ird_info.how_to_5')}</li></ol></InfoCard><InfoCard icon={<Trophy size={19} />} title={t('ird_info.prizes')} language={language}><div className="prize-list"><div><strong>NPR 100,000</strong><span>{t('ird_info.first_prize')}</span></div><div><strong>NPR 50,000</strong><span>{t('ird_info.second_prize')}</span></div><div><strong>NPR 25,000</strong><span>{t('ird_info.third_prize')}</span></div></div></InfoCard><InfoCard icon={<ShieldCheck size={19} />} title={t('ird_info.reminder')} language={language}><p>{t('ird_info.reminder_desc')}</p><Button variant="outline" onClick={() => window.open('https://ird.gov.np', '_blank')} icon={<ArrowRight size={15} />}>{t('ird_info.visit_ird')}</Button></InfoCard><section className="utility-links"><button onClick={() => navigate('check_eligibility')}><ClipboardCheck size={18} /> {t('ird_info.check_eligibility_link')} <ChevronRight size={16} /></button><button onClick={() => navigate('verify_vendor')}><Store size={18} /> {t('ird_info.verify_seller_link')} <ChevronRight size={16} /></button><button onClick={() => navigate('data_backup')}><FileJson size={18} /> {t('ird_info.data_backup_link')} <ChevronRight size={16} /></button></section></main><BottomNav /></>;
}

function InfoCard({ icon, title, children, language }: { icon: ReactNode; title: string; children: ReactNode; language: AppLanguage }) {
  void language;
  return <section className="info-card"><div className="form-section-title"><IconBox tone="navy">{icon}</IconBox><h2>{title}</h2></div>{children}</section>;
}

function EligibilityScreen() {
  const { navigateBack, showToast, language, eligibilityPrefill, setEligibilityPrefill } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const [amount, setAmount] = useState(eligibilityPrefill ? String(eligibilityPrefill.amount) : ''); const [payment, setPayment] = useState<PaymentMethod>(eligibilityPrefill?.paymentMethod ?? 'DIGITAL_WALLET'); const [pan, setPan] = useState(eligibilityPrefill?.panVat ?? ''); const [seller, setSeller] = useState(eligibilityPrefill?.sellerName ?? '');
  const [result, setResult] = useState<ReturnType<typeof checkEligibility> | null>(null);
  const run = () => { setResult(checkEligibility({ amount: Number(amount) || 0, paymentMethod: payment, purpose: 'PERSONAL', sellerPan: pan ? 'YES' : 'DONT_KNOW', sellerPanNumber: pan || null, sellerName: seller, category: 'NORMAL_GOODS', date: eligibilityPrefill?.date ?? new Date().toISOString().slice(0, 10), invoiceNumber: eligibilityPrefill?.invoiceNumber ?? null })); setEligibilityPrefill(null); };
  void showToast;
  return <><Header title={t('eligibility.title')} subtitle={t('eligibility.subtitle')} back /><main className="page-content form-page"><section className="form-section"><div className="form-section-title"><IconBox tone="green"><ClipboardCheck size={18} /></IconBox><h2>{t('eligibility.purchase_details')}</h2></div><Field label={t('eligibility.seller_name')} value={seller} onChange={setSeller} placeholder={t('eligibility.seller_placeholder')} /><Field label={t('add_invoice.amount_npr')} value={amount} onChange={setAmount} type="number" placeholder={t('eligibility.amount_placeholder')} /><label className="field"><span>{t('eligibility.payment_method')}</span><select value={payment} onChange={(e) => setPayment(e.target.value as PaymentMethod)}>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{AppStrings.getPaymentMethodLabel(m, language)}</option>)}</select></label><Field label={t('eligibility.seller_pan')} value={pan} onChange={setPan} placeholder={t('eligibility.pan_placeholder')} /><Button onClick={run} icon={<ClipboardCheck size={16} />}>{t('eligibility.check_btn')}</Button></section>{result && <section className="result-card eligibility-result"><StatusBadge status={result.status} language={language} /><h2>{result.status === 'LIKELY_ELIGIBLE' ? t('eligibility.likely_eligible_msg') : result.status === 'LIKELY_NOT_ELIGIBLE' ? t('eligibility.likely_not_msg') : t('eligibility.verification_msg')}</h2><ul>{result.reasons.map((reason) => <li key={reason.key}>{AppStrings.getReason(reason, language)}</li>)}</ul></section>}</main></>;
}

function VerifyVendorScreen() {
  const { navigateBack, showToast, navigate, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const [pan, setPan] = useState(''); const valid = isValidPanNumber(pan);
  const [copied, setCopied] = useState(false);
  const copyPan = () => { navigator.clipboard?.writeText(pan); setCopied(true); showToast(t('verify_vendor.pan_copied')); setTimeout(() => setCopied(false), 1500); };
  return <><Header title={t('verify_vendor.title')} subtitle={t('verify_vendor.subtitle')} back /><main className="page-content form-page"><InfoCard icon={<Store size={19} />} title={t('verify_vendor.track_a_header')} language={language}><p>{t('verify_vendor.track_a_desc')}</p><Field label={t('verify_vendor.pan_label')} value={pan} onChange={setPan} placeholder={t('verify_vendor.pan_placeholder')} /><div className="pan-display"><span>{t('verify_vendor.seller_pan')}</span><strong>{pan || '—'}</strong>{pan && <button onClick={copyPan}>{copied ? <Check size={15} /> : <Copy size={15} />} {t('verify_vendor.copy_pan')}</button>}</div>{!valid && pan.length > 0 && <p className="muted-text" style={{ color: '#dc2626' }}>{t('verify_vendor.invalid_pan')}</p>}{valid && <><p className="muted-text">{t('verify_vendor.pan_hint')}</p><p className="muted-text" style={{ fontSize: '13px' }}><ShieldCheck size={14} /> {t('verify_vendor.disclaimer')}</p><Button onClick={() => window.open('https://ird.gov.np/pan-search', '_blank')} icon={<ArrowRight size={16} />}>{t('verify_vendor.verify_on_ird')}</Button></>}</InfoCard><InfoCard icon={<ClipboardCheck size={19} />} title={t('verify_vendor.track_b_header')} language={language}><p>{t('verify_vendor.track_b_desc')}</p><Button variant="outline" onClick={() => navigate('check_eligibility')} icon={<ClipboardCheck size={15} />}>{t('verify_vendor.check_eligibility')}</Button></InfoCard><div className="form-actions"><Button variant="ghost" onClick={navigateBack} icon={<ArrowLeft size={15} />}>{t('verify_vendor.back_guide')}</Button></div></main></>;
}

function DataBackupScreen() {
  const { transactions, coupons, draws, exportData, importData, clearData, showToast, navigateBack, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const inputRef = useRef<HTMLInputElement>(null);
  const onImport = (e: ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { if (typeof reader.result === 'string' && importData(reader.result)) showToast(t('data_backup.imported')); else showToast(t('data_backup.import_failed')); }; reader.readAsText(file); };
  const clear = () => { if (window.confirm(t('data_backup.clear_confirm'))) { clearData(); showToast(t('data_backup.cleared')); } };
  void navigateBack;
  return <><Header title={t('data_backup.title')} subtitle={t('data_backup.subtitle')} back /><main className="page-content form-page"><section className="backup-summary"><div><strong>{transactions.length}</strong><span>{t('data_backup.summary_invoices')}</span></div><div><strong>{coupons.length}</strong><span>{t('data_backup.summary_coupons')}</span></div><div><strong>{draws.length}</strong><span>{t('data_backup.summary_draws')}</span></div></section><InfoCard icon={<Download size={19} />} title={t('data_backup.export_title')} language={language}><p>{t('data_backup.export_desc')}</p><Button onClick={() => { exportData(); showToast(t('data_backup.exported')); }} icon={<Download size={16} />}>{t('data_backup.export')}</Button></InfoCard><InfoCard icon={<Upload size={19} />} title={t('data_backup.import_title')} language={language}><p>{t('data_backup.import_desc')}</p><input ref={inputRef} type="file" accept="application/json" onChange={onImport} hidden /><Button variant="outline" onClick={() => inputRef.current?.click()} icon={<Upload size={16} />}>{t('data_backup.choose_file')}</Button></InfoCard><section className="danger-zone"><h2>{t('data_backup.clear_title')}</h2><p>{t('data_backup.clear_desc')}</p><Button variant="danger" onClick={clear} icon={<Trash2 size={16} />}>{t('data_backup.clear')}</Button></section></main></>;
}

function InvoiceDetailScreen() {
  const { selectedTransactionId, getTransaction, deleteTransaction, navigate, navigateBack, showToast, language } = useApp();
  const t = (k: string) => AppStrings.get(k, language);
  const tx = selectedTransactionId ? getTransaction(selectedTransactionId) : undefined;
  if (!tx) return <><Header title={t('invoice_detail.title')} back /><main className="page-content"><EmptyState icon={<Receipt size={24} />} title={t('invoice_detail.not_found')} description={t('invoice_detail.not_found_desc')} /></main></>;
  return <><Header title={t('invoice_detail.title')} subtitle={tx.sellerName} back action={<Button variant="danger" onClick={() => { deleteTransaction(tx.id); showToast(t('invoice_detail.deleted')); navigate('invoices'); }} icon={<Trash2 size={15} />}>{t('common.delete')}</Button>} /><main className="page-content detail-page"><div className="detail-hero"><IconBox tone="navy"><Receipt size={26} /></IconBox><div><h2>{tx.sellerName}</h2><p>{tx.date}</p></div><strong>NPR {tx.amount.toLocaleString()}</strong></div><section className="detail-grid"><ReportItem label={t('invoice_detail.payment')} value={AppStrings.getPaymentMethodLabel(tx.paymentMethod, language)} language={language} /><ReportItem label={t('invoice_detail.eligibility_label')} value={AppStrings.getStatusLabel(tx.eligibilityStatus, language)} language={language} /><ReportItem label={t('invoice_detail.pan')} value={tx.panVat || t('common.not_provided')} language={language} /><ReportItem label={t('invoice_detail.invoice_no')} value={tx.invoiceNumber || t('common.not_provided')} language={language} /><ReportItem label={t('invoice_detail.coupon_number')} value={tx.couponNumber ? formatCouponNumber(tx.couponNumber) : t('invoice_detail.awaiting_coupon')} language={language} /><ReportItem label={t('invoice_detail.notes')} value={tx.notes || t('invoice_detail.no_notes')} language={language} /></section><Button variant="outline" onClick={navigateBack} icon={<ArrowLeft size={15} />}>{t('common.back_btn')}</Button></main></>;
}

function App() { const { screen } = useApp(); const screenMap: Record<ScreenName, ReactNode> = { welcome: <Welcome />, home: <HomeScreen />, invoices: <InvoicesScreen />, add_invoice: <AddInvoiceScreen />, invoice_detail: <InvoiceDetailScreen />, coupons: <CouponsScreen />, add_coupon: <AddCouponScreen />, bulk_add_coupons: <BulkAddCouponsScreen />, winner_checker: <WinnerCheckerScreen />, claim_report: <ClaimReportScreen />, draw_history: <IrdInfoScreen />, check_eligibility: <EligibilityScreen />, verify_vendor: <VerifyVendorScreen />, ird_info: <IrdInfoScreen />, data_backup: <DataBackupScreen /> }; return <div className="app-shell">{screenMap[screen]}<Toast /></div>; }

export default App;
