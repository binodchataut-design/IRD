import { IRD_PRIZE_PORTAL_URL } from '@/utils/ird';
import type { DrawResultStatus } from '@/types';

export const OFFICIAL_IRD_RESULT_SOURCE = {
  name: 'Inland Revenue Department (IRD) Prize Portal',
  url: IRD_PRIZE_PORTAL_URL,
  machineReadable: false,
  permitted: false,
} as const;

export type DrawResultSource = 'OFFICIAL_IRD' | 'NONE';

export interface DrawResult {
  drawId: string;
  drawDate: string | null;
  winningNumbers: string[];
  source: DrawResultSource;
  fetchedAt: string | null;
  status: DrawResultStatus;
  available: boolean;
}

export type DrawResultResponse =
  | { available: true; result: DrawResult }
  | { available: false; reason: 'NO_OFFICIAL_SOURCE_AVAILABLE' };

export function getDrawResult(_drawId: string): DrawResultResponse {
  return { available: false, reason: 'NO_OFFICIAL_SOURCE_AVAILABLE' };
}

export function isAutomaticResultCheckingAvailable(): boolean {
  return OFFICIAL_IRD_RESULT_SOURCE.machineReadable && OFFICIAL_IRD_RESULT_SOURCE.permitted;
}
