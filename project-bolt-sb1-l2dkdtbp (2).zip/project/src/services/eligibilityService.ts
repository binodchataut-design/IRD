import type {
  EligibilityStatus,
  PaymentMethod,
  PurchasePurpose,
  SellerPanOption,
  TransactionCategory,
} from '@/types';

export interface TransactionEligibilityInput {
  amount: number;
  paymentMethod: PaymentMethod;
  purpose: PurchasePurpose;
  sellerPan: SellerPanOption;
  sellerPanNumber: string | null;
  sellerName: string;
  category: TransactionCategory;
  date: string;
  invoiceNumber: string | null;
}

export interface EligibilityReason {
  key: string;
  params?: Record<string, string | number>;
}

export interface EligibilityResult {
  status: EligibilityStatus;
  reasons: EligibilityReason[];
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
}

const MIN_AMOUNT = 100;

const DIGITAL_METHODS: PaymentMethod[] = [
  'DIGITAL_WALLET',
  'QR_PAYMENT',
  'MOBILE_BANKING',
  'CARD',
  'BANK_TRANSFER',
];

const EXEMPT_CATEGORIES: TransactionCategory[] = [
  'ELECTRICITY',
  'TELEPHONE_INTERNET',
  'AIRLINE',
  'TRANSPORT_FREIGHT',
  'VEHICLE',
];

export function checkEligibility(input: TransactionEligibilityInput): EligibilityResult {
  const reasons: EligibilityReason[] = [];
  let likelyEligible = true;

  if (input.amount < MIN_AMOUNT) {
    reasons.push({ key: 'eligibility.reason_min_amount', params: { minAmount: MIN_AMOUNT, currentAmount: input.amount } });
    likelyEligible = false;
  }

  if (input.purpose === 'BUSINESS' || input.purpose === 'GOVERNMENT') {
    reasons.push({ key: 'eligibility.reason_business_gov' });
    likelyEligible = false;
  }

  if (input.paymentMethod === 'CASH') {
    reasons.push({ key: 'eligibility.reason_cash' });
    likelyEligible = false;
  } else if (input.paymentMethod === 'OTHER') {
    reasons.push({ key: 'eligibility.reason_other_payment' });
    likelyEligible = false;
  } else if (!DIGITAL_METHODS.includes(input.paymentMethod)) {
    reasons.push({ key: 'eligibility.reason_non_digital' });
    likelyEligible = false;
  }

  if (EXEMPT_CATEGORIES.includes(input.category)) {
    reasons.push({ key: 'eligibility.reason_exempt_category' });
    likelyEligible = false;
  }

  if (input.sellerPan === 'NO') {
    reasons.push({ key: 'eligibility.reason_no_pan' });
    likelyEligible = false;
  } else if (input.sellerPan === 'DONT_KNOW') {
    reasons.push({ key: 'eligibility.reason_pan_unknown' });
  }

  if (input.sellerPan === 'YES' && input.sellerPanNumber) {
    const panDigits = input.sellerPanNumber.replace(/\D/g, '');
    if (panDigits.length !== 9) {
      reasons.push({ key: 'eligibility.reason_pan_digits', params: { currentDigits: panDigits.length } });
    }
  }

  let status: EligibilityStatus;
  let confidence: 'HIGH' | 'MEDIUM' | 'LOW';

  if (likelyEligible && input.sellerPan === 'YES') {
    status = 'LIKELY_ELIGIBLE';
    confidence = 'HIGH';
    if (reasons.length === 0) {
      reasons.push({ key: 'eligibility.reason_all_met' });
    }
  } else if (likelyEligible && input.sellerPan === 'DONT_KNOW') {
    status = 'NEEDS_VERIFICATION';
    confidence = 'MEDIUM';
    reasons.unshift({ key: 'eligibility.reason_verify_pan' });
  } else {
    status = 'LIKELY_NOT_ELIGIBLE';
    confidence = 'HIGH';
  }

  return { status, reasons, confidence };
}

export function getEligibilityColor(status: EligibilityStatus): {
  bg: string;
  text: string;
  border: string;
} {
  switch (status) {
    case 'COUPON_ADDED':
      return { bg: 'bg-status-successBg', text: 'text-status-success', border: 'border-status-successBorder' };
    case 'AWAITING_COUPON':
      return { bg: 'bg-status-pendingBg', text: 'text-status-pending', border: 'border-status-pendingBorder' };
    case 'LIKELY_ELIGIBLE':
      return { bg: 'bg-status-successBg', text: 'text-status-success', border: 'border-status-successBorder' };
    case 'NEEDS_VERIFICATION':
      return { bg: 'bg-status-pendingBg', text: 'text-status-pending', border: 'border-status-pendingBorder' };
    case 'LIKELY_NOT_ELIGIBLE':
      return { bg: 'bg-status-errorBg', text: 'text-status-error', border: 'border-status-errorBorder' };
    case 'NOT_CHECKED':
      return { bg: 'bg-surface-muted', text: 'text-text-secondary', border: 'border-border-subtle' };
  }
}
