import { useRef, useState, type ChangeEvent } from 'react';
import { Camera, Check, ImagePlus, QrCode, RotateCcw, ScanText, X } from 'lucide-react';
import { AppStrings } from '@/i18n/strings';
import { isValidPanNumber } from '@/utils/couponUtils';
import { EMPTY_BILL_DATA, type BillData } from '@/utils/billData';
import type { AppLanguage } from '@/types';
import { BillOcr, type OcrResult } from '@/components/BillOcr';
import { BillQr, type QrResult } from '@/components/BillQr';
import { BillConflictResolver } from '@/components/BillConflictResolver';

interface BillCaptureProps {
  language: AppLanguage;
  onConfirm: (photoReference: string) => void;
  onRemove: () => void;
  currentPhoto: string | null;
  currentFormValues: BillData;
  onApplyBillData: (data: BillData) => void;
}

type ScanMode = 'none' | 'ocr' | 'qr' | 'conflict';

export function BillCapture({ language, onConfirm, onRemove, currentPhoto, currentFormValues, onApplyBillData }: BillCaptureProps) {
  const t = (k: string) => AppStrings.get(k, language);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentPhoto);
  const [error, setError] = useState<string | null>(null);
  const [scanMode, setScanMode] = useState<ScanMode>('none');
  const [photoConfirmed, setPhotoConfirmed] = useState(false);
  const [pendingCandidate, setPendingCandidate] = useState<{ data: BillData; source: 'ocr' | 'qr' } | null>(null);

  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError(t('bill.not_image'));
      return;
    }
    setError(null);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    setPhotoConfirmed(false);
    setScanMode('none');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleRetake = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setError(null);
    setPhotoConfirmed(false);
    setScanMode('none');
    fileInputRef.current?.click();
  };

  const handleConfirm = () => {
    if (previewUrl) {
      onConfirm(previewUrl);
      setPhotoConfirmed(true);
    }
  };

  const handleRemove = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setError(null);
    setPhotoConfirmed(false);
    setScanMode('none');
    onRemove();
  };

  const triggerPicker = () => {
    setError(null);
    fileInputRef.current?.click();
  };

  const handleOcrConfirm = (result: OcrResult) => {
    setPendingCandidate({ data: result, source: 'ocr' });
    setScanMode('conflict');
  };

  const handleQrConfirm = (result: QrResult) => {
    const { qrContent: _qr, ...billData } = result;
    void _qr;
    setPendingCandidate({ data: billData, source: 'qr' });
    setScanMode('conflict');
  };

  const handleConflictApply = (resolved: BillData) => {
    onApplyBillData(resolved);
    setPendingCandidate(null);
    setScanMode('none');
  };

  const handleConflictCancel = () => {
    setPendingCandidate(null);
    setScanMode('none');
  };

  const handleScanSkip = () => {
    setScanMode('none');
  };

  if (currentPhoto && !previewUrl) {
    setPreviewUrl(currentPhoto);
  }

  return (
    <div className="bill-capture">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileSelect}
        hidden
      />

      {!previewUrl && (
        <div className="bill-capture-empty">
          <button type="button" className="bill-capture-trigger" onClick={triggerPicker}>
            <ImagePlus size={22} />
            <span>{t('bill.add_photo')}</span>
          </button>
          <p className="muted-text">{t('bill.photo_hint')}</p>
          {error && <p className="muted-text" style={{ color: '#dc2626' }}>{error}</p>}
        </div>
      )}

      {previewUrl && scanMode === 'none' && (
        <div className="bill-capture-preview">
          <div className="bill-capture-image-wrap">
            <img src={previewUrl} alt={t('bill.take_photo')} className="bill-capture-image" />
            <button type="button" className="bill-capture-remove" onClick={handleRemove} aria-label={t('bill.remove_photo')}>
              <X size={16} />
            </button>
          </div>
          {!photoConfirmed ? (
            <div className="bill-capture-actions">
              <button type="button" className="btn btn-outline" onClick={handleRetake}>
                <RotateCcw size={15} /> {t('bill.retake')}
              </button>
              <button type="button" className="btn btn-primary" onClick={handleConfirm}>
                <Check size={15} /> {t('bill.use_photo')}
              </button>
            </div>
          ) : (
            <div className="bill-capture-scan-actions">
              <button type="button" className="btn btn-outline" onClick={() => setScanMode('ocr')}>
                <ScanText size={15} /> {t('bill.ocr_extract')}
              </button>
              <button type="button" className="btn btn-outline" onClick={() => setScanMode('qr')}>
                <QrCode size={15} /> {t('bill.qr_scan')}
              </button>
            </div>
          )}
        </div>
      )}

      {previewUrl && scanMode === 'ocr' && (
        <BillOcr
          language={language}
          imageUrl={previewUrl}
          onConfirm={handleOcrConfirm}
          onSkip={handleScanSkip}
        />
      )}

      {previewUrl && scanMode === 'qr' && (
        <BillQr
          language={language}
          imageUrl={previewUrl}
          onConfirm={handleQrConfirm}
          onSkip={handleScanSkip}
          onUseOcr={() => setScanMode('ocr')}
        />
      )}

      {scanMode === 'conflict' && pendingCandidate && (
        <BillConflictResolver
          language={language}
          current={currentFormValues}
          candidate={pendingCandidate.data}
          source={pendingCandidate.source}
          onApply={handleConflictApply}
          onCancel={handleConflictCancel}
        />
      )}

      {error && !previewUrl && (
        <p className="muted-text" style={{ color: '#dc2626', fontSize: '13px' }}>
          <Camera size={14} /> {t('bill.capture_error')}
        </p>
      )}
    </div>
  );
}

export default BillCapture;
export { isValidPanNumber, EMPTY_BILL_DATA };
