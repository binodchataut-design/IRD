import { useState, type ReactNode } from 'react';
import { Check, Edit3, GitBranch } from 'lucide-react';
import { AppStrings } from '@/i18n/strings';
import { isValidPanNumber } from '@/utils/couponUtils';
import { BILL_DATA_FIELDS, type BillData } from '@/utils/billData';
import type { AppLanguage } from '@/types';

type Source = 'ocr' | 'qr';

interface BillConflictResolverProps {
  language: AppLanguage;
  current: BillData;
  candidate: BillData;
  source: Source;
  onApply: (resolved: BillData) => void;
  onCancel: () => void;
}

interface FieldChoice {
  selected: 'current' | 'candidate' | 'custom';
  customValue: string;
}

function labelForField(field: keyof BillData, lang: AppLanguage): string {
  const keys: Record<keyof BillData, string> = {
    sellerName: 'bill.ocr_seller',
    pan: 'bill.ocr_pan',
    invoiceNumber: 'bill.ocr_invoice',
    date: 'bill.ocr_date',
    amount: 'bill.ocr_amount',
  };
  return AppStrings.get(keys[field], lang);
}

export function BillConflictResolver({ language, current, candidate, source, onApply, onCancel }: BillConflictResolverProps) {
  const t = (k: string) => AppStrings.get(k, language);
  const sourceLabel = source === 'ocr' ? t('bill.conflict_ocr') : t('bill.conflict_qr');

  const fieldsWithConflict = BILL_DATA_FIELDS.filter(
    (f) => current[f].trim() !== '' && candidate[f].trim() !== '' && current[f].trim() !== candidate[f].trim()
  );
  const fieldsToFill = BILL_DATA_FIELDS.filter(
    (f) => current[f].trim() === '' && candidate[f].trim() !== ''
  );
  const allRelevantFields = [...new Set([...fieldsWithConflict, ...fieldsToFill])];

  const [choices, setChoices] = useState<Record<string, FieldChoice>>(() => {
    const init: Record<string, FieldChoice> = {};
    for (const f of allRelevantFields) {
      const isConflict = fieldsWithConflict.includes(f);
      init[f] = {
        selected: isConflict ? 'current' : 'candidate',
        customValue: '',
      };
    }
    return init;
  });

  const handleSelect = (field: keyof BillData, choice: 'current' | 'candidate' | 'custom') => {
    setChoices((prev) => ({
      ...prev,
      [field]: {
        selected: choice,
        customValue: choice === 'custom' ? (prev[field]?.customValue || current[field] || candidate[field]) : '',
      },
    }));
  };

  const handleCustomChange = (field: keyof BillData, value: string) => {
    setChoices((prev) => ({ ...prev, [field]: { selected: 'custom', customValue: value } }));
  };

  const handleApply = () => {
    const resolved: BillData = { ...current };
    for (const f of allRelevantFields) {
      const choice = choices[f];
      if (!choice) continue;
      if (choice.selected === 'current') {
        // keep current value (already in resolved)
      } else if (choice.selected === 'candidate') {
        resolved[f] = candidate[f];
      } else {
        resolved[f] = choice.customValue;
      }
    }
    onApply(resolved);
  };

  if (allRelevantFields.length === 0) {
    return (
      <div className="bill-conflict-resolver">
        <div className="bill-conflict-header">
          <GitBranch size={18} />
          <strong>{t('bill.conflict_title')}</strong>
        </div>
        <p className="muted-text">{t('bill.conflict_no_conflict')}</p>
        <div className="bill-conflict-actions">
          <button type="button" className="btn btn-ghost" onClick={onCancel}>{t('common.cancel')}</button>
        </div>
      </div>
    );
  }

  return (
    <div className="bill-conflict-resolver">
      <div className="bill-conflict-header">
        <GitBranch size={18} />
        <strong>{t('bill.conflict_title')}</strong>
      </div>
      <p className="muted-text">{t('bill.conflict_hint')}</p>

      <div className="bill-conflict-fields">
        {allRelevantFields.map((f) => {
          const isConflict = fieldsWithConflict.includes(f);
          const choice = choices[f];
          if (!choice) return null;
          const showPanHint = f === 'pan' && candidate[f] && isValidPanNumber(candidate[f]);
          return (
            <div key={f} className={`bill-conflict-field ${isConflict ? 'has-conflict' : 'fill-only'}`}>
              <span className="bill-conflict-field-label">{labelForField(f, language)}</span>
              {isConflict && (
                <div className="bill-conflict-options">
                  <button
                    type="button"
                    className={`bill-conflict-option ${choice.selected === 'current' ? 'active' : ''}`}
                    onClick={() => handleSelect(f, 'current')}
                  >
                    <span className="bill-conflict-option-label">{t('bill.conflict_current')}</span>
                    <span className="bill-conflict-option-value">{current[f] || '—'}</span>
                  </button>
                  <button
                    type="button"
                    className={`bill-conflict-option ${choice.selected === 'candidate' ? 'active' : ''}`}
                    onClick={() => handleSelect(f, 'candidate')}
                  >
                    <span className="bill-conflict-option-label">{sourceLabel}</span>
                    <span className="bill-conflict-option-value">{candidate[f] || '—'}</span>
                  </button>
                  <button
                    type="button"
                    className={`bill-conflict-option bill-conflict-edit ${choice.selected === 'custom' ? 'active' : ''}`}
                    onClick={() => handleSelect(f, 'custom')}
                  >
                    <Edit3 size={13} /> {t('bill.conflict_edit')}
                  </button>
                  {choice.selected === 'custom' && (
                    <input
                      type={f === 'date' ? 'date' : f === 'amount' ? 'number' : 'text'}
                      value={choice.customValue}
                      onChange={(e) => handleCustomChange(f, e.target.value)}
                      className="bill-conflict-custom-input"
                    />
                  )}
                </div>
              )}
              {!isConflict && (
                <div className="bill-conflict-fill-row">
                  <span className="bill-conflict-candidate-value">{candidate[f]}</span>
                  <button
                    type="button"
                    className="bill-conflict-toggle"
                    onClick={() => handleSelect(f, choice.selected === 'candidate' ? 'current' : 'candidate')}
                  >
                    {choice.selected === 'candidate' ? <Check size={14} /> : null}
                    {choice.selected === 'candidate' ? t('bill.conflict_use_detected') : t('bill.conflict_keep_current')}
                  </button>
                  {choice.selected === 'custom' && (
                    <input
                      type={f === 'date' ? 'date' : f === 'amount' ? 'number' : 'text'}
                      value={choice.customValue}
                      onChange={(e) => handleCustomChange(f, e.target.value)}
                      className="bill-conflict-custom-input"
                    />
                  )}
                  <button
                    type="button"
                    className="bill-conflict-edit-btn"
                    onClick={() => handleSelect(f, 'custom')}
                  >
                    <Edit3 size={13} />
                  </button>
                </div>
              )}
              {showPanHint && (
                <small className="muted-text" style={{ fontSize: '11px', display: 'block', marginTop: '4px' }}>
                  {t('bill.qr_pan_hint')}
                </small>
              )}
            </div>
          );
        })}
      </div>

      <div className="bill-conflict-actions">
        <button type="button" className="btn btn-outline" onClick={onCancel}>{t('common.cancel')}</button>
        <button type="button" className="btn btn-primary" onClick={handleApply}>
          <Check size={15} /> {t('bill.conflict_apply')}
        </button>
      </div>
    </div>
  );
}

export default BillConflictResolver;
export type { ReactNode };
