import { useState, type ReactNode } from 'react';
import { AlertCircle, Check, Loader2, ScanText, X } from 'lucide-react';
import { AppStrings } from '@/i18n/strings';
import { isValidPanNumber, normalizeCouponNumber } from '@/utils/couponUtils';
import { normalizeBillData, type BillData } from '@/utils/billData';
import type { AppLanguage } from '@/types';

export type OcrResult = BillData;

interface BillOcrProps {
  language: AppLanguage;
  imageUrl: string;
  onConfirm: (result: OcrResult) => void;
  onSkip: () => void;
}

type OcrState = 'idle' | 'processing' | 'results' | 'failed';

function detectPan(lines: string[]): string {
  for (const line of lines) {
    const digits = normalizeCouponNumber(line);
    const match = line.match(/\b(\d{9})\b/);
    if (match && isValidPanNumber(match[1])) return match[1];
    void digits;
  }
  const allDigits = lines.join(' ').match(/\b(\d{9})\b/g);
  if (allDigits) {
    for (const d of allDigits) {
      if (isValidPanNumber(d)) return d;
    }
  }
  return '';
}

function detectAmount(lines: string[]): string {
  for (const line of lines) {
    const lower = line.toLowerCase();
    if (lower.includes('total') || lower.includes('amount') || lower.includes('रकम') || lower.includes('जम्मा') || lower.includes('rs') || lower.includes('npr') || lower.includes('रु')) {
      const nums = line.match(/[\d,]+(?:\.\d{1,2})?/g);
      if (nums) {
        const cleaned = nums[nums.length - 1].replace(/,/g, '');
        if (/^\d+(\.\d{1,2})?$/.test(cleaned) && Number(cleaned) > 0) return cleaned;
      }
    }
  }
  const allNums = lines.join(' ').match(/[\d,]+(?:\.\d{1,2})?/g);
  if (allNums) {
    for (let i = allNums.length - 1; i >= 0; i--) {
      const cleaned = allNums[i].replace(/,/g, '');
      if (/^\d+(\.\d{1,2})?$/.test(cleaned) && Number(cleaned) >= 100) return cleaned;
    }
  }
  return '';
}

function detectInvoice(lines: string[]): string {
  for (const line of lines) {
    const lower = line.toLowerCase();
    if (lower.includes('invoice') || lower.includes('bill no') || lower.includes('receipt no') || lower.includes('चलानी') || lower.includes('बिल नं')) {
      const match = line.match(/([A-Za-z0-9\/\-]{3,})/g);
      if (match) {
        for (const m of match) {
          if (/\d/.test(m) && m.length >= 3 && !/^\d{9}$/.test(m)) return m;
        }
      }
    }
  }
  return '';
}

function detectDate(lines: string[]): string {
  for (const line of lines) {
    const isoMatch = line.match(/(\d{4}-\d{2}-\d{2})/);
    if (isoMatch) return isoMatch[1];
    const slashMatch = line.match(/(\d{1,2})[\/.](\d{1,2})[\/.](\d{2,4})/);
    if (slashMatch) {
      const [, d, m, y] = slashMatch;
      const year = y.length === 2 ? `20${y}` : y;
      const mm = m.padStart(2, '0');
      const dd = d.padStart(2, '0');
      return `${year}-${mm}-${dd}`;
    }
  }
  return '';
}

function detectSeller(lines: string[]): string {
  const skip = ['invoice', 'bill', 'receipt', 'total', 'amount', 'pan', 'vat', 'tax', 'date', 'tel', 'phone', 'address', 'चलानी', 'बिल', 'रकम', 'जम्मा', 'प्यान', 'भ्याट', 'कर', 'मिति', 'फोन', 'ठेगाना'];
  for (const line of lines.slice(0, 8)) {
    const lower = line.toLowerCase().trim();
    if (lower.length < 3 || lower.length > 50) continue;
    if (skip.some((s) => lower.includes(s))) continue;
    if (/^[\d\s\-\.,]+$/.test(line)) continue;
    return line.trim();
  }
  return '';
}

function parseOcrText(text: string): OcrResult {
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  return {
    sellerName: detectSeller(lines),
    pan: detectPan(lines),
    invoiceNumber: detectInvoice(lines),
    date: detectDate(lines),
    amount: detectAmount(lines),
  };
}

export function BillOcr({ language, imageUrl, onConfirm, onSkip }: BillOcrProps) {
  const t = (k: string) => AppStrings.get(k, language);
  const [state, setState] = useState<OcrState>('idle');
  const [result, setResult] = useState<OcrResult>({ sellerName: '', pan: '', invoiceNumber: '', date: '', amount: '' });
  const [edited, setEdited] = useState<OcrResult>(result);

  const runOcr = async () => {
    setState('processing');
    try {
      const { createWorker } = await import('tesseract.js');
      const langs = language === 'ne' ? 'eng+nep' : 'eng';
      const worker = await createWorker(langs);
      const { data } = await worker.recognize(imageUrl);
      await worker.terminate();
      const parsed = normalizeBillData(parseOcrText(data.text));
      const hasAny = parsed.sellerName || parsed.pan || parsed.invoiceNumber || parsed.date || parsed.amount;
      if (!hasAny) {
        setState('failed');
      } else {
        setResult(parsed);
        setEdited(parsed);
        setState('results');
      }
    } catch {
      setState('failed');
    }
  };

  const handleConfirm = () => {
    onConfirm(edited);
  };

  const hasFields = !!(edited.sellerName || edited.pan || edited.invoiceNumber || edited.date || edited.amount);
  const panValid = edited.pan ? isValidPanNumber(edited.pan) : false;

  if (state === 'idle') {
    return (
      <div className="bill-ocr-section">
        <button type="button" className="btn btn-outline bill-ocr-trigger" onClick={runOcr}>
          <ScanText size={16} /> {t('bill.ocr_extract')}
        </button>
        <button type="button" className="btn btn-ghost" onClick={onSkip}>
          {t('bill.ocr_skip')}
        </button>
      </div>
    );
  }

  if (state === 'processing') {
    return (
      <div className="bill-ocr-processing">
        <Loader2 size={22} className="spin" />
        <span>{t('bill.ocr_processing')}</span>
      </div>
    );
  }

  if (state === 'failed') {
    return (
      <div className="bill-ocr-failed">
        <AlertCircle size={20} />
        <span>{t('bill.ocr_failed')}</span>
        <div className="bill-ocr-actions">
          <button type="button" className="btn btn-outline" onClick={runOcr}>
            {t('bill.ocr_try_again')}
          </button>
          <button type="button" className="btn btn-ghost" onClick={onSkip}>
            {t('bill.ocr_continue_manual')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bill-ocr-results">
      <div className="bill-ocr-header">
        <ScanText size={18} />
        <strong>{t('bill.ocr_results_title')}</strong>
        <button type="button" className="bill-ocr-close" onClick={onSkip} aria-label={t('bill.ocr_skip')}>
          <X size={16} />
        </button>
      </div>
      <p className="muted-text">{t('bill.ocr_hint')}</p>
      {!hasFields && <p className="muted-text" style={{ color: '#b45309' }}>{t('bill.ocr_no_fields')}</p>}
      <div className="bill-ocr-fields">
        <OcrField label={t('bill.ocr_seller')} value={edited.sellerName} onChange={(v) => setEdited({ ...edited, sellerName: v })} />
        <OcrField label={t('bill.ocr_pan')} value={edited.pan} onChange={(v) => setEdited({ ...edited, pan: v })} hint={panValid ? t('bill.ocr_pan_hint') : undefined} />
        <OcrField label={t('bill.ocr_invoice')} value={edited.invoiceNumber} onChange={(v) => setEdited({ ...edited, invoiceNumber: v })} />
        <OcrField label={t('bill.ocr_date')} value={edited.date} onChange={(v) => setEdited({ ...edited, date: v })} type="date" />
        <OcrField label={t('bill.ocr_amount')} value={edited.amount} onChange={(v) => setEdited({ ...edited, amount: v })} type="number" />
      </div>
      <div className="bill-ocr-actions">
        <button type="button" className="btn btn-outline" onClick={runOcr}>
          {t('bill.ocr_try_again')}
        </button>
        <button type="button" className="btn btn-primary" onClick={handleConfirm} disabled={!hasFields}>
          <Check size={15} /> {t('bill.ocr_confirm')}
        </button>
      </div>
    </div>
  );
}

function OcrField({ label, value, onChange, type = 'text', hint }: { label: string; value: string; onChange: (v: string) => void; type?: string; hint?: string }): ReactNode {
  return (
    <label className="field">
      <span>{label}</span>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} />
      {hint && <small className="muted-text" style={{ fontSize: '11px' }}>{hint}</small>}
    </label>
  );
}

export default BillOcr;
