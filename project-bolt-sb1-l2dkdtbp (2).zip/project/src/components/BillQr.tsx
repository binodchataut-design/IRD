import { useState, type ReactNode } from 'react';
import { AlertCircle, Check, Loader2, QrCode, X } from 'lucide-react';
import { AppStrings } from '@/i18n/strings';
import { isValidPanNumber, normalizeCouponNumber } from '@/utils/couponUtils';
import { normalizeBillData, type BillData } from '@/utils/billData';
import type { AppLanguage } from '@/types';

export type QrResult = BillData & { qrContent: string };

interface BillQrProps {
  language: AppLanguage;
  imageUrl: string;
  onConfirm: (result: QrResult) => void;
  onSkip: () => void;
  onUseOcr?: () => void;
}

type QrState = 'idle' | 'processing' | 'results' | 'failed';

function detectPanFromText(text: string): string {
  const match = text.match(/\b(\d{9})\b/);
  if (match && isValidPanNumber(match[1])) return match[1];
  const digits = normalizeCouponNumber(text).match(/\d{9}/);
  if (digits && isValidPanNumber(digits[0])) return digits[0];
  return '';
}

function detectAmountFromText(text: string): string {
  const nums = text.match(/[\d,]+(?:\.\d{1,2})?/g);
  if (nums) {
    for (let i = nums.length - 1; i >= 0; i--) {
      const cleaned = nums[i].replace(/,/g, '');
      if (/^\d+(\.\d{1,2})?$/.test(cleaned) && Number(cleaned) >= 100) return cleaned;
    }
  }
  return '';
}

function detectInvoiceFromText(text: string): string {
  const match = text.match(/(INV[A-Za-z0-9\/\-]{2,}|[A-Z]{2,}[-\/]?\d{2,}[-\/]?\d*)/);
  if (match) return match[1];
  return '';
}

function detectDateFromText(text: string): string {
  const isoMatch = text.match(/(\d{4}-\d{2}-\d{2})/);
  if (isoMatch) return isoMatch[1];
  const slashMatch = text.match(/(\d{1,2})[\/.](\d{1,2})[\/.](\d{2,4})/);
  if (slashMatch) {
    const [, d, m, y] = slashMatch;
    const year = y.length === 2 ? `20${y}` : y;
    const mm = m.padStart(2, '0');
    const dd = d.padStart(2, '0');
    return `${year}-${mm}-${dd}`;
  }
  return '';
}

function parseQrContent(content: string): QrResult {
  let sellerName = '';
  let pan = '';
  let invoiceNumber = '';
  let date = '';
  let amount = '';

  const trimmed = content.trim();
  const isJson = trimmed.startsWith('{') || trimmed.startsWith('[');

  if (isJson) {
    try {
      const parsed = JSON.parse(trimmed);
      const obj = Array.isArray(parsed) ? parsed[0] : parsed;
      const lookup: Record<string, string> = {};
      const walk = (o: unknown, prefix = '') => {
        if (typeof o === 'object' && o !== null) {
          for (const [k, v] of Object.entries(o as Record<string, unknown>)) {
            if (typeof v === 'string' || typeof v === 'number') lookup[`${prefix}${k}`] = String(v);
            else walk(v, `${k}.`);
          }
        }
      };
      walk(parsed);
      const get = (...keys: string[]): string => {
        for (const k of keys) {
          const lk = k.toLowerCase();
          for (const [field, val] of Object.entries(lookup)) {
            if (field.toLowerCase().includes(lk)) return val;
          }
        }
        return '';
      };
      sellerName = get('seller', 'merchant', 'name', 'vendor', 'shop', 'firm');
      pan = detectPanFromText(get('pan', 'vat', 'taxid', 'tax_id', 'tin'));
      invoiceNumber = get('invoice', 'bill', 'receipt', 'invoiceno', 'invoice_number', 'billno');
      if (!invoiceNumber) invoiceNumber = detectInvoiceFromText(trimmed);
      date = detectDateFromText(get('date', 'datetime', 'billdate', 'invoice_date'));
      amount = detectAmountFromText(get('amount', 'total', 'grand_total', 'net_amount', 'rs', 'npr'));
    } catch {
      pan = detectPanFromText(trimmed);
      invoiceNumber = detectInvoiceFromText(trimmed);
      date = detectDateFromText(trimmed);
      amount = detectAmountFromText(trimmed);
    }
  } else {
    pan = detectPanFromText(trimmed);
    invoiceNumber = detectInvoiceFromText(trimmed);
    date = detectDateFromText(trimmed);
    amount = detectAmountFromText(trimmed);
    if (!sellerName) {
      const lines = trimmed.split(/[\n,;|]/).map((l) => l.trim()).filter(Boolean);
      for (const line of lines.slice(0, 5)) {
        if (line.length >= 3 && line.length <= 50 && !/^[\d\s\-\.,]+$/.test(line)) {
          sellerName = line;
          break;
        }
      }
    }
  }

  const normalized = normalizeBillData({ sellerName, pan, invoiceNumber, date, amount });
  return { ...normalized, qrContent: content };
}

async function loadImageData(url: string): Promise<ImageData> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) { reject(new Error('no ctx')); return; }
      ctx.drawImage(img, 0, 0);
      resolve(ctx.getImageData(0, 0, canvas.width, canvas.height));
    };
    img.onerror = () => reject(new Error('img load'));
    img.src = url;
  });
}

export function BillQr({ language, imageUrl, onConfirm, onSkip, onUseOcr }: BillQrProps) {
  const t = (k: string) => AppStrings.get(k, language);
  const [state, setState] = useState<QrState>('idle');
  const [decoded, setDecoded] = useState<string[]>([]);
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [edited, setEdited] = useState<QrResult>({ sellerName: '', pan: '', invoiceNumber: '', date: '', amount: '', qrContent: '' });

  const runQr = async () => {
    setState('processing');
    try {
      const jsQR = (await import('jsqr')).default;
      const imageData = await loadImageData(imageUrl);
      const code = jsQR(imageData.data, imageData.width, imageData.height);
      if (code && code.data) {
        const results = [code.data];
        setDecoded(results);
        setSelectedIdx(0);
        const parsed = parseQrContent(results[0]);
        setEdited(parsed);
        setState('results');
      } else {
        setState('failed');
      }
    } catch {
      setState('failed');
    }
  };

  const handleConfirm = () => {
    onConfirm(edited);
  };

  const isUrl = (text: string): boolean => /^https?:\/\//i.test(text.trim());

  if (state === 'idle') {
    return (
      <div className="bill-qr-section">
        <button type="button" className="btn btn-outline bill-qr-trigger" onClick={runQr}>
          <QrCode size={16} /> {t('bill.qr_scan')}
        </button>
        {onUseOcr && (
          <button type="button" className="btn btn-ghost" onClick={onUseOcr}>
            {t('bill.qr_continue_ocr')}
          </button>
        )}
        <button type="button" className="btn btn-ghost" onClick={onSkip}>
          {t('bill.qr_continue_manual')}
        </button>
      </div>
    );
  }

  if (state === 'processing') {
    return (
      <div className="bill-qr-processing">
        <Loader2 size={22} className="spin" />
        <span>{t('bill.qr_scanning')}</span>
      </div>
    );
  }

  if (state === 'failed') {
    return (
      <div className="bill-qr-failed">
        <AlertCircle size={20} />
        <span>{t('bill.qr_no_found')}</span>
        <div className="bill-qr-actions">
          <button type="button" className="btn btn-outline" onClick={runQr}>
            {t('bill.qr_try_again')}
          </button>
          {onUseOcr && (
            <button type="button" className="btn btn-ghost" onClick={onUseOcr}>
              {t('bill.qr_continue_ocr')}
            </button>
          )}
          <button type="button" className="btn btn-ghost" onClick={onSkip}>
            {t('bill.qr_continue_manual')}
          </button>
        </div>
      </div>
    );
  }

  const hasFields = !!(edited.sellerName || edited.pan || edited.invoiceNumber || edited.date || edited.amount);
  const panValid = edited.pan ? isValidPanNumber(edited.pan) : false;
  const urlWarning = isUrl(edited.qrContent);

  return (
    <div className="bill-qr-results">
      <div className="bill-qr-header">
        <QrCode size={18} />
        <strong>{t('bill.qr_review_title')}</strong>
        <button type="button" className="bill-qr-close" onClick={onSkip} aria-label={t('bill.qr_continue_manual')}>
          <X size={16} />
        </button>
      </div>
      <p className="muted-text">{t('bill.qr_review_hint')}</p>

      {decoded.length > 1 && (
        <p className="muted-text" style={{ color: '#b45309' }}>{t('bill.qr_multiple')}</p>
      )}

      <div className="bill-qr-raw">
        <span>{t('bill.qr_content')}</span>
        <textarea value={edited.qrContent} onChange={(e) => setEdited({ ...edited, qrContent: e.target.value })} rows={3} />
      </div>

      {urlWarning && (
        <p className="muted-text" style={{ color: '#b45309', fontSize: '12px' }}>
          <AlertCircle size={13} /> {t('bill.qr_url_warning')}
        </p>
      )}

      <div className="bill-qr-fields">
        <QrField label={t('bill.ocr_seller')} value={edited.sellerName} onChange={(v) => setEdited({ ...edited, sellerName: v })} />
        <QrField label={t('bill.ocr_pan')} value={edited.pan} onChange={(v) => setEdited({ ...edited, pan: v })} hint={panValid ? t('bill.qr_pan_hint') : undefined} />
        <QrField label={t('bill.ocr_invoice')} value={edited.invoiceNumber} onChange={(v) => setEdited({ ...edited, invoiceNumber: v })} />
        <QrField label={t('bill.ocr_date')} value={edited.date} onChange={(v) => setEdited({ ...edited, date: v })} type="date" />
        <QrField label={t('bill.ocr_amount')} value={edited.amount} onChange={(v) => setEdited({ ...edited, amount: v })} type="number" />
      </div>

      <div className="bill-qr-actions">
        <button type="button" className="btn btn-outline" onClick={runQr}>
          {t('bill.qr_try_again')}
        </button>
        <button type="button" className="btn btn-primary" onClick={handleConfirm} disabled={!hasFields && !edited.qrContent.trim()}>
          <Check size={15} /> {t('bill.qr_use_data')}
        </button>
      </div>
    </div>
  );
}

function QrField({ label, value, onChange, type = 'text', hint }: { label: string; value: string; onChange: (v: string) => void; type?: string; hint?: string }): ReactNode {
  return (
    <label className="field">
      <span>{label}</span>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} />
      {hint && <small className="muted-text" style={{ fontSize: '11px' }}>{hint}</small>}
    </label>
  );
}

export default BillQr;
