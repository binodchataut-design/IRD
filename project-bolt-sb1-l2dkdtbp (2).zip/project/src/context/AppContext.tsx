import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import type {
  AppLanguage,
  ClaimReportData,
  Coupon,
  CouponPrefillData,
  DrawAnnouncement,
  EligibilityPrefillData,
  ManualResultCheck,
  ScreenName,
  Transaction,
} from '@/types';
import { getSampleCoupons, getSampleTransactions } from '@/utils/sampleData';
import { getCurrentDrawPeriod } from '@/utils/nepaliDate';

const STORAGE_KEY = 'rasid-khata-data-v1';
const LANG_KEY = 'rasid-khata-lang';
const RESULT_CHECKS_KEY = 'rasid-khata-manual-result-checks';
const MAX_RESULT_CHECKS = 50;

interface StoredData {
  transactions: Transaction[];
  coupons: Coupon[];
  draws: DrawAnnouncement[];
}

interface AppContextValue {
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  toggleLanguage: () => void;

  screen: ScreenName;
  navigate: (screen: ScreenName) => void;
  navigateBack: () => void;

  transactions: Transaction[];
  coupons: Coupon[];
  draws: DrawAnnouncement[];

  addTransaction: (tx: Omit<Transaction, 'id' | 'createdAt'>) => void;
  deleteTransaction: (id: string) => void;
  getTransaction: (id: string) => Transaction | undefined;
  selectedTransactionId: string | null;
  setSelectedTransactionId: (id: string | null) => void;

  addCoupon: (coupon: Omit<Coupon, 'id' | 'createdAt'>) => void;
  addBulkCoupons: (numbers: string[], defaults?: { merchantName?: string; drawPeriod?: string }) => void;
  deleteCoupon: (id: string) => void;

  addDraw: (draw: Omit<DrawAnnouncement, 'id' | 'createdAt'>) => void;

  resultChecks: ManualResultCheck[];
  addResultCheck: (check: Omit<ManualResultCheck, 'id' | 'checkedAt' | 'source'>) => void;
  clearResultChecks: () => void;

  claimData: ClaimReportData | null;
  setClaimData: (data: ClaimReportData | null) => void;

  eligibilityPrefill: EligibilityPrefillData | null;
  setEligibilityPrefill: (data: EligibilityPrefillData | null) => void;

  couponPrefill: CouponPrefillData | null;
  setCouponPrefill: (data: CouponPrefillData | null) => void;

  toast: string | null;
  showToast: (msg: string) => void;

  exportData: () => void;
  importData: (json: string) => boolean;
  clearData: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<AppLanguage>(() => {
    const saved = localStorage.getItem(LANG_KEY);
    return saved === 'ne' ? 'ne' : 'en';
  });

  const [screen, setScreen] = useState<ScreenName>('welcome');
  const [screenHistory, setScreenHistory] = useState<ScreenName[]>([]);

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [draws, setDraws] = useState<DrawAnnouncement[]>([]);

  const [resultChecks, setResultChecks] = useState<ManualResultCheck[]>([]);

  const [selectedTransactionId, setSelectedTransactionId] = useState<string | null>(null);
  const [claimData, setClaimData] = useState<ClaimReportData | null>(null);
  const [eligibilityPrefill, setEligibilityPrefill] = useState<EligibilityPrefillData | null>(null);
  const [couponPrefill, setCouponPrefill] = useState<CouponPrefillData | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const data: StoredData = JSON.parse(saved);
        setTransactions(data.transactions ?? []);
        setCoupons(data.coupons ?? []);
        setDraws(data.draws ?? []);
      } catch {
        // ignore
      }
    } else {
      setTransactions(getSampleTransactions());
      setCoupons(getSampleCoupons());
    }

    const savedChecks = localStorage.getItem(RESULT_CHECKS_KEY);
    if (savedChecks) {
      try {
        const checks: ManualResultCheck[] = JSON.parse(savedChecks);
        if (Array.isArray(checks)) setResultChecks(checks);
      } catch {
        // ignore
      }
    }
  }, []);

  useEffect(() => {
    const data: StoredData = { transactions, coupons, draws };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [transactions, coupons, draws]);

  useEffect(() => {
    localStorage.setItem(RESULT_CHECKS_KEY, JSON.stringify(resultChecks));
  }, [resultChecks]);

  const setLanguage = useCallback((lang: AppLanguage) => {
    setLanguageState(lang);
    localStorage.setItem(LANG_KEY, lang);
  }, []);

  const toggleLanguage = useCallback(() => {
    setLanguageState((prev) => {
      const next = prev === 'en' ? 'ne' : 'en';
      localStorage.setItem(LANG_KEY, next);
      return next;
    });
  }, []);

  const navigate = useCallback((s: ScreenName) => {
    setScreenHistory((h) => [...h, screen]);
    setScreen(s);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [screen]);

  const navigateBack = useCallback(() => {
    setScreenHistory((h) => {
      if (h.length === 0) {
        setScreen('home');
        return h;
      }
      const prev = h[h.length - 1];
      setScreen(prev);
      return h.slice(0, -1);
    });
  }, []);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }, []);

  const addTransaction = useCallback((tx: Omit<Transaction, 'id' | 'createdAt'>) => {
    const newTx: Transaction = {
      ...tx,
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
      createdAt: new Date().toISOString(),
    };
    setTransactions((prev) => [newTx, ...prev]);
  }, []);

  const deleteTransaction = useCallback((id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const getTransaction = useCallback((id: string) => transactions.find((t) => t.id === id), [transactions]);

  const addCoupon = useCallback((coupon: Omit<Coupon, 'id' | 'createdAt'>) => {
    const newCoupon: Coupon = {
      ...coupon,
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
      createdAt: new Date().toISOString(),
    };
    setCoupons((prev) => [newCoupon, ...prev]);
  }, []);

  const addBulkCoupons = useCallback((
    numbers: string[],
    defaults?: { merchantName?: string; drawPeriod?: string }
  ) => {
    const now = new Date().toISOString();
    const today = new Date().toISOString().slice(0, 10);
    const period = defaults?.drawPeriod ?? getCurrentDrawPeriod(language).drawPeriod;
    const newCoupons: Coupon[] = numbers.map((num, i) => ({
      id: Date.now().toString(36) + i.toString(36) + Math.random().toString(36).slice(2, 6),
      couponNumber: num,
      date: today,
      drawPeriod: period,
      merchantName: defaults?.merchantName ?? null,
      amount: null,
      paymentMethod: null,
      invoiceNumber: null,
      notes: null,
      createdAt: now,
    }));
    setCoupons((prev) => [...newCoupons, ...prev]);
  }, []);

  const deleteCoupon = useCallback((id: string) => {
    setCoupons((prev) => prev.filter((c) => c.id !== id));
  }, []);

  const addResultCheck = useCallback((check: Omit<ManualResultCheck, 'id' | 'checkedAt' | 'source'>) => {
    const newCheck: ManualResultCheck = {
      ...check,
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
      checkedAt: new Date().toISOString(),
      source: 'USER_ENTERED',
    };
    setResultChecks((prev) => {
      const filtered = prev.filter((r) => {
        const sameDraw = (r.drawTitle ?? null) === (newCheck.drawTitle ?? null) && (r.drawPeriod ?? null) === (newCheck.drawPeriod ?? null);
        const sameResults = r.enteredResults.length === newCheck.enteredResults.length && r.enteredResults.every((n, i) => n === newCheck.enteredResults[i]);
        return !(sameDraw && sameResults);
      });
      return [newCheck, ...filtered].slice(0, MAX_RESULT_CHECKS);
    });
  }, []);

  const clearResultChecks = useCallback(() => {
    setResultChecks([]);
    localStorage.removeItem(RESULT_CHECKS_KEY);
  }, []);

  const addDraw = useCallback((draw: Omit<DrawAnnouncement, 'id' | 'createdAt'>) => {
    const newDraw: DrawAnnouncement = {
      ...draw,
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
      createdAt: new Date().toISOString(),
    };
    setDraws((prev) => [newDraw, ...prev]);
  }, []);

  const exportData = useCallback(() => {
    const data: StoredData = { transactions, coupons, draws };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rasid-khata-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [transactions, coupons, draws]);

  const importData = useCallback((json: string): boolean => {
    try {
      const data: StoredData = JSON.parse(json);
      if (Array.isArray(data.transactions)) setTransactions(data.transactions);
      if (Array.isArray(data.coupons)) setCoupons(data.coupons);
      if (Array.isArray(data.draws)) setDraws(data.draws);
      return true;
    } catch {
      return false;
    }
  }, []);

  const clearData = useCallback(() => {
    setTransactions([]);
    setCoupons([]);
    setDraws([]);
  }, []);

  const value: AppContextValue = {
    language,
    setLanguage,
    toggleLanguage,
    screen,
    navigate,
    navigateBack,
    transactions,
    coupons,
    draws,
    addTransaction,
    deleteTransaction,
    getTransaction,
    selectedTransactionId,
    setSelectedTransactionId,
    addCoupon,
    addBulkCoupons,
    deleteCoupon,
    addDraw,
    resultChecks,
    addResultCheck,
    clearResultChecks,
    claimData,
    setClaimData,
    eligibilityPrefill,
    setEligibilityPrefill,
    couponPrefill,
    setCouponPrefill,
    toast,
    showToast,
    exportData,
    importData,
    clearData,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
