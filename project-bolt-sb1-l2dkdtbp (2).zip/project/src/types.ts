export type AppLanguage = 'en' | 'ne';
export type PaymentMethod = 'DIGITAL_WALLET' | 'QR_PAYMENT' | 'MOBILE_BANKING' | 'CARD' | 'CASH' | 'BANK_TRANSFER' | 'OTHER';
export type EligibilityStatus = 'COUPON_ADDED' | 'AWAITING_COUPON' | 'LIKELY_ELIGIBLE' | 'NEEDS_VERIFICATION' | 'LIKELY_NOT_ELIGIBLE' | 'NOT_CHECKED';
export type PurchasePurpose = 'PERSONAL' | 'BUSINESS' | 'GOVERNMENT' | 'UNKNOWN';
export type SellerPanOption = 'YES' | 'NO' | 'DONT_KNOW';
export type TransactionCategory = 'NORMAL_GOODS' | 'FOOD_RESTAURANT' | 'ELECTRONICS' | 'CLOTHING' | 'ELECTRICITY' | 'TELEPHONE_INTERNET' | 'AIRLINE' | 'TRANSPORT_FREIGHT' | 'VEHICLE' | 'OTHER' | 'DONT_KNOW';
export interface Transaction { id: string; date: string; sellerName: string; amount: number; paymentMethod: PaymentMethod; panVat: string | null; invoiceNumber: string | null; couponNumber: string | null; eligibilityStatus: EligibilityStatus; notes: string | null; photoReference: string | null; createdAt: string; }
export interface Coupon { id: string; couponNumber: string; date: string | null; drawPeriod: string | null; merchantName: string | null; amount: number | null; paymentMethod: string | null; invoiceNumber: string | null; notes: string | null; createdAt: string; }
export interface DrawAnnouncement { id: string; title: string; drawPeriod: string; announcementDate: string; winningNumbers: string[]; sourceUrl: string; sourceName: string; notes: string | null; createdAt: string; }
export interface ClaimReportData { coupon: Coupon; transaction: Transaction | null; drawTitle: string | null; drawPeriod: string | null; announcementDate: string | null; }
export interface EligibilityPrefillData { amount: number; paymentMethod: PaymentMethod; panVat: string | null; sellerName: string; invoiceNumber: string | null; date: string | null; }
export interface CouponPrefillData { merchantName: string | null; drawPeriod: string | null; invoiceNumber: string | null; amount: number | null; }
export interface BulkParseResult { totalExtracted: number; validNew: string[]; duplicateInBatch: string[]; alreadySaved: string[]; invalidTokens: string[]; }
export type ScreenName = 'welcome' | 'home' | 'invoices' | 'add_invoice' | 'invoice_detail' | 'coupons' | 'add_coupon' | 'bulk_add_coupons' | 'winner_checker' | 'claim_report' | 'draw_history' | 'check_eligibility' | 'verify_vendor' | 'ird_info' | 'data_backup';
export type DrawResultStatus = 'NOT_CHECKED' | 'POSSIBLE_MATCH' | 'NOT_MATCHED' | 'OFFICIAL_WINNER_CONFIRMED';

export type ManualResultSource = 'USER_ENTERED';

export interface ManualResultCheck {
  id: string;
  drawTitle: string | null;
  drawPeriod: string | null;
  enteredResults: string[];
  matchedCouponNumbers: string[];
  matched: boolean;
  checkedAt: string;
  source: ManualResultSource;
}
