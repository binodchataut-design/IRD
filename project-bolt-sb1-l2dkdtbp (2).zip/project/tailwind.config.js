import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          primary: '#1E3A5F',
          light: '#3B5A82',
          container: '#E8EDF3',
          border: '#C7D2E0',
          onContainer: '#1E3A5F',
        },
        status: {
          success: '#16A34A',
          successBg: '#F0FDF4',
          successBorder: '#BBF7D0',
          pending: '#D97706',
          pendingBg: '#FFFBEB',
          pendingBorder: '#FDE68A',
          error: '#DC2626',
          errorBg: '#FEF2F2',
          errorBorder: '#FECACA',
        },
        surface: {
          card: '#FFFFFF',
          muted: '#F1F5F9',
        },
        text: {
          primary: '#1E293B',
          secondary: '#64748B',
          muted: '#94A3B8',
        },
        border: {
          subtle: '#E2E8F0',
          divider: '#CBD5E1',
        },
        amber: {
          primary: '#D97706',
          container: '#FEF3C7',
          border: '#FCD34D',
        },
        emerald: {
          primary: '#059669',
          border: '#A7F3D0',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
    },
  },
  plugins: [],
}

export default config
