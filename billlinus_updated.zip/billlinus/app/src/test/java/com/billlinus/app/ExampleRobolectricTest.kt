package com.billlinus.app

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.billlinus.app.data.BillLinusRepository
import com.billlinus.app.model.Coupon
import com.billlinus.app.model.DarkModePreference
import com.billlinus.app.model.ScreenName
import com.billlinus.app.service.BillOcrService
import com.billlinus.app.service.DrawResultService
import com.billlinus.app.ui.MainViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Bill Linus", appName)
    }

    @Test
    fun `default dark mode preference is LIGHT on clean install`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        // Clear prefs to simulate clean install
        context.getSharedPreferences("bill_linus_prefs", Context.MODE_PRIVATE).edit().clear().commit()

        val repo = BillLinusRepository(context)
        assertEquals(DarkModePreference.LIGHT, repo.darkMode.value)
    }

    @Test
    fun `draw result matching logic finds matching coupon numbers`() {
        val coupons = listOf(
            Coupon(
                id = "c1",
                couponNumber = "007315254493",
                createdAt = "2026-08-15T00:00:00Z"
            ),
            Coupon(
                id = "c2",
                couponNumber = "007315254494",
                createdAt = "2026-08-15T00:00:00Z"
            )
        )

        val winningNumbers = listOf("007315254493", "999999999999", "007 315 254 494")
        val matches = DrawResultService.findMatches(winningNumbers, coupons)

        assertEquals(2, matches.size)
        assertTrue(matches.contains("007315254493"))
        assertTrue(matches.contains("007315254494"))
        assertFalse(matches.contains("999999999999"))
    }

    @Test
    fun `notified matches tracking prevents duplicate alerts`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = BillLinusRepository(context)

        val matchKey = "draw-1_007315254493"
        assertFalse(repo.isMatchNotified(matchKey))

        repo.markMatchNotified(matchKey)
        assertTrue(repo.isMatchNotified(matchKey))
    }

    @Test
    fun `navigation to invoices and coupons and back works correctly`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = MainViewModel(app)

        assertEquals(ScreenName.HOME, vm.currentScreen.value)

        vm.navigateTo(ScreenName.INVOICES)
        assertEquals(ScreenName.INVOICES, vm.currentScreen.value)

        assertTrue(vm.navigateBack())
        assertEquals(ScreenName.HOME, vm.currentScreen.value)

        vm.navigateTo(ScreenName.COUPONS)
        assertEquals(ScreenName.COUPONS, vm.currentScreen.value)

        assertTrue(vm.navigateBack())
        assertEquals(ScreenName.HOME, vm.currentScreen.value)
    }

    @Test
    fun `gemini json response parsing correctly extracts seller, pan, invoice number and amount`() {
        val sampleJson = """
            ```json
            {
              "sellerName": "Bhatbhateni Supermarket Pvt. Ltd.",
              "panVat": "300054321",
              "invoiceNumber": "INV-2083-0982",
              "date": "2026-08-19",
              "totalAmount": 2450.50
            }
            ```
        """.trimIndent()

        val result = BillOcrService.parseGeminiJsonResponse(sampleJson)
        assertTrue(result != null)
        assertTrue(result!!.isSuccess)
        assertEquals("Bhatbhateni Supermarket Pvt. Ltd.", result.sellerName)
        assertEquals("300054321", result.panVat)
        assertEquals("INV-2083-0982", result.invoiceNumber)
        assertEquals("2026-08-19", result.date)
        assertEquals(2450.50, result.totalAmount!!, 0.01)
    }

    @Test
    fun `gemini json response parsing handles partial or invalid json gracefully`() {
        val brokenJson = "Sorry, I couldn't read the image clearly."
        val result = BillOcrService.parseGeminiJsonResponse(brokenJson)
        assertEquals(null, result)
    }

    @Test
    fun `user profile generates stable UUID and preserves it across mobile number changes`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val authRepo = com.billlinus.app.auth.FirebaseAuthRepository(app)

        kotlinx.coroutines.runBlocking {
            val initialProfile = authRepo.saveAccountSetupProfile("9841234567", "Nepali User")
            val initialUuid = initialProfile.uid
            assertTrue("UUID must not be blank", initialUuid.isNotBlank())
            assertEquals("9841234567", initialProfile.mobileNumber)
            assertEquals("NOT_VERIFIED", initialProfile.mobileVerificationStatus)

            // Update mobile number
            val updatedProfile = authRepo.saveAccountSetupProfile("9800000000", "Nepali User")
            assertEquals("UUID must remain permanent across mobile number updates", initialUuid, updatedProfile.uid)
            assertEquals("9800000000", updatedProfile.mobileNumber)
        }
    }

    @Test
    fun `cold start initializes session in unauthenticated state without auto-elevating`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val authRepo = com.billlinus.app.auth.FirebaseAuthRepository(app)

        kotlinx.coroutines.runBlocking {
            authRepo.saveAccountSetupProfile("9841234567")
        }

        // Simulate fresh process instance loading from storage
        val freshAuthRepo = com.billlinus.app.auth.FirebaseAuthRepository(app)
        val state = freshAuthRepo.authState.value
        assertTrue("Cold start must start Unauthenticated", state is com.billlinus.app.auth.AuthState.Unauthenticated)
        assertFalse("Must not auto-authenticate as PasskeyAuthenticated", state is com.billlinus.app.auth.AuthState.PasskeyAuthenticated)
    }

    @Test
    fun `signOut clears active session without deleting local profile or stable UUID`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val authRepo = com.billlinus.app.auth.FirebaseAuthRepository(app)

        kotlinx.coroutines.runBlocking {
            val profile = authRepo.saveAccountSetupProfile("9841234567")
            val uid = profile.uid
            authRepo.signOut()

            val state = authRepo.authState.value
            assertTrue("Must be Unauthenticated after sign out", state is com.billlinus.app.auth.AuthState.Unauthenticated)
            assertEquals("Profile must be retained", uid, authRepo.userProfile.value?.uid)
            assertEquals("9841234567", authRepo.userProfile.value?.mobileNumber)
        }
    }

    @Test
    fun `local profile schema version defaults to 1 and preserves metadata without cloud dependency`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val authRepo = com.billlinus.app.auth.FirebaseAuthRepository(app)

        kotlinx.coroutines.runBlocking {
            val profile = authRepo.saveAccountSetupProfile("9841234567", "Test User")
            assertEquals(1, profile.schemaVersion)
            assertEquals("NOT_VERIFIED", profile.mobileVerificationStatus)
            assertEquals(false, authRepo.isFirebaseConfigured)
        }
    }

    @Test
    fun `passkey enabled state is completely decoupled from cloud authentication`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val authRepo = com.billlinus.app.auth.FirebaseAuthRepository(app)

        kotlinx.coroutines.runBlocking {
            authRepo.saveAccountSetupProfile("9841234567")
            // Passkey not yet created
            assertFalse(authRepo.isPasskeyEnabled.value)
            // AuthState is Unauthenticated, not SignedIn
            assertTrue(authRepo.authState.value is com.billlinus.app.auth.AuthState.Unauthenticated)
        }
    }

    @Test
    fun `user profile maintains local permanent UUID distinct from firebaseUid`() {
        val localUuid = java.util.UUID.randomUUID().toString()
        val firebaseUid = "firebase_auth_user_12345"

        val profile = com.billlinus.app.model.UserProfile(
            uid = localUuid,
            firebaseUid = firebaseUid,
            mobileNumber = "9841234567",
            displayName = "Ram Sharma",
            mobileVerificationStatus = "AUTHENTICATED",
            schemaVersion = 1,
            createdAt = java.time.Instant.now().toString(),
            updatedAt = java.time.Instant.now().toString()
        )

        // uid and firebaseUid are completely distinct
        assertEquals(localUuid, profile.uid)
        assertEquals(firebaseUid, profile.firebaseUid)
        assertNotEquals(profile.uid, profile.firebaseUid)
    }

    @Test
    fun `saveAccountSetupProfile preserves permanent local UUID across mobile number updates`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val authRepo = com.billlinus.app.auth.FirebaseAuthRepository(app)

        kotlinx.coroutines.runBlocking {
            val initial = authRepo.saveAccountSetupProfile("9841111111", "Initial Name")
            val stableUid = initial.uid

            // Update mobile number via repo
            val updated = authRepo.saveAccountSetupProfile("9842222222", "Updated Name")

            assertEquals("Local UID must be preserved", stableUid, updated.uid)
            assertEquals("9842222222", updated.mobileNumber)
            assertEquals("Updated Name", updated.displayName)
        }
    }
}
