package com.billlinus.app.utils

object PhoneUtils {

    fun normalizeNepalMobile(raw: String?): String {
        if (raw == null) return ""
        val digits = raw.filter { it.isDigit() }
        return when {
            digits.startsWith("977") && digits.length == 13 -> digits.substring(3)
            digits.startsWith("0") && digits.length == 11 -> digits.substring(1)
            else -> digits
        }
    }

    fun isValidNepalMobile(raw: String?): Boolean {
        val normalized = normalizeNepalMobile(raw)
        // Nepal mobile numbers are 10 digits starting with 98 or 97
        return normalized.length == 10 && (normalized.startsWith("98") || normalized.startsWith("97"))
    }

    fun formatDisplay(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val norm = normalizeNepalMobile(raw)
        return if (norm.length == 10) {
            "+977 ${norm.substring(0, 3)} ${norm.substring(3, 6)} ${norm.substring(6)}"
        } else {
            raw
        }
    }

    fun isValidPhone(phone: String): Boolean {
        val digits = phone.filter { it.isDigit() }
        return digits.length in 10..14
    }

    fun maskPhone(phone: String?): String {
        if (phone.isNullOrBlank()) return ""
        val digits = phone.filter { it.isDigit() }
        return if (digits.length >= 7) {
            val start = digits.take(3)
            val end = digits.takeLast(2)
            val masked = "*".repeat((digits.length - 5).coerceAtLeast(2))
            "$start$masked$end"
        } else {
            phone
        }
    }

    fun formatPhone(phone: String): String {
        val digits = phone.filter { it.isDigit() }
        return if (digits.length == 10) {
            "${digits.substring(0, 3)}-${digits.substring(3, 6)}-${digits.substring(6)}"
        } else {
            phone
        }
    }
}
