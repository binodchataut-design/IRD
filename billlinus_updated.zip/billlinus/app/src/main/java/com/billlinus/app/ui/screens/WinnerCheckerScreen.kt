package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.ManualResultCheck
import com.billlinus.app.model.ScreenName
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.BillLinusBottomBar
import com.billlinus.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WinnerCheckerScreen(viewModel: MainViewModel) {
    val language by viewModel.language.collectAsState()
    var rawWinningText by remember { mutableStateOf("") }
    var drawTitle by remember { mutableStateOf("") }
    var checkResult by remember { mutableStateOf<ManualResultCheck?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = AppStrings.get("winner.title", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("btn_back_winner")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            BillLinusBottomBar(
                currentScreen = ScreenName.WINNER_CHECKER,
                onNavigate = { viewModel.navigateTo(it) },
                lang = language
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Slate50)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = drawTitle,
                onValueChange = { drawTitle = it },
                label = { Text("Draw Title / Period (e.g., Baisakh 2083 Lucky Draw)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = rawWinningText,
                onValueChange = { rawWinningText = it },
                label = { Text("Paste Winning Coupon Numbers (from official IRD result notice)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .testTag("input_winning_numbers"),
                maxLines = 10
            )

            Button(
                onClick = {
                    if (rawWinningText.isNotBlank()) {
                        checkResult = viewModel.checkWinners(rawWinningText, drawTitle)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_check_winning"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Emerald600, contentColor = Color.White)
            ) {
                Icon(Icons.Default.Celebration, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Check My Coupons")
            }

            checkResult?.let { res ->
                if (res.matched) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Emerald100)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Celebration, contentDescription = null, tint = Emerald600)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Congratulations! You have matching winning coupons!",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Emerald600
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Matched Coupons: ${res.matchedCouponNumbers.joinToString(", ")}",
                                style = MaterialTheme.typography.bodyMedium.copy(color = Slate800)
                            )
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate200)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "No matches found in your saved coupons for this draw.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = Slate700)
                            )
                        }
                    }
                }
            }
        }
    }
}
