package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.PinEntryGrid
import com.billlinus.app.ui.theme.*

@Composable
fun LockScreen(viewModel: MainViewModel) {
    val language by viewModel.language.collectAsState()
    var enteredPin by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate900)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                shape = CircleShape,
                color = Slate800,
                modifier = Modifier.size(72.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Emerald500,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = AppStrings.get("lock.enter_pin", language),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )

            if (showError) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = AppStrings.get("lock.incorrect_pin", language),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Red500
                    )
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // PIN Dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                repeat(4) { idx ->
                    val filled = idx < enteredPin.length
                    Surface(
                        shape = CircleShape,
                        color = if (filled) Emerald500 else Slate700,
                        modifier = Modifier.size(16.dp)
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            PinEntryGrid(
                onNumberClick = { num ->
                    if (enteredPin.length < 4) {
                        enteredPin += num
                        if (enteredPin.length == 4) {
                            val success = viewModel.unlockAppWithPin(enteredPin)
                            if (!success) {
                                showError = true
                                enteredPin = ""
                            }
                        }
                    }
                },
                onDeleteClick = {
                    if (enteredPin.isNotEmpty()) {
                        enteredPin = enteredPin.dropLast(1)
                        showError = false
                    }
                },
                onBiometricClick = {
                    viewModel.unlockWithBiometrics()
                }
            )
        }
    }
}
