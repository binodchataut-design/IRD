package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.theme.*
import com.billlinus.app.utils.CouponUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkAddCouponsScreen(viewModel: MainViewModel) {
    val language by viewModel.language.collectAsState()
    var rawText by remember { mutableStateOf("") }
    var defaultMerchant by remember { mutableStateOf("") }
    var resultCount by remember { mutableStateOf<Int?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Bulk Add Coupons",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("btn_back_bulk")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Slate50)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = defaultMerchant,
                onValueChange = { defaultMerchant = it },
                label = { Text("Default Store / Merchant (Optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = rawText,
                onValueChange = { rawText = it },
                label = { Text("Enter Coupon Numbers (One per line or separated by commas)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .testTag("input_bulk_coupons"),
                maxLines = 15
            )

            Button(
                onClick = {
                    val lines = rawText.split(Regex("[\\r\\n;,\\s]+"))
                        .map { CouponUtils.normalizeCouponNumber(it) }
                        .filter { it.length == 12 }
                        .distinct()

                    if (lines.isNotEmpty()) {
                        val count = viewModel.saveBulkCoupons(lines, defaultMerchant.takeIf { it.isNotBlank() })
                        resultCount = count
                        rawText = ""
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_save_bulk_coupons"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Emerald600, contentColor = Color.White)
            ) {
                Text("Import Coupons")
            }

            if (resultCount != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Emerald100)
                ) {
                    Text(
                        text = "Successfully imported $resultCount coupons!",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Emerald600
                        ),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}
