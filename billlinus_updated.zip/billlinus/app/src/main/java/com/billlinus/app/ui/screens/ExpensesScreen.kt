package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.model.ScreenName
import com.billlinus.app.model.Transaction
import com.billlinus.app.model.TransactionCategory
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.BillLinusBottomBar
import com.billlinus.app.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeParseException
import java.time.temporal.ChronoUnit

private enum class ExpensesTab { CATEGORIES, WARRANTY }

private enum class WarrantyStatus { ACTIVE, EXPIRING_SOON, EXPIRED }

private data class WarrantyItem(
    val transaction: Transaction,
    val purchaseDate: LocalDate,
    val expiryDate: LocalDate,
    val status: WarrantyStatus,
    val daysLeft: Long
)

private data class WarrantyStatusStyle(
    val label: String,
    val bg: Color,
    val fg: Color,
    val icon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(viewModel: MainViewModel) {
    val language by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    var selectedTab by remember { mutableStateOf(ExpensesTab.CATEGORIES) }

    val categoryTotals = remember(transactions) {
        transactions.groupBy { it.category }.mapValues { entry -> entry.value.sumOf { it.amount } }
    }

    val warrantyItems = remember(transactions) {
        val today = LocalDate.now()
        transactions
            .filter { it.hasWarranty && (it.warrantyMonths ?: 0) > 0 }
            .mapNotNull { tx ->
                val purchaseDate = try {
                    LocalDate.parse(tx.date)
                } catch (e: DateTimeParseException) {
                    null
                } ?: return@mapNotNull null
                val months = tx.warrantyMonths ?: return@mapNotNull null
                val expiryDate = purchaseDate.plusMonths(months.toLong())
                val daysLeft = ChronoUnit.DAYS.between(today, expiryDate)
                val status = when {
                    daysLeft < 0 -> WarrantyStatus.EXPIRED
                    daysLeft <= 30 -> WarrantyStatus.EXPIRING_SOON
                    else -> WarrantyStatus.ACTIVE
                }
                WarrantyItem(tx, purchaseDate, expiryDate, status, daysLeft)
            }
            .sortedBy { it.expiryDate }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = AppStrings.get("expenses.title", language),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Slate900
                            )
                        )
                        Text(
                            text = AppStrings.get("expenses.subtitle", language),
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 11.sp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            BillLinusBottomBar(
                currentScreen = ScreenName.EXPENSES,
                onNavigate = { viewModel.navigateTo(it) },
                lang = language
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Slate50)
        ) {
            TabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = Emerald700
            ) {
                Tab(
                    selected = selectedTab == ExpensesTab.CATEGORIES,
                    onClick = { selectedTab = ExpensesTab.CATEGORIES },
                    modifier = Modifier.testTag("tab_expenses_categories"),
                    text = {
                        Text(
                            AppStrings.get("expenses.tab_categories", language),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                )
                Tab(
                    selected = selectedTab == ExpensesTab.WARRANTY,
                    onClick = { selectedTab = ExpensesTab.WARRANTY },
                    modifier = Modifier.testTag("tab_expenses_warranty"),
                    text = {
                        Text(
                            AppStrings.get("expenses.tab_warranty", language),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                )
            }

            when (selectedTab) {
                ExpensesTab.CATEGORIES -> CategoriesTabContent(
                    language = language,
                    categoryTotals = categoryTotals,
                    totalBills = transactions.size
                )
                ExpensesTab.WARRANTY -> WarrantyTabContent(
                    language = language,
                    items = warrantyItems,
                    onViewReceipt = { tx ->
                        viewModel.selectInvoice(tx.id)
                    }
                )
            }
        }
    }
}

@Composable
private fun CategoriesTabContent(
    language: AppLanguage,
    categoryTotals: Map<TransactionCategory, Double>,
    totalBills: Int
) {
    val totalSpending = categoryTotals.values.sum()

    if (categoryTotals.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            EmptyStateCard(
                title = AppStrings.get("expenses.empty_categories_title", language),
                description = AppStrings.get("expenses.empty_categories_desc", language),
                onAction = {},
                actionText = ""
            )
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MetricCard(
                    title = AppStrings.get("expenses.total_spending", language),
                    value = "Rs. ${"%,.0f".format(totalSpending)}",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = AppStrings.get("expenses.total_bills_count", language),
                    value = totalBills.toString(),
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Text(
                text = AppStrings.get("expenses.category_breakdown", language),
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Slate900),
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        items(categoryTotals.entries.sortedByDescending { it.value }.toList()) { entry ->
            val pct = if (totalSpending > 0) (entry.value / totalSpending) * 100 else 0.0
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = entry.key.name.replace("_", " "),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = Slate900)
                        )
                        Text(
                            text = "Rs. ${"%,.0f".format(entry.value)}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Emerald600)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { (pct / 100).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Emerald600,
                        trackColor = Slate100
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = AppStrings.get("expenses.percentage_format", language).format(pct),
                        style = MaterialTheme.typography.labelSmall.copy(color = Slate500, fontSize = 11.sp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 11.sp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Slate900))
        }
    }
}

@Composable
private fun WarrantyTabContent(
    language: AppLanguage,
    items: List<WarrantyItem>,
    onViewReceipt: (Transaction) -> Unit
) {
    if (items.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            EmptyStateCard(
                title = AppStrings.get("expenses.empty_warranty_title", language),
                description = AppStrings.get("expenses.empty_warranty_desc", language),
                onAction = {},
                actionText = ""
            )
        }
        return
    }

    val activeCount = items.count { it.status == WarrantyStatus.ACTIVE }
    val expiringCount = items.count { it.status == WarrantyStatus.EXPIRING_SOON }
    val expiredCount = items.count { it.status == WarrantyStatus.EXPIRED }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = AppStrings.get("expenses.warranty_tracker", language),
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Slate900)
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                WarrantyCountChip(
                    label = AppStrings.get("expenses.active_warranties", language),
                    count = activeCount,
                    bg = Emerald100,
                    fg = Emerald700,
                    modifier = Modifier.weight(1f)
                )
                WarrantyCountChip(
                    label = AppStrings.get("expenses.expiring_soon_count", language),
                    count = expiringCount,
                    bg = Amber100,
                    fg = Amber600,
                    modifier = Modifier.weight(1f)
                )
                WarrantyCountChip(
                    label = AppStrings.get("expenses.expired_count", language),
                    count = expiredCount,
                    bg = Red100,
                    fg = Red600,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        items(items) { item ->
            WarrantyItemCard(language = language, item = item, onViewReceipt = { onViewReceipt(item.transaction) })
        }
    }
}

@Composable
private fun WarrantyCountChip(label: String, count: Int, bg: Color, fg: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(count.toString(), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = fg))
            Text(label, style = MaterialTheme.typography.labelSmall.copy(color = fg, fontSize = 10.sp), maxLines = 1)
        }
    }
}

@Composable
private fun warrantyStatusStyle(status: WarrantyStatus, language: AppLanguage): WarrantyStatusStyle = when (status) {
    WarrantyStatus.ACTIVE -> WarrantyStatusStyle(
        label = AppStrings.get("expenses.status_active", language),
        bg = Emerald100,
        fg = Emerald700,
        icon = Icons.Default.CheckCircle
    )
    WarrantyStatus.EXPIRING_SOON -> WarrantyStatusStyle(
        label = AppStrings.get("expenses.status_expiring_soon", language),
        bg = Amber100,
        fg = Amber600,
        icon = Icons.Default.Schedule
    )
    WarrantyStatus.EXPIRED -> WarrantyStatusStyle(
        label = AppStrings.get("expenses.status_expired", language),
        bg = Red100,
        fg = Red600,
        icon = Icons.Default.ErrorOutline
    )
}

@Composable
private fun WarrantyItemCard(
    language: AppLanguage,
    item: WarrantyItem,
    onViewReceipt: () -> Unit
) {
    val style = warrantyStatusStyle(item.status, language)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f, fill = false)) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = Slate500, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.transaction.sellerName,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Slate900),
                        maxLines = 1
                    )
                }
                Surface(shape = RoundedCornerShape(20.dp), color = style.bg) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = style.icon,
                            contentDescription = null,
                            tint = style.fg,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = style.label,
                            style = MaterialTheme.typography.labelSmall.copy(color = style.fg, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Slate400, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${AppStrings.get("expenses.purchased_on", language)} ${item.purchaseDate}",
                    style = MaterialTheme.typography.labelSmall.copy(color = Slate500, fontSize = 11.sp)
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${AppStrings.get("expenses.expires_on", language)} ${item.expiryDate}",
                    style = MaterialTheme.typography.labelSmall.copy(color = Slate500, fontSize = 11.sp)
                )
                Text(
                    text = AppStrings.get("expenses.warranty_months_label", language).format(item.transaction.warrantyMonths ?: 0),
                    style = MaterialTheme.typography.labelSmall.copy(color = Slate500, fontSize = 11.sp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            val badgeText = when (item.status) {
                WarrantyStatus.EXPIRED -> AppStrings.get("expenses.expired_days_ago_badge", language).format(-item.daysLeft)
                else -> if (item.daysLeft > 60) {
                    AppStrings.get("expenses.months_left_badge", language).format(item.daysLeft / 30)
                } else {
                    AppStrings.get("expenses.days_left_badge", language).format(item.daysLeft)
                }
            }
            Text(
                text = badgeText,
                style = MaterialTheme.typography.labelSmall.copy(color = style.fg, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Slate100)
            Spacer(modifier = Modifier.height(8.dp))

            val hasReceipt = !item.transaction.photoReference.isNullOrBlank()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = hasReceipt) { onViewReceipt() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Image, contentDescription = null, tint = if (hasReceipt) Emerald600 else Slate400, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (hasReceipt) AppStrings.get("expenses.view_receipt", language) else AppStrings.get("expenses.no_receipt_photo", language),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (hasReceipt) Emerald600 else Slate400,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}
