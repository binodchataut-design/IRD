package com.billlinus.app.auth

import com.billlinus.app.model.UserProfile

/**
 * Authentication state representation decoupling user registration/account presence
 * from active in-memory session authentication.
 */
sealed interface AuthState {
    /** Checking initialization or current auth status */
    data object Loading : AuthState

    /** Device is not authenticated in the current session (account and passkey may exist locally) */
    data class Unauthenticated(
        val userProfile: UserProfile?,
        val isPasskeyRegistered: Boolean
    ) : AuthState

    /** Actively executing credential assertion with Credential Manager */
    data object Authenticating : AuthState

    /** Device authenticated via modern Android Credential Manager Passkey */
    data class PasskeyAuthenticated(val userProfile: UserProfile) : AuthState

    /** A user is currently authenticated with their profile details (e.g. Firebase sign-in) */
    data class SignedIn(val userProfile: UserProfile) : AuthState

    /** Account profile setup on device with mobile number (unauthenticated/pre-passkey state) */
    data class AccountSetup(val userProfile: UserProfile?) : AuthState

    /** Device does not have passkey or Credential Manager provider support */
    data class PasskeyNotAvailable(val message: String) : AuthState

    /** Cloud identity conflict when signed-in Firebase UID does not match already linked account */
    data class FirebaseIdentityConflict(
        val existingFirebaseUid: String,
        val newFirebaseUid: String
    ) : AuthState

    /** An authentication error occurred */
    data class Error(val message: String) : AuthState

    /** Firebase is not configured or google-services.json is missing */
    data object FirebaseNotConfigured : AuthState

    /** Firebase is initialized and available, but no user is currently authenticated */
    data object SignedOut : AuthState
}

/**
 * High-level Firebase availability status.
 */
enum class FirebaseStatus {
    CONFIGURED,
    NOT_CONFIGURED
}
