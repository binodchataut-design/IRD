package com.billlinus.app.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.billlinus.app.auth.AuthRepository
import com.billlinus.app.auth.AuthState
import com.billlinus.app.auth.FirebaseAuthRepository
import com.billlinus.app.auth.GoogleSignInResult
import com.billlinus.app.auth.PasskeyResult
import com.billlinus.app.data.BillLinusRepository
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.model.ClaimReportData
import com.billlinus.app.model.Coupon
import com.billlinus.app.model.CouponPrefillData
import com.billlinus.app.model.DarkModePreference
import com.billlinus.app.model.DrawAnnouncement
import com.billlinus.app.model.EligibilityPrefillData
import com.billlinus.app.model.EligibilityStatus
import com.billlinus.app.model.FontScalePreference
import com.billlinus.app.model.ManualResultCheck
import com.billlinus.app.model.PaymentMethod
import com.billlinus.app.model.ScreenName
import com.billlinus.app.model.Transaction
import com.billlinus.app.model.TransactionCategory
import com.billlinus.app.model.UserProfile
import com.billlinus.app.service.DrawResultService
import com.billlinus.app.service.EligibilityService
import com.billlinus.app.service.NotificationHelper
import com.billlinus.app.service.TransactionEligibilityInput
import com.billlinus.app.utils.CouponUtils
import com.billlinus.app.utils.DrawPeriodInfo
import com.billlinus.app.utils.NepaliDateUtils
import com.billlinus.app.utils.SampleData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BillLinusRepository(application)
    private val authRepository: AuthRepository = FirebaseAuthRepository(application)

    val authState: StateFlow<AuthState> = authRepository.authState
    val userProfile: StateFlow<UserProfile?> = authRepository.userProfile
    val isPasskeyEnabled: StateFlow<Boolean> = authRepository.isPasskeyEnabled
    val isFirebaseConfigured: Boolean get() = authRepository.isFirebaseConfigured
    val currentUserId: String? get() = authRepository.currentUserId

    val language: StateFlow<AppLanguage> = repository.language
    val darkMode: StateFlow<DarkModePreference> = repository.darkMode
    val fontScale: StateFlow<FontScalePreference> = repository.fontScale
    val hasCompletedWelcome: StateFlow<Boolean> = repository.hasCompletedWelcome
    val transactions: StateFlow<List<Transaction>> = repository.transactions
    val coupons: StateFlow<List<Coupon>> = repository.coupons
    val draws: StateFlow<List<DrawAnnouncement>> = repository.draws
    val lastDrawsFetchTimestamp: StateFlow<Long> = repository.lastDrawsFetchTimestamp
    val resultChecks: StateFlow<List<ManualResultCheck>> = repository.resultChecks
    val isAppLockEnabled: StateFlow<Boolean> = repository.isAppLockEnabled

    private val _isRefreshingDraws = MutableStateFlow(false)
    val isRefreshingDraws: StateFlow<Boolean> = _isRefreshingDraws.asStateFlow()

    private val _isAppLocked = MutableStateFlow(
        repository.isAppLockEnabled.value && repository.hasCompletedWelcome.value
    )
    val isAppLocked: StateFlow<Boolean> = _isAppLocked.asStateFlow()

    private val _currentScreen = MutableStateFlow(ScreenName.HOME)
    val currentScreen: StateFlow<ScreenName> = _currentScreen.asStateFlow()

    private val screenStack = ArrayDeque<ScreenName>()

    private val _selectedInvoiceId = MutableStateFlow<String?>(null)
    val selectedInvoiceId: StateFlow<String?> = _selectedInvoiceId.asStateFlow()

    private val _editingInvoiceId = MutableStateFlow<String?>(null)
    val editingInvoiceId: StateFlow<String?> = _editingInvoiceId.asStateFlow()

    private val _editingCouponId = MutableStateFlow<String?>(null)
    val editingCouponId: StateFlow<String?> = _editingCouponId.asStateFlow()

    private val _linkedInvoiceId = MutableStateFlow<String?>(null)
    val linkedInvoiceId: StateFlow<String?> = _linkedInvoiceId.asStateFlow()

    private val _claimReportData = MutableStateFlow<ClaimReportData?>(null)
    val claimReportData: StateFlow<ClaimReportData?> = _claimReportData.asStateFlow()

    private val _eligibilityPrefill = MutableStateFlow<EligibilityPrefillData?>(null)
    val eligibilityPrefill: StateFlow<EligibilityPrefillData?> = _eligibilityPrefill.asStateFlow()

    private val _invoicePrefill = MutableStateFlow<EligibilityPrefillData?>(null)
    val invoicePrefill: StateFlow<EligibilityPrefillData?> = _invoicePrefill.asStateFlow()

    private val _vendorPanPrefill = MutableStateFlow<String?>(null)
    val vendorPanPrefill: StateFlow<String?> = _vendorPanPrefill.asStateFlow()

    private val _couponPrefill = MutableStateFlow<CouponPrefillData?>(null)
    val couponPrefill: StateFlow<CouponPrefillData?> = _couponPrefill.asStateFlow()

    private val _lastCheckResult = MutableStateFlow<ManualResultCheck?>(null)
    val lastCheckResult: StateFlow<ManualResultCheck?> = _lastCheckResult.asStateFlow()

    val currentDrawInfo: StateFlow<DrawPeriodInfo> = language.combine(_currentScreen) { lang, _ ->
        NepaliDateUtils.getCurrentDrawPeriod(lang)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        NepaliDateUtils.getCurrentDrawPeriod(AppLanguage.EN)
    )

    init {
        refreshDraws()
    }

    fun refreshDraws() {
        viewModelScope.launch(Dispatchers.IO) {
            _isRefreshingDraws.value = true
            try {
                DrawResultService.getAvailableDraws(repository)
                checkForWinningAnnouncements()
            } catch (_: Exception) {
                // Graceful fallback to cached results
            } finally {
                _isRefreshingDraws.value = false
            }
        }
    }

    fun hasPromptedNotificationPermission(): Boolean = repository.hasPromptedNotificationPermission()

    fun markNotificationPermissionPrompted() {
        repository.setPromptedNotificationPermission()
    }

    fun checkForWinningAnnouncements() {
        val currentCoupons = coupons.value
        if (currentCoupons.isEmpty()) return

        val availableDraws = repository.draws.value.ifEmpty { DrawResultService.getDefaultFallbackDraws() }
        for (draw in availableDraws) {
            val matchedNumbers = DrawResultService.findMatches(draw.winningNumbers, currentCoupons)
            if (matchedNumbers.isNotEmpty()) {
                val newMatches = matchedNumbers.filter { num ->
                    !repository.isMatchNotified("${draw.id}_$num")
                }
                if (newMatches.isNotEmpty()) {
                    NotificationHelper.showWinnerNotification(
                        context = getApplication(),
                        lang = language.value,
                        drawTitle = draw.title,
                        matchedCouponNumbers = newMatches
                    )
                    val newKeys = newMatches.map { "${draw.id}_$it" }
                    repository.markMatchesNotified(newKeys)
                }
            }
        }
    }

    fun navigateTo(screen: ScreenName) {
        if (_currentScreen.value != screen) {
            screenStack.addLast(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (screenStack.isNotEmpty()) {
            _currentScreen.value = screenStack.removeLast()
            true
        } else {
            false
        }
    }

    fun toggleLanguage() {
        repository.toggleLanguage()
    }

    fun setLanguage(lang: AppLanguage) {
        repository.setLanguage(lang)
    }

    fun completeWelcome() {
        repository.completeWelcome()
        if (_currentScreen.value == ScreenName.WELCOME) {
            _currentScreen.value = ScreenName.HOME
        }
    }

    fun onWelcomeGetStarted() {
        repository.completeWelcome()
        _currentScreen.value = ScreenName.ACCOUNT_SETUP
    }

    fun completeAccountSetup() {
        _currentScreen.value = ScreenName.HOME
    }

    fun saveAccountProfile(mobileNumber: String, displayName: String? = null) {
        viewModelScope.launch {
            authRepository.saveAccountSetupProfile(mobileNumber, displayName)
        }
    }

    fun createPasskey(context: Context, onResult: (PasskeyResult) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.createPasskey(context)
            onResult(result)
        }
    }

    fun signInWithPasskey(context: Context, onResult: (PasskeyResult) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.signInWithPasskey(context)
            onResult(result)
        }
    }

    fun signInWithGoogle(context: Context, onResult: (GoogleSignInResult) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.signInWithGoogle(context)
            onResult(result)
        }
    }

    fun clearPasskey() {
        viewModelScope.launch {
            authRepository.clearPasskey()
        }
    }

    fun clearAccountProfile() {
        viewModelScope.launch {
            authRepository.clearAccountProfile()
        }
    }

    fun resetWelcome() {
        repository.resetWelcome()
    }

    fun selectInvoice(id: String) {
        _selectedInvoiceId.value = id
        navigateTo(ScreenName.INVOICE_DETAIL)
    }

    fun openAddInvoice(invoiceIdToEdit: String? = null, prefill: EligibilityPrefillData? = null) {
        _editingInvoiceId.value = invoiceIdToEdit
        _invoicePrefill.value = prefill
        navigateTo(ScreenName.ADD_INVOICE)
    }

    fun openEditInvoice(id: String) {
        _editingInvoiceId.value = id
        _invoicePrefill.value = null
        navigateTo(ScreenName.ADD_INVOICE)
    }

    fun openAddCoupon(
        prefill: CouponPrefillData? = null,
        couponIdToEdit: String? = null,
        linkedInvoiceId: String? = null
    ) {
        _couponPrefill.value = prefill
        _editingCouponId.value = couponIdToEdit
        _linkedInvoiceId.value = linkedInvoiceId
        navigateTo(ScreenName.ADD_COUPON)
    }

    fun openEditCoupon(id: String) {
        _editingCouponId.value = id
        _linkedInvoiceId.value = null
        _couponPrefill.value = null
        navigateTo(ScreenName.ADD_COUPON)
    }

    fun openBulkAddCoupons() {
        navigateTo(ScreenName.BULK_ADD_COUPONS)
    }

    fun openEligibilityChecker(prefill: EligibilityPrefillData? = null) {
        _eligibilityPrefill.value = prefill
        navigateTo(ScreenName.CHECK_ELIGIBILITY)
    }

    fun openVerifyVendor(pan: String? = null) {
        _vendorPanPrefill.value = pan
        navigateTo(ScreenName.VERIFY_VENDOR)
    }

    fun openScan() {
        navigateTo(ScreenName.SCAN)
    }

    fun openDataBackup() {
        navigateTo(ScreenName.DATA_BACKUP)
    }

    fun openClaimReport(coupon: Coupon, drawTitle: String? = null, announcementDate: String? = null) {
        val matchingTx = transactions.value.find {
            it.couponNumber == coupon.couponNumber ||
                    (coupon.invoiceNumber != null && it.invoiceNumber == coupon.invoiceNumber)
        }
        _claimReportData.value = ClaimReportData(
            coupon = coupon,
            transaction = matchingTx,
            drawTitle = drawTitle ?: coupon.drawPeriod,
            drawPeriod = coupon.drawPeriod,
            announcementDate = announcementDate
        )
        navigateTo(ScreenName.CLAIM_REPORT)
    }

    fun saveTransaction(
        sellerName: String,
        amount: Double,
        paymentMethod: PaymentMethod,
        panVat: String?,
        invoiceNumber: String?,
        couponNumber: String?,
        date: String,
        notes: String?,
        category: TransactionCategory = TransactionCategory.NORMAL_GOODS,
        hasWarranty: Boolean = false,
        warrantyMonths: Int? = null,
        photoReference: String? = null
    ): Transaction {
        val normCoupon = if (!couponNumber.isNullOrBlank()) CouponUtils.normalizeCouponNumber(couponNumber) else null
        val eligibility = EligibilityService.checkEligibility(
            TransactionEligibilityInput(
                amount = amount,
                paymentMethod = paymentMethod,
                sellerPanNumber = panVat,
                sellerName = sellerName,
                category = category,
                date = date,
                invoiceNumber = invoiceNumber
            )
        )

        val status = if (!normCoupon.isNullOrBlank() && CouponUtils.isValidCouponNumber(normCoupon)) {
            EligibilityStatus.COUPON_ADDED
        } else if (eligibility.status == EligibilityStatus.LIKELY_ELIGIBLE) {
            EligibilityStatus.AWAITING_COUPON
        } else {
            eligibility.status
        }

        val tx = Transaction(
            id = SampleData.generateId(),
            date = date.ifBlank { LocalDate.now().format(DateTimeFormatter.ISO_DATE) },
            sellerName = sellerName.trim(),
            amount = amount,
            paymentMethod = paymentMethod,
            panVat = panVat?.trim()?.ifBlank { null },
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            couponNumber = normCoupon,
            eligibilityStatus = status,
            notes = notes?.trim()?.ifBlank { null },
            photoReference = photoReference?.trim()?.ifBlank { null },
            createdAt = java.time.Instant.now().toString(),
            category = category,
            hasWarranty = hasWarranty,
            warrantyMonths = if (hasWarranty) warrantyMonths else null
        )

        repository.addTransaction(tx)

        // If a valid 12-digit coupon was entered on the invoice, check if coupon already exists or save coupon record
        if (normCoupon != null && CouponUtils.isValidCouponNumber(normCoupon)) {
            val drawInfo = NepaliDateUtils.getDrawPeriodForDate(tx.date, language.value)
            val existingCoupon = coupons.value.find {
                it.couponNumber == normCoupon || (tx.invoiceNumber != null && it.invoiceNumber == tx.invoiceNumber)
            }
            if (existingCoupon != null) {
                val updatedCoupon = existingCoupon.copy(
                    couponNumber = normCoupon,
                    date = tx.date,
                    drawPeriod = drawInfo.drawPeriod,
                    merchantName = tx.sellerName,
                    amount = tx.amount,
                    paymentMethod = AppStrings.getPaymentMethodLabel(tx.paymentMethod, AppLanguage.EN),
                    invoiceNumber = tx.invoiceNumber,
                    notes = tx.notes
                )
                repository.updateCoupon(updatedCoupon)
            } else {
                val coupon = Coupon(
                    id = SampleData.generateId(),
                    couponNumber = normCoupon,
                    date = tx.date,
                    drawPeriod = drawInfo.drawPeriod,
                    merchantName = tx.sellerName,
                    amount = tx.amount,
                    paymentMethod = AppStrings.getPaymentMethodLabel(tx.paymentMethod, AppLanguage.EN),
                    invoiceNumber = tx.invoiceNumber,
                    notes = tx.notes,
                    createdAt = java.time.Instant.now().toString()
                )
                repository.addCoupon(coupon)
            }
        }

        return tx
    }

    fun updateTransaction(
        id: String,
        sellerName: String,
        amount: Double,
        paymentMethod: PaymentMethod,
        panVat: String?,
        invoiceNumber: String?,
        couponNumber: String?,
        date: String,
        notes: String?,
        category: TransactionCategory = TransactionCategory.NORMAL_GOODS,
        hasWarranty: Boolean = false,
        warrantyMonths: Int? = null,
        photoReference: String? = null
    ): Transaction? {
        val existing = transactions.value.find { it.id == id } ?: return null
        val normCoupon = if (!couponNumber.isNullOrBlank()) CouponUtils.normalizeCouponNumber(couponNumber) else null
        val eligibility = EligibilityService.checkEligibility(
            TransactionEligibilityInput(
                amount = amount,
                paymentMethod = paymentMethod,
                sellerPanNumber = panVat,
                sellerName = sellerName,
                category = category,
                date = date,
                invoiceNumber = invoiceNumber
            )
        )

        val status = if (!normCoupon.isNullOrBlank() && CouponUtils.isValidCouponNumber(normCoupon)) {
            EligibilityStatus.COUPON_ADDED
        } else if (eligibility.status == EligibilityStatus.LIKELY_ELIGIBLE) {
            EligibilityStatus.AWAITING_COUPON
        } else {
            eligibility.status
        }

        val updatedTx = existing.copy(
            date = date.ifBlank { existing.date },
            sellerName = sellerName.trim(),
            amount = amount,
            paymentMethod = paymentMethod,
            panVat = panVat?.trim()?.ifBlank { null },
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            couponNumber = normCoupon,
            eligibilityStatus = status,
            notes = notes?.trim()?.ifBlank { null },
            photoReference = photoReference?.trim()?.ifBlank { existing.photoReference },
            category = category,
            hasWarranty = hasWarranty,
            warrantyMonths = if (hasWarranty) warrantyMonths else null
        )

        repository.updateTransaction(updatedTx)
        _selectedInvoiceId.value = id
        _editingInvoiceId.value = null

        // Sync associated coupon if present
        if (normCoupon != null && CouponUtils.isValidCouponNumber(normCoupon)) {
            val drawInfo = NepaliDateUtils.getDrawPeriodForDate(updatedTx.date, language.value)
            val existingCoupon = coupons.value.find {
                it.couponNumber == normCoupon ||
                        (existing.couponNumber != null && it.couponNumber == existing.couponNumber) ||
                        (existing.invoiceNumber != null && it.invoiceNumber == existing.invoiceNumber) ||
                        (updatedTx.invoiceNumber != null && it.invoiceNumber == updatedTx.invoiceNumber)
            }
            if (existingCoupon != null) {
                val updatedCoupon = existingCoupon.copy(
                    couponNumber = normCoupon,
                    merchantName = updatedTx.sellerName,
                    amount = updatedTx.amount,
                    paymentMethod = AppStrings.getPaymentMethodLabel(updatedTx.paymentMethod, AppLanguage.EN),
                    invoiceNumber = updatedTx.invoiceNumber,
                    date = updatedTx.date,
                    notes = updatedTx.notes ?: existingCoupon.notes
                )
                repository.updateCoupon(updatedCoupon)
            } else {
                val newCoupon = Coupon(
                    id = SampleData.generateId(),
                    couponNumber = normCoupon,
                    date = updatedTx.date,
                    drawPeriod = drawInfo.drawPeriod,
                    merchantName = updatedTx.sellerName,
                    amount = updatedTx.amount,
                    paymentMethod = AppStrings.getPaymentMethodLabel(updatedTx.paymentMethod, AppLanguage.EN),
                    invoiceNumber = updatedTx.invoiceNumber,
                    notes = updatedTx.notes,
                    createdAt = java.time.Instant.now().toString()
                )
                repository.addCoupon(newCoupon)
            }
        }

        return updatedTx
    }

    fun deleteTransaction(id: String) {
        repository.deleteTransaction(id)
        if (_currentScreen.value == ScreenName.INVOICE_DETAIL && _selectedInvoiceId.value == id) {
            navigateBack()
        }
    }

    fun saveCoupon(
        couponNumber: String,
        merchantName: String?,
        amount: Double?,
        drawPeriod: String?,
        invoiceNumber: String?,
        notes: String?
    ): Boolean {
        val norm = CouponUtils.normalizeCouponNumber(couponNumber)
        if (!CouponUtils.isValidCouponNumber(norm)) return false

        val dateStr = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
        val period = drawPeriod ?: NepaliDateUtils.getDrawPeriodForDate(dateStr, language.value).drawPeriod

        val coupon = Coupon(
            id = SampleData.generateId(),
            couponNumber = norm,
            date = dateStr,
            drawPeriod = period,
            merchantName = merchantName?.trim()?.ifBlank { null },
            amount = amount,
            paymentMethod = null,
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            notes = notes?.trim()?.ifBlank { null },
            createdAt = java.time.Instant.now().toString()
        )

        repository.addCoupon(coupon)

        // Automatically update linked transaction if specified, or matching by invoice number
        val linkedId = _linkedInvoiceId.value
        if (linkedId != null) {
            val tx = transactions.value.find { it.id == linkedId }
            if (tx != null) {
                val updatedTx = tx.copy(
                    couponNumber = norm,
                    eligibilityStatus = EligibilityStatus.COUPON_ADDED,
                    invoiceNumber = tx.invoiceNumber ?: invoiceNumber?.trim()?.ifBlank { null }
                )
                repository.updateTransaction(updatedTx)
            }
        } else if (!coupon.invoiceNumber.isNullOrBlank()) {
            val tx = transactions.value.find { it.invoiceNumber == coupon.invoiceNumber }
            if (tx != null) {
                val updatedTx = tx.copy(
                    couponNumber = norm,
                    eligibilityStatus = EligibilityStatus.COUPON_ADDED
                )
                repository.updateTransaction(updatedTx)
            }
        }

        _couponPrefill.value = null
        _editingCouponId.value = null
        _linkedInvoiceId.value = null
        checkForWinningAnnouncements()
        return true
    }

    fun updateCoupon(
        id: String,
        couponNumber: String,
        merchantName: String?,
        amount: Double?,
        drawPeriod: String?,
        invoiceNumber: String?,
        notes: String?
    ): Boolean {
        val norm = CouponUtils.normalizeCouponNumber(couponNumber)
        if (!CouponUtils.isValidCouponNumber(norm)) return false

        val existing = coupons.value.find { it.id == id } ?: return false
        val updatedCoupon = existing.copy(
            couponNumber = norm,
            merchantName = merchantName?.trim()?.ifBlank { null },
            amount = amount,
            drawPeriod = drawPeriod ?: existing.drawPeriod,
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            notes = notes?.trim()?.ifBlank { null }
        )

        repository.updateCoupon(updatedCoupon)

        // Update any matching transaction so it reflects the updated coupon number & invoice details
        val linkedId = _linkedInvoiceId.value
        val txToUpdate = if (linkedId != null) {
            transactions.value.find { it.id == linkedId }
        } else {
            transactions.value.find {
                it.couponNumber == existing.couponNumber ||
                        (existing.invoiceNumber != null && it.invoiceNumber == existing.invoiceNumber) ||
                        (updatedCoupon.invoiceNumber != null && it.invoiceNumber == updatedCoupon.invoiceNumber)
            }
        }

        if (txToUpdate != null) {
            val updatedTx = txToUpdate.copy(
                couponNumber = norm,
                eligibilityStatus = EligibilityStatus.COUPON_ADDED,
                invoiceNumber = updatedCoupon.invoiceNumber ?: txToUpdate.invoiceNumber
            )
            repository.updateTransaction(updatedTx)
        }

        _editingCouponId.value = null
        _linkedInvoiceId.value = null
        _couponPrefill.value = null
        return true
    }

    fun saveBulkCoupons(
        couponNumbers: List<String>,
        defaultMerchant: String?
    ): Int {
        val dateStr = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
        val period = NepaliDateUtils.getDrawPeriodForDate(dateStr, language.value).drawPeriod
        val list = couponNumbers.map { num ->
            Coupon(
                id = SampleData.generateId(),
                couponNumber = num,
                date = dateStr,
                drawPeriod = period,
                merchantName = defaultMerchant?.trim()?.ifBlank { null },
                amount = null,
                paymentMethod = null,
                invoiceNumber = null,
                notes = null,
                createdAt = java.time.Instant.now().toString()
            )
        }
        repository.addBulkCoupons(list)
        checkForWinningAnnouncements()
        return list.size
    }

    fun deleteCoupon(id: String) {
        repository.deleteCoupon(id)
    }

    fun checkWinners(
        inputText: String,
        drawTitle: String?
    ): ManualResultCheck {
        val rawLines = inputText.split(Regex("[\\r\\n;,\\s]+"))
            .map { CouponUtils.normalizeCouponNumber(it) }
            .filter { it.length == 12 }
            .distinct()

        val matched = DrawResultService.findMatches(rawLines, coupons.value)
        val title = drawTitle?.trim()?.ifBlank { null } ?: currentDrawInfo.value.drawPeriod

        val check = ManualResultCheck(
            id = SampleData.generateId(),
            drawTitle = title,
            drawPeriod = currentDrawInfo.value.drawPeriod,
            enteredResults = rawLines,
            matchedCouponNumbers = matched,
            matched = matched.isNotEmpty(),
            checkedAt = java.time.Instant.now().toString()
        )

        _lastCheckResult.value = check
        repository.addResultCheck(check)

        if (matched.isNotEmpty()) {
            val newMatches = matched.filter { num ->
                !repository.isMatchNotified("${check.id}_$num")
            }
            if (newMatches.isNotEmpty()) {
                NotificationHelper.showWinnerNotification(
                    context = getApplication(),
                    lang = language.value,
                    drawTitle = title,
                    matchedCouponNumbers = newMatches
                )
                val newKeys = newMatches.map { "${check.id}_$it" }
                repository.markMatchesNotified(newKeys)
            }
        }

        return check
    }

    fun updateResultCheckWonAmount(checkId: String, wonAmount: Double?) {
        repository.updateResultCheckWonAmount(checkId, wonAmount)
        if (_lastCheckResult.value?.id == checkId) {
            _lastCheckResult.value = _lastCheckResult.value?.copy(wonAmount = wonAmount)
        }
    }

    fun setDarkMode(mode: DarkModePreference) {
        repository.setDarkMode(mode)
    }

    fun setFontScale(scale: FontScalePreference) {
        repository.setFontScale(scale)
    }

    fun clearResultChecks() {
        repository.clearResultChecks()
    }

    fun exportData(): String {
        return repository.exportJson()
    }

    fun exportBackupJson(): String {
        return repository.exportJson()
    }

    fun importData(json: String): Boolean {
        val ok = repository.importJson(json)
        if (ok) {
            checkForWinningAnnouncements()
        }
        return ok
    }

    fun restoreBackupJson(json: String): Boolean {
        val ok = repository.importJson(json)
        if (ok) {
            checkForWinningAnnouncements()
        }
        return ok
    }

    fun loadSampleData() {
        repository.loadSampleData()
        checkForWinningAnnouncements()
    }

    fun clearAllData() {
        repository.clearAllData()
    }

    fun unlockApp() {
        _isAppLocked.value = false
    }

    fun lockApp() {
        if (repository.isAppLockEnabled.value && repository.hasCompletedWelcome.value) {
            _isAppLocked.value = true
        }
    }

    fun checkAndLockIfEnabled() {
        if (repository.isAppLockEnabled.value && repository.hasCompletedWelcome.value) {
            _isAppLocked.value = true
        }
    }

    fun verifyPin(pin: String): Boolean = repository.verifyPin(pin)

    fun hasPin(): Boolean = repository.hasPin()

    fun setPinAndEnableLock(pin: String) {
        repository.setPin(pin)
        repository.setAppLockEnabled(true)
        _isAppLocked.value = false
    }

    fun disableAppLock() {
        repository.removePin()
        _isAppLocked.value = false
    }

    fun changePin(newPin: String) {
        repository.setPin(newPin)
    }

    fun signOutAuth() {
        viewModelScope.launch {
            authRepository.signOut()
        }
    }
}
