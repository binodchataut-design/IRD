package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.Coupon
import com.billlinus.app.model.ScreenName
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.theme.*
import com.billlinus.app.utils.CouponUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CouponsScreen(viewModel: MainViewModel) {
    val language by viewModel.language.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    var couponToDelete by remember { mutableStateOf<Coupon?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = AppStrings.get("nav.coupons", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("btn_back_coupons")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Slate700)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenName.BULK_ADD_COUPONS) },
                        modifier = Modifier.testTag("btn_bulk_add_coupons")
                    ) {
                        Icon(Icons.Default.PlaylistAdd, contentDescription = "Bulk Add", tint = Slate700)
                    }
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenName.ADD_COUPON) },
                        modifier = Modifier.testTag("btn_add_coupon_top")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Coupon", tint = Slate700)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(ScreenName.ADD_COUPON) },
                containerColor = Emerald600,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("fab_add_coupon")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Coupon")
            }
        }
    ) { padding ->
        if (coupons.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Slate50)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                EmptyStateCard(
                    title = AppStrings.get("coupons.empty_title", language),
                    description = AppStrings.get("coupons.empty_desc", language),
                    onAction = { viewModel.navigateTo(ScreenName.ADD_COUPON) },
                    actionText = AppStrings.get("coupons.add_coupon", language)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Slate50),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(coupons, key = { it.id }) { coupon ->
                    CouponCard(
                        coupon = coupon,
                        onDelete = { couponToDelete = coupon }
                    )
                }
            }
        }
    }

    if (couponToDelete != null) {
        AlertDialog(
            onDismissRequest = { couponToDelete = null },
            title = { Text("Delete Coupon") },
            text = { Text("Are you sure you want to delete coupon ${couponToDelete?.couponNumber}?") },
            confirmButton = {
                Button(
                    onClick = {
                        couponToDelete?.let { viewModel.deleteCoupon(it.id) }
                        couponToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Red600)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { couponToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun CouponCard(
    coupon: Coupon,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Emerald100,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.ConfirmationNumber,
                            contentDescription = null,
                            tint = Emerald600,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = CouponUtils.formatCoupon(coupon.couponNumber),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = listOfNotNull(coupon.merchantName, coupon.drawPeriod).joinToString(" • "),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Slate500,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete",
                    tint = Slate400,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
