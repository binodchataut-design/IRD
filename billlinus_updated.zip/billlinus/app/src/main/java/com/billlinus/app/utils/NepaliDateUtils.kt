package com.billlinus.app.utils

import com.billlinus.app.model.AppLanguage
import java.time.LocalDate
import java.time.format.DateTimeFormatter

data class DrawPeriodInfo(
    val cycleName: String,
    val drawPeriod: String,
    val expectedAnnouncement: String
)

object NepaliDateUtils {

    fun getCurrentDrawPeriod(lang: AppLanguage): DrawPeriodInfo {
        val now = LocalDate.now()
        val yearBs = now.year + 57
        val monthBs = when (now.monthValue) {
            4 -> 1 // Baisakh
            5 -> 2 // Jestha
            6 -> 3 // Ashadh
            7 -> 4 // Shrawan
            8 -> 5 // Bhadra
            9 -> 6 // Ashwin
            10 -> 7 // Kartik
            11 -> 8 // Mangsir
            12 -> 9 // Poush
            1 -> 10 // Magh
            2 -> 11 // Falgun
            else -> 12 // Chaitra
        }

        val monthName = when (monthBs) {
            1 -> if (lang == AppLanguage.NE) "बैशाख" else "Baisakh"
            2 -> if (lang == AppLanguage.NE) "जेठ" else "Jestha"
            3 -> if (lang == AppLanguage.NE) "असार" else "Ashadh"
            4 -> if (lang == AppLanguage.NE) "श्रावण" else "Shrawan"
            5 -> if (lang == AppLanguage.NE) "भाद्र" else "Bhadra"
            6 -> if (lang == AppLanguage.NE) "आश्विन" else "Ashwin"
            7 -> if (lang == AppLanguage.NE) "कार्तिक" else "Kartik"
            8 -> if (lang == AppLanguage.NE) "मंसिर" else "Mangsir"
            9 -> if (lang == AppLanguage.NE) "पुष" else "Poush"
            10 -> if (lang == AppLanguage.NE) "माघ" else "Magh"
            11 -> if (lang == AppLanguage.NE) "फाल्गुन" else "Falgun"
            else -> if (lang == AppLanguage.NE) "चैत" else "Chaitra"
        }

        return DrawPeriodInfo(
            cycleName = if (lang == AppLanguage.NE) "$monthName $yearBs लक्की ड्र" else "$monthName $yearBs Lucky Draw",
            drawPeriod = "$monthName $yearBs",
            expectedAnnouncement = if (lang == AppLanguage.NE) "महिनाको अन्त्यमा" else "End of Month"
        )
    }

    fun getDrawPeriodForDate(dateStr: String, lang: AppLanguage): DrawPeriodInfo {
        return getCurrentDrawPeriod(lang)
    }

    fun currentBikramSambatDate(): String {
        val now = LocalDate.now()
        val yearBs = now.year + 57
        val monthBs = String.format("%02d", now.monthValue)
        val dayBs = String.format("%02d", now.dayOfMonth)
        return "$yearBs-$monthBs-$dayBs"
    }

    fun formatDate(dateStr: String, lang: AppLanguage): String {
        return dateStr
    }
}
