package com.billlinus.app.utils

import com.billlinus.app.model.Coupon
import com.billlinus.app.model.EligibilityStatus
import com.billlinus.app.model.PaymentMethod
import com.billlinus.app.model.Transaction
import com.billlinus.app.model.TransactionCategory
import java.util.UUID

object SampleData {

    fun generateId(): String = UUID.randomUUID().toString()

    fun getSampleTransactions(): List<Transaction> = listOf(
        Transaction(
            id = generateId(),
            date = "2026-04-10",
            sellerName = "Bhatbhateni Supermarket",
            amount = 3450.0,
            paymentMethod = PaymentMethod.QR_PAYMENT,
            panVat = "300123456",
            invoiceNumber = "BBS-2082-019",
            couponNumber = "984123456789",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "Monthly groceries and household items",
            photoReference = null,
            createdAt = "2026-04-10T10:30:00Z",
            category = TransactionCategory.NORMAL_GOODS
        ),
        Transaction(
            id = generateId(),
            date = "2026-04-12",
            sellerName = "Himalayan Java Coffee",
            amount = 820.0,
            paymentMethod = PaymentMethod.DIGITAL_WALLET,
            panVat = "600987654",
            invoiceNumber = "HJC-4421",
            couponNumber = "985112233445",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "Breakfast meeting",
            photoReference = null,
            createdAt = "2026-04-12T09:15:00Z",
            category = TransactionCategory.FOOD_RESTAURANT
        ),
        Transaction(
            id = generateId(),
            date = "2026-04-14",
            sellerName = "Big Mart",
            amount = 1200.0,
            paymentMethod = PaymentMethod.QR_PAYMENT,
            panVat = "302345678",
            invoiceNumber = "BM-8834",
            couponNumber = null,
            eligibilityStatus = EligibilityStatus.AWAITING_COUPON,
            notes = "Snacks and beverages",
            photoReference = null,
            createdAt = "2026-04-14T16:00:00Z",
            category = TransactionCategory.NORMAL_GOODS
        )
    )

    fun getSampleCoupons(): List<Coupon> = listOf(
        Coupon(
            id = generateId(),
            couponNumber = "984123456789",
            date = "2026-04-10",
            drawPeriod = "Baisakh 2083",
            merchantName = "Bhatbhateni Supermarket",
            amount = 3450.0,
            paymentMethod = "QR Payment",
            invoiceNumber = "BBS-2082-019",
            notes = "Baisakh Lucky Draw entry",
            createdAt = "2026-04-10T10:30:00Z"
        ),
        Coupon(
            id = generateId(),
            couponNumber = "985112233445",
            date = "2026-04-12",
            drawPeriod = "Baisakh 2083",
            merchantName = "Himalayan Java Coffee",
            amount = 820.0,
            paymentMethod = "Digital Wallet",
            invoiceNumber = "HJC-4421",
            notes = "Baisakh Lucky Draw entry",
            createdAt = "2026-04-12T09:15:00Z"
        )
    )
}
