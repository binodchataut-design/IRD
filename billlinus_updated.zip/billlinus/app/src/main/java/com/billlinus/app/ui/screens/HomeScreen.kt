package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.EligibilityStatus
import com.billlinus.app.model.ScreenName
import com.billlinus.app.model.Transaction
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.BillLinusBottomBar
import com.billlinus.app.ui.components.DrawBannerCard
import com.billlinus.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val language by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val currentDrawInfo by viewModel.currentDrawInfo.collectAsState()

    val totalSpent = remember(transactions) { transactions.sumOf { it.amount } }
    val totalCoupons = remember(coupons) { coupons.size }
    val eligibleInvoices = remember(transactions) {
        transactions.count { it.eligibilityStatus == EligibilityStatus.COUPON_ADDED || it.eligibilityStatus == EligibilityStatus.LIKELY_ELIGIBLE }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BrandGreenLight.copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.ReceiptLong,
                                    contentDescription = null,
                                    tint = BrandGreenDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "BillLinus",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Slate900
                                )
                            )
                            Text(
                                text = if (!userProfile?.fullName.isNullOrBlank()) "Namaste, ${userProfile?.fullName}" else AppStrings.get("app.tagline", language),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Slate500,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenName.PROFILE) },
                        modifier = Modifier.testTag("btn_home_profile")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Profile",
                            tint = Slate700
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            BillLinusBottomBar(
                currentScreen = ScreenName.HOME,
                onNavigate = { viewModel.navigateTo(it) },
                lang = language
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(ScreenName.SCAN) },
                containerColor = Emerald600,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("fab_scan_bill")
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan Bill")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Slate50),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Draw Banner
            item {
                DrawBannerCard(
                    drawInfo = currentDrawInfo,
                    couponCount = totalCoupons,
                    lang = language,
                    onCheckWinners = { viewModel.navigateTo(ScreenName.WINNER_CHECKER) }
                )
            }

            // Quick Stats Summary
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = AppStrings.get("home.total_spent", language),
                        value = "Rs. ${"%,.0f".format(totalSpent)}",
                        icon = Icons.Default.AccountBalanceWallet,
                        iconTint = Indigo600,
                        iconBg = Indigo100,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = AppStrings.get("home.saved_coupons", language),
                        value = totalCoupons.toString(),
                        icon = Icons.Default.ConfirmationNumber,
                        iconTint = Emerald600,
                        iconBg = Emerald100,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Quick Actions
            item {
                Text(
                    text = AppStrings.get("home.quick_actions", language),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Slate900
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        icon = Icons.Default.Add,
                        label = AppStrings.get("home.add_bill", language),
                        onClick = { viewModel.navigateTo(ScreenName.ADD_INVOICE) },
                        modifier = Modifier.weight(1f),
                        testTag = "btn_quick_add_bill"
                    )
                    QuickActionTile(
                        icon = Icons.Default.ConfirmationNumber,
                        label = AppStrings.get("home.add_coupon", language),
                        onClick = { viewModel.navigateTo(ScreenName.ADD_COUPON) },
                        modifier = Modifier.weight(1f),
                        testTag = "btn_quick_add_coupon"
                    )
                    QuickActionTile(
                        icon = Icons.Default.FactCheck,
                        label = AppStrings.get("home.check_eligibility", language),
                        onClick = { viewModel.navigateTo(ScreenName.CHECK_ELIGIBILITY) },
                        modifier = Modifier.weight(1f),
                        testTag = "btn_quick_check_eligibility"
                    )
                    QuickActionTile(
                        icon = Icons.Default.Verified,
                        label = AppStrings.get("home.verify_vendor", language),
                        onClick = { viewModel.navigateTo(ScreenName.VERIFY_VENDOR) },
                        modifier = Modifier.weight(1f),
                        testTag = "btn_quick_verify_vendor"
                    )
                }
            }

            // Recent Invoices Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.get("home.recent_bills", language),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                    )
                    TextButton(
                        onClick = { viewModel.navigateTo(ScreenName.INVOICES) },
                        modifier = Modifier.testTag("btn_view_all_invoices")
                    ) {
                        Text(
                            text = AppStrings.get("common.view_all", language),
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Emerald600,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }
            }

            if (transactions.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = AppStrings.get("home.no_bills_title", language),
                        description = AppStrings.get("home.no_bills_desc", language),
                        onAction = { viewModel.navigateTo(ScreenName.ADD_INVOICE) },
                        actionText = AppStrings.get("home.add_first_bill", language)
                    )
                }
            } else {
                items(transactions.take(5)) { tx ->
                    InvoiceListItem(
                        transaction = tx,
                        onClick = {
                            viewModel.selectInvoice(tx.id)
                            viewModel.navigateTo(ScreenName.INVOICE_DETAIL)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = iconBg,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 11.sp)
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Slate900)
                )
            }
        }
    }
}

@Composable
fun QuickActionTile(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(testTag),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(12.dp),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = CircleShape,
                color = Emerald50,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = Emerald600, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Medium,
                    color = Slate700,
                    fontSize = 11.sp
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
fun InvoiceListItem(
    transaction: Transaction,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Slate100,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Receipt,
                            contentDescription = null,
                            tint = Slate700,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = transaction.sellerName,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        ),
                        maxLines = 1
                    )
                    Text(
                        text = transaction.date,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Slate500,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Rs. ${"%,.0f".format(transaction.amount)}",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Slate900
                    )
                )
                if (transaction.couponNumber != null) {
                    Text(
                        text = "Coupon Added",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Emerald600,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    title: String,
    description: String,
    onAction: () -> Unit,
    actionText: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.ReceiptLong,
                contentDescription = null,
                tint = Slate400,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Slate800
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Slate500
                )
            )
            if (actionText.isNotBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Emerald600,
                        contentColor = Color.White
                    )
                ) {
                    Text(actionText)
                }
            }
        }
    }
}
