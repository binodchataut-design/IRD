package com.billlinus.app.model

import kotlinx.serialization.Serializable

/**
 * Account profile data model for local encrypted storage and Firestore profile metadata.
 *
 * Security & Privacy constraints (Phase 10E):
 * - Internal UUID ([uid]): Permanent UUID generated once. Never replaced by mobile updates.
 * - [mobileVerificationStatus]: Truthful verification state ("NOT_VERIFIED", "AUTHENTICATED").
 * - [schemaVersion]: Schema migration version for future cloud synchronization.
 * - NEVER stores: biometric data, private keys, passwords, bill photos, or raw credential material.
 */
@Serializable
data class UserProfile(
    val uid: String = "", // Permanent local BillLinus UUID (WebAuthn user handle)
    val firebaseUid: String? = null, // Nullable Firebase Auth UID (cloud identity mapping)
    val mobileNumber: String? = null,
    val displayName: String? = null,
    val mobileVerificationStatus: String = "NOT_VERIFIED",
    val schemaVersion: Int = 1,
    val createdAt: String,
    val updatedAt: String
)
