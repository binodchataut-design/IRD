package com.billlinus.app.utils

object CouponUtils {

    fun normalizeCouponNumber(raw: String?): String {
        if (raw == null) return ""
        return raw.filter { it.isDigit() }
    }

    fun isValidCouponNumber(raw: String?): Boolean {
        if (raw == null) return false
        val digits = normalizeCouponNumber(raw)
        return digits.length == 12
    }

    fun formatCoupon(raw: String?): String {
        val digits = normalizeCouponNumber(raw)
        return when {
            digits.length > 8 -> "${digits.substring(0, 4)} ${digits.substring(4, 8)} ${digits.substring(8)}"
            digits.length > 4 -> "${digits.substring(0, 4)} ${digits.substring(4)}"
            else -> digits
        }
    }

    fun formatCouponNumber(raw: String?): String = formatCoupon(raw)
}
