package com.billlinus.app.auth

import com.billlinus.app.model.UserProfile

/**
 * Result representation for Google Sign-In and Firebase Auth credential exchange operations.
 */
sealed interface GoogleSignInResult {
    /** Successfully authenticated with Google and linked to BillLinus account */
    data class Success(val profile: UserProfile) : GoogleSignInResult

    /** User cancelled or dismissed the Google Sign-In prompt */
    data object Cancelled : GoogleSignInResult

    /** The Google/Firebase account is already linked to a different BillLinus account */
    data class Conflict(val existingFirebaseUid: String, val newFirebaseUid: String) : GoogleSignInResult

    /** Firebase or Google Sign-In is not configured on this build */
    data class NotConfigured(val message: String) : GoogleSignInResult

    /** Device does not support Credential Manager or Google Sign-In */
    data class NotSupported(val message: String) : GoogleSignInResult

    /** An error occurred during authentication */
    data class Error(val message: String, val throwable: Throwable? = null) : GoogleSignInResult
}
