package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.*
import com.billlinus.app.service.EligibilityResult
import com.billlinus.app.service.EligibilityService
import com.billlinus.app.service.TransactionEligibilityInput
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EligibilityCheckerScreen(viewModel: MainViewModel) {
    val language by viewModel.language.collectAsState()
    var amountStr by remember { mutableStateOf("") }
    var sellerName by remember { mutableStateOf("") }
    var sellerPan by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.QR_PAYMENT) }
    var checkResult by remember { mutableStateOf<EligibilityResult?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Eligibility Checker",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("btn_back_eligibility")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Slate50)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = sellerName,
                onValueChange = { sellerName = it },
                label = { Text("Store / Merchant Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = sellerPan,
                onValueChange = { sellerPan = it },
                label = { Text("Seller PAN Number (9 digits)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = amountStr,
                onValueChange = { amountStr = it },
                label = { Text("Bill Amount (NPR)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    checkResult = EligibilityService.checkEligibility(
                        TransactionEligibilityInput(
                            amount = amt,
                            paymentMethod = paymentMethod,
                            sellerPanNumber = sellerPan.takeIf { it.isNotBlank() },
                            sellerName = sellerName
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_run_eligibility"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Emerald600, contentColor = Color.White)
            ) {
                Text("Check Eligibility")
            }

            checkResult?.let { res ->
                val isEligible = res.status == EligibilityStatus.LIKELY_ELIGIBLE
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isEligible) Emerald100 else Amber100
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isEligible) "Eligible for Lucky Draw!" else "Action Required / Needs Verification",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isEligible) Emerald600 else Amber600
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isEligible) "This transaction satisfies Nepalese IRD Lucky Draw rules (PAN registered seller + Electronic Payment)." else "Please ensure a valid 9-digit PAN and electronic payment (eSewa/Khalti/Fonepay/Card).",
                            style = MaterialTheme.typography.bodyMedium.copy(color = Slate800)
                        )
                    }
                }
            }
        }
    }
}
