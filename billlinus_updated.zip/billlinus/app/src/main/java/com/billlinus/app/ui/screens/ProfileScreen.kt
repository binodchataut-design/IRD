package com.billlinus.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.auth.GoogleSignInResult
import com.billlinus.app.auth.PasskeyResult
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.model.DarkModePreference
import com.billlinus.app.model.FontScalePreference
import com.billlinus.app.model.ScreenName
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.BillLinusBottomBar
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.components.AuthenticatePinDialog
import com.billlinus.app.ui.components.SetPinDialog
import com.billlinus.app.ui.theme.Amber100
import com.billlinus.app.ui.theme.Amber400
import com.billlinus.app.ui.theme.Amber500
import com.billlinus.app.ui.theme.Amber600
import com.billlinus.app.ui.theme.BrandGreenDark
import com.billlinus.app.ui.theme.BrandGreenLight
import com.billlinus.app.ui.theme.BrandNavy
import com.billlinus.app.ui.theme.BrandNavyLight
import com.billlinus.app.ui.theme.Emerald100
import com.billlinus.app.ui.theme.Emerald500
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Indigo100
import com.billlinus.app.ui.theme.Indigo600
import com.billlinus.app.ui.theme.Red600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate200
import com.billlinus.app.ui.theme.Slate300
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.ui.theme.Slate900
import com.billlinus.app.utils.PhoneUtils

@Composable
fun ProfileScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val resultChecks by viewModel.resultChecks.collectAsState()
    val darkModePref by viewModel.darkMode.collectAsState()
    val fontScalePref by viewModel.fontScale.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isAppLockEnabled by viewModel.isAppLockEnabled.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val isPasskeyEnabled by viewModel.isPasskeyEnabled.collectAsState()
    val authState by viewModel.authState.collectAsState()
    val isAuthenticated = authState is com.billlinus.app.auth.AuthState.PasskeyAuthenticated || authState is com.billlinus.app.auth.AuthState.SignedIn
    val context = LocalContext.current
    var isPasskeyInProgress by remember { mutableStateOf(false) }
    var isGoogleAuthInProgress by remember { mutableStateOf(false) }

    var showSetPinDialog by remember { mutableStateOf(false) }
    var showTurnOffAuthDialog by remember { mutableStateOf(false) }
    var showChangePinAuthDialog by remember { mutableStateOf(false) }
    var showChangePinNewDialog by remember { mutableStateOf(false) }

    // Calculations
    val totalExpenditure = remember(transactions) {
        transactions.sumOf { it.amount }
    }

    val totalPrizeWinnings = remember(resultChecks) {
        resultChecks.filter { it.matched }.mapNotNull { it.wonAmount }.sum()
    }

    val monthsTrackedCount = remember(transactions) {
        transactions.mapNotNull {
            if (it.date.length >= 7) it.date.substring(0, 7) else null
        }.distinct().size
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("profile.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            BillLinusBottomBar(
                currentScreen = currentScreen,
                onNavigate = { viewModel.navigateTo(it) },
                lang = lang
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(2.dp)) }

            // User Identity & App Hero Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = AppStrings.get("profile.user_title", lang),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = AppStrings.get("profile.user_tagline", lang),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 13.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                shape = RoundedCornerShape(100.dp),
                                color = BrandGreenLight
                            ) {
                                Text(
                                    text = if (lang == AppLanguage.NE) "सुरक्षित अन-डिभाइस भण्डारण" else "100% On-Device Safe",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = BrandGreenDark,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Cloud Identity Conflict Banner (Phase 10F & 10G)
            if (authState is com.billlinus.app.auth.AuthState.FirebaseIdentityConflict) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Amber100,
                        border = BorderStroke(1.dp, Amber400),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("banner_identity_conflict")
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Amber600,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = AppStrings.get("profile.cloud_account_conflict", lang),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Slate900,
                                        fontWeight = FontWeight.Medium
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.signOutAuth()
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .align(Alignment.End)
                                    .testTag("btn_dismiss_conflict")
                            ) {
                                Text(
                                    text = AppStrings.get("auth.cancel_conflict", lang),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }

            // BillLinus Account Section (Phase 10B & 10C)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_billlinus_account")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Mobile number row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Indigo100,
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.PhoneAndroid,
                                            contentDescription = null,
                                            tint = Indigo600,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = AppStrings.get("profile.account_section_title", lang),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Slate900
                                        )
                                    )
                                    val mobileNumber = userProfile?.mobileNumber
                                    if (!mobileNumber.isNullOrBlank()) {
                                        Text(
                                            text = "${AppStrings.get("profile.mobile_label", lang)}: ${PhoneUtils.formatDisplay(mobileNumber)}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = Slate700,
                                                fontWeight = FontWeight.Medium
                                            )
                                        )
                                    } else {
                                        Text(
                                            text = AppStrings.get("profile.account_not_set_up", lang),
                                            style = MaterialTheme.typography.bodySmall.copy(color = Slate500)
                                        )
                                    }
                                }
                            }

                            // Status badge: Authenticated / Passkey Registered / Setup / Not set up
                            val isSetup = !userProfile?.mobileNumber.isNullOrBlank()
                            Surface(
                                shape = RoundedCornerShape(100.dp),
                                color = when {
                                    isAuthenticated -> Emerald100
                                    isPasskeyEnabled -> Indigo100
                                    isSetup -> Slate100
                                    else -> Amber100
                                }
                            ) {
                                Text(
                                    text = when {
                                        isAuthenticated -> AppStrings.get("profile.status_authenticated", lang)
                                        isPasskeyEnabled -> AppStrings.get("profile.status_unauthenticated", lang)
                                        isSetup -> AppStrings.get("profile.status_account_setup", lang)
                                        else -> AppStrings.get("profile.status_not_setup", lang)
                                    },
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = when {
                                            isAuthenticated -> Emerald600
                                            isPasskeyEnabled -> Indigo600
                                            isSetup -> Slate700
                                            else -> Amber600
                                        },
                                        fontSize = 11.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Passkey status row
                        HorizontalDivider(color = Slate100, thickness = 1.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isPasskeyEnabled) Emerald100 else Slate100,
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Key,
                                            contentDescription = null,
                                            tint = if (isPasskeyEnabled) Emerald600 else Slate500,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = AppStrings.get("profile.passkey_label", lang),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Slate900
                                        )
                                    )
                                    Text(
                                        text = if (isPasskeyEnabled) {
                                            AppStrings.get("passkey.biometric_notice", lang)
                                        } else {
                                            AppStrings.get("passkey.create_subtitle", lang)
                                        },
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = Slate500,
                                            fontSize = 12.sp,
                                            lineHeight = 16.sp
                                        ),
                                        maxLines = 2
                                    )
                                }
                            }

                            // Passkey Badge: Enabled / Not enabled
                            Surface(
                                shape = RoundedCornerShape(100.dp),
                                color = if (isPasskeyEnabled) Emerald100 else Slate100
                            ) {
                                Text(
                                    text = if (isPasskeyEnabled) {
                                        AppStrings.get("profile.passkey_enabled", lang)
                                    } else {
                                        AppStrings.get("profile.passkey_not_enabled", lang)
                                    },
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isPasskeyEnabled) Emerald600 else Slate500,
                                        fontSize = 11.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Cloud / Google Account Section (Phase 10F & 10G)
                        HorizontalDivider(color = Slate100, thickness = 1.dp)

                        if (!userProfile?.firebaseUid.isNullOrBlank()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f, fill = false)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = com.billlinus.app.ui.theme.Blue100,
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.CloudDone,
                                                contentDescription = null,
                                                tint = com.billlinus.app.ui.theme.Blue600,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = AppStrings.get("auth.google_connected", lang),
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = Slate900
                                            )
                                        )
                                        Text(
                                            text = AppStrings.get("profile.cloud_account_desc", lang),
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = Slate500,
                                                fontSize = 12.sp,
                                                lineHeight = 16.sp
                                            ),
                                            maxLines = 2
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(100.dp),
                                    color = com.billlinus.app.ui.theme.Blue100
                                ) {
                                    Text(
                                        text = AppStrings.get("profile.cloud_account_linked", lang),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = com.billlinus.app.ui.theme.Blue600,
                                            fontSize = 11.sp
                                        ),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Slate100,
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.AccountCircle,
                                                contentDescription = null,
                                                tint = Slate700,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = AppStrings.get("auth.connect_account_title", lang),
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = Slate900
                                            )
                                        )
                                        Text(
                                            text = AppStrings.get("auth.connect_account_desc", lang),
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = Slate500,
                                                fontSize = 12.sp,
                                                lineHeight = 16.sp
                                            ),
                                            maxLines = 2
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (isGoogleAuthInProgress) return@Button
                                        isGoogleAuthInProgress = true
                                        viewModel.signInWithGoogle(context) { res ->
                                            isGoogleAuthInProgress = false
                                            when (res) {
                                                is GoogleSignInResult.Success -> {
                                                    Toast.makeText(
                                                        context,
                                                        AppStrings.get("auth.google_connected", lang),
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                                is GoogleSignInResult.Conflict -> {
                                                    Toast.makeText(
                                                        context,
                                                        AppStrings.get("profile.cloud_account_conflict", lang),
                                                        Toast.LENGTH_LONG
                                                    ).show()
                                                }
                                                is GoogleSignInResult.Cancelled -> {
                                                    // User cancelled the prompt
                                                }
                                                is GoogleSignInResult.NotConfigured -> {
                                                    Toast.makeText(
                                                        context,
                                                        res.message,
                                                        Toast.LENGTH_LONG
                                                    ).show()
                                                }
                                                is GoogleSignInResult.NotSupported -> {
                                                    Toast.makeText(
                                                        context,
                                                        res.message,
                                                        Toast.LENGTH_LONG
                                                    ).show()
                                                }
                                                is GoogleSignInResult.Error -> {
                                                    Toast.makeText(
                                                        context,
                                                        res.message,
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(42.dp)
                                        .testTag("btn_continue_with_google"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Slate900,
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccountCircle,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = AppStrings.get("auth.btn_continue_google", lang),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                            }
                        }

                        // Passkey / Account Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (isAuthenticated) {
                                // Sign Out Session button (does not wipe local data/keys)
                                OutlinedButton(
                                    onClick = {
                                        viewModel.signOutAuth()
                                        Toast.makeText(
                                            context,
                                            AppStrings.get("profile.sign_out_confirm", lang),
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("btn_profile_signout_session"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = Slate700
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = AppStrings.get("profile.btn_sign_out", lang),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                            } else if (isPasskeyEnabled) {
                                OutlinedButton(
                                    onClick = {
                                        if (isPasskeyInProgress) return@OutlinedButton
                                        isPasskeyInProgress = true
                                        viewModel.signInWithPasskey(context) { result ->
                                            isPasskeyInProgress = false
                                            when (result) {
                                                is PasskeyResult.Success -> {
                                                    Toast.makeText(
                                                        context,
                                                        AppStrings.get("passkey.success_signin", lang),
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                                is PasskeyResult.Cancelled -> {
                                                    Toast.makeText(
                                                        context,
                                                        AppStrings.get("passkey.cancelled_message", lang),
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                                is PasskeyResult.NoPasskeyFound -> {
                                                    Toast.makeText(
                                                        context,
                                                        AppStrings.get("passkey.no_passkey_found", lang),
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                                is PasskeyResult.NotSupported -> {
                                                    Toast.makeText(
                                                        context,
                                                        AppStrings.get("passkey.not_supported", lang),
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                                is PasskeyResult.Error -> {
                                                    Toast.makeText(
                                                        context,
                                                        result.message.ifBlank { AppStrings.get("passkey.cancelled_message", lang) },
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("btn_profile_signin_passkey"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = MaterialTheme.colorScheme.primary
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Key,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = AppStrings.get("profile.passkey_signin_button", lang),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                            } else {
                                OutlinedButton(
                                    onClick = { viewModel.navigateTo(ScreenName.ACCOUNT_SETUP) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("btn_profile_setup_passkey"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = MaterialTheme.colorScheme.primary
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Key,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = AppStrings.get("profile.passkey_setup_button", lang),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                            }

                            // Secondary action: Update / Setup mobile
                            OutlinedButton(
                                onClick = { viewModel.navigateTo(ScreenName.ACCOUNT_SETUP) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("btn_profile_account_action"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Slate700
                                )
                            ) {
                                val hasMobile = !userProfile?.mobileNumber.isNullOrBlank()
                                Text(
                                    text = if (hasMobile) {
                                        AppStrings.get("profile.update_mobile", lang)
                                    } else {
                                        AppStrings.get("profile.setup_account", lang)
                                    },
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Stat Cards Section
            item {
                Text(
                    text = AppStrings.get("profile.stats_section", lang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Total Expenditure Card
                    ProfileStatRowCard(
                        title = AppStrings.get("profile.stat_expenditure", lang),
                        value = "NPR ${String.format(java.util.Locale.US, "%,.2f", totalExpenditure)}",
                        subtitle = "${transactions.size} ${AppStrings.get("profile.stat_spent_sub", lang)}",
                        icon = Icons.Default.ReceiptLong,
                        iconBg = Indigo100,
                        iconTint = Indigo600
                    )

                    // Total Prize Winnings Card
                    ProfileStatRowCard(
                        title = AppStrings.get("profile.stat_prize_winnings", lang),
                        value = "NPR ${String.format(java.util.Locale.US, "%,.0f", totalPrizeWinnings)}",
                        subtitle = AppStrings.get("profile.stat_winnings_sub", lang),
                        icon = Icons.Default.EmojiEvents,
                        iconBg = Amber100,
                        iconTint = Amber600
                    )

                    // Months Tracked Streak Card
                    ProfileStatRowCard(
                        title = AppStrings.get("profile.stat_streak", lang),
                        value = "$monthsTrackedCount ${if (lang == AppLanguage.NE) "महिना" else if (monthsTrackedCount == 1) "Month" else "Months"}",
                        subtitle = AppStrings.get("profile.stat_streak_sub", lang),
                        icon = Icons.Default.CalendarMonth,
                        iconBg = Emerald100,
                        iconTint = Emerald600
                    )
                }
            }

            // Settings & Preferences Section
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = AppStrings.get("profile.settings_section", lang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            // Dark Mode Setting Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Indigo100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (darkModePref) {
                                        DarkModePreference.DARK -> Icons.Default.DarkMode
                                        DarkModePreference.LIGHT -> Icons.Default.LightMode
                                        DarkModePreference.SYSTEM -> Icons.Default.SettingsBrightness
                                    },
                                    contentDescription = null,
                                    tint = Indigo600,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppStrings.get("profile.dark_mode_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp
                                    )
                                )
                                Text(
                                    text = AppStrings.get("profile.dark_mode_desc", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Segmented control for Dark Mode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val options = listOf(
                                DarkModePreference.SYSTEM to AppStrings.get("profile.dark_mode_system", lang),
                                DarkModePreference.LIGHT to AppStrings.get("profile.dark_mode_light", lang),
                                DarkModePreference.DARK to AppStrings.get("profile.dark_mode_dark", lang)
                            )

                            options.forEach { (mode, label) ->
                                val isSelected = darkModePref == mode
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { viewModel.setDarkMode(mode) }
                                        .testTag("btn_dark_mode_${mode.name.lowercase()}")
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Font Scaling Setting Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Amber100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FormatSize,
                                    contentDescription = null,
                                    tint = Amber600,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppStrings.get("profile.font_size_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp
                                    )
                                )
                                Text(
                                    text = AppStrings.get("profile.font_size_desc", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Segmented control for Font Scale
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val scales = listOf(
                                FontScalePreference.SMALL to AppStrings.get("profile.font_size_small", lang),
                                FontScalePreference.MEDIUM to AppStrings.get("profile.font_size_medium", lang),
                                FontScalePreference.LARGE to AppStrings.get("profile.font_size_large", lang)
                            )

                            scales.forEach { (scale, label) ->
                                val isSelected = fontScalePref == scale
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { viewModel.setFontScale(scale) }
                                        .testTag("btn_font_scale_${scale.name.lowercase()}")
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Language Toggle Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Emerald100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = null,
                                    tint = Emerald600,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppStrings.get("profile.language_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp
                                    )
                                )
                                Text(
                                    text = AppStrings.get("profile.language_desc", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Segmented control for Language
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val languages = listOf(
                                AppLanguage.EN to "English",
                                AppLanguage.NE to "नेपाली"
                            )

                            languages.forEach { (l, label) ->
                                val isSelected = lang == l
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { viewModel.setLanguage(l) }
                                        .testTag("btn_lang_${l.name.lowercase()}")
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // App Lock Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isAppLockEnabled) BrandNavyLight else Slate100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isAppLockEnabled) Icons.Default.Lock else Icons.Default.LockOpen,
                                    contentDescription = null,
                                    tint = if (isAppLockEnabled) BrandNavy else Slate500,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppStrings.get("profile.app_lock_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp
                                    )
                                )
                                Text(
                                    text = AppStrings.get("profile.app_lock_desc", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                            Switch(
                                checked = isAppLockEnabled,
                                onCheckedChange = { enable ->
                                    if (enable) {
                                        showSetPinDialog = true
                                    } else {
                                        showTurnOffAuthDialog = true
                                    }
                                },
                                modifier = Modifier.testTag("switch_app_lock")
                            )
                        }

                        if (isAppLockEnabled) {
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { showChangePinAuthDialog = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_change_pin"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Key,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = AppStrings.get("profile.change_pin", lang),
                                        fontSize = 13.sp
                                    )
                                }

                                OutlinedButton(
                                    onClick = { showTurnOffAuthDialog = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_turn_off_app_lock"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Red600)
                                ) {
                                    Text(
                                        text = AppStrings.get("profile.turn_off_lock", lang),
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Data Backup & Restore Action Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo(ScreenName.DATA_BACKUP) }
                        .testTag("btn_goto_backup")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Indigo100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Backup,
                                    contentDescription = null,
                                    tint = Indigo600,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = AppStrings.get("profile.data_backup_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp
                                    )
                                )
                                Text(
                                    text = AppStrings.get("profile.data_backup_desc", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            tint = Slate400,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Information & Guide Section
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = AppStrings.get("profile.info_section", lang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            // Welcome Tour link
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo(ScreenName.WELCOME) }
                        .testTag("btn_goto_welcome_tour")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Emerald100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = Emerald600,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = AppStrings.get("profile.view_welcome_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp
                                    )
                                )
                                Text(
                                    text = AppStrings.get("profile.view_welcome_desc", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            tint = Slate400,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // IRD Guide link
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo(ScreenName.IRD_INFO) }
                        .testTag("btn_goto_ird_info")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Amber100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = Amber600,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = AppStrings.get("profile.ird_guide_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 15.sp
                                    )
                                )
                                Text(
                                    text = AppStrings.get("profile.ird_guide_desc", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            tint = Slate400,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Privacy Assurance Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = BrandGreenDark,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = AppStrings.get("profile.disclaimer_title", lang),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = AppStrings.get("profile.disclaimer_desc", lang),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }

    if (showSetPinDialog) {
        SetPinDialog(
            lang = lang,
            onDismiss = { showSetPinDialog = false },
            onPinSet = { pin ->
                viewModel.setPinAndEnableLock(pin)
                showSetPinDialog = false
            }
        )
    }

    if (showTurnOffAuthDialog) {
        AuthenticatePinDialog(
            title = AppStrings.get("profile.turn_off_lock", lang),
            subtitle = AppStrings.get("profile.enter_current_pin_desc", lang),
            lang = lang,
            verifyPin = { pin -> viewModel.verifyPin(pin) },
            onDismiss = { showTurnOffAuthDialog = false },
            onSuccess = {
                viewModel.disableAppLock()
                showTurnOffAuthDialog = false
            }
        )
    }

    if (showChangePinAuthDialog) {
        AuthenticatePinDialog(
            title = AppStrings.get("profile.change_pin", lang),
            subtitle = AppStrings.get("profile.enter_current_pin_desc", lang),
            lang = lang,
            verifyPin = { pin -> viewModel.verifyPin(pin) },
            onDismiss = { showChangePinAuthDialog = false },
            onSuccess = {
                showChangePinAuthDialog = false
                showChangePinNewDialog = true
            }
        )
    }

    if (showChangePinNewDialog) {
        SetPinDialog(
            lang = lang,
            onDismiss = { showChangePinNewDialog = false },
            onPinSet = { newPin ->
                viewModel.changePin(newPin)
                showChangePinNewDialog = false
            }
        )
    }
}

@Composable
private fun ProfileStatRowCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = Slate500,
                        fontWeight = FontWeight.Medium
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Slate400,
                        fontSize = 11.sp
                    )
                )
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
