package com.billlinus.app.auth

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.credentials.CreatePublicKeyCredentialRequest
import androidx.credentials.CreatePublicKeyCredentialResponse
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetPublicKeyCredentialOption
import androidx.credentials.PublicKeyCredential
import androidx.credentials.exceptions.CreateCredentialCancellationException
import androidx.credentials.exceptions.CreateCredentialNoCreateOptionException
import androidx.credentials.exceptions.CreateCredentialProviderConfigurationException
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialProviderConfigurationException
import androidx.credentials.exceptions.NoCredentialException
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.billlinus.app.data.FirestoreCollections
import com.billlinus.app.model.UserProfile
import com.billlinus.app.utils.PhoneUtils
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.SecureRandom
import java.time.Instant
import java.util.UUID

/**
 * Concrete implementation of [AuthRepository] backed by AndroidX Credential Manager (Passkeys)
 * and Firebase Authentication / Firestore, combined with secure local profile persistence.
 *
 * Security guarantees (Phase 10D):
 * - Internal UUID: Every user profile receives a stable cryptographic UUID (`uid`) generated once.
 *   This UUID remains permanent across app restarts, lifecycle recreation, and mobile number edits.
 * - Decoupled State: Having a registered passkey (`isPasskeyEnabled == true`) is decoupled from active
 *   session authentication.
 * - Cold-Start Re-authentication: On fresh process launch, the session starts as [AuthState.Unauthenticated].
 *   Active passkey assertion is required to transition to [AuthState.PasskeyAuthenticated].
 * - Authentication Failure Safety: All cancellation and failure paths strictly resolve to [AuthState.Unauthenticated]
 *   or [AuthState.PasskeyNotAvailable].
 * - Zero Private Key Storage: Private keys and biometric data never touch the app and remain securely
 *   isolated inside the OS Credential Manager.
 */
class FirebaseAuthRepository(
    private val context: Context,
    private val coroutineScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
) : AuthRepository {

    private val prefs: SharedPreferences = try {
        val masterKey: MasterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "bill_linus_auth_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        context.getSharedPreferences("bill_linus_auth_prefs", Context.MODE_PRIVATE)
    }

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = false
        encodeDefaults = true
    }

    private var firebaseAuth: FirebaseAuth? = null
    private var firestore: FirebaseFirestore? = null

    private val _authState = MutableStateFlow<AuthState>(AuthState.Loading)
    override val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _userProfile = MutableStateFlow<UserProfile?>(loadAndMigrateLocalProfile())
    override val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    private val _isPasskeyEnabled = MutableStateFlow(prefs.getBoolean("passkey_setup_state", false))
    override val isPasskeyEnabled: StateFlow<Boolean> = _isPasskeyEnabled.asStateFlow()

    override val currentUserId: String?
        get() = firebaseAuth?.currentUser?.uid

    override val isFirebaseConfigured: Boolean
        get() = firebaseAuth != null

    init {
        initializeFirebase()
    }

    /**
     * Loads the local profile and safely ensures a permanent cryptographic UUID exists.
     * Migration Safety: If an existing profile has an empty uid, it is automatically assigned
     * a stable UUID and persisted immediately.
     */
    private fun loadAndMigrateLocalProfile(): UserProfile? {
        val str = prefs.getString("local_user_profile_json", null) ?: return null
        return try {
            val profile = json.decodeFromString<UserProfile>(str)
            if (profile.uid.isBlank()) {
                val migrated = profile.copy(uid = UUID.randomUUID().toString())
                saveLocalProfile(migrated)
                migrated
            } else {
                profile
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun saveLocalProfile(profile: UserProfile?) {
        if (profile == null) {
            prefs.edit().remove("local_user_profile_json").apply()
        } else {
            try {
                val str = json.encodeToString(profile)
                prefs.edit().putString("local_user_profile_json", str).apply()
            } catch (_: Exception) {
                // Ignore storage errors gracefully
            }
        }
    }

    private fun initializeFirebase() {
        try {
            val app = try {
                val existing = FirebaseApp.getApps(context)
                if (existing.isNotEmpty()) {
                    FirebaseApp.getInstance()
                } else {
                    FirebaseApp.initializeApp(context)
                }
            } catch (_: Exception) {
                null
            }

            if (app != null) {
                val auth = FirebaseAuth.getInstance(app)
                val db = FirebaseFirestore.getInstance(app)
                firebaseAuth = auth
                firestore = db

                auth.addAuthStateListener { fa ->
                    val user = fa.currentUser
                    if (user != null) {
                        handleUserSignedIn(user)
                    } else {
                        handleSignedOutOrLocalSetup(isConfigured = true)
                    }
                }
            } else {
                handleSignedOutOrLocalSetup(isConfigured = false)
            }
        } catch (_: Exception) {
            handleSignedOutOrLocalSetup(isConfigured = false)
        }
    }

    /**
     * Cold-Start state initialization.
     * Enforces the separation between passkey registration and active in-memory session authentication.
     * Does NOT mark the session as authenticated automatically on cold start.
     */
    private fun handleSignedOutOrLocalSetup(isConfigured: Boolean) {
        val localProfile = _userProfile.value
        val passkeyConfigured = _isPasskeyEnabled.value
        if (localProfile != null && !localProfile.mobileNumber.isNullOrBlank()) {
            // Decoupled: account exists, but active session begins unauthenticated until passkey assertion
            _authState.value = AuthState.Unauthenticated(
                userProfile = localProfile,
                isPasskeyRegistered = passkeyConfigured
            )
        } else {
            _authState.value = if (isConfigured) AuthState.SignedOut else AuthState.FirebaseNotConfigured
        }
    }

    private fun handleUserSignedIn(user: FirebaseUser) {
        val newFirebaseUid = user.uid
        val existing = _userProfile.value ?: loadAndMigrateLocalProfile()

        // 1. Permanent stable local UUID (never overwritten by Firebase UID)
        val stableLocalUid = if (!existing?.uid.isNullOrBlank()) existing.uid else UUID.randomUUID().toString()

        // 2. Identity Conflict Check: if existing local profile is already linked to a different Firebase UID
        if (existing?.firebaseUid != null && existing.firebaseUid != newFirebaseUid) {
            _authState.value = AuthState.FirebaseIdentityConflict(
                existingFirebaseUid = existing.firebaseUid,
                newFirebaseUid = newFirebaseUid
            )
            return
        }

        val mobileNumber = user.phoneNumber ?: existing?.mobileNumber
        val displayName = user.displayName ?: existing?.displayName
        val nowIso = Instant.now().toString()

        val initialProfile = UserProfile(
            uid = stableLocalUid, // NEVER overwritten with user.uid
            firebaseUid = newFirebaseUid, // Stored separately as cloud identity link
            mobileNumber = mobileNumber,
            displayName = displayName,
            mobileVerificationStatus = "AUTHENTICATED",
            schemaVersion = existing?.schemaVersion ?: 1,
            createdAt = existing?.createdAt ?: nowIso,
            updatedAt = nowIso
        )
        _userProfile.value = initialProfile
        saveLocalProfile(initialProfile)
        _authState.value = AuthState.SignedIn(initialProfile)

        // Asynchronously check and sync Firestore profile at users/{newFirebaseUid}
        coroutineScope.launch {
            try {
                val db = firestore ?: return@launch
                val userDocRef = db.collection(FirestoreCollections.USERS).document(newFirebaseUid)
                val snapshot = userDocRef.get().await()

                if (snapshot.exists()) {
                    val dbMobile = snapshot.getString("mobileNumber") ?: mobileNumber
                    val dbDisplayName = snapshot.getString("displayName") ?: displayName
                    val dbCreatedAt = snapshot.getString("createdAt") ?: initialProfile.createdAt
                    val dbUpdatedAt = snapshot.getString("updatedAt") ?: initialProfile.updatedAt
                    val dbSchemaVersion = snapshot.getLong("schemaVersion")?.toInt() ?: 1

                    val syncedProfile = UserProfile(
                        uid = stableLocalUid, // Maintain permanent local UUID
                        firebaseUid = newFirebaseUid,
                        mobileNumber = dbMobile,
                        displayName = dbDisplayName,
                        mobileVerificationStatus = "AUTHENTICATED",
                        schemaVersion = dbSchemaVersion,
                        createdAt = dbCreatedAt,
                        updatedAt = dbUpdatedAt
                    )
                    _userProfile.value = syncedProfile
                    saveLocalProfile(syncedProfile)
                    _authState.value = AuthState.SignedIn(syncedProfile)
                } else {
                    val initialData = hashMapOf(
                        "firebaseUid" to newFirebaseUid,
                        "localAccountId" to stableLocalUid,
                        "mobileNumber" to (mobileNumber ?: ""),
                        "displayName" to (displayName ?: ""),
                        "mobileVerificationStatus" to "AUTHENTICATED",
                        "schemaVersion" to initialProfile.schemaVersion,
                        "createdAt" to initialProfile.createdAt,
                        "updatedAt" to initialProfile.updatedAt
                    )
                    userDocRef.set(initialData, SetOptions.merge()).await()
                }
            } catch (_: Exception) {
                // If offline or Firestore is temporarily unreachable, maintain signed-in auth profile
            }
        }
    }

    override suspend fun createPasskey(context: Context): PasskeyResult {
        val profile = _userProfile.value
        _authState.value = AuthState.Authenticating
        return try {
            val credentialManager = CredentialManager.create(context)
            val requestJson = generateCreatePasskeyJson(profile)
            val createRequest = CreatePublicKeyCredentialRequest(requestJson)

            val result = credentialManager.createCredential(context, createRequest)
            if (result is CreatePublicKeyCredentialResponse) {
                prefs.edit().putBoolean("passkey_setup_state", true).apply()
                _isPasskeyEnabled.value = true

                if (profile != null) {
                    _authState.value = AuthState.PasskeyAuthenticated(profile)
                } else {
                    _authState.value = AuthState.Unauthenticated(null, isPasskeyRegistered = true)
                }

                PasskeyResult.Success(result.registrationResponseJson)
            } else {
                _authState.value = AuthState.Unauthenticated(profile, isPasskeyRegistered = _isPasskeyEnabled.value)
                PasskeyResult.Error("Unexpected response type from Credential Manager")
            }
        } catch (e: CreateCredentialCancellationException) {
            _authState.value = AuthState.Unauthenticated(profile, isPasskeyRegistered = _isPasskeyEnabled.value)
            PasskeyResult.Cancelled
        } catch (e: CreateCredentialNoCreateOptionException) {
            _authState.value = AuthState.PasskeyNotAvailable(e.message ?: "No passkey creation option available on this device")
            PasskeyResult.NotSupported(e.message ?: "No passkey creation option available on this device")
        } catch (e: CreateCredentialProviderConfigurationException) {
            _authState.value = AuthState.PasskeyNotAvailable(e.message ?: "Credential provider configuration error")
            PasskeyResult.NotSupported(e.message ?: "Credential provider configuration error")
        } catch (e: Exception) {
            _authState.value = AuthState.Unauthenticated(profile, isPasskeyRegistered = _isPasskeyEnabled.value)
            PasskeyResult.Error(e.message ?: "Passkey creation failed", e)
        }
    }

    override suspend fun signInWithPasskey(context: Context): PasskeyResult {
        val profile = _userProfile.value
        _authState.value = AuthState.Authenticating
        return try {
            val credentialManager = CredentialManager.create(context)
            val requestJson = generateGetPasskeyJson()
            val getPublicKeyCredentialOption = GetPublicKeyCredentialOption(requestJson)
            val getCredRequest = GetCredentialRequest(listOf(getPublicKeyCredentialOption))

            val result = credentialManager.getCredential(context, getCredRequest)
            val credential = result.credential
            if (credential is PublicKeyCredential) {
                prefs.edit().putBoolean("passkey_setup_state", true).apply()
                _isPasskeyEnabled.value = true

                if (profile != null) {
                    _authState.value = AuthState.PasskeyAuthenticated(profile)
                } else {
                    _authState.value = AuthState.Unauthenticated(null, isPasskeyRegistered = true)
                }

                PasskeyResult.Success(credential.authenticationResponseJson)
            } else {
                _authState.value = AuthState.Unauthenticated(profile, isPasskeyRegistered = _isPasskeyEnabled.value)
                PasskeyResult.Error("Unexpected credential type returned")
            }
        } catch (e: GetCredentialCancellationException) {
            _authState.value = AuthState.Unauthenticated(profile, isPasskeyRegistered = _isPasskeyEnabled.value)
            PasskeyResult.Cancelled
        } catch (e: NoCredentialException) {
            _authState.value = AuthState.Unauthenticated(profile, isPasskeyRegistered = false)
            PasskeyResult.NoPasskeyFound
        } catch (e: GetCredentialProviderConfigurationException) {
            _authState.value = AuthState.PasskeyNotAvailable(e.message ?: "Credential provider configuration error")
            PasskeyResult.NotSupported(e.message ?: "Credential provider configuration error")
        } catch (e: Exception) {
            _authState.value = AuthState.Unauthenticated(profile, isPasskeyRegistered = _isPasskeyEnabled.value)
            PasskeyResult.Error(e.message ?: "Passkey sign-in failed", e)
        }
    }

    override suspend fun clearPasskey() {
        prefs.edit().remove("passkey_setup_state").apply()
        _isPasskeyEnabled.value = false
        val profile = _userProfile.value
        _authState.value = AuthState.Unauthenticated(profile, isPasskeyRegistered = false)
    }

    /**
     * Constructs the WebAuthn PublicKeyCredentialCreationOptions JSON.
     * Uses the permanent UUID as the WebAuthn user handle (never the raw mobile number).
     */
    private fun generateCreatePasskeyJson(profile: UserProfile?): String {
        val challengeBytes = ByteArray(PasskeyConfig.CHALLENGE_BYTE_LENGTH)
        SecureRandom().nextBytes(challengeBytes)
        val challengeBase64 = Base64.encodeToString(
            challengeBytes,
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )

        // WebAuthn user.id MUST use the stable internal UUID, not the raw mobile number
        val stableUid = profile?.uid?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        val userIdBase64 = Base64.encodeToString(
            stableUid.toByteArray(Charsets.UTF_8),
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )
        val username = profile?.displayName?.takeIf { it.isNotBlank() }
            ?: profile?.mobileNumber?.takeIf { it.isNotBlank() }
            ?: "user_$stableUid"
        val displayName = profile?.displayName?.takeIf { it.isNotBlank() } ?: username

        return """
        {
          "challenge": "$challengeBase64",
          "rp": {
            "name": "${PasskeyConfig.RP_NAME}",
            "id": "${PasskeyConfig.RP_ID}"
          },
          "user": {
            "id": "$userIdBase64",
            "name": "$username",
            "displayName": "$displayName"
          },
          "pubKeyCredParams": [
            {"type": "public-key", "alg": -7},
            {"type": "public-key", "alg": -257}
          ],
          "timeout": ${PasskeyConfig.TIMEOUT_MILLIS},
          "attestation": "none",
          "authenticatorSelection": {
            "authenticatorAttachment": "platform",
            "residentKey": "required",
            "requireResidentKey": true,
            "userVerification": "required"
          }
        }
        """.trimIndent()
    }

    /**
     * Constructs the WebAuthn PublicKeyCredentialRequestOptions JSON.
     */
    private fun generateGetPasskeyJson(): String {
        val challengeBytes = ByteArray(PasskeyConfig.CHALLENGE_BYTE_LENGTH)
        SecureRandom().nextBytes(challengeBytes)
        val challengeBase64 = Base64.encodeToString(
            challengeBytes,
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )

        return """
        {
          "challenge": "$challengeBase64",
          "timeout": ${PasskeyConfig.TIMEOUT_MILLIS},
          "rpId": "${PasskeyConfig.RP_ID}",
          "userVerification": "required"
        }
        """.trimIndent()
    }

    override suspend fun saveAccountSetupProfile(
        mobileNumber: String,
        displayName: String?
    ): UserProfile {
        val normalized = PhoneUtils.normalizeNepalMobile(mobileNumber)
        val nowIso = Instant.now().toString()
        val existing = _userProfile.value ?: loadAndMigrateLocalProfile()

        // Preserve stable UUID if already assigned; generate once if missing
        val stableUid = if (!existing?.uid.isNullOrBlank()) existing.uid else UUID.randomUUID().toString()

        val profile = UserProfile(
            uid = stableUid,
            firebaseUid = existing?.firebaseUid, // Preserve linked firebaseUid across mobile number updates
            mobileNumber = normalized,
            displayName = displayName ?: existing?.displayName,
            mobileVerificationStatus = existing?.mobileVerificationStatus ?: "NOT_VERIFIED", // Truthful state: no fake verification claimed
            schemaVersion = existing?.schemaVersion ?: 1,
            createdAt = existing?.createdAt ?: nowIso,
            updatedAt = nowIso
        )

        saveLocalProfile(profile)
        _userProfile.value = profile

        if (firebaseAuth?.currentUser == null) {
            _authState.value = AuthState.Unauthenticated(
                userProfile = profile,
                isPasskeyRegistered = _isPasskeyEnabled.value
            )
        }

        return profile
    }

    override suspend fun clearAccountProfile() {
        saveLocalProfile(null)
        _userProfile.value = null
        if (firebaseAuth?.currentUser == null) {
            _authState.value = if (firebaseAuth != null) AuthState.SignedOut else AuthState.FirebaseNotConfigured
        }
    }

    private fun getServerClientId(context: Context): String? {
        return try {
            val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId != 0) {
                context.getString(resId)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    override suspend fun signInWithGoogle(context: Context): GoogleSignInResult {
        val auth = firebaseAuth
        if (auth == null) {
            _authState.value = AuthState.FirebaseNotConfigured
            return GoogleSignInResult.NotConfigured("Firebase is not initialized or configured on this device")
        }

        val serverClientId = getServerClientId(context)
        if (serverClientId.isNullOrBlank()) {
            return GoogleSignInResult.NotConfigured("Firebase Web Client ID not found. Ensure google-services.json is configured.")
        }

        _authState.value = AuthState.Authenticating
        return try {
            val credentialManager = CredentialManager.create(context)
            val signInWithGoogleOption = GetSignInWithGoogleOption.Builder(serverClientId)
                .build()
            val getCredRequest = GetCredentialRequest(listOf(signInWithGoogleOption))

            val result = credentialManager.getCredential(context, getCredRequest)
            val credential = result.credential

            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken
                val authCredential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult = auth.signInWithCredential(authCredential).await()
                val user = authResult.user

                if (user != null) {
                    handleUserSignedIn(user)
                    val currentAuthState = _authState.value
                    if (currentAuthState is AuthState.FirebaseIdentityConflict) {
                        GoogleSignInResult.Conflict(
                            existingFirebaseUid = currentAuthState.existingFirebaseUid,
                            newFirebaseUid = currentAuthState.newFirebaseUid
                        )
                    } else {
                        val profile = _userProfile.value
                        if (profile != null) {
                            GoogleSignInResult.Success(profile)
                        } else {
                            GoogleSignInResult.Error("Failed to load user profile after sign-in")
                        }
                    }
                } else {
                    handleSignedOutOrLocalSetup(isConfigured = true)
                    GoogleSignInResult.Error("Firebase user is null after sign-in")
                }
            } else {
                handleSignedOutOrLocalSetup(isConfigured = true)
                GoogleSignInResult.Error("Unexpected credential type: ${credential::class.java.simpleName}")
            }
        } catch (e: GetCredentialCancellationException) {
            handleSignedOutOrLocalSetup(isConfigured = true)
            GoogleSignInResult.Cancelled
        } catch (e: NoCredentialException) {
            handleSignedOutOrLocalSetup(isConfigured = true)
            GoogleSignInResult.Error(e.message ?: "No Google account found on device", e)
        } catch (e: GetCredentialProviderConfigurationException) {
            _authState.value = AuthState.PasskeyNotAvailable(e.message ?: "Credential provider configuration error")
            GoogleSignInResult.NotSupported(e.message ?: "Credential provider configuration error")
        } catch (e: Exception) {
            handleSignedOutOrLocalSetup(isConfigured = true)
            GoogleSignInResult.Error(e.message ?: "Google Sign-In failed", e)
        }
    }

    override suspend fun signOut() {
        try {
            firebaseAuth?.signOut()
        } catch (_: Exception) {
            // Gracefully handle signOut errors
        }
        val localProfile = _userProfile.value
        _authState.value = AuthState.Unauthenticated(
            userProfile = localProfile,
            isPasskeyRegistered = _isPasskeyEnabled.value
        )
    }
}
