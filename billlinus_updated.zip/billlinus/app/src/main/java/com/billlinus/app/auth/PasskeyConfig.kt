package com.billlinus.app.auth

/**
 * WebAuthn and Passkey configuration constants for BillLinus.
 *
 * Domain & Digital Asset Links Preparation (Phase 10D):
 * For production passkey support, the Relying Party ID ([RP_ID]) must match the domain
 * hosting the Digital Asset Links specification at:
 * `https://billlinus.app/.well-known/assetlinks.json`
 *
 * The assetlinks.json file must declare the Android application ID (`com.billlinus.app` or project namespace)
 * and the production release signing certificate SHA-256 fingerprint.
 *
 * Current State:
 * - Domain and RP ID configuration is prepared and isolated in this configuration object.
 * - Digital Asset Links is NOT yet active because live domain hosting and production certificate
 *   deployment will be configured in a subsequent server deployment phase.
 */
object PasskeyConfig {
    /** Relying Party Identifier */
    const val RP_ID = "billlinus.app"

    /** Human-readable Relying Party Name displayed in Credential Manager UI */
    const val RP_NAME = "BillLinus"

    /** Cryptographic random challenge byte length for WebAuthn */
    const val CHALLENGE_BYTE_LENGTH = 32

    /** Passkey credential operation timeout in milliseconds (60s) */
    const val TIMEOUT_MILLIS = 60000L

    /** Digital Asset Links preparation status indicator */
    const val ASSET_LINKS_STATUS = "PREPARED_PENDING_PRODUCTION_HOSTING"
}
