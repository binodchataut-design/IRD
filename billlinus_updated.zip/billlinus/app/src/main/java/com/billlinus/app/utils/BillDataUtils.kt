package com.billlinus.app.utils

data class ParsedBillData(
    val sellerName: String = "",
    val pan: String = "",
    val invoiceNumber: String = "",
    val date: String = "",
    val amount: String = ""
)

object BillDataUtils {

    fun extractFromText(rawText: String): ParsedBillData {
        var sellerName = ""
        var pan = ""
        var invoiceNumber = ""
        var date = ""
        var amount = ""

        val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }

        // Find PAN: 9 digits
        val panRegex = Regex("""(?:PAN|VAT|प्यान|भ्याट)[\s:]*([0-9]{9})""", RegexOption.IGNORE_CASE)
        val plainPanRegex = Regex("""\b([1-9][0-9]{8})\b""")
        for (line in lines) {
            val match = panRegex.find(line) ?: plainPanRegex.find(line)
            if (match != null && pan.isBlank()) {
                pan = match.groupValues.last()
            }
        }

        // Find Invoice Number
        val invRegex = Regex("""(?:INV|Invoice|Bill|रसिद|बिल)[\s#No.:-]*([A-Za-z0-9\-/]+)""", RegexOption.IGNORE_CASE)
        for (line in lines) {
            val match = invRegex.find(line)
            if (match != null && invoiceNumber.isBlank()) {
                invoiceNumber = match.groupValues[1]
            }
        }

        // Find Amount
        val amountRegex = Regex("""(?:Total|Grand Total|Net Total|जम्मा|कुल)[\s:]*(?:Rs\.?|NPR)?\s*([0-9,]+(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
        for (line in lines.reversed()) {
            val match = amountRegex.find(line)
            if (match != null && amount.isBlank()) {
                amount = match.groupValues[1].replace(",", "")
            }
        }

        // First non-empty header line as seller name candidate
        if (lines.isNotEmpty()) {
            sellerName = lines.firstOrNull { it.length > 2 && !it.contains(Regex("""(?:PAN|VAT|Tax Invoice|Invoice|Bill)""", RegexOption.IGNORE_CASE)) } ?: lines[0]
        }

        return ParsedBillData(
            sellerName = sellerName,
            pan = pan,
            invoiceNumber = invoiceNumber,
            date = date,
            amount = amount
        )
    }
}
