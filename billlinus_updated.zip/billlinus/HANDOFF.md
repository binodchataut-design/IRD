# Bill Linus — Handoff Notes (Claude session, continued from nav redesign)

This zip is the same project you uploaded, with source-level edits applied on top.
**I could not compile, build, or run this project** — there's no Android SDK, Gradle,
or emulator in my sandbox. Everything below was verified by reading source, checking
brace/paren balance, and cross-referencing every symbol I used (functions, string
keys, color tokens, enum values) against what actually exists elsewhere in the
codebase. It has **not** been built or run on a device. Treat it as "should compile"
not "confirmed compiles."

## What changed, file by file

### 1. `ui/components/CommonComponents.kt` — added `BillLinusBottomBar`
This was the root cause of your Home screen regression. `HomeScreen`, `InvoicesScreen`,
`CouponsScreen`, and `ExpensesScreen` all called a `BillLinusBottomBar(...)` composable
that **did not exist anywhere in the project** — only `AppBottomNav` existed, with a
different tab set. That mismatch is almost certainly why stat cards / nav behavior was
broken.

`BillLinusBottomBar` is now defined with your requested 5 tabs:
**Home · Winner · Scan · Expenses · Profile** — bilingual labels via `AppStrings`,
using existing keys `nav.home`, `nav.winner`, `nav.scan`, `nav.expenses`, `nav.profile`
(all already existed in `AppStrings.kt`).

### 2. `ui/screens/HomeScreen.kt`
- Now passes `lang = language` into `BillLinusBottomBar` (was previously missing).
- `EmptyStateCard`'s action button is now conditional — only renders if `actionText`
  is non-blank, so empty-state cards without an action (used in the new warranty tab)
  don't show a blank button.

### 3. `ui/screens/InvoicesScreen.kt` / `ui/screens/CouponsScreen.kt`
Per your instruction, Bills and Coupons are no longer separate bottom-nav tabs — they're
reached from Home (recent bills list, "view all", quick actions). Both screens now:
- Have a back arrow in the top bar (`viewModel.navigateBack()`) instead of a bottom nav.
- No longer reference `BillLinusBottomBar` / `ScreenName.INVOICES` / `ScreenName.COUPONS`
  as a nav target.

**Not yet verified:** `viewModel.navigateBack()` already existed in `MainViewModel.kt`
(saw it referenced elsewhere), but I did not re-open `MainViewModel.kt` after this edit
to confirm the back-stack behaves correctly when entering these screens from different
places (e.g. Home's "view all" vs. a quick action). Worth a manual test.

### 4. `ui/screens/WinnerCheckerScreen.kt` / `ui/screens/ScanScreen.kt`
Added `BillLinusBottomBar` to both (they previously had no bottom nav at all, which
would have made them dead-ends). Added the missing imports:
`ScreenName`, `BillLinusBottomBar` (Winner screen), `BillLinusBottomBar` (Scan screen).

### 5. `ui/screens/ProfileScreen.kt`
Swapped `AppBottomNav` → `BillLinusBottomBar` so all 5 top-level screens use the same
nav component instead of two divergent ones.

### 6. `ui/screens/ExpensesScreen.kt` — full rewrite
This is the biggest change. Two tabs now:
- **Categories** (your original spend-by-category view, rebuilt)
- **Warranty & Guarantee** (new, per your request)

Warranty tab logic:
- Reads `Transaction.hasWarranty` + `Transaction.warrantyMonths` (these fields
  **already existed** in `model/Types.kt` — nothing added to the data model)
- Computes expiry = purchase date (`Transaction.date`, ISO `yyyy-MM-dd`) + warranty
  months, using `java.time.LocalDate` / `ChronoUnit`
- Status buckets: **Active** / **Expiring soon** (≤30 days left) / **Expired**
  (color-coded, with counts at the top)
- Each card shows purchase date, expiry date, warranty length, a "days/months left"
  or "expired N days ago" badge, and a tap-through to the bill's photo if one was
  attached during scan/entry
- All strings pulled from **existing** `AppStrings.kt` keys (`expenses.warranty_*`,
  `expenses.status_*`, etc.) — I found these were already written in a prior AI
  Studio pass but never wired to a screen. I verified every key I used actually
  exists (see verification section below) rather than assuming.

**Known gap:** there is currently no UI for a user to *set* `hasWarranty` /
`warrantyMonths` when adding a bill. I did not check whether `AddInvoiceScreen.kt`
already has fields for this. If it doesn't, the warranty tab will stay empty forever
in real use — see "Next steps," item 1.

## Verification I actually did (no compiler available)
- Brace `{}` and paren `()` counts balance in every edited file.
- Every function I called (`EmptyStateCard`, `viewModel.selectInvoice`,
  `viewModel.navigateTo`, `viewModel.navigateBack`) exists with a matching signature.
- Every `ScreenName` enum value I referenced (`SCAN`, `WINNER_CHECKER`, `EXPENSES`,
  `PROFILE`, `INVOICE_DETAIL`, `HOME`) exists in `model/Types.kt`.
- Every `AppStrings` key I referenced exists (checked individually, listed above).
- Every color token (`Emerald100/600/700`, `Amber100/600`, `Red100/600`,
  `Slate50-900`) exists in `ui/theme/Color.kt`.
- `Transaction` fields used (`hasWarranty`, `warrantyMonths`, `photoReference`,
  `sellerName`, `date`) all exist in `model/Types.kt` with matching types.
- Swapped `Icons.Default.ShieldMoon` → `Icons.Default.Shield` (safer, more universally
  available icon in `material-icons-extended`, which is already a project dependency).

## What I did NOT get to (be honest about limits)
1. **No actual build.** Please open this in Android Studio (or re-upload to AI Studio)
   and run a Gradle build first. There's a real chance of a small issue I couldn't
   catch by reading alone (e.g. an import ordering issue, a subtle type mismatch).
2. **`ScreenName.IRD_INFO` navigation crash** — mentioned in earlier sessions, never
   investigated this session. Needs someone to check `IrdInfoScreen.kt` (if it exists)
   and how `MainActivity.kt` / `MainViewModel.kt` route `ScreenName.IRD_INFO`.
3. **No UI to set warranty info when adding a bill.** Check `AddInvoiceScreen.kt` —
   if there's no "Has warranty? / Warranty length" input there, add one so the new
   Warranty tab actually gets populated by real usage.
4. **Dark mode / fonts / full theming pass** — you asked for "theme, fonts, all what
   an app needs." I did not do a general theming audit this session; I only touched
   the screens listed above. `ui/theme/Theme.kt` and `Type.kt` (fonts) were viewed but
   not modified — worth a dedicated pass if dark mode/typography still needs work.
5. **No local notifications for warranty expiry** — "expiring soon" is only visible if
   the user opens the Expenses → Warranty tab. A push/local notification 7 days before
   expiry would make this feature far more useful, and the project already has a
   notifications system (seven phases mentioned it was done) — just needs a new
   trigger wired to warranty expiry dates.
6. **Home screen stat-card regression** you mentioned earlier (stat cards need to
   reopen full invoice/coupon list screens) — the nav fix in this session addresses
   the *bottom bar* mismatch, but I did not specifically re-check the stat card
   tap-through logic on `HomeScreen.kt`. Worth a manual test.

## Suggested order for the next session
1. Open in Android Studio → Gradle sync → build. Fix any compile errors (should be
   minor if any, per the verification above).
2. Manually test: bottom nav across all 5 screens, back button on Invoices/Coupons,
   Warranty tab with a manually-added test bill (set `hasWarranty = true` on a sample
   transaction if there's no UI for it yet).
3. Add warranty fields to `AddInvoiceScreen.kt` if missing (item 3 above).
4. Trace `IRD_INFO` crash (item 2 above).
5. Theming/fonts/dark-mode pass if still needed (item 4 above).
6. Warranty expiry notifications (item 5 above) — nice-to-have, not blocking.

If you paste this file's contents (or just this repo) back into a fresh Claude
conversation, that's enough context for me to pick up exactly where this session
left off without you having to re-explain anything.
