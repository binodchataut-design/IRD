package com.example.data.services

import com.example.data.models.IRDNotice
import com.example.data.models.IRDSourceType

object IRDInfoService {
    val NOTICES: List<IRDNotice> = listOf(
        IRDNotice(
            id = "prog-cur-01",
            sourceType = IRDSourceType.CURRENT_PROGRAMME,
            programmeId = "nepal-ird-electronic-billing-consumer-incentive",
            title = "Electronic Billing Consumer Tax Incentive Scheme (Current Fiscal Framework)",
            publicationDate = "2026-08-01",
            effectiveFrom = "2026-07-16",
            sourceOrganization = "Inland Revenue Department (IRD Nepal)",
            sourceUrl = "https://ird.gov.np",
            category = "Current Programme Directive",
            summary = "Official consumer tax incentive guidelines for electronic billing and digital payment transactions in Nepal.",
            details = "Consumers who make retail purchases above NPR 100 paid via approved digital channels (QR payments, mobile banking, digital wallets like eSewa/Khalti, or cards) at PAN-registered merchants receive automatic eligibility to participate in fortnightly IRD lottery draws based on the 12-digit prize coupon numbers generated at billing.",
            lastVerifiedAt = "2026-08-17",
            isOfficialSource = true
        ),
        IRDNotice(
            id = "legal-prov-01",
            sourceType = IRDSourceType.LEGAL_PROVISION,
            programmeId = "nepal-tax-statutory-framework",
            title = "Value Added Tax Act & Electronic Billing System (CBMS) Mandate",
            publicationDate = "2025-11-20",
            effectiveFrom = "2025-11-20",
            sourceOrganization = "Ministry of Finance & IRD Legal Division",
            sourceUrl = "https://ird.gov.np/legal-framework",
            category = "Statutory Tax Provision",
            summary = "Statutory provisions governing merchant obligations to issue authorized fiscal receipts and maintain real-time CBMS electronic sales logs.",
            details = "Under the Nepal Value Added Tax Act and Electronic Billing Guidelines, registered commercial entities are required to issue authentic computerized invoices displaying their valid 9-digit PAN/VAT number and synchronise sales data directly with IRD's Central Billing Monitoring System (CBMS).",
            lastVerifiedAt = "2026-08-17",
            isOfficialSource = true
        ),
        IRDNotice(
            id = "ann-upd-01",
            sourceType = IRDSourceType.OFFICIAL_ANNOUNCEMENT,
            programmeId = "nepal-ird-electronic-billing-consumer-incentive",
            title = "Public Advisory on QR Code Invoices and Authorized Billing Software",
            publicationDate = "2026-07-28",
            effectiveFrom = "2026-07-28",
            effectiveTo = "2026-10-30",
            sourceOrganization = "Inland Revenue Department — System & Monitoring Division",
            sourceUrl = "https://ird.gov.np/notices",
            category = "Public Advisory Circular",
            summary = "Important advisory regarding software verification, QR code bill validation, and prize claim procedures.",
            details = "Registered taxpayers and consumers are advised to verify that bills contain approved QR codes and 9-digit PAN. In the event of a winning coupon draw, winners must claim their prize within 15 days of announcement at the local IRD Taxpayer Service Office (TSO) or via the IRD portal with original bill/digital payment slip.",
            lastVerifiedAt = "2026-08-17",
            isOfficialSource = true
        ),
        IRDNotice(
            id = "app-guide-01",
            sourceType = IRDSourceType.APP_EXPLANATION,
            programmeId = "rasid-khata-app-guide",
            title = "How to Organize Personal Invoices and Payment Proofs",
            publicationDate = "2026-08-15",
            sourceOrganization = "Rasid Khata Application",
            sourceUrl = "https://ird.gov.np",
            category = "App User Guide",
            summary = "Educational overview explaining why tracking merchant PANs and saving bill receipts helps manage personal expenditure records.",
            details = "Keeping a personal log of your daily retail purchases, digital wallet transaction references, and merchant PAN numbers simplifies personal tax tracking. Having organized digital records makes documentation straightforward whenever you want to check lottery draws or audit household expenses.",
            lastVerifiedAt = "2026-08-17",
            isOfficialSource = false
        ),
        IRDNotice(
            id = "app-guide-02",
            sourceType = IRDSourceType.APP_EXPLANATION,
            programmeId = "rasid-khata-app-guide",
            title = "Understanding Merchant PAN and VAT Numbers on Invoices",
            publicationDate = "2026-07-10",
            sourceOrganization = "Rasid Khata Application",
            sourceUrl = "https://ird.gov.np",
            category = "App Concept Guide",
            summary = "What the 9-digit Permanent Account Number (PAN) printed on cash receipts represents and how to spot authentic bills.",
            details = "In Nepal, all businesses registered with the Inland Revenue Department are issued a unique 9-digit Permanent Account Number (PAN). When making purchases, always ensure the printed receipt includes this 9-digit number and specifies the taxable VAT amount.",
            lastVerifiedAt = "2026-08-17",
            isOfficialSource = false
        )
    )

    fun getAll(): List<IRDNotice> = NOTICES
    fun getLatest(limit: Int = 3): List<IRDNotice> = NOTICES.take(limit)
    fun getById(id: String): IRDNotice? = NOTICES.firstOrNull { it.id == id }
    fun getByLayer(layer: IRDSourceType): List<IRDNotice> = NOTICES.filter { it.sourceType == layer }
}
