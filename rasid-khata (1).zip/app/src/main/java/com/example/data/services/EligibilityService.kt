package com.example.data.services

import com.example.data.models.EligibilityStatus
import com.example.data.models.PaymentMethod
import com.example.data.models.PurchasePurpose
import com.example.data.models.SellerPanOption
import com.example.data.models.TransactionCategory
import com.example.data.models.TransactionEligibilityInput
import com.example.data.models.TransactionEligibilityResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EligibilityService {
    /**
     * Evaluates a transaction input against official IRD Taxpayer Incentive rules
     * and Fortnightly Prize Coupon eligibility guidelines.
     */
    fun checkEligibility(input: TransactionEligibilityInput): TransactionEligibilityResult {
        val reasons = mutableListOf<String>()
        val caveats = mutableListOf<String>()
        val nextSteps = mutableListOf<String>()

        val isDigitalMethod = input.paymentMethod in listOf(
            PaymentMethod.DIGITAL_WALLET,
            PaymentMethod.QR_PAYMENT,
            PaymentMethod.MOBILE_BANKING,
            PaymentMethod.CARD,
            PaymentMethod.BANK_TRANSFER
        )

        val isCash = input.paymentMethod == PaymentMethod.CASH
        val isUnknownMethod = input.paymentMethod == PaymentMethod.OTHER

        // 1. Check Disqualifiers
        val disqualifiers = mutableListOf<String>()

        if (input.amount <= 100) {
            disqualifiers.add("Amount must be more than NPR 100 (NPR 100 or less does not qualify for IRD lottery prize coupons).")
        }

        if (isCash) {
            disqualifiers.add("Cash purchases do not generate electronic incentive prize coupons. Approved digital/electronic payments qualify.")
        }

        if (input.purpose == PurchasePurpose.BUSINESS || input.purpose == PurchasePurpose.GOVERNMENT) {
            disqualifiers.add("Business, commercial, and institutional/government purchases are excluded. Only individual consumer personal purchases qualify.")
        }

        if (input.category == TransactionCategory.ELECTRICITY || input.category == TransactionCategory.TELEPHONE_INTERNET) {
            disqualifiers.add("Utility bills (electricity, telephone, internet) are excluded from the consumer taxpayer incentive lottery scheme.")
        }

        if (input.category == TransactionCategory.AIRLINE || input.category == TransactionCategory.TRANSPORT_FREIGHT) {
            disqualifiers.add("Air tickets, public transport, and freight charges are currently excluded from the consumer lottery scheme.")
        }

        if (input.sellerPan == SellerPanOption.NO) {
            disqualifiers.add("Seller PAN/VAT information is missing. Transactions must be from registered businesses issuing authorized electronic tax bills.")
        }

        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val evaluatedAt = sdf.format(Date())

        // A. LIKELY NOT ELIGIBLE
        if (disqualifiers.isNotEmpty()) {
            nextSteps.add("Keep invoices for personal records, but note this transaction is unlikely to receive an IRD lottery prize coupon.")
            nextSteps.add("For upcoming draws, pay via digital wallet/QR above NPR 100 for personal goods at PAN-registered stores.")

            return TransactionEligibilityResult(
                status = EligibilityStatus.LIKELY_NOT_ELIGIBLE,
                title = "Likely Not Eligible",
                statusLabel = "Likely not eligible for IRD Prize Coupon Lottery",
                reasons = disqualifiers,
                caveats = listOf(
                    "Rasid Khata is an independent helper app. This result is not an official IRD eligibility confirmation."
                ),
                digitalWarning = null,
                nextSteps = nextSteps,
                evaluatedAt = evaluatedAt
            )
        }

        // 2. Check Needs Verification items
        val verificationReasons = mutableListOf<String>()

        if (input.sellerPan == SellerPanOption.DONT_KNOW) {
            verificationReasons.add("Seller PAN status is unconfirmed. The merchant must be registered with IRD and submit electronic invoices to CBMS.")
        }

        if (input.category == TransactionCategory.DONT_KNOW) {
            verificationReasons.add("Transaction category is unconfirmed. Verify that the purchased items are standard taxable retail goods/services.")
        }

        if (input.purpose == PurchasePurpose.UNKNOWN) {
            verificationReasons.add("Purchase purpose is unconfirmed. Only personal consumer purchases are eligible.")
        }

        if (isUnknownMethod) {
            verificationReasons.add("Payment mode cannot be verified as an approved electronic/digital channel.")
        }

        if (isDigitalMethod) {
            verificationReasons.add("Rasid Khata cannot verify offline whether the seller's billing software successfully transmitted the invoice to IRD's central CBMS.")
        }

        // B. NEEDS VERIFICATION
        if (input.sellerPan == SellerPanOption.DONT_KNOW ||
            input.category == TransactionCategory.DONT_KNOW ||
            input.purpose == PurchasePurpose.UNKNOWN ||
            isUnknownMethod
        ) {
            nextSteps.add("Check your bill or invoice slip for the seller's 9-digit PAN/VAT number.")
            nextSteps.add("Check your payment app (eSewa, Khalti, Mobile Banking) to see if a 12-digit Prize Coupon Number was generated.")
            nextSteps.add("Keep your invoice/receipt until the fortnightly draw is completed.")

            return TransactionEligibilityResult(
                status = EligibilityStatus.NEEDS_VERIFICATION,
                title = "Needs Verification",
                statusLabel = "Needs verification with seller & payment channel",
                reasons = verificationReasons,
                caveats = listOf(
                    "Rasid Khata is an independent helper app. This result is not an official IRD eligibility confirmation.",
                    "Your digital payment may qualify, but Rasid Khata cannot verify whether the transaction was successfully reported to IRD."
                ),
                digitalWarning = if (isDigitalMethod) {
                    "Digital payment does not automatically guarantee an IRD coupon. Your 12-digit Prize Coupon Number should come from the payment app (eSewa, Khalti, Fonepay) or the official IRD system when the transaction is successfully logged."
                } else null,
                nextSteps = nextSteps,
                evaluatedAt = evaluatedAt
            )
        }

        // C. LIKELY ELIGIBLE
        val eligibleReasons = listOf(
            "Amount (NPR ${String.format(Locale.US, "%,.2f", input.amount)}) is above the NPR 100 threshold.",
            "Purchased for personal individual consumer use.",
            "Payment method (${input.paymentMethod.displayName}) is an approved electronic/digital channel.",
            "Seller is PAN-registered and issuing taxable electronic bills."
        )

        nextSteps.add("Check your payment app (eSewa, Khalti, Mobile Banking) or SMS for your 12-digit Prize Coupon Number.")
        nextSteps.add("Save the 12-digit number in Rasid Khata's Coupon Manager to check against official winner announcements.")
        nextSteps.add("Keep your invoice/receipt safe until the fortnightly draw is concluded.")

        return TransactionEligibilityResult(
            status = EligibilityStatus.LIKELY_ELIGIBLE,
            title = "Likely Eligible",
            statusLabel = "Likely eligible for IRD Prize Coupon Lottery",
            reasons = eligibleReasons,
            caveats = listOf(
                "This is a preliminary check by Rasid Khata based on Nepal tax directives. Final eligibility is determined by IRD Nepal.",
                "Rasid Khata is an independent helper app and is not affiliated with the Inland Revenue Department."
            ),
            digitalWarning = if (isDigitalMethod) {
                "Digital payment does not mean Rasid Khata can confirm your IRD coupon. Your Prize Coupon Number should come from the relevant payment app or the official IRD system. Keep your receipt safe!"
            } else null,
            nextSteps = nextSteps,
            evaluatedAt = evaluatedAt
        )
    }
}
