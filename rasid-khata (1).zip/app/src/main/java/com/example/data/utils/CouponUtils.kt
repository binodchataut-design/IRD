package com.example.data.utils

import com.example.data.models.BulkParseResult

object CouponUtils {
    /**
     * Normalizes a coupon number string by removing all non-digit characters.
     * Preserves leading zeros.
     * Example: "007 315 254 493" -> "007315254493"
     */
    fun normalizeCouponNumber(input: String?): String {
        if (input.isNullOrBlank()) return ""
        return input.filter { it.isDigit() }
    }

    /**
     * Validates whether a normalized string is a valid 12-digit prize coupon number.
     */
    fun isValidCouponNumber(normalized: String?): Boolean {
        if (normalized == null) return false
        return normalized.length == 12 && normalized.all { it.isDigit() }
    }

    /**
     * Formats a 12-digit coupon number into human-readable 3-digit groups.
     * Example: "007315254493" -> "007 315 254 493"
     */
    fun formatCouponNumber(couponNumber: String?): String {
        if (couponNumber.isNullOrBlank()) return ""
        val digits = normalizeCouponNumber(couponNumber)
        return if (digits.length == 12) {
            "${digits.substring(0, 3)} ${digits.substring(3, 6)} ${digits.substring(6, 9)} ${digits.substring(9, 12)}"
        } else {
            digits.chunked(3).joinToString(" ")
        }
    }

    /**
     * Validates a 9-digit PAN/VAT number commonly used in Nepal.
     */
    fun isValidPanNumber(pan: String?): Boolean {
        if (pan.isNullOrBlank()) return false
        val digits = pan.filter { it.isDigit() }
        return digits.length == 9
    }

    /**
     * Formats 9-digit PAN (e.g. "601928374" -> "601 928 374")
     */
    fun formatPanNumber(pan: String?): String {
        if (pan.isNullOrBlank()) return ""
        val digits = pan.filter { it.isDigit() }
        return if (digits.length == 9) {
            "${digits.substring(0, 3)} ${digits.substring(3, 6)} ${digits.substring(6, 9)}"
        } else digits
    }

    /**
     * Parses raw multi-line/comma-separated text and extracts 12-digit coupon numbers.
     */
    fun parseBulkCouponsText(
        rawText: String,
        existingSavedNumbers: Set<String>
    ): BulkParseResult {
        if (rawText.isBlank()) {
            return BulkParseResult(0, emptyList(), emptyList(), emptyList(), emptyList())
        }

        val lines = rawText.split(Regex("[\\r\\n;,]+"))
        val seenInBatch = mutableSetOf<String>()
        val validNew = mutableListOf<String>()
        val duplicateInBatch = mutableListOf<String>()
        val alreadySaved = mutableListOf<String>()
        val invalidTokens = mutableListOf<String>()

        fun processNumber(num: String) {
            when {
                existingSavedNumbers.contains(num) -> alreadySaved.add(num)
                seenInBatch.contains(num) -> duplicateInBatch.add(num)
                else -> {
                    seenInBatch.add(num)
                    validNew.add(num)
                }
            }
        }

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue

            val normalizedLine = normalizeCouponNumber(trimmed)
            when {
                normalizedLine.length == 12 && isValidCouponNumber(normalizedLine) -> {
                    processNumber(normalizedLine)
                }
                normalizedLine.length > 12 && normalizedLine.length % 12 == 0 -> {
                    for (i in 0 until normalizedLine.length step 12) {
                        val chunk = normalizedLine.substring(i, i + 12)
                        processNumber(chunk)
                    }
                }
                else -> {
                    val tokens = trimmed.split(Regex("\\s+"))
                    val combinedDigits = normalizeCouponNumber(tokens.joinToString(""))
                    if (combinedDigits.length == 12 && isValidCouponNumber(combinedDigits)) {
                        processNumber(combinedDigits)
                    } else {
                        var tokenProcessed = false
                        for (token in tokens) {
                            val normToken = normalizeCouponNumber(token)
                            if (normToken.length == 12 && isValidCouponNumber(normToken)) {
                                processNumber(normToken)
                                tokenProcessed = true
                            }
                        }
                        if (!tokenProcessed && trimmed.isNotEmpty()) {
                            invalidTokens.add(trimmed)
                        }
                    }
                }
            }
        }

        val totalExtracted = validNew.size + duplicateInBatch.size + alreadySaved.size
        return BulkParseResult(
            totalExtracted = totalExtracted,
            validNew = validNew,
            duplicateInBatch = duplicateInBatch,
            alreadySaved = alreadySaved,
            invalidTokens = invalidTokens
        )
    }

    /**
     * Parses raw text of winning numbers announced by IRD.
     */
    fun parseWinningNumbersText(rawText: String): Pair<List<String>, List<String>> {
        if (rawText.isBlank()) return Pair(emptyList(), emptyList())

        val lines = rawText.split(Regex("[\\r\\n;,]+"))
        val seen = mutableSetOf<String>()
        val validWinningNumbers = mutableListOf<String>()
        val invalidTokens = mutableListOf<String>()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue

            val normalized = normalizeCouponNumber(trimmed)
            when {
                normalized.length == 12 && isValidCouponNumber(normalized) -> {
                    if (!seen.contains(normalized)) {
                        seen.add(normalized)
                        validWinningNumbers.add(normalized)
                    }
                }
                normalized.length > 12 && normalized.length % 12 == 0 -> {
                    for (i in 0 until normalized.length step 12) {
                        val chunk = normalized.substring(i, i + 12)
                        if (!seen.contains(chunk)) {
                            seen.add(chunk)
                            validWinningNumbers.add(chunk)
                        }
                    }
                }
                else -> {
                    val tokens = trimmed.split(Regex("\\s+"))
                    val combined = normalizeCouponNumber(tokens.joinToString(""))
                    if (combined.length == 12 && isValidCouponNumber(combined)) {
                        if (!seen.contains(combined)) {
                            seen.add(combined)
                            validWinningNumbers.add(combined)
                        }
                    } else {
                        invalidTokens.add(trimmed)
                    }
                }
            }
        }

        return Pair(validWinningNumbers, invalidTokens)
    }
}
