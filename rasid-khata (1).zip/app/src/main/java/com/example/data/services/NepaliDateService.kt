package com.example.data.services

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DrawPeriodInfo(
    val drawPeriod: String,
    val expectedAnnouncement: String,
    val cycleName: String,
    val isExact: Boolean
)

object NepaliDateService {
    fun getCurrentCycle(): DrawPeriodInfo {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = sdf.format(Date())
        return getDrawPeriodInfo(today)
    }

    fun getDrawPeriodInfo(dateStr: String?): DrawPeriodInfo {
        if (dateStr.isNullOrBlank() || !dateStr.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
            return DrawPeriodInfo(
                drawPeriod = "Current Scheme Cycle",
                expectedAnnouncement = "Next scheduled IRD fortnightly draw",
                cycleName = "Fortnightly consumer draw",
                isExact = false
            )
        }

        return try {
            val parts = dateStr.split("-")
            val year = parts[0].toInt()
            val month = parts[1].toInt()
            val day = parts[2].toInt()

            if (year == 2026) {
                when {
                    month == 7 && day >= 16 -> DrawPeriodInfo(
                        drawPeriod = "Shrawan 1–15, 2083",
                        expectedAnnouncement = "Shrawan 22, 2083 (Approx. Aug 7, 2026)",
                        cycleName = "Shrawan 1st Half Draw",
                        isExact = true
                    )
                    month == 7 && day < 16 -> DrawPeriodInfo(
                        drawPeriod = "Ashadh 16–31, 2083",
                        expectedAnnouncement = "Shrawan 7, 2083 (Approx. July 22, 2026)",
                        cycleName = "Ashadh 2nd Half Draw",
                        isExact = true
                    )
                    month == 8 && day <= 16 -> DrawPeriodInfo(
                        drawPeriod = "Shrawan 16–31, 2083",
                        expectedAnnouncement = "Bhadra 6, 2083 (Approx. Aug 22, 2026)",
                        cycleName = "Shrawan 2nd Half Draw",
                        isExact = true
                    )
                    month == 8 && day > 16 -> DrawPeriodInfo(
                        drawPeriod = "Bhadra 1–15, 2083",
                        expectedAnnouncement = "Bhadra 22, 2083 (Approx. Sept 7, 2026)",
                        cycleName = "Bhadra 1st Half Draw",
                        isExact = true
                    )
                    month == 9 && day <= 16 -> DrawPeriodInfo(
                        drawPeriod = "Bhadra 16–31, 2083",
                        expectedAnnouncement = "Ashwin 6, 2083 (Approx. Sept 22, 2026)",
                        cycleName = "Bhadra 2nd Half Draw",
                        isExact = true
                    )
                    month == 9 && day > 16 -> DrawPeriodInfo(
                        drawPeriod = "Ashwin 1–15, 2083",
                        expectedAnnouncement = "Ashwin 22, 2083 (Approx. Oct 8, 2026)",
                        cycleName = "Ashwin 1st Half Draw",
                        isExact = true
                    )
                    else -> DrawPeriodInfo(
                        drawPeriod = "Fiscal Year 2083/84 Cycle",
                        expectedAnnouncement = "Following the 15-day billing cycle",
                        cycleName = "Fortnightly consumer draw",
                        isExact = false
                    )
                }
            } else {
                DrawPeriodInfo(
                    drawPeriod = "Based on transaction date",
                    expectedAnnouncement = "Following the 15-day billing cycle",
                    cycleName = "Fortnightly consumer draw",
                    isExact = false
                )
            }
        } catch (e: Exception) {
            DrawPeriodInfo(
                drawPeriod = "Based on transaction date",
                expectedAnnouncement = "Following the 15-day billing cycle",
                cycleName = "Fortnightly consumer draw",
                isExact = false
            )
        }
    }
}
