package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.models.*
import com.example.data.utils.CouponUtils
import com.example.data.services.EligibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class AppRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("rasid_khata_db_v1", Context.MODE_PRIVATE)

    private val _transactions = MutableStateFlow<List<Transaction>>(emptyList())
    val transactions: StateFlow<List<Transaction>> = _transactions.asStateFlow()

    private val _coupons = MutableStateFlow<List<Coupon>>(emptyList())
    val coupons: StateFlow<List<Coupon>> = _coupons.asStateFlow()

    private val _drawAnnouncements = MutableStateFlow<List<DrawAnnouncement>>(emptyList())
    val drawAnnouncements: StateFlow<List<DrawAnnouncement>> = _drawAnnouncements.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        val txJson = prefs.getString(KEY_TRANSACTIONS, null)
        if (txJson.isNullOrBlank()) {
            _transactions.value = emptyList()
        } else {
            _transactions.value = parseTransactions(txJson)
        }

        val cpJson = prefs.getString(KEY_COUPONS, null)
        if (cpJson.isNullOrBlank()) {
            _coupons.value = emptyList()
        } else {
            _coupons.value = parseCoupons(cpJson)
        }

        val drawJson = prefs.getString(KEY_DRAWS, null)
        if (drawJson.isNullOrBlank()) {
            _drawAnnouncements.value = emptyList()
        } else {
            _drawAnnouncements.value = parseDraws(drawJson)
        }
    }

    // --- TRANSACTION METHODS ---

    fun addTransaction(
        date: String,
        sellerName: String,
        amount: Double,
        paymentMethod: PaymentMethod,
        panVat: String?,
        invoiceNumber: String?,
        couponNumber: String?,
        notes: String?,
        photoReference: String? = null
    ): Transaction {
        val evalInput = TransactionEligibilityInput(
            amount = amount,
            paymentMethod = paymentMethod,
            purpose = PurchasePurpose.PERSONAL,
            sellerPan = if (!panVat.isNullOrBlank()) SellerPanOption.YES else SellerPanOption.NO,
            sellerPanNumber = panVat,
            sellerName = sellerName,
            category = TransactionCategory.NORMAL_GOODS,
            date = date,
            invoiceNumber = invoiceNumber
        )
        val evalResult = EligibilityService.checkEligibility(evalInput)
        val normalizedCoupon = CouponUtils.normalizeCouponNumber(couponNumber)

        val status = when {
            normalizedCoupon.length == 12 -> EligibilityStatus.COUPON_ADDED
            evalResult.status == EligibilityStatus.LIKELY_ELIGIBLE -> EligibilityStatus.AWAITING_COUPON
            else -> evalResult.status
        }

        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
        val newTx = Transaction(
            id = "tx-${UUID.randomUUID().toString().take(8)}",
            date = date,
            sellerName = sellerName.trim(),
            amount = amount,
            paymentMethod = paymentMethod,
            panVat = panVat?.trim()?.ifBlank { null },
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            couponNumber = normalizedCoupon.ifBlank { null },
            eligibilityStatus = status,
            eligibilityReasons = evalResult.reasons,
            notes = notes?.trim()?.ifBlank { null },
            photoReference = photoReference,
            createdAt = now
        )

        val updated = listOf(newTx) + _transactions.value
        _transactions.value = updated
        saveTransactions(updated)

        // Automatically add coupon to coupons list if 12 digits provided
        if (normalizedCoupon.length == 12) {
            addCoupon(
                couponNumber = normalizedCoupon,
                date = date,
                drawPeriod = null,
                merchantName = sellerName,
                amount = amount,
                paymentMethod = paymentMethod.displayName,
                invoiceNumber = invoiceNumber,
                notes = "Auto-linked from invoice $invoiceNumber"
            )
        }

        return newTx
    }

    fun deleteTransaction(id: String): Boolean {
        val current = _transactions.value
        val updated = current.filter { it.id != id }
        if (updated.size == current.size) return false
        _transactions.value = updated
        saveTransactions(updated)
        return true
    }

    fun getTransactionById(id: String): Transaction? {
        return _transactions.value.firstOrNull { it.id == id }
    }

    fun updateTransactionCoupon(transactionId: String, couponNumber: String): Boolean {
        val current = _transactions.value
        val normalized = CouponUtils.normalizeCouponNumber(couponNumber)
        val updated = current.map {
            if (it.id == transactionId) {
                it.copy(
                    couponNumber = normalized,
                    eligibilityStatus = if (normalized.length == 12) EligibilityStatus.COUPON_ADDED else it.eligibilityStatus
                )
            } else it
        }
        _transactions.value = updated
        saveTransactions(updated)
        return true
    }

    // --- COUPON METHODS ---

    fun addCoupon(
        couponNumber: String,
        date: String? = null,
        drawPeriod: String? = null,
        merchantName: String? = null,
        amount: Double? = null,
        paymentMethod: String? = null,
        invoiceNumber: String? = null,
        notes: String? = null
    ): Coupon? {
        val normalized = CouponUtils.normalizeCouponNumber(couponNumber)
        if (!CouponUtils.isValidCouponNumber(normalized)) return null

        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
        val newCoupon = Coupon(
            id = "cp-${UUID.randomUUID().toString().take(8)}",
            couponNumber = normalized,
            date = date,
            drawPeriod = drawPeriod ?: "Shrawan 1–15, 2083",
            merchantName = merchantName?.trim()?.ifBlank { null },
            amount = amount,
            paymentMethod = paymentMethod,
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            notes = notes?.trim()?.ifBlank { null },
            createdAt = now
        )

        val current = _coupons.value
        // If not already present, add to list
        if (current.none { it.couponNumber == normalized }) {
            val updated = listOf(newCoupon) + current
            _coupons.value = updated
            saveCoupons(updated)
        }
        return newCoupon
    }

    fun addBulkCoupons(numbers: List<String>): Int {
        val existing = _coupons.value.map { it.couponNumber }.toSet()
        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
        val toAdd = mutableListOf<Coupon>()
        val seen = mutableSetOf<String>()

        for (num in numbers) {
            val norm = CouponUtils.normalizeCouponNumber(num)
            if (CouponUtils.isValidCouponNumber(norm) && !existing.contains(norm) && !seen.contains(norm)) {
                seen.add(norm)
                toAdd.add(
                    Coupon(
                        id = "cp-${UUID.randomUUID().toString().take(8)}",
                        couponNumber = norm,
                        drawPeriod = "Shrawan 1–15, 2083",
                        notes = "Bulk imported",
                        createdAt = now
                    )
                )
            }
        }

        if (toAdd.isNotEmpty()) {
            val updated = toAdd + _coupons.value
            _coupons.value = updated
            saveCoupons(updated)
        }
        return toAdd.size
    }

    fun deleteCoupon(id: String): Boolean {
        val current = _coupons.value
        val updated = current.filter { it.id != id }
        if (updated.size == current.size) return false
        _coupons.value = updated
        saveCoupons(updated)
        return true
    }

    // --- DRAW ANNOUNCEMENT METHODS ---

    fun addDrawAnnouncement(
        title: String,
        drawPeriod: String,
        announcementDate: String,
        winningNumbers: List<String>,
        sourceUrl: String = "https://ird.gov.np/notices",
        sourceName: String = "Inland Revenue Department (IRD Nepal)",
        notes: String? = null
    ): DrawAnnouncement {
        val validWinners = winningNumbers.map { CouponUtils.normalizeCouponNumber(it) }
            .filter { CouponUtils.isValidCouponNumber(it) }
            .distinct()

        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
        val newDraw = DrawAnnouncement(
            id = "draw-${UUID.randomUUID().toString().take(8)}",
            title = title.trim(),
            drawPeriod = drawPeriod.trim(),
            announcementDate = announcementDate.trim(),
            winningNumbers = validWinners,
            sourceUrl = sourceUrl.trim(),
            sourceName = sourceName.trim(),
            notes = notes?.trim()?.ifBlank { null },
            createdAt = now
        )

        val updated = listOf(newDraw) + _drawAnnouncements.value
        _drawAnnouncements.value = updated
        saveDraws(updated)
        return newDraw
    }

    fun deleteDrawAnnouncement(id: String): Boolean {
        val current = _drawAnnouncements.value
        val updated = current.filter { it.id != id }
        if (updated.size == current.size) return false
        _drawAnnouncements.value = updated
        saveDraws(updated)
        return true
    }

    // --- WINNER CHECK ENGINE ---

    fun checkWinners(
        winningNumbers: List<String>,
        drawTitle: String? = null,
        drawPeriod: String? = null,
        announcementDate: String? = null
    ): WinnerCheckResult {
        val normalizedWinners = winningNumbers.map { CouponUtils.normalizeCouponNumber(it) }
            .filter { CouponUtils.isValidCouponNumber(it) }
            .toSet()

        val saved = _coupons.value
        val matches = mutableListOf<CouponMatch>()

        for (userCoupon in saved) {
            val normUserNum = CouponUtils.normalizeCouponNumber(userCoupon.couponNumber)
            if (normalizedWinners.contains(normUserNum)) {
                matches.add(
                    CouponMatch(
                        userCoupon = userCoupon,
                        matchedWinningNumber = normUserNum,
                        drawTitle = drawTitle ?: "Official IRD Winner Draw",
                        drawPeriod = drawPeriod ?: userCoupon.drawPeriod ?: "Current Fortnight Cycle",
                        announcementDate = announcementDate ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    )
                )
            }
        }

        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        return WinnerCheckResult(
            checkedCouponCount = saved.size,
            winningNumberCount = normalizedWinners.size,
            matches = matches,
            checkedAt = sdf.format(Date()),
            drawInfoTitle = drawTitle,
            drawPeriod = drawPeriod,
            announcementDate = announcementDate
        )
    }

    // --- BACKUP & RESTORE ---

    fun exportBackupJson(): String {
        val root = JSONObject()
        root.put("app", "Rasid Khata")
        root.put("backupVersion", 1)
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()))

        val txArray = JSONArray()
        for (tx in _transactions.value) {
            val obj = JSONObject()
            obj.put("id", tx.id)
            obj.put("date", tx.date)
            obj.put("sellerName", tx.sellerName)
            obj.put("amount", tx.amount)
            obj.put("paymentMethod", tx.paymentMethod.name)
            obj.put("panVat", tx.panVat ?: "")
            obj.put("invoiceNumber", tx.invoiceNumber ?: "")
            obj.put("couponNumber", tx.couponNumber ?: "")
            obj.put("eligibilityStatus", tx.eligibilityStatus.name)
            obj.put("notes", tx.notes ?: "")
            obj.put("photoReference", tx.photoReference ?: "")
            obj.put("createdAt", tx.createdAt)
            txArray.put(obj)
        }
        root.put("transactions", txArray)

        val cpArray = JSONArray()
        for (cp in _coupons.value) {
            val obj = JSONObject()
            obj.put("id", cp.id)
            obj.put("couponNumber", cp.couponNumber)
            obj.put("date", cp.date ?: "")
            obj.put("drawPeriod", cp.drawPeriod ?: "")
            obj.put("merchantName", cp.merchantName ?: "")
            obj.put("amount", cp.amount ?: 0.0)
            obj.put("paymentMethod", cp.paymentMethod ?: "")
            obj.put("invoiceNumber", cp.invoiceNumber ?: "")
            obj.put("notes", cp.notes ?: "")
            obj.put("createdAt", cp.createdAt)
            cpArray.put(obj)
        }
        root.put("coupons", cpArray)

        val drawArray = JSONArray()
        for (d in _drawAnnouncements.value) {
            val obj = JSONObject()
            obj.put("id", d.id)
            obj.put("title", d.title)
            obj.put("drawPeriod", d.drawPeriod)
            obj.put("announcementDate", d.announcementDate)
            val numArr = JSONArray()
            d.winningNumbers.forEach { numArr.put(it) }
            obj.put("winningNumbers", numArr)
            obj.put("sourceUrl", d.sourceUrl)
            obj.put("sourceName", d.sourceName)
            obj.put("notes", d.notes ?: "")
            obj.put("createdAt", d.createdAt)
            drawArray.put(obj)
        }
        root.put("customDraws", drawArray)

        return root.toString(2)
    }

    fun restoreBackupJson(jsonString: String, mode: String = "merge"): Boolean {
        return try {
            val root = JSONObject(jsonString)
            val txArr = root.optJSONArray("transactions") ?: JSONArray()
            val cpArr = root.optJSONArray("coupons") ?: JSONArray()
            val drawArr = root.optJSONArray("customDraws") ?: JSONArray()

            val parsedTx = mutableListOf<Transaction>()
            for (i in 0 until txArr.length()) {
                val obj = txArr.getJSONObject(i)
                parsedTx.add(
                    Transaction(
                        id = obj.optString("id", "tx-$i"),
                        date = obj.optString("date", "2026-08-01"),
                        sellerName = obj.optString("sellerName", "Store"),
                        amount = obj.optDouble("amount", 0.0),
                        paymentMethod = PaymentMethod.fromString(obj.optString("paymentMethod", "Digital Wallet")),
                        panVat = obj.optString("panVat").ifBlank { null },
                        invoiceNumber = obj.optString("invoiceNumber").ifBlank { null },
                        couponNumber = obj.optString("couponNumber").ifBlank { null },
                        eligibilityStatus = EligibilityStatus.fromString(obj.optString("eligibilityStatus")),
                        notes = obj.optString("notes").ifBlank { null },
                        photoReference = obj.optString("photoReference").ifBlank { null },
                        createdAt = obj.optString("createdAt", "")
                    )
                )
            }

            val parsedCp = mutableListOf<Coupon>()
            for (i in 0 until cpArr.length()) {
                val obj = cpArr.getJSONObject(i)
                parsedCp.add(
                    Coupon(
                        id = obj.optString("id", "cp-$i"),
                        couponNumber = CouponUtils.normalizeCouponNumber(obj.optString("couponNumber")),
                        date = obj.optString("date").ifBlank { null },
                        drawPeriod = obj.optString("drawPeriod").ifBlank { null },
                        merchantName = obj.optString("merchantName").ifBlank { null },
                        amount = if (obj.has("amount")) obj.optDouble("amount") else null,
                        paymentMethod = obj.optString("paymentMethod").ifBlank { null },
                        invoiceNumber = obj.optString("invoiceNumber").ifBlank { null },
                        notes = obj.optString("notes").ifBlank { null },
                        createdAt = obj.optString("createdAt", "")
                    )
                )
            }

            val parsedDraws = mutableListOf<DrawAnnouncement>()
            for (i in 0 until drawArr.length()) {
                val obj = drawArr.getJSONObject(i)
                val winArr = obj.optJSONArray("winningNumbers") ?: JSONArray()
                val winList = mutableListOf<String>()
                for (w in 0 until winArr.length()) {
                    winList.add(CouponUtils.normalizeCouponNumber(winArr.getString(w)))
                }
                parsedDraws.add(
                    DrawAnnouncement(
                        id = obj.optString("id", "draw-$i"),
                        title = obj.optString("title", "Draw Announcement"),
                        drawPeriod = obj.optString("drawPeriod", "Fiscal Draw"),
                        announcementDate = obj.optString("announcementDate", "2026-08-01"),
                        winningNumbers = winList,
                        sourceUrl = obj.optString("sourceUrl", "https://ird.gov.np"),
                        sourceName = obj.optString("sourceName", "Inland Revenue Department (IRD Nepal)"),
                        notes = obj.optString("notes").ifBlank { null },
                        createdAt = obj.optString("createdAt", "")
                    )
                )
            }

            if (mode == "replace") {
                _transactions.value = parsedTx
                saveTransactions(parsedTx)
                _coupons.value = parsedCp
                saveCoupons(parsedCp)
                if (parsedDraws.isNotEmpty()) {
                    _drawAnnouncements.value = parsedDraws
                    saveDraws(parsedDraws)
                }
            } else {
                // Merge mode
                val currentTxIds = _transactions.value.map { it.id }.toSet()
                val newTx = parsedTx.filter { !currentTxIds.contains(it.id) }
                val mergedTx = newTx + _transactions.value
                _transactions.value = mergedTx
                saveTransactions(mergedTx)

                val currentCpNums = _coupons.value.map { it.couponNumber }.toSet()
                val newCp = parsedCp.filter { !currentCpNums.contains(it.couponNumber) }
                val mergedCp = newCp + _coupons.value
                _coupons.value = mergedCp
                saveCoupons(mergedCp)

                val currentDrawIds = _drawAnnouncements.value.map { it.id }.toSet()
                val newDraws = parsedDraws.filter { !currentDrawIds.contains(it.id) }
                val mergedDraws = newDraws + _drawAnnouncements.value
                _drawAnnouncements.value = mergedDraws
                saveDraws(mergedDraws)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun exportTransactionsCsv(): String {
        val sb = StringBuilder()
        sb.append("ID,Date,Merchant,Amount (NPR),Payment Method,PAN/VAT,Invoice #,Coupon #,Status\n")
        for (tx in _transactions.value) {
            sb.append("\"${tx.id}\",")
            sb.append("\"${tx.date}\",")
            sb.append("\"${tx.sellerName.replace("\"", "\"\"")}\",")
            sb.append("${tx.amount},")
            sb.append("\"${tx.paymentMethod.displayName}\",")
            sb.append("\"${tx.panVat ?: ""}\",")
            sb.append("\"${tx.invoiceNumber ?: ""}\",")
            sb.append("\"${tx.couponNumber ?: ""}\",")
            sb.append("\"${tx.eligibilityStatus.label}\"\n")
        }
        return sb.toString()
    }

    fun exportCouponsCsv(): String {
        val sb = StringBuilder()
        sb.append("Coupon Number,Draw Period,Merchant,Amount (NPR),Date,Invoice #\n")
        for (cp in _coupons.value) {
            sb.append("\"${CouponUtils.formatCouponNumber(cp.couponNumber)}\",")
            sb.append("\"${cp.drawPeriod ?: ""}\",")
            sb.append("\"${(cp.merchantName ?: "").replace("\"", "\"\"")}\",")
            sb.append("${cp.amount ?: ""},")
            sb.append("\"${cp.date ?: ""}\",")
            sb.append("\"${cp.invoiceNumber ?: ""}\"\n")
        }
        return sb.toString()
    }

    fun resetToEmpty() {
        _transactions.value = emptyList()
        prefs.edit().remove(KEY_TRANSACTIONS).apply()

        _coupons.value = emptyList()
        prefs.edit().remove(KEY_COUPONS).apply()

        _drawAnnouncements.value = emptyList()
        prefs.edit().remove(KEY_DRAWS).apply()
    }

    fun loadDemoData() {
        val tx = getSampleTransactions()
        _transactions.value = tx
        saveTransactions(tx)

        val cp = getSampleCoupons()
        _coupons.value = cp
        saveCoupons(cp)

        val dr = getSampleDraws()
        _drawAnnouncements.value = dr
        saveDraws(dr)
    }

    fun resetToDefaults() {
        resetToEmpty()
    }

    // --- PERSISTENCE HELPERS ---

    private fun saveTransactions(list: List<Transaction>) {
        val arr = JSONArray()
        for (tx in list) {
            val obj = JSONObject()
            obj.put("id", tx.id)
            obj.put("date", tx.date)
            obj.put("sellerName", tx.sellerName)
            obj.put("amount", tx.amount)
            obj.put("paymentMethod", tx.paymentMethod.name)
            obj.put("panVat", tx.panVat ?: "")
            obj.put("invoiceNumber", tx.invoiceNumber ?: "")
            obj.put("couponNumber", tx.couponNumber ?: "")
            obj.put("eligibilityStatus", tx.eligibilityStatus.name)
            obj.put("notes", tx.notes ?: "")
            obj.put("photoReference", tx.photoReference ?: "")
            obj.put("createdAt", tx.createdAt)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_TRANSACTIONS, arr.toString()).apply()
    }

    private fun parseTransactions(json: String): List<Transaction> {
        val list = mutableListOf<Transaction>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    Transaction(
                        id = obj.optString("id"),
                        date = obj.optString("date"),
                        sellerName = obj.optString("sellerName"),
                        amount = obj.optDouble("amount", 0.0),
                        paymentMethod = PaymentMethod.fromString(obj.optString("paymentMethod")),
                        panVat = obj.optString("panVat").ifBlank { null },
                        invoiceNumber = obj.optString("invoiceNumber").ifBlank { null },
                        couponNumber = obj.optString("couponNumber").ifBlank { null },
                        eligibilityStatus = EligibilityStatus.fromString(obj.optString("eligibilityStatus")),
                        notes = obj.optString("notes").ifBlank { null },
                        photoReference = obj.optString("photoReference").ifBlank { null },
                        createdAt = obj.optString("createdAt")
                    )
                )
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return list
    }

    private fun saveCoupons(list: List<Coupon>) {
        val arr = JSONArray()
        for (cp in list) {
            val obj = JSONObject()
            obj.put("id", cp.id)
            obj.put("couponNumber", cp.couponNumber)
            obj.put("date", cp.date ?: "")
            obj.put("drawPeriod", cp.drawPeriod ?: "")
            obj.put("merchantName", cp.merchantName ?: "")
            if (cp.amount != null) obj.put("amount", cp.amount)
            obj.put("paymentMethod", cp.paymentMethod ?: "")
            obj.put("invoiceNumber", cp.invoiceNumber ?: "")
            obj.put("notes", cp.notes ?: "")
            obj.put("createdAt", cp.createdAt)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_COUPONS, arr.toString()).apply()
    }

    private fun parseCoupons(json: String): List<Coupon> {
        val list = mutableListOf<Coupon>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    Coupon(
                        id = obj.optString("id"),
                        couponNumber = obj.optString("couponNumber"),
                        date = obj.optString("date").ifBlank { null },
                        drawPeriod = obj.optString("drawPeriod").ifBlank { null },
                        merchantName = obj.optString("merchantName").ifBlank { null },
                        amount = if (obj.has("amount")) obj.optDouble("amount") else null,
                        paymentMethod = obj.optString("paymentMethod").ifBlank { null },
                        invoiceNumber = obj.optString("invoiceNumber").ifBlank { null },
                        notes = obj.optString("notes").ifBlank { null },
                        createdAt = obj.optString("createdAt")
                    )
                )
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return list
    }

    private fun saveDraws(list: List<DrawAnnouncement>) {
        val arr = JSONArray()
        for (d in list) {
            val obj = JSONObject()
            obj.put("id", d.id)
            obj.put("title", d.title)
            obj.put("drawPeriod", d.drawPeriod)
            obj.put("announcementDate", d.announcementDate)
            val winArr = JSONArray()
            d.winningNumbers.forEach { winArr.put(it) }
            obj.put("winningNumbers", winArr)
            obj.put("sourceUrl", d.sourceUrl)
            obj.put("sourceName", d.sourceName)
            obj.put("notes", d.notes ?: "")
            obj.put("createdAt", d.createdAt)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_DRAWS, arr.toString()).apply()
    }

    private fun parseDraws(json: String): List<DrawAnnouncement> {
        val list = mutableListOf<DrawAnnouncement>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val winArr = obj.optJSONArray("winningNumbers") ?: JSONArray()
                val winList = mutableListOf<String>()
                for (w in 0 until winArr.length()) {
                    winList.add(winArr.getString(w))
                }
                list.add(
                    DrawAnnouncement(
                        id = obj.optString("id"),
                        title = obj.optString("title"),
                        drawPeriod = obj.optString("drawPeriod"),
                        announcementDate = obj.optString("announcementDate"),
                        winningNumbers = winList,
                        sourceUrl = obj.optString("sourceUrl"),
                        sourceName = obj.optString("sourceName"),
                        notes = obj.optString("notes").ifBlank { null },
                        createdAt = obj.optString("createdAt")
                    )
                )
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return list
    }

    // --- DEMO / SAMPLE DATA HELPERS (Only loaded on explicit user request in DataBackupScreen) ---

    private fun getSampleTransactions(): List<Transaction> = listOf(
        Transaction(
            id = "tx-001",
            date = "2026-08-16",
            sellerName = "Sagarmatha Bakery & Cafe",
            amount = 320.0,
            paymentMethod = PaymentMethod.DIGITAL_WALLET,
            panVat = "601928374",
            invoiceNumber = "SB-8821",
            couponNumber = "007315254493",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "Morning tea and bakery items on Tripureshwor road.",
            photoReference = "https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80",
            createdAt = "2026-08-16T08:15:00Z"
        ),
        Transaction(
            id = "tx-002",
            date = "2026-08-15",
            sellerName = "Annapurna Stationery & Gift House",
            amount = 450.0,
            paymentMethod = PaymentMethod.CARD,
            panVat = "302819201",
            invoiceNumber = "AS-1049",
            couponNumber = "002928817811",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "Notebooks and gel pens.",
            createdAt = "2026-08-15T11:20:00Z"
        ),
        Transaction(
            id = "tx-003",
            date = "2026-08-15",
            sellerName = "Patan Stationery Hub",
            amount = 240.0,
            paymentMethod = PaymentMethod.CASH,
            panVat = "609123847",
            invoiceNumber = "INV-2026-009",
            eligibilityStatus = EligibilityStatus.LIKELY_NOT_ELIGIBLE,
            notes = "Photocopy and folder files.",
            createdAt = "2026-08-15T14:40:00Z"
        ),
        Transaction(
            id = "tx-004",
            date = "2026-08-14",
            sellerName = "Lalitpur Electronics Express",
            amount = 480.0,
            paymentMethod = PaymentMethod.DIGITAL_WALLET,
            panVat = null,
            invoiceNumber = "INV-2026-009",
            couponNumber = "015611059075",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "USB-C fast charging cable.",
            photoReference = "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80",
            createdAt = "2026-08-14T10:05:00Z"
        ),
        Transaction(
            id = "tx-005",
            date = "2026-08-14",
            sellerName = "Shree Pashupati Organic Spices & Herbs",
            amount = 390.0,
            paymentMethod = PaymentMethod.CASH,
            panVat = "100482910",
            invoiceNumber = "SPH-99214",
            eligibilityStatus = EligibilityStatus.LIKELY_NOT_ELIGIBLE,
            notes = "Ginger powder and organic tea leaves.",
            photoReference = "https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80",
            createdAt = "2026-08-14T16:30:00Z"
        ),
        Transaction(
            id = "tx-006",
            date = "2026-08-13",
            sellerName = "Everest IT Hardware & Office Equipments",
            amount = 54850.0,
            paymentMethod = PaymentMethod.BANK_TRANSFER,
            panVat = "304918273",
            invoiceNumber = "EIT-2026-784",
            couponNumber = "004128930192",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "Office monitor and ergonomic mesh chair.",
            createdAt = "2026-08-13T09:45:00Z"
        ),
        Transaction(
            id = "tx-007",
            date = "2026-08-13",
            sellerName = "Dhulikhel Fresh Veggie & Fruit Mart",
            amount = 180.0,
            paymentMethod = PaymentMethod.CASH,
            panVat = null,
            invoiceNumber = null,
            eligibilityStatus = EligibilityStatus.LIKELY_NOT_ELIGIBLE,
            notes = "Seasonal fresh vegetables.",
            createdAt = "2026-08-13T17:10:00Z"
        ),
        Transaction(
            id = "tx-008",
            date = "2026-08-12",
            sellerName = "Bagmati Auto Parts & Lubricants",
            amount = 350.0,
            paymentMethod = PaymentMethod.DIGITAL_WALLET,
            panVat = "602938475",
            invoiceNumber = "BAP-4401",
            couponNumber = "005829104728",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "Scooter engine oil top up.",
            createdAt = "2026-08-12T13:25:00Z"
        ),
        Transaction(
            id = "tx-009",
            date = "2026-08-11",
            sellerName = "Namaste Departmental Store",
            amount = 1250.0,
            paymentMethod = PaymentMethod.QR_PAYMENT,
            panVat = "301928374",
            invoiceNumber = "NDS-9912",
            couponNumber = "008273910482",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "Groceries, olive oil and kitchen wipes.",
            createdAt = "2026-08-11T16:00:00Z"
        ),
        Transaction(
            id = "tx-010",
            date = "2026-08-10",
            sellerName = "Himalayan Java Cafe",
            amount = 680.0,
            paymentMethod = PaymentMethod.DIGITAL_WALLET,
            panVat = "301293847",
            invoiceNumber = "HJC-4421",
            eligibilityStatus = EligibilityStatus.AWAITING_COUPON,
            notes = "Cold brew and blueberry cheesecake.",
            createdAt = "2026-08-10T15:20:00Z"
        ),
        Transaction(
            id = "tx-011",
            date = "2026-08-09",
            sellerName = "Bhatbhateni Supermarket",
            amount = 3450.0,
            paymentMethod = PaymentMethod.CARD,
            panVat = "300182736",
            invoiceNumber = "BBS-2083-9910",
            couponNumber = "002938475619",
            eligibilityStatus = EligibilityStatus.COUPON_ADDED,
            notes = "Monthly kitchen provisions and toiletries.",
            createdAt = "2026-08-09T18:40:00Z"
        ),
        Transaction(
            id = "tx-012",
            date = "2026-08-08",
            sellerName = "Nepal Electricity Authority (NEA)",
            amount = 1450.0,
            paymentMethod = PaymentMethod.DIGITAL_WALLET,
            panVat = "100000001",
            invoiceNumber = "NEA-2026-08",
            eligibilityStatus = EligibilityStatus.LIKELY_NOT_ELIGIBLE,
            notes = "Monthly electricity bill payment.",
            createdAt = "2026-08-08T10:15:00Z"
        )
    )

    private fun getSampleCoupons(): List<Coupon> = listOf(
        Coupon(
            id = "cp-001",
            couponNumber = "007315254493",
            date = "2026-08-16",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Sagarmatha Bakery & Cafe",
            amount = 320.0,
            paymentMethod = "Digital Wallet",
            invoiceNumber = "SB-8821",
            notes = "Breakfast & coffee on Tripureshwor road",
            createdAt = "2026-08-16T08:15:00Z"
        ),
        Coupon(
            id = "cp-002",
            couponNumber = "002928817811",
            date = "2026-08-15",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Annapurna Stationery & Gift House",
            amount = 450.0,
            paymentMethod = "Card",
            invoiceNumber = "AS-1049",
            notes = "Office supplies & pens",
            createdAt = "2026-08-15T11:20:00Z"
        ),
        Coupon(
            id = "cp-003",
            couponNumber = "003066779589",
            date = "2026-08-15",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Patan Stationery Hub",
            amount = 240.0,
            paymentMethod = "Cash",
            invoiceNumber = "INV-2026-009",
            notes = "Photocopies and files",
            createdAt = "2026-08-15T14:40:00Z"
        ),
        Coupon(
            id = "cp-004",
            couponNumber = "015611059075",
            date = "2026-08-14",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Lalitpur Electronics Express",
            amount = 480.0,
            paymentMethod = "Digital Wallet",
            invoiceNumber = "INV-2026-009",
            notes = "Fast charging cable",
            createdAt = "2026-08-14T10:05:00Z"
        ),
        Coupon(
            id = "cp-005",
            couponNumber = "009917833245",
            date = "2026-08-14",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Shree Pashupati Organic Spices",
            amount = 390.0,
            paymentMethod = "Cash",
            invoiceNumber = "SPH-99214",
            notes = "Organic tea & cardamom",
            createdAt = "2026-08-14T16:30:00Z"
        ),
        Coupon(
            id = "cp-006",
            couponNumber = "004128930192",
            date = "2026-08-13",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Everest IT Hardware Outlet",
            amount = 54850.0,
            paymentMethod = "Bank Transfer",
            invoiceNumber = "EIT-2026-784",
            notes = "Monitor purchase with electronic tax invoice",
            createdAt = "2026-08-13T09:45:00Z"
        ),
        Coupon(
            id = "cp-007",
            couponNumber = "001827364510",
            date = "2026-08-13",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Dhulikhel Fresh Veggie Mart",
            amount = 180.0,
            paymentMethod = "Cash",
            notes = "Seasonal groceries",
            createdAt = "2026-08-13T17:10:00Z"
        ),
        Coupon(
            id = "cp-008",
            couponNumber = "005829104728",
            date = "2026-08-12",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Bagmati Auto Parts & Lubricants",
            amount = 350.0,
            paymentMethod = "Digital Wallet",
            invoiceNumber = "BAP-4401",
            notes = "Scooter maintenance oil",
            createdAt = "2026-08-12T13:25:00Z"
        ),
        Coupon(
            id = "cp-009",
            couponNumber = "008273910482",
            date = "2026-08-11",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Namaste Departmental Store",
            amount = 1250.0,
            paymentMethod = "QR Payment",
            invoiceNumber = "NDS-9912",
            notes = "Kitchen provisions",
            createdAt = "2026-08-11T16:00:00Z"
        ),
        Coupon(
            id = "cp-010",
            couponNumber = "002938475619",
            date = "2026-08-09",
            drawPeriod = "Shrawan 1–15, 2083",
            merchantName = "Bhatbhateni Supermarket",
            amount = 3450.0,
            paymentMethod = "Card",
            invoiceNumber = "BBS-2083-9910",
            notes = "Groceries & household items",
            createdAt = "2026-08-09T18:40:00Z"
        )
    )

    private fun getSampleDraws(): List<DrawAnnouncement> = listOf(
        DrawAnnouncement(
            id = "draw-001",
            title = "First Draw (Shrawan 1–15, 2083)",
            drawPeriod = "Shrawan 1–15, 2083",
            announcementDate = "2026-08-07",
            winningNumbers = listOf(
                "007315254493",
                "007755590670",
                "002928817811",
                "003066779589",
                "015611059075",
                "009917833245",
                "004128930192",
                "005829104728",
                "008273910482",
                "002938475619",
                "006918273645",
                "011293847560",
                "003829104857",
                "009283746150",
                "004928173645",
                "001928374650"
            ),
            sourceUrl = "https://ird.gov.np/notices",
            sourceName = "Inland Revenue Department (IRD Nepal)",
            notes = "Official draw for electronic billing incentive coupons issued between Shrawan 1–15, 2083.",
            createdAt = "2026-08-07T12:00:00Z"
        ),
        DrawAnnouncement(
            id = "draw-002",
            title = "Second Draw (Shrawan 16–31, 2083)",
            drawPeriod = "Shrawan 16–31, 2083",
            announcementDate = "2026-08-22",
            winningNumbers = listOf(
                "008192837465",
                "005192837465",
                "003928174650",
                "002819283746",
                "006819283746",
                "004819283746",
                "007819283746",
                "001182938475",
                "009827364512",
                "004738291045",
                "003728194056",
                "019283746510",
                "018273645920",
                "017263548910",
                "016253489102",
                "015243981023"
            ),
            sourceUrl = "https://ird.gov.np/notices",
            sourceName = "Inland Revenue Department (IRD Nepal)",
            notes = "Second fortnightly consumer incentive draw announced for Shrawan second half.",
            createdAt = "2026-08-22T14:30:00Z"
        )
    )

    companion object {
        private const val KEY_TRANSACTIONS = "transactions_data"
        private const val KEY_COUPONS = "coupons_data"
        private const val KEY_DRAWS = "draws_data"
    }
}
