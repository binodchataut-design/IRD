package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.EligibilityStatus
import com.example.data.models.PaymentMethod
import com.example.data.models.Transaction
import com.example.data.utils.CouponUtils
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.EligibilityBadge
import com.example.ui.components.EmptyStateView
import com.example.ui.components.RasidKhataHeader
import com.example.ui.theme.*
import java.util.Locale

enum class InvoiceFilter(val labelNp: String, val labelEn: String) {
    ALL("सबै", "All"),
    COUPON_LINKED("कुपन जोडिएको", "Coupon Linked"),
    AWAITING_COUPON("कुपन पर्खिएको", "Awaiting Coupon"),
    DIGITAL_PAYMENT("QR / डिजिटल", "Digital / QR"),
    CASH("नगद", "Cash"),
    WITH_PAN("PAN सहित", "With PAN")
}

@Composable
fun TransactionsScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val transactions by viewModel.transactions.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(InvoiceFilter.ALL) }

    val filteredTransactions = remember(transactions, searchQuery, selectedFilter) {
        transactions.filter { tx ->
            val matchesQuery = searchQuery.isBlank() ||
                tx.sellerName.contains(searchQuery, ignoreCase = true) ||
                (tx.panVat ?: "").contains(searchQuery) ||
                (tx.invoiceNumber ?: "").contains(searchQuery, ignoreCase = true) ||
                (tx.couponNumber ?: "").contains(searchQuery)

            val matchesFilter = when (selectedFilter) {
                InvoiceFilter.ALL -> true
                InvoiceFilter.COUPON_LINKED -> tx.eligibilityStatus == EligibilityStatus.COUPON_ADDED || !tx.couponNumber.isNullOrBlank()
                InvoiceFilter.AWAITING_COUPON -> tx.eligibilityStatus == EligibilityStatus.AWAITING_COUPON
                InvoiceFilter.DIGITAL_PAYMENT -> tx.paymentMethod in listOf(
                    PaymentMethod.DIGITAL_WALLET,
                    PaymentMethod.QR_PAYMENT,
                    PaymentMethod.MOBILE_BANKING,
                    PaymentMethod.CARD,
                    PaymentMethod.BANK_TRANSFER
                )
                InvoiceFilter.CASH -> tx.paymentMethod == PaymentMethod.CASH
                InvoiceFilter.WITH_PAN -> !tx.panVat.isNullOrBlank()
            }

            matchesQuery && matchesFilter
        }
    }

    val totalAmount = remember(filteredTransactions) {
        filteredTransactions.sumOf { it.amount }
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "रसिद तथा कारोबारहरू",
                subtitle = "Invoices & Purchases • ${transactions.size} records",
                rightAction = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.AddInvoice) },
                        modifier = Modifier.testTag("invoices_add_header_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Invoice",
                            tint = NavyPrimary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(Screen.AddInvoice) },
                containerColor = NavyPrimary,
                contentColor = SurfaceCard,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("invoices_fab_add")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Invoice"
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("पसलको नाम, PAN, रसिद # वा कुपन खोज्नुहोस्...", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NavyPrimary,
                        unfocusedBorderColor = BorderSubtle,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("invoices_search_input")
                )
            }

            // Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(InvoiceFilter.entries.toTypedArray()) { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = {
                                Text("${filter.labelNp} (${filter.labelEn})", fontSize = 11.sp)
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NavyContainer,
                                selectedLabelColor = NavyPrimary
                            ),
                            modifier = Modifier.testTag("filter_chip_${filter.name}")
                        )
                    }
                }
            }

            // Totals Summary Strip
            item {
                Surface(
                    color = SurfaceMuted,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${filteredTransactions.size} रसिदहरू (Invoices)",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "NPR ${String.format(Locale.US, "%,.2f", totalAmount)}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = NavyPrimary
                        )
                    }
                }
            }

            // Empty State
            if (filteredTransactions.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.ReceiptLong,
                        nepaliTitle = if (searchQuery.isNotEmpty()) "कुनै रसिद फेला परेन" else "अहिलेसम्म कुनै कारोबार थपिएको छैन",
                        englishTitle = if (searchQuery.isNotEmpty()) "No Invoices Found" else "No Transactions Recorded Yet",
                        nepaliDescription = if (searchQuery.isNotEmpty()) "खोज शब्द वा फिल्टर परिवर्तन गरी पुनः प्रयास गर्नुहोस् ।" else "तपाईंको खरिद बिल तथा रसिदहरू थपी Prize Coupon ट्र्याक गर्नुहोस् ।",
                        englishDescription = if (searchQuery.isNotEmpty()) "Try adjusting your search query or active filter." else "Log your purchase bills to track and manage prize coupons.",
                        actionLabel = "+ पहिलो कारोबार थप्नुहोस् (Add Transaction)",
                        onAction = { viewModel.navigateTo(Screen.AddInvoice) }
                    )
                }
            } else {
                // Invoices List
                items(filteredTransactions, key = { it.id }) { tx ->
                    InvoiceCard(
                        transaction = tx,
                        onClick = { viewModel.viewTransactionDetail(tx.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun InvoiceCard(
    transaction: Transaction,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("invoice_card_${transaction.id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = transaction.sellerName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "मिति: ${transaction.date}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
                Text(
                    text = "NPR ${String.format(Locale.US, "%,.2f", transaction.amount)}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = NavyPrimary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = SurfaceMuted,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = transaction.paymentMethod.displayName,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (!transaction.panVat.isNullOrBlank()) {
                        Surface(
                            color = NavyContainer,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "PAN: ${CouponUtils.formatPanNumber(transaction.panVat)}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                EligibilityBadge(status = transaction.eligibilityStatus)
            }

            if (!transaction.couponNumber.isNullOrBlank()) {
                Surface(
                    color = TealContainer,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, Color(0xFFCCFBF1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ConfirmationNumber,
                            contentDescription = null,
                            tint = TealAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Prize Coupon: ${CouponUtils.formatCouponNumber(transaction.couponNumber)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = OnTealContainer
                        )
                    }
                }
            }
        }
    }
}
