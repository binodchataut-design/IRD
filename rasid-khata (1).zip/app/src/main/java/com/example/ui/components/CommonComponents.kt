package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.EligibilityStatus
import com.example.data.utils.CouponUtils
import com.example.ui.Screen
import com.example.ui.theme.*

// =========================================================================
// 1. APP TOP BAR / HEADER
// =========================================================================
@Composable
fun RasidKhataHeader(
    title: String,
    subtitle: String? = null,
    nepaliTitle: String? = null,
    showBack: Boolean = false,
    onBack: () -> Unit = {},
    rightAction: (@Composable () -> Unit)? = null
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (showBack) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(38.dp)
                            .background(SurfaceMuted, shape = RoundedCornerShape(10.dp))
                            .testTag("header_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = NavyPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(NavyContainer, shape = RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = "Rasid Khata Logo",
                            tint = NavyPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = title,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (!nepaliTitle.isNullOrBlank()) {
                            Text(
                                text = "($nepaliTitle)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = NavyPrimaryLight
                            )
                        }
                    }
                    if (!subtitle.isNullOrBlank()) {
                        Text(
                            text = subtitle,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (rightAction != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    rightAction()
                }
            }
        }
    }
}

// =========================================================================
// 2. MODERN BOTTOM NAVIGATION BAR
// =========================================================================
data class NavItem(
    val screen: Screen,
    val nepaliLabel: String,
    val englishLabel: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun RasidKhataBottomNav(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        NavItem(
            screen = Screen.Home,
            nepaliLabel = "गृह",
            englishLabel = "Home",
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            testTag = "nav_home"
        ),
        NavItem(
            screen = Screen.Invoices,
            nepaliLabel = "कारोबार",
            englishLabel = "Invoices",
            selectedIcon = Icons.Filled.ReceiptLong,
            unselectedIcon = Icons.Outlined.ReceiptLong,
            testTag = "nav_invoices"
        ),
        NavItem(
            screen = Screen.Coupons,
            nepaliLabel = "कुपन",
            englishLabel = "Coupons",
            selectedIcon = Icons.Filled.ConfirmationNumber,
            unselectedIcon = Icons.Outlined.ConfirmationNumber,
            testTag = "nav_coupons"
        ),
        NavItem(
            screen = Screen.WinnerChecker,
            nepaliLabel = "नतिजा",
            englishLabel = "Winner",
            selectedIcon = Icons.Filled.EmojiEvents,
            unselectedIcon = Icons.Outlined.EmojiEvents,
            testTag = "nav_winner"
        ),
        NavItem(
            screen = Screen.IRDInfo,
            nepaliLabel = "जानकारी",
            englishLabel = "Guide",
            selectedIcon = Icons.Filled.Info,
            unselectedIcon = Icons.Outlined.Info,
            testTag = "nav_info"
        )
    )

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = modifier.navigationBarsPadding()
    ) {
        items.forEach { item ->
            val isSelected = currentScreen == item.screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(item.screen) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.englishLabel,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = item.nepaliLabel,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                        Text(
                            text = item.englishLabel,
                            fontSize = 9.sp,
                            color = if (isSelected) NavyPrimary else TextMuted
                        )
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = NavyPrimary,
                    selectedTextColor = NavyPrimary,
                    indicatorColor = NavyContainer,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary
                ),
                modifier = Modifier.testTag(item.testTag)
            )
        }
    }
}

// =========================================================================
// 3. UNIFIED STATUS BADGE SYSTEM
// =========================================================================
@Composable
fun EligibilityBadge(
    status: EligibilityStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, borderColor, icon, labelNp, labelEn) = when (status) {
        EligibilityStatus.COUPON_ADDED -> Tuple6(
            StatusSuccessBg, StatusSuccess, StatusSuccessBorder,
            Icons.Default.CheckCircle, "कुपन जोडिएको", "Coupon Linked"
        )
        EligibilityStatus.AWAITING_COUPON -> Tuple6(
            StatusPendingBg, StatusPending, StatusPendingBorder,
            Icons.Default.HourglassTop, "कुपन पर्खिएको", "Awaiting Coupon"
        )
        EligibilityStatus.LIKELY_ELIGIBLE -> Tuple6(
            StatusSuccessBg, StatusSuccess, StatusSuccessBorder,
            Icons.Default.CheckCircleOutline, "योग्य हुने सम्भावना", "Likely Eligible"
        )
        EligibilityStatus.NEEDS_VERIFICATION -> Tuple6(
            StatusPendingBg, StatusPending, StatusPendingBorder,
            Icons.Default.HelpOutline, "पुष्टि आवश्यक", "Needs Verification"
        )
        EligibilityStatus.LIKELY_NOT_ELIGIBLE -> Tuple6(
            StatusErrorBg, StatusError, StatusErrorBorder,
            Icons.Default.Cancel, "अयोग्य हुने सम्भावना", "Not Eligible"
        )
        EligibilityStatus.NOT_CHECKED -> Tuple6(
            SurfaceMuted, TextSecondary, BorderSubtle,
            Icons.Default.HelpOutline, "जाँच हुन बाँकी", "Not Checked"
        )
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = "$labelNp • $labelEn",
                color = textColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private data class Tuple6<A, B, C, D, E, F>(
    val a: A, val b: B, val c: C, val d: D, val e: E, val f: F
)

// =========================================================================
// 4. COUPON NUMBER DISPLAY (Monospaced, Preserves Leading Zeros)
// =========================================================================
@Composable
fun CouponNumberDisplay(
    couponNumber: String,
    modifier: Modifier = Modifier,
    showCopyButton: Boolean = true,
    fontSize: Int = 16
) {
    val context = LocalContext.current
    val formatted = CouponUtils.formatCouponNumber(couponNumber)

    Surface(
        color = SurfaceMuted,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ConfirmationNumber,
                    contentDescription = null,
                    tint = NavyPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = formatted,
                    fontSize = fontSize.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    letterSpacing = 1.sp
                )
            }

            if (showCopyButton) {
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Coupon Number", couponNumber))
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy Coupon",
                        tint = NavyPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

// =========================================================================
// 5. EMPTY STATE COMPONENT
// =========================================================================
@Composable
fun EmptyStateView(
    icon: ImageVector,
    nepaliTitle: String,
    englishTitle: String,
    nepaliDescription: String,
    englishDescription: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(NavyContainer, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NavyPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = nepaliTitle,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = englishTitle,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }

            Text(
                text = "$nepaliDescription\n$englishDescription",
                fontSize = 12.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp
            )

            if (actionLabel != null && onAction != null) {
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NavyPrimary,
                        contentColor = SurfaceCard
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    Text(
                        text = actionLabel,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// =========================================================================
// 6. SECTION HEADER
// =========================================================================
@Composable
fun SectionHeader(
    nepaliTitle: String,
    englishTitle: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(
                text = nepaliTitle,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = englishTitle.uppercase(),
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary,
                letterSpacing = 0.5.sp
            )
        }

        if (actionLabel != null && onAction != null) {
            TextButton(
                onClick = onAction,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = actionLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimaryLight
                )
            }
        }
    }
}

// =========================================================================
// 7. INDEPENDENT APP DISCLAIMER BANNER
// =========================================================================
@Composable
fun DisclaimerBanner(modifier: Modifier = Modifier) {
    Surface(
        color = SurfaceMuted,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.VerifiedUser,
                contentDescription = null,
                tint = NavyPrimary,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "रसिद खाता (Rasid Khata) एक स्वतन्त्र निजी एप हो । आधिकारिक पुष्टि तथा पुरस्कार दाबीका लागि ird.gov.np हेर्नुहोला ।\nIndependent helper app. Official claims via ird.gov.np.",
                fontSize = 10.sp,
                color = TextSecondary,
                lineHeight = 14.sp
            )
        }
    }
}
