package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.CouponMatch
import com.example.data.models.DrawAnnouncement
import com.example.data.models.WinnerCheckResult
import com.example.data.utils.CouponUtils
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.CouponNumberDisplay
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.EmptyStateView
import com.example.ui.components.RasidKhataHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun WinnerCheckerScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val coupons by viewModel.coupons.collectAsState()
    val drawAnnouncements by viewModel.drawAnnouncements.collectAsState()
    val winnerResult by viewModel.winnerCheckResult.collectAsState()

    var customInputText by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Official IRD Draws, 1: Custom Winning Numbers

    val (parsedCustomWinners, invalidTokens) = remember(customInputText) {
        CouponUtils.parseWinningNumbersText(customInputText)
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "विजेता नम्बर जाँच",
                subtitle = "Official IRD Winner & Draw Checker",
                rightAction = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.DrawHistory) },
                        modifier = Modifier.testTag("btn_draw_history")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Draw History",
                            tint = NavyPrimary
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // TAB SELECTOR
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = SurfaceMuted,
                    contentColor = NavyPrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                "आधिकारिक IRD गोलाप्रथा (${drawAnnouncements.size})",
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                "अन्य विजेता नम्बर प्रविष्टि",
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            // TAB 0: OFFICIAL DRAWS
            if (selectedTab == 0) {
                if (drawAnnouncements.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Default.EmojiEvents,
                            nepaliTitle = "आधिकारिक गोलाप्रथा नतिजा थपिएको छैन",
                            englishTitle = "No Official Draw Results Loaded",
                            nepaliDescription = "आन्तरिक राजस्व विभाग (IRD) ले पाक्षिक लटरी नतिजा प्रकाशित गरेपछि 'अन्य विजेता नम्बर प्रविष्टि' ट्याबमा पेस्ट गरी जाँच गर्नुहोस् ।",
                            englishDescription = "When IRD publishes lottery results, paste winning numbers in the 'Custom Winning Numbers' tab to check your coupons.",
                            actionLabel = "विजेता नम्बर प्रविष्टि गर्नुहोस् (Enter Numbers)",
                            onAction = { selectedTab = 1 }
                        )
                    }
                } else {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, BorderSubtle),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "IRD आधिकारिक पाक्षिक गोलाप्रथा जाँच",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )

                                Text(
                                    text = "तपाईंको वालेटमा रहेका ${coupons.size} वटा कुपनहरूलाई आन्तरिक राजस्व विभागको प्रकाशित नतिजासँग १-ट्यापमा रुजु गर्नुहोस् :",
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    lineHeight = 16.sp
                                )

                                Button(
                                    onClick = {
                                        val allWinningNumbers = drawAnnouncements.flatMap { it.winningNumbers }
                                        viewModel.runWinnerCheck(
                                            winningNumbers = allWinningNumbers,
                                            drawTitle = "सबै प्रकाशित IRD गोलाप्रथा",
                                            drawPeriod = "Recent Draws"
                                        )
                                    },
                                    enabled = coupons.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldWinner, contentColor = SurfaceCard),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("btn_run_official_check")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null)
                                        Text(
                                            text = "सबै ${coupons.size} कुपनको नतिजा जाँच्नुहोस् (Check All)",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // TAB 1: CUSTOM WINNING NUMBERS INPUT
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "पत्रिका वा सूचनाबाट विजेता नम्बरहरू पेस्ट गर्नुहोस्",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )

                            OutlinedTextField(
                                value = customInputText,
                                onValueChange = { customInputText = it },
                                placeholder = { Text("007 315 254 493\n009 881 234 112\n...", fontSize = 12.sp) },
                                minLines = 4,
                                maxLines = 8,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("custom_winner_textarea")
                            )

                            // Secondary Sample Helper Buttons (clearly test tools)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        customInputText = if (coupons.isNotEmpty()) {
                                            coupons.take(2).joinToString("\n") { it.couponNumber } + "\n009881234112\n001928374650"
                                        } else {
                                            "007315254493\n002928817811\n003066779589"
                                        }
                                    },
                                    border = BorderStroke(1.dp, BorderSubtle),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_sample_match")
                                ) {
                                    Text("Sample (Match)", fontSize = 11.sp, color = TextSecondary)
                                }

                                OutlinedButton(
                                    onClick = {
                                        customInputText = "099999999999\n088888888888\n077777777777"
                                    },
                                    border = BorderStroke(1.dp, BorderSubtle),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_sample_no_match")
                                ) {
                                    Text("Sample (No Match)", fontSize = 11.sp, color = TextSecondary)
                                }
                            }

                            if (customInputText.isNotBlank()) {
                                Text(
                                    text = "भेटिएका मान्य विजेता नम्बर: ${parsedCustomWinners.size}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (parsedCustomWinners.isNotEmpty()) StatusSuccess else StatusError
                                )
                            }

                            Button(
                                onClick = {
                                    if (parsedCustomWinners.isNotEmpty()) {
                                        viewModel.runWinnerCheck(
                                            winningNumbers = parsedCustomWinners,
                                            drawTitle = "प्रविष्ट गरिएका विजेता नम्बरहरू",
                                            drawPeriod = "Custom Draw Check"
                                        )
                                    }
                                },
                                enabled = parsedCustomWinners.isNotEmpty() && coupons.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_run_custom_check")
                            ) {
                                Text(
                                    text = "रुजु गर्नुहोस् (${parsedCustomWinners.size} Winners)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // RESULTS DISPLAY
            if (winnerResult != null) {
                val res = winnerResult!!

                item {
                    SectionHeader(
                        nepaliTitle = "जाँच नतिजा (Check Outcome)",
                        englishTitle = "${res.checkedCouponCount} Coupons Evaluated"
                    )
                }

                if (res.matches.isNotEmpty()) {
                    // WINNER CELEBRATION CARD
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = GoldWinnerContainer),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(2.dp, GoldWinner),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(GoldWinner, shape = CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = SurfaceCard,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }

                                Text(
                                    text = "बधाई छ! तपाईंको कुपन विजेता सूचीमा परेको छ!",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = OnGoldWinner
                                )

                                Text(
                                    text = "${res.matches.size} Matching Winning Coupons Found",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }
                        }
                    }

                    // MATCHED COUPONS CARDS
                    items(res.matches) { match ->
                        MatchedCouponItem(match = match, viewModel = viewModel)
                    }
                } else {
                    // NO MATCHES
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, BorderSubtle),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Text(
                                    text = "यस पटक कुनै कुपन मिलेन",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "तपाईंका ${res.checkedCouponCount} वटा कुपनहरूलाई ${res.winningNumberCount} वटा विजेता नम्बरसँग जाँच गर्दा कुनै मेल खाएन । आगामी पाक्षिक गोलाप्रथामा पुनः जाँच गर्नुहोस् ।",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }

            // DISCLAIMER
            item {
                DisclaimerBanner()
            }
        }
    }
}

@Composable
private fun MatchedCouponItem(
    match: CouponMatch,
    viewModel: RasidKhataViewModel
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.5.dp, GoldWinner),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = match.drawTitle,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = OnGoldWinner
                )
                Text(
                    text = match.drawPeriod,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            CouponNumberDisplay(
                couponNumber = match.userCoupon.couponNumber,
                fontSize = 16,
                modifier = Modifier.fillMaxWidth()
            )

            if (!match.userCoupon.merchantName.isNullOrBlank()) {
                Text(
                    text = "पसल: ${match.userCoupon.merchantName}",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Button(
                onClick = {
                    val claimData = com.example.data.models.ClaimReportData(
                        matchedCoupon = match.userCoupon,
                        matchedWinningNumber = match.matchedWinningNumber,
                        drawTitle = match.drawTitle,
                        drawPeriod = match.drawPeriod,
                        announcementDate = match.announcementDate
                    )
                    viewModel.openClaimReport(claimData)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "दाबी तयारी कागजात हेर्नुहोस् (View Claim Dossier)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
