package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Coupon
import com.example.data.utils.CouponUtils
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.CouponNumberDisplay
import com.example.ui.components.EmptyStateView
import com.example.ui.components.RasidKhataHeader
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MyCouponsScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val coupons by viewModel.coupons.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var couponToDelete by remember { mutableStateOf<Coupon?>(null) }

    val filteredCoupons = remember(coupons, searchQuery) {
        coupons.filter { cp ->
            searchQuery.isBlank() ||
                cp.couponNumber.contains(searchQuery) ||
                (cp.merchantName ?: "").contains(searchQuery, ignoreCase = true) ||
                (cp.drawPeriod ?: "").contains(searchQuery, ignoreCase = true) ||
                (cp.invoiceNumber ?: "").contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "मेरो Prize Coupons",
                subtitle = "${coupons.size} १२-अंकका कुपनहरू (Prize Coupons)",
                rightAction = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.AddCoupon) },
                        modifier = Modifier.testTag("coupons_add_header_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Coupon",
                            tint = NavyPrimary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SmallFloatingActionButton(
                    onClick = { viewModel.navigateTo(Screen.BulkAddCoupons) },
                    containerColor = NavyContainer,
                    contentColor = NavyPrimary,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("coupons_fab_bulk")
                ) {
                    Icon(imageVector = Icons.Default.PostAdd, contentDescription = "Bulk Add")
                }

                FloatingActionButton(
                    onClick = { viewModel.navigateTo(Screen.AddCoupon) },
                    containerColor = NavyPrimary,
                    contentColor = SurfaceCard,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("coupons_fab_add")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Coupon")
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Action Strip
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.navigateTo(Screen.AddCoupon) },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_single_coupon")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("+ १ कुपन", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { viewModel.navigateTo(Screen.BulkAddCoupons) },
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_bulk_coupons")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("धेरै कुपन (Bulk)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { viewModel.navigateTo(Screen.WinnerChecker) },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldWinner),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("btn_check_all_winners")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("नतिजा जाँच", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("१२ अंकको कुपन, पसल वा अवधि खोज्नुहोस्...", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NavyPrimary,
                        unfocusedBorderColor = BorderSubtle,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("coupons_search_input")
                )
            }

            // Info Box
            item {
                Surface(
                    color = NavyContainer,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = NavyPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "सबै १२-अंकका कुपनहरू पाक्षिक गोलाप्रथामा विजेता जाँच (Winner Checker) गर्न सकिन्छ ।",
                            fontSize = 11.sp,
                            color = NavyPrimary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // Empty State
            if (filteredCoupons.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.ConfirmationNumber,
                        nepaliTitle = if (searchQuery.isNotEmpty()) "कुपन फेला परेन" else "अहिलेसम्म Prize Coupon छैन",
                        englishTitle = if (searchQuery.isNotEmpty()) "No Coupons Match" else "No Prize Coupons Saved Yet",
                        nepaliDescription = if (searchQuery.isNotEmpty()) "खोज शब्द परिवर्तन गरी पुनः प्रयास गर्नुहोस् ।" else "डिजिटल भुक्तानी वा बिलमा प्राप्त १२ अंकको कुपन सुरक्षित गरी लटरी विजेता जाँच्नुहोस् ।",
                        englishDescription = if (searchQuery.isNotEmpty()) "No coupons match '$searchQuery'." else "Add your 12-digit prize coupons from digital receipts to check lottery results.",
                        actionLabel = "+ कुपन थप्नुहोस् (Add Coupon)",
                        onAction = { viewModel.navigateTo(Screen.AddCoupon) }
                    )
                }
            } else {
                // Coupons List
                items(filteredCoupons, key = { it.id }) { cp ->
                    CouponCard(
                        coupon = cp,
                        onDelete = { couponToDelete = cp }
                    )
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (couponToDelete != null) {
        val cp = couponToDelete!!
        AlertDialog(
            onDismissRequest = { couponToDelete = null },
            title = { Text("कुपन मेटाउने? (Delete Coupon)", fontWeight = FontWeight.Bold) },
            text = {
                Text("के तपाईं कुपन ${CouponUtils.formatCouponNumber(cp.couponNumber)} हटाउन निश्चित हुनुहुन्छ?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCoupon(cp.id)
                        couponToDelete = null
                        viewModel.showSnackbar("कुपन मेटाइयो (Coupon deleted)")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("मेटाउनुहोस् (Delete)")
                }
            },
            dismissButton = {
                TextButton(onClick = { couponToDelete = null }) {
                    Text("रद्द (Cancel)")
                }
            }
        )
    }
}

@Composable
private fun CouponCard(
    coupon: Coupon,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("coupon_card_${coupon.couponNumber}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CouponNumberDisplay(
                    couponNumber = coupon.couponNumber,
                    fontSize = 15,
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(32.dp)
                        .padding(start = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    if (!coupon.merchantName.isNullOrBlank()) {
                        Text(
                            text = coupon.merchantName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (!coupon.drawPeriod.isNullOrBlank()) {
                        Text(
                            text = "लटरी अवधि: ${coupon.drawPeriod}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                if (coupon.amount != null && coupon.amount > 0) {
                    Text(
                        text = "NPR ${String.format(Locale.US, "%,.2f", coupon.amount)}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                }
            }
        }
    }
}
