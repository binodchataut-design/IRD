package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.services.NepaliDateService
import com.example.data.utils.CouponUtils
import com.example.ui.RasidKhataViewModel
import com.example.ui.components.CouponNumberDisplay
import com.example.ui.components.RasidKhataHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AddCouponScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val defaultDrawPeriod = remember { NepaliDateService.getDrawPeriodInfo(todayStr).drawPeriod }

    var couponNumber by remember { mutableStateOf("") }
    var merchantName by remember { mutableStateOf("") }
    var drawPeriod by remember { mutableStateOf(defaultDrawPeriod) }
    var invoiceNumber by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }

    val normalized = CouponUtils.normalizeCouponNumber(couponNumber)
    val isValid = CouponUtils.isValidCouponNumber(normalized)

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "कुपन थप्नुहोस्",
                subtitle = "Add 12-Digit Prize Coupon",
                showBack = true,
                onBack = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "१२-अंकको Prize Coupon नम्बर प्रविष्ट गर्नुहोस्",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        OutlinedTextField(
                            value = couponNumber,
                            onValueChange = { couponNumber = it },
                            label = { Text("१२-Digit Coupon Number *") },
                            placeholder = { Text("007 315 254 493") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.ConfirmationNumber,
                                    contentDescription = null,
                                    tint = if (isValid) StatusSuccess else NavyPrimary
                                )
                            },
                            trailingIcon = {
                                if (couponNumber.isNotEmpty()) {
                                    Icon(
                                        imageVector = if (isValid) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                        contentDescription = null,
                                        tint = if (isValid) StatusSuccess else StatusPending
                                    )
                                }
                            },
                            supportingText = {
                                Text(
                                    text = "${normalized.length}/12 अंक प्रविष्ट गरियो (शून्य नहटाउनुहोस्)",
                                    fontSize = 10.sp,
                                    color = if (isValid) StatusSuccess else TextSecondary
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_coupon_input")
                        )

                        if (normalized.isNotEmpty()) {
                            CouponNumberDisplay(
                                couponNumber = normalized,
                                fontSize = 16,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        HorizontalDivider(color = BorderDivider)

                        OutlinedTextField(
                            value = merchantName,
                            onValueChange = { merchantName = it },
                            label = { Text("पसल वा बिक्रेताको नाम (Merchant Name)") },
                            placeholder = { Text("जस्तै: बिग मार्ट, भाटभटेनी") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_coupon_merchant_input")
                        )

                        OutlinedTextField(
                            value = drawPeriod,
                            onValueChange = { drawPeriod = it },
                            label = { Text("लटरी अवधि (Draw Period)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_coupon_period_input")
                        )

                        OutlinedTextField(
                            value = invoiceNumber,
                            onValueChange = { invoiceNumber = it },
                            label = { Text("बिल / रसिद # (Invoice Reference)") },
                            placeholder = { Text("जस्तै: INV-2083-001") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_coupon_invoice_input")
                        )

                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("रसिद रकम (Amount in NPR)") },
                            placeholder = { Text("1500") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_coupon_amount_input")
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        if (isValid) {
                            val amt = amountText.toDoubleOrNull()
                            viewModel.addCoupon(
                                couponNumber = normalized,
                                merchantName = merchantName.ifBlank { null },
                                drawPeriod = drawPeriod.ifBlank { null },
                                invoiceNumber = invoiceNumber.ifBlank { null },
                                amount = amt
                            )
                            viewModel.showSnackbar("कुपन सफलतापूर्वक सुरक्षित भयो (Coupon saved)")
                            viewModel.navigateBack()
                        }
                    },
                    enabled = isValid,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NavyPrimary,
                        contentColor = SurfaceCard
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("add_coupon_save_button")
                ) {
                    Text(
                        text = "कुपन सुरक्षित गर्नुहोस् (Save Coupon)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
