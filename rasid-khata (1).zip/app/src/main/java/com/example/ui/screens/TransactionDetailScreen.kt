package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.*
import com.example.data.services.EligibilityService
import com.example.data.services.NepaliDateService
import com.example.data.utils.CouponUtils
import com.example.ui.RasidKhataViewModel
import com.example.ui.components.CouponNumberDisplay
import com.example.ui.components.EligibilityBadge
import com.example.ui.components.RasidKhataHeader
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TransactionDetailScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val transaction by viewModel.selectedTransaction.collectAsState()

    var isLinkCouponDialogOpen by remember { mutableStateOf(false) }
    var couponInput by remember { mutableStateOf("") }
    var isDeleteDialogOpen by remember { mutableStateOf(false) }

    if (transaction == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("कारोबार फेला परेन (Invoice not found).")
        }
        return
    }

    val tx = transaction!!
    val drawPeriodInfo = remember(tx.date) { NepaliDateService.getDrawPeriodInfo(tx.date) }

    val evalResult = remember(tx) {
        val input = TransactionEligibilityInput(
            amount = tx.amount,
            paymentMethod = tx.paymentMethod,
            purpose = PurchasePurpose.PERSONAL,
            sellerPan = if (!tx.panVat.isNullOrBlank()) SellerPanOption.YES else SellerPanOption.NO,
            sellerPanNumber = tx.panVat,
            sellerName = tx.sellerName,
            category = TransactionCategory.NORMAL_GOODS,
            date = tx.date,
            invoiceNumber = tx.invoiceNumber
        )
        EligibilityService.checkEligibility(input)
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "रसिद विवरण",
                subtitle = tx.sellerName,
                showBack = true,
                onBack = { viewModel.navigateBack() },
                rightAction = {
                    IconButton(
                        onClick = { isDeleteDialogOpen = true },
                        modifier = Modifier.testTag("invoice_detail_delete_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete",
                            tint = StatusError
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. RECEIPT MAIN CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PURCHASE RECEIPT (खरिद रसिद)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                            EligibilityBadge(status = tx.eligibilityStatus)
                        }

                        Text(
                            text = tx.sellerName,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )

                        Text(
                            text = "NPR ${String.format(Locale.US, "%,.2f", tx.amount)}",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = NavyPrimary
                        )

                        HorizontalDivider(color = BorderDivider)

                        ReceiptDetailRow(label = "कारोबार मिति (Date)", value = tx.date)
                        ReceiptDetailRow(label = "भुक्तानी विधि (Payment Mode)", value = tx.paymentMethod.displayName)

                        if (!tx.panVat.isNullOrBlank()) {
                            ReceiptDetailRow(
                                label = "बिक्रेता PAN (Seller PAN)",
                                value = CouponUtils.formatPanNumber(tx.panVat)
                            )
                        }

                        if (!tx.invoiceNumber.isNullOrBlank()) {
                            ReceiptDetailRow(label = "रसिद / बिल # (Invoice #)", value = tx.invoiceNumber)
                        }

                        ReceiptDetailRow(label = "अनुमानित लटरी अवधि (Draw Period)", value = drawPeriodInfo.drawPeriod)

                        if (!tx.notes.isNullOrBlank()) {
                            ReceiptDetailRow(label = "सामान / टिपोट (Notes)", value = tx.notes)
                        }
                    }
                }
            }

            // 2. 12-DIGIT PRIZE COUPON CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (!tx.couponNumber.isNullOrBlank()) TealContainer else StatusPendingBg
                    ),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        1.dp,
                        if (!tx.couponNumber.isNullOrBlank()) Color(0xFF99F6E4) else StatusPendingBorder
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ConfirmationNumber,
                                    contentDescription = null,
                                    tint = if (!tx.couponNumber.isNullOrBlank()) TealAccent else StatusPending,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "१२-अंकको PRIZE COUPON",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }

                            if (tx.couponNumber.isNullOrBlank()) {
                                Button(
                                    onClick = { isLinkCouponDialogOpen = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NavyPrimary,
                                        contentColor = SurfaceCard
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("link_coupon_button")
                                ) {
                                    Text("+ कुपन जोड्नुहोस्", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        if (!tx.couponNumber.isNullOrBlank()) {
                            CouponNumberDisplay(
                                couponNumber = tx.couponNumber,
                                fontSize = 17,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                text = "यो कुपन रसिद खातामा सुरक्षित छ र पाक्षिक लटरी घोषणामा स्वतः जाँचिन्छ ।",
                                fontSize = 11.sp,
                                color = OnTealContainer
                            )
                        } else {
                            Text(
                                text = "यस कारोबारमा कुपन जोडिएको छैन । बिल वा वालेट एपमा प्राप्त १२-अंकको कुपन जोड्न '+ कुपन जोड्नुहोस्' थिच्नुहोस् ।",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // 3. TAX INCENTIVE & VAT REBATE ASSESSMENT
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "कर प्रोत्साहन मूल्यांकन (Tax Incentive Assessment)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )

                        Text(
                            text = evalResult.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        evalResult.reasons.forEach { reason ->
                            Text(
                                text = "• $reason",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Link Coupon Dialog
    if (isLinkCouponDialogOpen) {
        val normalizedInput = CouponUtils.normalizeCouponNumber(couponInput)
        val isInputValid = CouponUtils.isValidCouponNumber(normalizedInput)

        AlertDialog(
            onDismissRequest = { isLinkCouponDialogOpen = false },
            title = { Text("१२-अंकको कुपन जोड्नुहोस्", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "कम्प्युटराइज्ड कर बिजक वा डिजिटल वालेट (eSewa, Khalti) मा प्राप्त १२ अंकको नम्बर प्रविष्ट गर्नुहोस् ।",
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = couponInput,
                        onValueChange = { couponInput = it },
                        label = { Text("१२-Digit Coupon Number") },
                        placeholder = { Text("007 315 254 493") },
                        singleLine = true,
                        supportingText = {
                            Text("${normalizedInput.length}/12 अंक प्रविष्ट गरियो")
                        },
                        modifier = Modifier.testTag("dialog_coupon_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isInputValid) {
                            viewModel.linkCouponToTransaction(tx.id, normalizedInput)
                            isLinkCouponDialogOpen = false
                            couponInput = ""
                            viewModel.showSnackbar("कुपन सफलतापूर्वक जोडियो (Coupon linked)")
                        }
                    },
                    enabled = isInputValid,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("जोड्नुहोस् (Link & Save)")
                }
            },
            dismissButton = {
                TextButton(onClick = { isLinkCouponDialogOpen = false }) {
                    Text("रद्द (Cancel)")
                }
            }
        )
    }

    // Delete Confirmation Dialog
    if (isDeleteDialogOpen) {
        AlertDialog(
            onDismissRequest = { isDeleteDialogOpen = false },
            title = { Text("रसिद मेटाउने हो? (Delete Invoice)", fontWeight = FontWeight.Bold) },
            text = { Text("के तपाईं यो खरिद रसिद फोनबाट हटाउन निश्चित हुनुहुन्छ?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTransaction(tx.id)
                        isDeleteDialogOpen = false
                        viewModel.showSnackbar("रसिद मेटाइयो (Invoice deleted)")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("मेटाउनुहोस् (Delete)")
                }
            },
            dismissButton = {
                TextButton(onClick = { isDeleteDialogOpen = false }) {
                    Text("रद्द (Cancel)")
                }
            }
        )
    }
}

@Composable
private fun ReceiptDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = TextSecondary,
            modifier = Modifier.weight(0.45f)
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            modifier = Modifier.weight(0.55f)
        )
    }
}
