package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.EligibilityStatus
import com.example.data.services.NepaliDateService
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.RasidKhataHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val transactions by viewModel.transactions.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    val draws by viewModel.drawAnnouncements.collectAsState()

    val totalTrackedAmount = remember(transactions) {
        transactions.sumOf { it.amount }
    }

    val awaitingCouponsCount = remember(transactions) {
        transactions.count { it.eligibilityStatus == EligibilityStatus.AWAITING_COUPON }
    }

    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val currentPeriodInfo = remember(todayStr) {
        NepaliDateService.getDrawPeriodInfo(todayStr)
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "Rasid Khata",
                nepaliTitle = "रसिद खाता",
                subtitle = "तपाईंका रसिद, कारोबार र Prize Coupon एकै ठाउँमा",
                rightAction = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.DataBackup) },
                        modifier = Modifier
                            .size(38.dp)
                            .background(SurfaceMuted, shape = RoundedCornerShape(10.dp))
                            .testTag("home_data_backup_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudSync,
                            contentDescription = "Data & Backup",
                            tint = NavyPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. PRIMARY HERO ACTION CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(Screen.AddInvoice) }
                        .testTag("home_primary_add_btn")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    color = Color.White.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "+ नयाँ कारोबार",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = "Quick Entry",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                            Text(
                                text = "कारोबार थप्नुहोस्",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Text(
                                text = "Add purchase bill • रसिद दर्ता तथा लटरी कुपन व्यवस्थापन",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.15f), shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            // FIRST-RUN WELCOME CARD (When no transactions or coupons recorded)
            if (transactions.isEmpty() && coupons.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = NavyContainer,
                                    shape = CircleShape,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.WavingHand,
                                            contentDescription = null,
                                            tint = NavyPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "रसिद खातामा स्वागत छ!",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "Welcome to Rasid Khata • Get Started",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }
                            }

                            Text(
                                text = "कुनै पनि पसलबाट खरिद गर्दा डिजिटल भुक्तानी (QR/Wallet) गरी प्राप्त भएको रसिद वा १२-अंकको Prize Coupon यहाँ दर्ता गर्नुहोस् । पाक्षिक लटरीको नतिजा आउँदा १-ट्यापमा विजेता जाँच्न सकिनेछ ।",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.navigateTo(Screen.AddInvoice) },
                                    border = BorderStroke(1.dp, NavyPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("+ रसिद थप्नुहोस्", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.navigateTo(Screen.AddCoupon) },
                                    border = BorderStroke(1.dp, TealAccent),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("+ कुपन थप्नुहोस्", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TealAccent)
                                }
                            }
                        }
                    }
                }
            }

            // 2. MY IRD TRACKING SUMMARY (४ मुख्य सूचकहरू)
            item {
                SectionHeader(
                    nepaliTitle = "मेरो IRD ट्र्याकिङ",
                    englishTitle = "My Tracking Metrics"
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCompactCard(
                        labelNp = "कुपनहरू",
                        labelEn = "Prize Coupons",
                        value = "${coupons.size}",
                        icon = Icons.Default.ConfirmationNumber,
                        accentColor = NavyPrimary,
                        onClick = { viewModel.navigateTo(Screen.Coupons) },
                        modifier = Modifier.weight(1f),
                        testTag = "metric_coupons"
                    )
                    MetricCompactCard(
                        labelNp = "कुपन पर्खिएको",
                        labelEn = "Awaiting Coupon",
                        value = "$awaitingCouponsCount",
                        icon = Icons.Default.HourglassTop,
                        accentColor = if (awaitingCouponsCount > 0) StatusPending else TextSecondary,
                        onClick = { viewModel.navigateTo(Screen.Invoices) },
                        modifier = Modifier.weight(1f),
                        testTag = "metric_awaiting"
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCompactCard(
                        labelNp = "दर्ता रसिद रकम",
                        labelEn = "Tracked Bills",
                        value = "NPR ${String.format(Locale.US, "%,.0f", totalTrackedAmount)}",
                        icon = Icons.Default.ReceiptLong,
                        accentColor = TealAccent,
                        onClick = { viewModel.navigateTo(Screen.Invoices) },
                        modifier = Modifier.weight(1f),
                        testTag = "metric_bills"
                    )
                    MetricCompactCard(
                        labelNp = "जाँचिएका नतिजा",
                        labelEn = "Draws Checked",
                        value = "${draws.size} Draws",
                        icon = Icons.Default.EmojiEvents,
                        accentColor = GoldWinner,
                        onClick = { viewModel.navigateTo(Screen.WinnerChecker) },
                        modifier = Modifier.weight(1f),
                        testTag = "metric_draws"
                    )
                }
            }

            // 3. QUICK ACTIONS GRID
            item {
                SectionHeader(
                    nepaliTitle = "छरितो कार्यहरू",
                    englishTitle = "Quick Actions"
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionTile(
                        nepaliLabel = "कुपन सूची",
                        englishLabel = "My Coupons",
                        icon = Icons.Default.ConfirmationNumber,
                        accentColor = NavyPrimary,
                        onClick = { viewModel.navigateTo(Screen.Coupons) },
                        modifier = Modifier.weight(1f),
                        testTag = "quick_coupons"
                    )
                    QuickActionTile(
                        nepaliLabel = "नतिजा जाँच",
                        englishLabel = "Check Winner",
                        icon = Icons.Default.EmojiEvents,
                        accentColor = GoldWinner,
                        onClick = { viewModel.navigateTo(Screen.WinnerChecker) },
                        modifier = Modifier.weight(1f),
                        testTag = "quick_winner"
                    )
                    QuickActionTile(
                        nepaliLabel = "योग्यता क्यालकुलेटर",
                        englishLabel = "Eligibility",
                        icon = Icons.Default.FactCheck,
                        accentColor = TealAccent,
                        onClick = { viewModel.navigateTo(Screen.CheckEligibility) },
                        modifier = Modifier.weight(1f),
                        testTag = "quick_eligibility"
                    )
                }
            }

            // 4. CURRENT DRAW / STATUS CARD
            item {
                SectionHeader(
                    nepaliTitle = "चालू पाक्षिक गोलाप्रथा",
                    englishTitle = "Current Draw Cycle",
                    actionLabel = "सबै हेर्नुहोस् (All Draws)",
                    onAction = { viewModel.navigateTo(Screen.DrawHistory) }
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(StatusSuccess, shape = CircleShape)
                                )
                                Text(
                                    text = "चालू अवधि (Active Period)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }
                            Surface(
                                color = NavyContainer,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = currentPeriodInfo.drawPeriod,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyPrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "नतिजा प्रकाशन अनुमानित मिति:",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                                Text(
                                    text = currentPeriodInfo.expectedAnnouncement,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }

                            Button(
                                onClick = { viewModel.navigateTo(Screen.WinnerChecker) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GoldWinner,
                                    contentColor = SurfaceCard
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        text = "नतिजा हेर्नुहोस्",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 5. EDUCATIONAL 5-STEP SECTION (How IRD Scheme Works)
            item {
                SectionHeader(
                    nepaliTitle = "यसले कसरी काम गर्छ?",
                    englishTitle = "How IRD Scheme Works",
                    actionLabel = "विस्तृत नियम (Full Guide)",
                    onAction = { viewModel.navigateTo(Screen.IRDInfo) }
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StepItemRow(
                            stepNumber = "१",
                            icon = Icons.Default.ShoppingCart,
                            titleNp = "वस्तु वा सेवा खरिद गर्नुहोस्",
                            titleEn = "1. Buy from PAN/VAT registered seller"
                        )
                        StepItemRow(
                            stepNumber = "२",
                            icon = Icons.Default.QrCodeScanner,
                            titleNp = "QR वा डिजिटल वालेटबाट भुक्तानी गर्नुहोस्",
                            titleEn = "2. Pay digitally (QR, Wallet, Card, e-Banking)"
                        )
                        StepItemRow(
                            stepNumber = "३",
                            icon = Icons.Default.ConfirmationNumber,
                            titleNp = "१२ अंकको Prize Coupon प्राप्त गर्नुहोस्",
                            titleEn = "3. Get 12-digit Coupon on invoice/app"
                        )
                        StepItemRow(
                            stepNumber = "४",
                            icon = Icons.Default.Event,
                            titleNp = "आन्तरिक राजस्व विभागको पाक्षिक लटरी",
                            titleEn = "4. IRD fortnightly lottery draw"
                        )
                        StepItemRow(
                            stepNumber = "५",
                            icon = Icons.Default.CheckCircle,
                            titleNp = "रसिद खातामा १-ट्यापमा नतिजा जाँच्नुहोस्",
                            titleEn = "5. Instant 1-tap winner verification"
                        )
                    }
                }
            }

            // 6. DISCLAIMER BANNER
            item {
                DisclaimerBanner()
            }
        }
    }
}

@Composable
private fun MetricCompactCard(
    labelNp: String,
    labelEn: String,
    value: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = labelNp,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }

            Text(
                text = value,
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )

            Text(
                text = labelEn,
                fontSize = 9.sp,
                color = TextMuted
            )
        }
    }
}

@Composable
private fun QuickActionTile(
    nepaliLabel: String,
    englishLabel: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(accentColor.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = nepaliLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = englishLabel,
                    fontSize = 9.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun StepItemRow(
    stepNumber: String,
    icon: ImageVector,
    titleNp: String,
    titleEn: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(NavyContainer, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNumber,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
        }

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(
                text = titleNp,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Text(
                text = titleEn,
                fontSize = 10.sp,
                color = TextSecondary
            )
        }
    }
}
