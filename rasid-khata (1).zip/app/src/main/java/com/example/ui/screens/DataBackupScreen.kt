package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RasidKhataViewModel
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.RasidKhataHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun DataBackupScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val transactions by viewModel.transactions.collectAsState()
    val coupons by viewModel.coupons.collectAsState()

    var jsonRestoreText by remember { mutableStateOf("") }
    var isResetDialogOpen by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "डेटा ब्याकअप तथा रिस्टोर",
                subtitle = "Data Backup, CSV Export & Offline Storage",
                showBack = true,
                onBack = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. DATA SUMMARY CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "स्थानीय भण्डारण स्थिति (Offline Local Storage)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "सबै कारोबार र कुपन तपाईंको आफ्नै फोनमा १००% सुरक्षित छन् । कुनै बाह्य सर्भरमा डेटा पठाइँदैन ।",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            DataMetricPill(
                                label = "रसिदहरू",
                                count = transactions.size,
                                modifier = Modifier.weight(1f)
                            )
                            DataMetricPill(
                                label = "कुपनहरू",
                                count = coupons.size,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 2. JSON BACKUP EXPORT
            item {
                SectionHeader(
                    nepaliTitle = "JSON ब्याकअप प्रतिलिपि",
                    englishTitle = "JSON Backup Export"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "फोन परिवर्तन गर्दा वा सुरक्षित राख्न सम्पूर्ण डेटा JSON फर्म्याटमा कपी गर्नुहोस्:",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        Button(
                            onClick = {
                                val json = viewModel.exportBackupJson()
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("RasidKhata Backup", json))
                                viewModel.showSnackbar("ब्याकअप JSON कपी गरियो (JSON Copied)")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_export_json")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null)
                                Text("JSON ब्याकअप कपी गर्नुहोस् (Copy JSON Backup)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 3. RESTORE FROM JSON
            item {
                SectionHeader(
                    nepaliTitle = "JSON ब्याकअपबाट रिस्टोर",
                    englishTitle = "Restore from JSON"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "पहिले सुरक्षित गरिएको JSON ब्याकअप यहाँ पेस्ट गर्नुहोस्:",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        OutlinedTextField(
                            value = jsonRestoreText,
                            onValueChange = { jsonRestoreText = it },
                            placeholder = { Text("{\"version\":1,\"transactions\":[...],\"coupons\":[...]}", fontSize = 11.sp) },
                            minLines = 3,
                            maxLines = 6,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("restore_json_input")
                        )

                        Button(
                            onClick = {
                                if (jsonRestoreText.isNotBlank()) {
                                    val success = viewModel.restoreBackupJson(jsonRestoreText, "merge")
                                    if (success) {
                                        jsonRestoreText = ""
                                    }
                                }
                            },
                            enabled = jsonRestoreText.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_confirm_restore")
                        ) {
                            Text("डेटा रिस्टोर गर्नुहोस् (Restore Data)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 4. CSV EXPORT
            item {
                SectionHeader(
                    nepaliTitle = "एक्सेल / CSV प्रतिलिपि",
                    englishTitle = "CSV / Excel Export"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val csv = viewModel.exportInvoicesCsv()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Invoices CSV", csv))
                                    viewModel.showSnackbar("रसिद CSV कपी गरियो (Invoices CSV Copied)")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyContainer, contentColor = NavyPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_export_invoices_csv")
                            ) {
                                Text("रसिद CSV", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    val csv = viewModel.exportCouponsCsv()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Coupons CSV", csv))
                                    viewModel.showSnackbar("कुपन CSV कपी गरियो (Coupons CSV Copied)")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyContainer, contentColor = NavyPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_export_coupons_csv")
                            ) {
                                Text("कुपन CSV", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 5. TESTING TOOLS (DEMO DATA)
            item {
                SectionHeader(
                    nepaliTitle = "परीक्षण उपकरणहरू",
                    englishTitle = "Testing Tools"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WarningAmber,
                                    contentDescription = null,
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(18.dp)
                                )
                                Column {
                                    Text(
                                        text = "डेमो डेटा — आधिकारिक IRD रेकर्ड होइन",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF92400E)
                                    )
                                    Text(
                                        text = "Demo data for testing features — not actual government records",
                                        fontSize = 10.sp,
                                        color = Color(0xFFB45309)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "एपका सुविधाहरू (विजेता जाँच, लटरी कुपन, दाबी कागजात) परीक्षण गर्न नमुना डेटा लोड गर्न सक्नुहुन्छ:",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        OutlinedButton(
                            onClick = {
                                viewModel.loadDemoData()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = NavyPrimary
                            ),
                            border = BorderStroke(1.5.dp, NavyPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_load_demo_data")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("परीक्षण नमुना डेटा लोड गर्नुहोस् (Load Sample Data)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 6. RESET / DANGER ZONE
            item {
                SectionHeader(
                    nepaliTitle = "डेटा खाली गर्ने (Clear Data)",
                    englishTitle = "Danger Zone"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusErrorBg),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, StatusErrorBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "सबै स्थानीय रसिद, कुपन र नतिजा डेटा फोनबाट स्थायी रूपमा हटाउन:",
                            fontSize = 11.sp,
                            color = StatusError
                        )

                        Button(
                            onClick = { isResetDialogOpen = true },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_reset_all_data")
                        ) {
                            Text("सबै डेटा खाली गर्नुहोस् (Clear All Data)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // DISCLAIMER
            item {
                DisclaimerBanner()
            }
        }
    }

    // Reset Confirmation Dialog
    if (isResetDialogOpen) {
        AlertDialog(
            onDismissRequest = { isResetDialogOpen = false },
            title = { Text("सबै डेटा खाली गर्ने हो? (Clear All Data)", fontWeight = FontWeight.Bold) },
            text = {
                Text("के तपाईं फोनमा सुरक्षित सबै रसिद र कुपन डेटा हटाउन निश्चित हुनुहुन्छ? यो प्रक्रिया उल्टाउन सकिँदैन ।")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetToEmpty()
                        isResetDialogOpen = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("निश्चित हटाउनुहोस् (Clear All)")
                }
            },
            dismissButton = {
                TextButton(onClick = { isResetDialogOpen = false }) {
                    Text("रद्द (Cancel)")
                }
            }
        )
    }
}

@Composable
private fun DataMetricPill(
    label: String,
    count: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SurfaceMuted,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontSize = 12.sp, color = TextSecondary)
            Text(text = "$count", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
        }
    }
}
