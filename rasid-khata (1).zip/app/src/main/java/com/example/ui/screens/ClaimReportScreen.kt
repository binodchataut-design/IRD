package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ClaimReportData
import com.example.ui.RasidKhataViewModel
import com.example.ui.components.CouponNumberDisplay
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.RasidKhataHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun ClaimReportScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val claimData by viewModel.activeClaimReport.collectAsState()

    val dossierText = remember(claimData) {
        val coupon = claimData?.matchedCoupon?.couponNumber ?: "N/A"
        val draw = claimData?.drawTitle ?: "IRD Lottery Draw"
        val period = claimData?.drawPeriod ?: "Current Cycle"
        val date = claimData?.announcementDate ?: "N/A"
        val merchant = claimData?.matchedCoupon?.merchantName ?: "N/A"

        """
        ==================================================
        आन्तरिक राजस्व विभाग (IRD) उपभोक्ता पुरस्कार दाबी विवरण
        OFFICIAL IRD PRIZE CLAIM DOSSIER - RASID KHATA
        ==================================================
        
        १. विजेता कुपन नम्बर (Winning Coupon): $coupon
        २. गोलाप्रथा शीर्षक (Draw Title): $draw
        ३. लटरी अवधि (Draw Period): $period
        ४. नतिजा प्रकाशन मिति (Date): $date
        ५. बिक्रेता / पसल (Merchant): $merchant
        
        दाबी गर्दा आवश्यक कागजातहरू (Required Documents):
        --------------------------------------------------
        [ ] १. सक्कल कर बिजक वा डिजिटल रसिद (Original Invoice / Receipt)
        [ ] २. डिजिटल भुक्तानीको प्रमाण (Payment Transaction Reference)
        [ ] ३. नेपाली नागरिकताको प्रमाणपत्रको प्रतिलिपि (Citizenship Copy)
        [ ] ४. व्यक्तिगत स्थायी लेखा नम्बर (Personal PAN Card Copy)
        [ ] ५. बैंक खाताको चेक प्रतिलिपि (Bank Account Cheque Copy)
        
        वैधानिक म्याद (Statutory Deadline):
        लटरी नतिजा प्रकाशित भएको मितिले १५ दिनभित्र नजिकको आन्तरिक राजस्व कार्यालय (IRO)
        वा करदाता सेवा कार्यालय (TSO) मा दाबी पेस गर्नुपर्नेछ ।
        ==================================================
        """.trimIndent()
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "दाबी तयारी कागजात",
                subtitle = "Official IRD Prize Claim Dossier",
                showBack = true,
                onBack = { viewModel.navigateBack() },
                rightAction = {
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Claim Dossier", dossierText))
                            viewModel.showSnackbar("दाबी विवरण प्रतिलिपि गरियो (Dossier copied)")
                        },
                        modifier = Modifier.testTag("btn_copy_dossier")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Dossier",
                            tint = NavyPrimary
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. STATUTORY DEADLINE WARNING CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, StatusPendingBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassBottom,
                            contentDescription = null,
                            tint = StatusPending,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "१५ दिनभित्र दाबी गर्नुपर्ने वैधानिक म्याद (15-Day Deadline)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusPending
                            )
                            Text(
                                text = "लटरी नतिजा सार्वजनिक भएको मितिले १५ दिनभित्र सक्कल रसिद वा डिजिटल बिजक र आफ्नो नागरिकता/प्यान लिई सम्बन्धित करदाता सेवा कार्यालय (TSO) वा आन्तरिक राजस्व कार्यालय (IRO) मा दाबी पेस गर्नुपर्छ ।",
                                fontSize = 11.sp,
                                color = TextPrimary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            // 2. MATCHED COUPON DETAILS
            if (claimData != null) {
                val data = claimData!!
                item {
                    SectionHeader(
                        nepaliTitle = "विजेता कुपन विवरण",
                        englishTitle = "Winning Coupon Details"
                    )
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, GoldWinner),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = data.drawTitle,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = OnGoldWinner
                            )
                            Text(
                                text = "अवधि: ${data.drawPeriod} • मिति: ${data.announcementDate}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )

                            CouponNumberDisplay(
                                couponNumber = data.matchedCoupon.couponNumber,
                                fontSize = 16,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // 3. REQUIRED DOCUMENTS CHECKLIST
            item {
                SectionHeader(
                    nepaliTitle = "दाबी गर्दा आवश्यक पर्ने कागजातहरू",
                    englishTitle = "Required Documents Checklist"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ChecklistRow("१. सक्कल कर बिजक वा डिजिटल रसिद (Original Invoice / Digital Receipt)")
                        ChecklistRow("२. डिजिटल भुक्तानीको प्रमाण वा स्टेटमेन्ट (Payment Reference / Statement)")
                        ChecklistRow("३. नेपाली नागरिकताको प्रमाणपत्रको प्रतिलिपि (Citizenship Copy)")
                        ChecklistRow("४. व्यक्तिगत स्थायी लेखा नम्बर (Personal PAN Card Copy)")
                        ChecklistRow("५. बैंक खाताको चेक प्रतिलिपि (Bank Account Cheque Copy)")
                    }
                }
            }

            // 4. OFFICIAL PROCESS STEPS
            item {
                SectionHeader(
                    nepaliTitle = "दाबी प्रक्रिया (Official Claim Steps)",
                    englishTitle = "How to Claim at IRD"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "१. आधिकारिक IRD वेबसाइट (ird.gov.np) मा प्रकाशित सूचनामा आफ्नो कुपन पुनः रुजु गर्नुहोस् ।",
                            fontSize = 11.sp,
                            color = TextPrimary,
                            lineHeight = 16.sp
                        )
                        Text(
                            text = "२. माथि उल्लिखित कागजात तयार गरी नजिकको आन्तरिक राजस्व कार्यालय (IRO) वा करदाता सेवा कार्यालय (TSO) जानुहोस् ।",
                            fontSize = 11.sp,
                            color = TextPrimary,
                            lineHeight = 16.sp
                        )
                        Text(
                            text = "३. कार्यालयमा उपभोक्ता प्रोत्साहन दाबी फाराम भरी दाखिला गर्नुहोस् ।",
                            fontSize = 11.sp,
                            color = TextPrimary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // 5. COPY ACTION
            item {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Claim Dossier", dossierText))
                        viewModel.showSnackbar("दाबी विवरण प्रतिलिपि गरियो (Dossier copied)")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null)
                        Text(
                            text = "दाबी विवरण कपी गर्नुहोस् (Copy Full Dossier)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // DISCLAIMER
            item {
                DisclaimerBanner()
            }
        }
    }
}

@Composable
private fun ChecklistRow(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = StatusSuccess,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = text,
            fontSize = 11.sp,
            color = TextPrimary,
            modifier = Modifier.weight(1f)
        )
    }
}
