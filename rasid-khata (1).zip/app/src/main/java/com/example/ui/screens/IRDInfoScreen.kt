package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.RasidKhataHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun IRDInfoScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = "कानूनी प्रावधान तथा निर्देशिका",
                subtitle = "IRD Tax Incentive Rules & Guidelines",
                rightAction = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.DataBackup) },
                        modifier = Modifier.testTag("info_backup_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudSync,
                            contentDescription = "Data & Backup",
                            tint = NavyPrimary
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. IRD CONSUMER INCENTIVE SCHEME OVERVIEW CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Gavel,
                                contentDescription = null,
                                tint = NavyPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "आन्तरिक राजस्व विभाग — विद्युतीय बिलिङ तथा लटरी योजना",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Text(
                            text = "नेपाल सरकार तथा आन्तरिक राजस्व विभागले विद्युतीय भुक्तानी (QR, कार्ड, वालेट) मार्फत खरिद गर्ने करदाता तथा उपभोक्तालाई प्रोत्साहन गर्न १२-अंकको लटरी कुपन जारी गरी पाक्षिक गोलाप्रथा पुरस्कार योजना सञ्चालन गर्दै आएको छ ।",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            // 2. ELIGIBILITY CRITERIA
            item {
                SectionHeader(
                    nepaliTitle = "लटरी कुपन तथा सहभागिताका मुख्य सर्तहरू",
                    englishTitle = "Lottery Coupon Conditions"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ConditionItem("१. न्यूनतम खरिद रकम रु. १०० वा सोभन्दा माथि हुनुपर्छ ।")
                        ConditionItem("२. भुक्तानी विद्युतीय माध्यम (QR, वालेट, कार्ड वा अनलाइन) बाट हुनुपर्छ ।")
                        ConditionItem("३. बिक्रेता आन्तरिक राजस्व विभागको कम्प्युटराइज्ड बिलिङ प्रणालीमा आबद्ध हुनुपर्छ ।")
                        ConditionItem("४. खरिद व्यक्तिगत तथा अन्तिम उपभोगका लागि हुनुपर्छ ।")
                        ConditionItem("५. नगद भुक्तानीमा यो सुविधा प्राप्त हुँदैन ।")
                    }
                }
            }

            // 3. PRIZE LOTTERY TIERS
            item {
                SectionHeader(
                    nepaliTitle = "पाक्षिक गोलाप्रथा पुरस्कार संरचना",
                    englishTitle = "Prize Structure"
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PrizeRow(tier = "प्रथम पुरस्कार (First Prize)", amount = "रु. ५०,०००")
                        PrizeRow(tier = "दोस्रो पुरस्कार (Second Prize)", amount = "रु. ३०,०००")
                        PrizeRow(tier = "तेस्रो पुरस्कार (Third Prize)", amount = "रु. २०,०००")
                        PrizeRow(tier = "सान्त्वना पुरस्कार (Consolation)", amount = "रु. ५,००० (१० जना)")
                    }
                }
            }

            // 4. ACTION BUTTON TO ELIGIBILITY SIMULATOR
            item {
                Button(
                    onClick = { viewModel.navigateTo(Screen.CheckEligibility) },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "✓ योग्यता क्यालकुलेटर चलाउनुहोस् (Check Eligibility)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // 5. DISCLAIMER
            item {
                DisclaimerBanner()
            }
        }
    }
}

@Composable
private fun ConditionItem(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = null,
            tint = TealAccent,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = text,
            fontSize = 12.sp,
            color = TextPrimary,
            lineHeight = 16.sp
        )
    }
}

@Composable
private fun PrizeRow(tier: String, amount: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = tier, fontSize = 12.sp, color = TextPrimary)
        Text(text = amount, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = GoldWinner)
    }
}
