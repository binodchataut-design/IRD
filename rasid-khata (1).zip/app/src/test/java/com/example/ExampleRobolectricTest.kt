package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.models.EligibilityStatus
import com.example.data.models.PaymentMethod
import com.example.data.models.PurchasePurpose
import com.example.data.models.SellerPanOption
import com.example.data.models.TransactionCategory
import com.example.data.models.TransactionEligibilityInput
import com.example.data.services.EligibilityService
import com.example.data.utils.CouponUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Rasid Khata", appName)
  }

  @Test
  fun `coupon normalization and formatting`() {
    val raw = "007-315 254-493"
    val normalized = CouponUtils.normalizeCouponNumber(raw)
    assertEquals("007315254493", normalized)
    assertTrue(CouponUtils.isValidCouponNumber(normalized))

    val formatted = CouponUtils.formatCouponNumber(normalized)
    assertEquals("007 315 254 493", formatted)
  }

  @Test
  fun `eligibility calculation for digital personal purchase`() {
    val input = TransactionEligibilityInput(
      amount = 1500.0,
      paymentMethod = PaymentMethod.DIGITAL_WALLET,
      purpose = PurchasePurpose.PERSONAL,
      sellerPan = SellerPanOption.YES,
      sellerPanNumber = "601928374",
      sellerName = "Bhatbhateni Supermarket",
      category = TransactionCategory.NORMAL_GOODS
    )
    val result = EligibilityService.checkEligibility(input)
    assertEquals(EligibilityStatus.LIKELY_ELIGIBLE, result.status)
    assertTrue(result.reasons.isNotEmpty())
  }
}
