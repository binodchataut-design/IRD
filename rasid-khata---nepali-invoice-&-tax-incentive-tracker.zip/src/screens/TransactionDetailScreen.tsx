import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Calendar, 
  Store, 
  Hash, 
  Receipt, 
  CreditCard, 
  FileText, 
  Image as ImageIcon, 
  Trash2,
  AlertTriangle,
  Sparkles,
  Ticket,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink
} from 'lucide-react';
import { ScreenName, EligibilityStatus } from '../types/transaction';
import { transactionService } from '../services/transactionService';
import { nepaliDateService } from '../services/nepaliDateService';
import { TrustBanner } from '../components/common/TrustBanner';

interface TransactionDetailScreenProps {
  transactionId?: string;
  onBack: () => void;
  onNavigate: (
    screen: ScreenName, 
    params?: { 
      transactionId?: string;
      prefillCoupon?: {
        merchantName?: string;
        amount?: number;
        date?: string;
        paymentMethod?: string;
        invoiceNumber?: string;
        fromTransactionId?: string;
      };
    }
  ) => void;
}

export const TransactionDetailScreen: React.FC<TransactionDetailScreenProps> = ({
  transactionId,
  onBack,
  onNavigate,
}) => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const transaction = transactionId ? transactionService.getById(transactionId) : undefined;

  if (!transaction) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-lg mx-auto w-full space-y-4">
        <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
          <Receipt className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-base font-bold text-slate-800">Transaction Not Found</h2>
          <p className="text-xs text-slate-500 mt-1">
            The requested transaction record could not be loaded.
          </p>
        </div>
        <button
          onClick={onBack}
          className="bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm"
        >
          Return to My Transactions
        </button>
      </div>
    );
  }

  const handleDelete = () => {
    transactionService.delete(transaction.id);
    onBack();
  };

  const formatAmount = (num: number) => {
    if (typeof num !== 'number' || isNaN(num) || !isFinite(num)) {
      return '0.00';
    }
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 2,
      minimumFractionDigits: 0
    }).format(num);
  };

  const panValue = transaction.panVat || transaction.sellerPanVat;
  const photoValue = transaction.photoReference || transaction.invoicePhotoUrl;
  const sellerDisplayName = transaction.sellerName || 'Unnamed Merchant';
  const drawInfo = nepaliDateService.getDrawPeriodInfo(transaction.date);

  const getStatusBadge = (status?: EligibilityStatus, couponNumber?: string) => {
    if (couponNumber || status === 'coupon_added') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded">
          <Ticket className="w-3 h-3" />
          Prize Coupon Linked
        </span>
      );
    }
    if (status === 'awaiting_coupon') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded">
          <AlertTriangle className="w-3 h-3 text-amber-600" />
          Awaiting 12-Digit Coupon
        </span>
      );
    }
    if (status === 'likely_eligible') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded">
          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
          Likely Eligible
        </span>
      );
    }
    if (status === 'likely_not_eligible') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200 px-2 py-0.5 rounded">
          <XCircle className="w-3 h-3 text-rose-600" />
          Likely Not Eligible
        </span>
      );
    }
    if (status === 'needs_verification') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded">
          <AlertTriangle className="w-3 h-3 text-amber-600" />
          Needs Verification
        </span>
      );
    }
    return (
      <span className="text-[10px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
        Eligibility Not Checked
      </span>
    );
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-14">
      {/* Explicit Label: User-entered Saved Information */}
      <TrustBanner 
        type="user-data" 
        text="This is your personal saved record on this device. It has not been verified with government tax authorities."
      />

      {/* Main Card: Amount & Seller */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Purchase Amount
            </span>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">
              रू {formatAmount(transaction.amount)}
            </div>
          </div>

          <div className="bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded text-xs font-semibold text-emerald-800 text-right">
            {transaction.paymentMethod}
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-start gap-2">
          <Store className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <span className="text-xs font-bold text-slate-900 break-words leading-relaxed">
            {sellerDisplayName}
          </span>
        </div>
      </div>

      {/* IRD ELIGIBILITY & INCENTIVE TRACKING CARD */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Tax Incentive Status
            </h3>
          </div>
          {getStatusBadge(transaction.eligibilityStatus, transaction.couponNumber)}
        </div>

        {/* Coupon Number Details if Linked */}
        {transaction.couponNumber ? (
          <div className="p-3 bg-emerald-50/80 border border-emerald-200 rounded-lg space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-emerald-900 uppercase">Prize Coupon #</span>
              <span className="text-xs font-mono font-bold text-emerald-950 bg-white px-2 py-0.5 rounded border border-emerald-300">
                {transaction.couponNumber}
              </span>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('winner_checker')}
              className="w-full py-1.5 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold flex items-center justify-center gap-1 transition-colors"
            >
              <span>Check for Winning Draws</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {transaction.eligibilityStatus === 'awaiting_coupon' && (
              <p className="text-xs text-amber-800 bg-amber-50 p-2.5 rounded-lg border border-amber-200 leading-relaxed">
                ⏳ This purchase appears eligible. Please check your payment app (eSewa, Khalti, Fonepay) for the 12-digit prize coupon number.
              </p>
            )}

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                id="btn-detail-add-coupon"
                onClick={() => onNavigate('add_coupon', {
                  prefillCoupon: {
                    merchantName: transaction.sellerName,
                    amount: transaction.amount,
                    date: transaction.date,
                    paymentMethod: transaction.paymentMethod,
                    invoiceNumber: transaction.invoiceNumber,
                    fromTransactionId: transaction.id,
                  }
                })}
                className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
              >
                <Ticket className="w-3.5 h-3.5" />
                <span>Add 12-Digit Coupon</span>
              </button>

              <button
                type="button"
                id="btn-detail-recheck-elig"
                onClick={() => onNavigate('check_eligibility')}
                className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold border border-slate-300 transition-colors"
              >
                <span>Check Eligibility</span>
              </button>
            </div>
          </div>
        )}

        {/* Estimated Draw Period */}
        <div className="pt-2 border-t border-slate-100 text-xs text-slate-600 flex items-center justify-between">
          <span className="flex items-center gap-1 text-slate-500">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>Draw Period:</span>
          </span>
          <span className="font-semibold text-slate-800">{drawInfo.drawPeriod}</span>
        </div>
      </div>

      {/* Structured Details Breakdown */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
        <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Transaction Details
        </h3>

        <div className="divide-y divide-slate-100 text-xs">
          {/* Seller / Merchant Name */}
          <div className="py-2.5 flex items-start justify-between gap-3">
            <span className="text-slate-500 flex items-center gap-2 shrink-0">
              <Store className="w-3.5 h-3.5 text-slate-400" />
              Seller / Merchant
            </span>
            <span className="font-semibold text-slate-800 text-right break-words max-w-[65%]">
              {sellerDisplayName}
            </span>
          </div>

          {/* Date */}
          <div className="py-2.5 flex items-center justify-between">
            <span className="text-slate-500 flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              Date
            </span>
            <span className="font-semibold text-slate-800">
              {transaction.date}
            </span>
          </div>

          {/* Seller PAN/VAT */}
          <div className="py-2.5 flex items-center justify-between">
            <span className="text-slate-500 flex items-center gap-2">
              <Hash className="w-3.5 h-3.5 text-slate-400" />
              Seller PAN / VAT
            </span>
            <span className="font-mono font-semibold text-slate-800">
              {panValue || <span className="text-slate-400 font-normal italic">Not recorded</span>}
            </span>
          </div>

          {/* Invoice Number */}
          <div className="py-2.5 flex items-center justify-between">
            <span className="text-slate-500 flex items-center gap-2">
              <Receipt className="w-3.5 h-3.5 text-slate-400" />
              Invoice / Bill Number
            </span>
            <span className="font-semibold text-slate-800 font-mono">
              {transaction.invoiceNumber || <span className="text-slate-400 font-normal italic">Not recorded</span>}
            </span>
          </div>

          {/* Payment Method */}
          <div className="py-2.5 flex items-center justify-between">
            <span className="text-slate-500 flex items-center gap-2">
              <CreditCard className="w-3.5 h-3.5 text-slate-400" />
              Payment Mode
            </span>
            <span className="font-semibold text-slate-800">
              {transaction.paymentMethod}
            </span>
          </div>

          {/* Notes */}
          <div className="py-2.5 space-y-1">
            <span className="text-slate-500 flex items-center gap-2">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              Notes & Remarks
            </span>
            <p className="text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs leading-relaxed break-words">
              {transaction.notes || <span className="text-slate-400 italic">No notes added for this transaction.</span>}
            </p>
          </div>
        </div>
      </div>

      {/* Invoice Photo Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Invoice Photo
          </h3>
          {photoValue ? (
            <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
              Photo Attached
            </span>
          ) : (
            <span className="text-[10px] text-slate-400">
              No photo
            </span>
          )}
        </div>

        {photoValue ? (
          <div className="rounded-lg overflow-hidden border border-slate-200 bg-slate-900 shadow-xs">
            <img
              src={photoValue}
              alt={`Invoice for ${sellerDisplayName}`}
              className="w-full max-h-64 object-contain bg-slate-950"
              referrerPolicy="no-referrer"
            />
            <div className="p-2 bg-slate-900 text-slate-300 text-[10px] flex items-center justify-between">
              <span>Saved purchase invoice slip</span>
            </div>
          </div>
        ) : (
          <div className="border border-dashed border-slate-200 rounded-lg p-5 text-center space-y-1 bg-slate-50/50">
            <ImageIcon className="w-5 h-5 text-slate-400 mx-auto mb-1" />
            <p className="text-xs font-semibold text-slate-700">No invoice image attached</p>
            <p className="text-[10px] text-slate-400">
              You can attach a bill photo next time when adding a transaction.
            </p>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal / Inline Sheet */}
      {showDeleteConfirm && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 space-y-3">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-red-900">Delete this transaction?</h4>
              <p className="text-[11px] text-red-700 mt-0.5">
                This will permanently remove this record from your local device storage.
              </p>
            </div>
          </div>
          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              onClick={() => setShowDeleteConfirm(false)}
              className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg"
            >
              Cancel
            </button>
            <button
              id="btn-confirm-delete-tx"
              onClick={handleDelete}
              className="px-3 py-1.5 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white text-xs font-semibold rounded-lg shadow-xs"
            >
              Confirm Delete
            </button>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="space-y-2 pt-1">
        {!showDeleteConfirm && (
          <button
            id="btn-delete-transaction"
            onClick={() => setShowDeleteConfirm(true)}
            className="w-full border border-red-200 bg-red-50/50 hover:bg-red-50 active:bg-red-100 text-red-700 font-semibold py-2.5 rounded-lg text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5 text-red-600" />
            <span>Delete Transaction Record</span>
          </button>
        )}

        <button
          id="btn-back-to-transactions"
          onClick={onBack}
          className="w-full border border-slate-200 hover:bg-slate-50 active:bg-slate-100 text-slate-700 font-semibold py-2.5 rounded-lg text-xs flex items-center justify-center gap-1.5 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to My Transactions</span>
        </button>
      </div>
    </div>
  );
};

