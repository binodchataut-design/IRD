import React from 'react';
import { 
  Printer, 
  ArrowLeft, 
  ShieldAlert, 
  CheckCircle2, 
  Receipt, 
  Building2, 
  Calendar, 
  ExternalLink, 
  AlertCircle,
  FileCheck,
  CreditCard
} from 'lucide-react';
import { ClaimReportData, ScreenName } from '../types/transaction';
import { formatCouponNumber } from '../utils/couponUtils';

interface ClaimReportScreenProps {
  reportData: ClaimReportData | null;
  onBack: () => void;
  onNavigate: (screen: ScreenName) => void;
}

export const ClaimReportScreen: React.FC<ClaimReportScreenProps> = ({
  reportData,
  onBack,
  onNavigate,
}) => {
  if (!reportData) {
    return (
      <div className="p-6 text-center">
        <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-3" />
        <h2 className="text-base font-bold text-slate-800">No Claim Report Selected</h2>
        <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
          Please run a Winner Check or select a matched winning coupon to view its claim dossier.
        </p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold hover:bg-emerald-700"
        >
          Back to Winner Checker
        </button>
      </div>
    );
  }

  const { matchedCoupon, matchedWinningNumber, drawTitle, drawPeriod, announcementDate, associatedTransaction } = reportData;
  const formattedCoupon = formatCouponNumber(matchedCoupon.couponNumber);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 sm:p-6 space-y-5 print:p-0 print:m-0 print:space-y-4">
      {/* Screen Toolbar (hidden in print) */}
      <div className="flex items-center justify-between gap-3 print:hidden">
        <button
          id="claim-report-back-btn"
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3 py-2 rounded-lg shadow-2xs hover:bg-slate-50 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            id="print-claim-report-btn"
            onClick={handlePrint}
            className="flex items-center gap-1.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 px-4 py-2 rounded-lg shadow-xs transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-7 shadow-xs print:border-none print:shadow-none print:p-0">
        {/* Document Header */}
        <div className="border-b border-slate-200 pb-5 mb-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-md bg-emerald-700 text-white flex items-center justify-center font-bold text-xs">
                  र
                </span>
                <span className="text-xs font-bold tracking-wider text-emerald-800 uppercase">
                  Rasid Khata • रसिद खाता
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 mt-1.5">
                Prize Coupon Claim Preparation Dossier
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Personal Verification Record for IRD Electronic Billing Incentive Draw
              </p>
            </div>
            <div className="text-right shrink-0">
              <span className="inline-block px-2.5 py-1 bg-emerald-100 border border-emerald-300 text-emerald-800 rounded-md text-[11px] font-bold">
                MATCHED WINNER
              </span>
              <p className="text-[10px] text-slate-400 mt-1">
                Generated: {new Date().toLocaleDateString()}
              </p>
            </div>
          </div>
        </div>

        {/* Independent Advisory Notice */}
        <div className="bg-amber-50/80 border border-amber-200/80 rounded-xl p-3.5 mb-5 flex items-start gap-3">
          <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900 leading-relaxed">
            <span className="font-bold">Independent Advisory Notice:</span> Rasid Khata is an independent personal helper tool and is <strong>not affiliated with the Inland Revenue Department (IRD) Nepal</strong>. This printable dossier is intended solely for your personal records and preparation. To claim any official prize, you must verify your coupon against official IRD notices and follow official government submission procedures.
          </div>
        </div>

        {/* Highlighted Matched Winning Number */}
        <div className="bg-slate-900 text-white rounded-xl p-5 mb-6 text-center relative overflow-hidden">
          <div className="text-[11px] font-medium text-emerald-400 uppercase tracking-wider mb-1">
            Matched 12-Digit Coupon Number
          </div>
          <div className="text-2xl sm:text-3xl font-mono font-bold tracking-wider text-white">
            {formattedCoupon}
          </div>
          <div className="text-[11px] text-slate-400 mt-1.5 font-mono">
            Raw string format: <span className="text-slate-200 font-semibold">{matchedCoupon.couponNumber}</span>
          </div>
        </div>

        {/* Two Column Details Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          {/* Draw & Announcement Info */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 mb-3">
              <Calendar className="w-3.5 h-3.5 text-emerald-700" />
              <span>Draw &amp; Announcement Details</span>
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between border-b border-slate-200/60 pb-1.5">
                <span className="text-slate-500">Draw Cycle:</span>
                <span className="font-semibold text-slate-800">{drawPeriod || matchedCoupon.drawPeriod || 'Fiscal Fortnight'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200/60 pb-1.5">
                <span className="text-slate-500">Announcement Title:</span>
                <span className="font-semibold text-slate-800 text-right">{drawTitle || 'Official Draw'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200/60 pb-1.5">
                <span className="text-slate-500">Announcement Date:</span>
                <span className="font-semibold text-slate-800">{announcementDate || 'Not recorded'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Official Publisher:</span>
                <span className="font-semibold text-slate-800">IRD Nepal (ird.gov.np)</span>
              </div>
            </div>
          </div>

          {/* Associated Purchase / Bill Details */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 mb-3">
              <Receipt className="w-3.5 h-3.5 text-emerald-700" />
              <span>Purchase Invoice Record</span>
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between border-b border-slate-200/60 pb-1.5">
                <span className="text-slate-500">Merchant:</span>
                <span className="font-semibold text-slate-800 text-right truncate max-w-[170px]">
                  {matchedCoupon.merchantName || associatedTransaction?.sellerName || 'Recorded Merchant'}
                </span>
              </div>
              <div className="flex justify-between border-b border-slate-200/60 pb-1.5">
                <span className="text-slate-500">Purchase Date:</span>
                <span className="font-semibold text-slate-800">{matchedCoupon.date || associatedTransaction?.date || 'N/A'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200/60 pb-1.5">
                <span className="text-slate-500">Invoice / Bill No:</span>
                <span className="font-mono font-semibold text-slate-800">{matchedCoupon.invoiceNumber || associatedTransaction?.invoiceNumber || 'N/A'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200/60 pb-1.5">
                <span className="text-slate-500">Amount:</span>
                <span className="font-bold text-emerald-800">
                  {matchedCoupon.amount !== undefined 
                    ? `NPR ${matchedCoupon.amount.toLocaleString()}` 
                    : associatedTransaction?.amount !== undefined 
                      ? `NPR ${associatedTransaction.amount.toLocaleString()}`
                      : 'N/A'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Seller PAN/VAT:</span>
                <span className="font-mono font-semibold text-slate-800">{associatedTransaction?.panVat || 'N/A'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Physical Claim Checklist */}
        <div className="border border-slate-200 rounded-xl p-4 sm:p-5 bg-white mb-6">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 mb-3">
            <FileCheck className="w-4 h-4 text-emerald-700" />
            <span>IRD Prize Claim Requirement Checklist</span>
          </h3>
          <p className="text-xs text-slate-500 mb-3">
            Before submitting your claim to the Inland Revenue Department or visiting the nearest Taxpayer Service Office (करदाता सेवा कार्यालय), prepare the following documents:
          </p>

          <div className="space-y-2.5">
            <label className="flex items-start gap-3 p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs text-slate-700 cursor-pointer">
              <input type="checkbox" className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500" />
              <div>
                <span className="font-bold text-slate-900">1. Original Tax Invoice / Bill: </span>
                Physical printed cash register bill or certified electronic invoice showing matching Invoice No and Coupon No.
              </div>
            </label>

            <label className="flex items-start gap-3 p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs text-slate-700 cursor-pointer">
              <input type="checkbox" className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500" />
              <div>
                <span className="font-bold text-slate-900">2. Official Government Identification: </span>
                Original and photocopy of Nepali Citizenship Certificate (नागरिकता), National Identity Card (राष्ट्रिय परिचयपत्र), Voter ID, or Passport.
              </div>
            </label>

            <label className="flex items-start gap-3 p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs text-slate-700 cursor-pointer">
              <input type="checkbox" className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500" />
              <div>
                <span className="font-bold text-slate-900">3. Personal PAN Number: </span>
                Personal PAN Certificate / Card copy of the claiming consumer.
              </div>
            </label>

            <label className="flex items-start gap-3 p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs text-slate-700 cursor-pointer">
              <input type="checkbox" className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500" />
              <div>
                <span className="font-bold text-slate-900">4. Bank Account Details / Cheque Copy: </span>
                Cancelled cheque leaf or bank account verification letter in the claimant's name for prize money deposit.
              </div>
            </label>
          </div>
        </div>

        {/* Footer Disclaimers */}
        <div className="text-[11px] text-slate-400 border-t border-slate-200 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Official IRD Portal: <strong className="text-slate-600">https://ird.gov.np</strong></span>
          <span>Rasid Khata • Offline Personal Billing &amp; Incentive Helper</span>
        </div>
      </div>
    </div>
  );
};
