import React, { useState } from 'react';
import { 
  Ticket, 
  Calendar, 
  Store, 
  Tag, 
  CreditCard, 
  FileText, 
  AlertCircle, 
  CheckCircle2, 
  ArrowLeft,
  Sparkles,
  Copy,
  Layers
} from 'lucide-react';
import { couponService } from '../services/couponService';
import { normalizeCouponNumber, formatCouponNumber, isValidCouponNumber } from '../utils/couponUtils';
import { ScreenName, PaymentMethod } from '../types/transaction';
import { TrustBanner } from '../components/common/TrustBanner';
import { transactionService } from '../services/transactionService';
import { nepaliDateService } from '../services/nepaliDateService';

export interface PrefillCouponData {
  merchantName?: string;
  amount?: number;
  date?: string;
  paymentMethod?: string;
  invoiceNumber?: string;
  fromTransactionId?: string;
}

interface AddCouponScreenProps {
  onNavigate: (screen: ScreenName) => void;
  onBack: () => void;
  prefillData?: PrefillCouponData;
}

export const AddCouponScreen: React.FC<AddCouponScreenProps> = ({ onNavigate, onBack, prefillData }) => {
  const [rawCouponNumber, setRawCouponNumber] = useState<string>('');
  const [date, setDate] = useState<string>(prefillData?.date || new Date().toISOString().split('T')[0]);
  const [drawPeriod, setDrawPeriod] = useState<string>(
    prefillData?.date 
      ? nepaliDateService.getDrawPeriodInfo(prefillData.date).drawPeriod 
      : 'Shrawan 16–31, 2083'
  );
  const [merchantName, setMerchantName] = useState<string>(prefillData?.merchantName || '');
  const [amount, setAmount] = useState<string>(prefillData?.amount !== undefined ? String(prefillData.amount) : '');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | ''>(
    (prefillData?.paymentMethod as PaymentMethod) || 'Digital Wallet'
  );
  const [invoiceNumber, setInvoiceNumber] = useState<string>(prefillData?.invoiceNumber || '');
  const [notes, setNotes] = useState<string>('');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const normalized = normalizeCouponNumber(rawCouponNumber);
  const isValid12 = isValidCouponNumber(normalized);
  const formattedDisplay = formatCouponNumber(normalized);

  // Check duplicate in real-time
  const duplicateCoupon = normalized.length === 12 ? couponService.getByCouponNumber(normalized) : undefined;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!normalized) {
      setErrorMessage('Please enter a 12-digit prize coupon number.');
      return;
    }

    if (!isValid12) {
      setErrorMessage(`Coupon number must be exactly 12 digits (currently ${normalized.length} digits).`);
      return;
    }

    if (duplicateCoupon) {
      setErrorMessage(`Coupon ${formatCouponNumber(normalized)} is already saved in your records.`);
      return;
    }

    const numAmount = amount ? parseFloat(amount) : undefined;

    const result = couponService.add({
      couponNumber: normalized,
      date: date || undefined,
      drawPeriod: drawPeriod || undefined,
      merchantName: merchantName || undefined,
      amount: numAmount,
      paymentMethod: paymentMethod || undefined,
      invoiceNumber: invoiceNumber || undefined,
      notes: notes || undefined,
    });

    if (result.success && result.coupon) {
      // If linked with a transaction, update the transaction record
      if (prefillData?.fromTransactionId) {
        transactionService.update(prefillData.fromTransactionId, {
          couponNumber: normalized,
          eligibilityStatus: 'coupon_added',
        });
      }

      setSuccessMessage(`Coupon ${formatCouponNumber(normalized)} successfully saved!`);
      // Reset form
      setRawCouponNumber('');
      setMerchantName('');
      setAmount('');
      setInvoiceNumber('');
      setNotes('');
      setTimeout(() => {
        onNavigate('my_coupons');
      }, 700);
    } else {
      setErrorMessage(result.error || 'Failed to save coupon.');
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-20">
      {/* Top Helper Banner */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900">
            Prize Coupon Entry
          </h2>
          <p className="text-xs text-slate-500">
            Enter 12-digit number printed on your electronic tax invoice.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('bulk_add_coupons')}
          className="text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-lg transition-colors shrink-0 flex items-center gap-1"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Bulk Add</span>
        </button>
      </div>

      {/* Success Banner */}
      {successMessage && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 flex items-center gap-2.5 text-emerald-900 text-xs font-medium animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Error Banner */}
      {errorMessage && (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 flex items-start gap-2.5 text-rose-900 text-xs font-medium">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Form Card */}
      <form onSubmit={handleSubmit} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
        {/* Coupon Number Input (Required & Prominent) */}
        <div className="space-y-1.5">
          <label 
            htmlFor="input-coupon-number" 
            className="block text-xs font-bold text-slate-900 flex items-center justify-between"
          >
            <span className="flex items-center gap-1.5">
              <Ticket className="w-4 h-4 text-emerald-600" />
              <span>12-Digit Coupon Number *</span>
            </span>
            <span className={`text-[11px] font-mono font-semibold ${
              normalized.length === 12 
                ? 'text-emerald-600' 
                : normalized.length > 12 
                ? 'text-rose-600' 
                : 'text-slate-400'
            }`}>
              {normalized.length}/12 digits
            </span>
          </label>

          <input
            id="input-coupon-number"
            type="text"
            inputMode="numeric"
            value={rawCouponNumber}
            onChange={(e) => setRawCouponNumber(e.target.value)}
            placeholder="e.g. 007 315 254 493 or 007315254493"
            className={`w-full text-base font-mono font-bold tracking-wider px-3.5 py-2.5 rounded-lg border outline-none transition-all ${
              duplicateCoupon
                ? 'border-rose-400 bg-rose-50/50 text-rose-900 focus:ring-2 focus:ring-rose-200'
                : isValid12
                ? 'border-emerald-500 bg-emerald-50/30 text-emerald-950 focus:ring-2 focus:ring-emerald-200'
                : 'border-slate-300 text-slate-900 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100'
            }`}
            autoFocus
          />

          {/* Formatted Number Preview */}
          {normalized.length > 0 && (
            <div className="pt-1 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-slate-600">
                <span className="text-[11px] text-slate-400">Formatted:</span>
                <span className="font-mono font-bold text-slate-800 tracking-wide bg-slate-100 px-2 py-0.5 rounded">
                  {formattedDisplay}
                </span>
              </div>
              {duplicateCoupon && (
                <span className="text-[11px] font-semibold text-rose-600">
                  Already in saved records!
                </span>
              )}
            </div>
          )}
        </div>

        {/* Draw Period (Optional but helpful) */}
        <div className="space-y-1.5">
          <label htmlFor="input-draw-period" className="block text-xs font-semibold text-slate-700">
            Draw Period / Scheme Cycle
          </label>
          <input
            id="input-draw-period"
            type="text"
            value={drawPeriod}
            onChange={(e) => setDrawPeriod(e.target.value)}
            placeholder="e.g. Shrawan 1–15, 2083"
            className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
          />
        </div>

        {/* Date & Amount 2-Column Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <label htmlFor="input-coupon-date" className="block text-xs font-semibold text-slate-700 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Purchase Date</span>
            </label>
            <input
              id="input-coupon-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
            />
          </div>

          <div className="space-y-1.5">
            <label htmlFor="input-coupon-amount" className="block text-xs font-semibold text-slate-700">
              Amount (Rs.)
            </label>
            <input
              id="input-coupon-amount"
              type="number"
              min="0"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g. 450"
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
            />
          </div>
        </div>

        {/* Merchant Name */}
        <div className="space-y-1.5">
          <label htmlFor="input-coupon-merchant" className="block text-xs font-semibold text-slate-700 flex items-center gap-1">
            <Store className="w-3.5 h-3.5 text-slate-400" />
            <span>Merchant / Store Name</span>
          </label>
          <input
            id="input-coupon-merchant"
            type="text"
            value={merchantName}
            onChange={(e) => setMerchantName(e.target.value)}
            placeholder="e.g. Annapurna Stationery & Gift House"
            className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
          />
        </div>

        {/* Payment Method & Invoice Number 2-Column Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <label htmlFor="input-coupon-payment" className="block text-xs font-semibold text-slate-700 flex items-center gap-1">
              <CreditCard className="w-3.5 h-3.5 text-slate-400" />
              <span>Payment Method</span>
            </label>
            <select
              id="input-coupon-payment"
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none bg-white"
            >
              <option value="Digital Wallet">Digital Wallet (eSewa/Khalti)</option>
              <option value="Card">Card / POS</option>
              <option value="Cash">Cash</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="input-coupon-invoice" className="block text-xs font-semibold text-slate-700 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>Invoice #</span>
            </label>
            <input
              id="input-coupon-invoice"
              type="text"
              value={invoiceNumber}
              onChange={(e) => setInvoiceNumber(e.target.value)}
              placeholder="e.g. AS-1049"
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
            />
          </div>
        </div>

        {/* Notes */}
        <div className="space-y-1.5">
          <label htmlFor="input-coupon-notes" className="block text-xs font-semibold text-slate-700">
            Notes / Item description
          </label>
          <input
            id="input-coupon-notes"
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. Notebooks and pens"
            className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
          />
        </div>

        {/* Action Buttons */}
        <div className="pt-2 flex items-center gap-2.5">
          <button
            type="button"
            onClick={onBack}
            className="w-1/3 py-2.5 px-3 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-semibold transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            id="btn-save-coupon"
            disabled={!isValid12 || !!duplicateCoupon}
            className={`w-2/3 py-2.5 px-4 rounded-lg text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5 ${
              isValid12 && !duplicateCoupon
                ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white cursor-pointer'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Ticket className="w-4 h-4" />
            <span>Save Coupon</span>
          </button>
        </div>
      </form>

      {/* Informational Privacy Note */}
      <TrustBanner 
        type="info"
        text="Saved locally on your phone. Leading zeros are preserved. Normalize spacing and formatting automatically."
      />
    </div>
  );
};
