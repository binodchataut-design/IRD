import React, { useState } from 'react';
import { 
  Calendar, 
  Store, 
  Hash, 
  FileText, 
  CreditCard, 
  Camera, 
  Image as ImageIcon, 
  X, 
  Check, 
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { PaymentMethod, ScreenName, NewTransactionInput } from '../types/transaction';
import { transactionService } from '../services/transactionService';

interface AddTransactionScreenProps {
  onNavigate: (screen: ScreenName, params?: { transactionId?: string }) => void;
  onBack: () => void;
}

const PAYMENT_METHODS: PaymentMethod[] = [
  'Digital Wallet',
  'Card',
  'Cash',
  'Bank Transfer',
  'Other'
];

export const AddTransactionScreen: React.FC<AddTransactionScreenProps> = ({
  onNavigate,
  onBack,
}) => {
  // Form State
  const today = new Date().toISOString().split('T')[0];
  const [date, setDate] = useState<string>(today);
  const [sellerName, setSellerName] = useState<string>('');
  const [sellerPanVat, setSellerPanVat] = useState<string>('');
  const [invoiceNumber, setInvoiceNumber] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Digital Wallet');
  const [notes, setNotes] = useState<string>('');
  const [invoicePhotoUrl, setInvoicePhotoUrl] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isSaved, setIsSaved] = useState<boolean>(false);

  // Photo selection handlers
  const handleMockSamplePhoto = (sampleUrl: string) => {
    setInvoicePhotoUrl(sampleUrl);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const files = e.target.files;
      if (!files || files.length === 0) {
        // User cancelled file selection dialog
        return;
      }
      const file = files[0];
      if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            setInvoicePhotoUrl(reader.result);
          }
        };
        reader.onerror = () => {
          console.warn('FileReader encountered an error reading the file.');
        };
        reader.readAsDataURL(file);
      }
    } catch (err) {
      console.warn('File selection handler failed gracefully:', err);
    }
  };

  const handleRemovePhoto = () => {
    setInvoicePhotoUrl('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    // Validations
    const trimmedSeller = sellerName.trim();
    if (!trimmedSeller) {
      setErrorMessage('Please enter the seller / merchant name.');
      return;
    }

    const numericAmount = parseFloat(amount);
    if (!amount.trim() || isNaN(numericAmount) || !isFinite(numericAmount) || numericAmount <= 0) {
      setErrorMessage('Please enter a valid positive transaction amount.');
      return;
    }

    const newTxData: NewTransactionInput = {
      date: date || new Date().toISOString().split('T')[0],
      sellerName: trimmedSeller,
      panVat: sellerPanVat.trim() || undefined,
      sellerPanVat: sellerPanVat.trim() || undefined,
      invoiceNumber: invoiceNumber.trim() || undefined,
      amount: numericAmount,
      paymentMethod,
      notes: notes.trim() || undefined,
      photoReference: invoicePhotoUrl || undefined,
      invoicePhotoUrl: invoicePhotoUrl || undefined,
    };

    const created = transactionService.add(newTxData);
    setIsSaved(true);

    setTimeout(() => {
      onNavigate('transaction_detail', { transactionId: created.id });
    }, 450);
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full pb-10 space-y-4">
      {/* Top Card / Overview */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-1">
          <h2 className="text-base font-bold text-slate-900">Add Transaction</h2>
          <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded">
            Manual Entry
          </span>
        </div>
        <p className="text-xs text-slate-500">
          Save your purchase invoice and digital payment details for personal incentive records.
        </p>
      </div>

      {errorMessage && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2 text-xs text-red-800">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {isSaved && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-xs text-emerald-800">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Transaction saved successfully! Opening details...</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
        {/* Date Field */}
        <div>
          <label htmlFor="tx-date" className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1 block">
            Transaction Date <span className="text-red-500">*</span>
          </label>
          <input
            id="tx-date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
            className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
          />
        </div>

        {/* Seller / Merchant Name */}
        <div>
          <label htmlFor="tx-seller-name" className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1 block">
            Seller / Merchant Name <span className="text-red-500">*</span>
          </label>
          <input
            id="tx-seller-name"
            type="text"
            placeholder="e.g. Bhat-Bhateni Supermarket, Daraz, Local Mart"
            value={sellerName}
            onChange={(e) => setSellerName(e.target.value)}
            required
            className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
          />
        </div>

        {/* Amount */}
        <div>
          <label htmlFor="tx-amount" className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1 block">
            Amount (NPR / रू) <span className="text-red-500">*</span>
          </label>
          <div className="relative flex items-center">
            <span className="absolute left-3 text-xs font-bold text-slate-500">
              रू
            </span>
            <input
              id="tx-amount"
              type="number"
              step="0.01"
              min="0"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              className="w-full bg-white border border-slate-200 rounded-lg pl-8 pr-3 py-2 text-xs text-slate-900 font-bold focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 placeholder:text-slate-400"
            />
          </div>
        </div>

        {/* Payment Method Selector */}
        <div>
          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5 block">
            Payment Method <span className="text-red-500">*</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {PAYMENT_METHODS.map((method) => {
              const isSelected = paymentMethod === method;
              return (
                <button
                  key={method}
                  type="button"
                  id={`method-btn-${method.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => setPaymentMethod(method)}
                  className={`py-2 px-2.5 text-xs font-semibold rounded-lg border text-center transition-all ${
                    isSelected
                      ? 'bg-emerald-50 border-emerald-600 text-emerald-800 ring-1 ring-emerald-600'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {method}
                </button>
              );
            })}
          </div>
          <p className="text-[10px] text-slate-400 mt-1.5">
            Tip: Record electronic payment channels (QR, Mobile Wallet, Card) for digital transaction tracking.
          </p>
        </div>

        {/* Optional Section: PAN & Invoice */}
        <div className="pt-3 border-t border-slate-100 space-y-3">
          {/* Seller PAN/VAT Number */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="tx-seller-pan" className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Seller PAN / VAT Number
              </label>
              <span className="text-[10px] text-slate-400 font-normal">
                (Optional)
              </span>
            </div>
            <input
              id="tx-seller-pan"
              type="text"
              placeholder="9-digit PAN (e.g. 300054812)"
              value={sellerPanVat}
              onChange={(e) => setSellerPanVat(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 placeholder:text-slate-400 font-mono"
            />
          </div>

          {/* Invoice Number */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="tx-invoice-no" className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Invoice / Bill Number
              </label>
              <span className="text-[10px] text-slate-400 font-normal">
                (Optional)
              </span>
            </div>
            <input
              id="tx-invoice-no"
              type="text"
              placeholder="e.g. BBSM-88492 or INV-2026-01"
              value={invoiceNumber}
              onChange={(e) => setInvoiceNumber(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 placeholder:text-slate-400"
            />
          </div>

          {/* Notes */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="tx-notes" className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Notes
              </label>
              <span className="text-[10px] text-slate-400 font-normal">
                (Optional)
              </span>
            </div>
            <textarea
              id="tx-notes"
              rows={2}
              placeholder="Add remarks, item categories, or details..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 placeholder:text-slate-400 resize-none"
            />
          </div>
        </div>

        {/* Invoice Photo Section */}
        <div className="pt-3 border-t border-slate-100">
          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5 block">
            Invoice Photo Attachment <span className="text-slate-400 font-normal lowercase">(optional)</span>
          </label>

          {invoicePhotoUrl ? (
            <div className="relative rounded-lg overflow-hidden border border-slate-200 bg-slate-900">
              <img
                src={invoicePhotoUrl}
                alt="Selected invoice"
                className="w-full h-40 object-cover"
                referrerPolicy="no-referrer"
              />
              <button
                type="button"
                id="btn-remove-invoice-photo"
                onClick={handleRemovePhoto}
                className="absolute top-2 right-2 bg-slate-900/80 text-white p-1.5 rounded-full hover:bg-slate-900 transition-colors"
                aria-label="Remove photo"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="absolute bottom-2 left-2 bg-slate-900/80 text-slate-200 text-[10px] px-2 py-0.5 rounded font-medium">
                Photo Attached
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <label
                htmlFor="tx-file-input"
                className="w-full border-2 border-dashed border-slate-200 hover:border-emerald-500 bg-slate-50/70 hover:bg-emerald-50/20 rounded-lg p-3.5 flex flex-col items-center justify-center cursor-pointer transition-colors"
              >
                <Camera className="w-5 h-5 text-emerald-600 mb-1.5" />
                <span className="text-xs font-semibold text-slate-800">
                  Attach Bill Photo
                </span>
                <span className="text-[10px] text-slate-400 mt-0.5">
                  Tap to capture or upload image
                </span>
                <input
                  id="tx-file-input"
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              {/* Quick Sample Presets */}
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[10px] text-slate-400">Samples:</span>
                <button
                  type="button"
                  id="btn-mock-photo-receipt"
                  onClick={() => handleMockSamplePhoto('https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80')}
                  className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-0.5 rounded border border-slate-200 font-medium transition-colors"
                >
                  Paper Receipt
                </button>
                <button
                  type="button"
                  id="btn-mock-photo-digital"
                  onClick={() => handleMockSamplePhoto('https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80')}
                  className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-0.5 rounded border border-slate-200 font-medium transition-colors"
                >
                  POS Slip
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="pt-3 flex items-center gap-2.5">
          <button
            type="button"
            id="tx-form-cancel-btn"
            onClick={onBack}
            className="flex-1 py-2.5 border border-slate-200 hover:bg-slate-50 active:bg-slate-100 text-slate-700 font-semibold rounded-lg text-xs transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            id="tx-form-save-btn"
            disabled={isSaved}
            className="flex-[2] py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold rounded-lg text-xs shadow-sm transition-all flex items-center justify-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>Save Transaction</span>
          </button>
        </div>
      </form>
    </div>
  );
};
