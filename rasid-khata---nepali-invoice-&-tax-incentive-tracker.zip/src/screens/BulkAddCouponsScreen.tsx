import React, { useState, useMemo } from 'react';
import { 
  Layers, 
  CheckCircle2, 
  AlertCircle, 
  Copy, 
  ArrowRight, 
  Info, 
  Calendar, 
  Store,
  Sparkles,
  Ticket,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { couponService } from '../services/couponService';
import { parseBulkCouponsText, formatCouponNumber } from '../utils/couponUtils';
import { ScreenName } from '../types/transaction';
import { TrustBanner } from '../components/common/TrustBanner';

interface BulkAddCouponsScreenProps {
  onNavigate: (screen: ScreenName) => void;
  onBack: () => void;
}

const SAMPLE_PASTE_DATA = `007 315 254 493
002 928 817 811
003 066 779 589
015 611 059 075
009 917 833 245
004 128 930 192
005 829 104 728
008 273 910 482
002 938 475 619
006 918 273 645
011 293 847 560
003 829 104 857
007 755 590 670
009 283 746 150
004 928 173 645
001 928 374 650`;

export const BulkAddCouponsScreen: React.FC<BulkAddCouponsScreenProps> = ({ onNavigate, onBack }) => {
  const [rawText, setRawText] = useState<string>('');
  const [defaultDrawPeriod, setDefaultDrawPeriod] = useState<string>('Shrawan 1–15, 2083');
  const [defaultDate, setDefaultDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [defaultMerchant, setDefaultMerchant] = useState<string>('');
  const [savedSuccessCount, setSavedSuccessCount] = useState<number | null>(null);

  // Existing coupons saved in storage
  const existingCoupons = couponService.getAll();
  const existingNumbersSet = useMemo(() => new Set(existingCoupons.map(c => c.couponNumber)), [existingCoupons]);

  // Live parsing breakdown
  const parseResult = useMemo(() => {
    return parseBulkCouponsText(rawText, existingNumbersSet);
  }, [rawText, existingNumbersSet]);

  const handleSaveValid = () => {
    if (parseResult.validNew.length === 0) return;

    const result = couponService.addBulk(parseResult.validNew, {
      date: defaultDate || undefined,
      drawPeriod: defaultDrawPeriod || undefined,
      merchantName: defaultMerchant || undefined,
    });

    setSavedSuccessCount(result.addedCount);
    setRawText('');
    setTimeout(() => {
      onNavigate('my_coupons');
    }, 1000);
  };

  const handleLoadSample = () => {
    setRawText(SAMPLE_PASTE_DATA);
    setSavedSuccessCount(null);
  };

  const handleClear = () => {
    setRawText('');
    setSavedSuccessCount(null);
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-20">
      {/* Header Info */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-1.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900">Bulk Add Coupons</h2>
          </div>
          <button
            type="button"
            onClick={handleLoadSample}
            className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2.5 py-1 rounded transition-colors flex items-center gap-1"
          >
            <Sparkles className="w-3 h-3" />
            <span>Load Sample (16)</span>
          </button>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          Paste 10, 50, or 200+ coupon numbers from spreadsheets, messages, or notes. Spaces and hyphens are automatically normalized.
        </p>
      </div>

      {/* Success Notification */}
      {savedSuccessCount !== null && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 flex items-center gap-2.5 text-emerald-900 text-xs font-medium animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>Successfully added {savedSuccessCount} new prize coupons to your personal record!</span>
        </div>
      )}

      {/* Main Input Textarea */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <label htmlFor="bulk-coupon-textarea" className="text-xs font-bold text-slate-800">
            Paste Coupon Numbers
          </label>
          {rawText && (
            <button
              type="button"
              onClick={handleClear}
              className="text-[10px] text-slate-400 hover:text-slate-700 font-semibold"
            >
              Clear
            </button>
          )}
        </div>

        <textarea
          id="bulk-coupon-textarea"
          rows={6}
          value={rawText}
          onChange={(e) => setRawText(e.target.value)}
          placeholder={`Paste 12-digit numbers (one per line, space-separated, or comma-separated):\n007 315 254 493\n002 928 817 811\n003066779589`}
          className="w-full font-mono text-xs p-3 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100 outline-none resize-y leading-relaxed"
        />

        {/* Live Parsing Metrics Breakdown */}
        {rawText.trim().length > 0 && (
          <div className="pt-2 border-t border-slate-100 space-y-2.5">
            <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Extraction Preview
            </h4>

            {/* 5-Metric Pills */}
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5 text-center text-xs">
              <div className="bg-slate-50 border border-slate-200 p-2 rounded-lg">
                <span className="text-[10px] text-slate-500 block font-medium">Total Detected</span>
                <span className="font-bold text-slate-900 text-sm font-mono">{parseResult.totalExtracted}</span>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 p-2 rounded-lg">
                <span className="text-[10px] text-emerald-700 block font-medium">Valid New</span>
                <span className="font-bold text-emerald-800 text-sm font-mono">{parseResult.validNew.length}</span>
              </div>

              <div className="bg-amber-50 border border-amber-200 p-2 rounded-lg">
                <span className="text-[10px] text-amber-700 block font-medium">Batch Dups</span>
                <span className="font-bold text-amber-800 text-sm font-mono">{parseResult.duplicateInBatch.length}</span>
              </div>

              <div className="bg-blue-50 border border-blue-200 p-2 rounded-lg">
                <span className="text-[10px] text-blue-700 block font-medium">Already Saved</span>
                <span className="font-bold text-blue-800 text-sm font-mono">{parseResult.alreadySaved.length}</span>
              </div>

              <div className="bg-rose-50 border border-rose-200 p-2 rounded-lg col-span-3 sm:col-span-1">
                <span className="text-[10px] text-rose-700 block font-medium">Invalid Tokens</span>
                <span className="font-bold text-rose-800 text-sm font-mono">{parseResult.invalidTokens.length}</span>
              </div>
            </div>

            {/* List Preview of Valid New Numbers */}
            {parseResult.validNew.length > 0 && (
              <div className="mt-2 bg-emerald-50/50 border border-emerald-200/80 rounded-lg p-3 space-y-1.5 max-h-40 overflow-y-auto">
                <div className="flex items-center justify-between text-[11px] font-bold text-emerald-900">
                  <span>Ready to Save ({parseResult.validNew.length})</span>
                  <span className="text-[10px] text-emerald-700 font-normal">Formatted for review</span>
                </div>
                <div className="grid grid-cols-2 gap-1 font-mono text-[11px] text-emerald-950 font-medium">
                  {parseResult.validNew.slice(0, 20).map((num, i) => (
                    <span key={i} className="bg-white/80 border border-emerald-200 px-2 py-0.5 rounded">
                      {formatCouponNumber(num)}
                    </span>
                  ))}
                </div>
                {parseResult.validNew.length > 20 && (
                  <p className="text-[10px] text-emerald-700 text-center pt-1 font-semibold">
                    + {parseResult.validNew.length - 20} more valid coupons
                  </p>
                )}
              </div>
            )}

            {/* Warnings if invalid tokens exist */}
            {parseResult.invalidTokens.length > 0 && (
              <div className="bg-rose-50 border border-rose-200 rounded-lg p-2.5 text-xs text-rose-900 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-[11px] text-rose-800">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  <span>Invalid entries detected (skipped):</span>
                </div>
                <p className="text-[10px] font-mono text-rose-700 break-words">
                  {parseResult.invalidTokens.slice(0, 5).join(', ')}
                  {parseResult.invalidTokens.length > 5 && ` (+${parseResult.invalidTokens.length - 5} more)`}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Optional Batch Defaults */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <h3 className="text-xs font-bold text-slate-800">
          Default Details for This Batch (Optional)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1">
            <label htmlFor="bulk-default-draw" className="block text-[11px] font-semibold text-slate-600">
              Draw Period / Scheme
            </label>
            <input
              id="bulk-default-draw"
              type="text"
              value={defaultDrawPeriod}
              onChange={(e) => setDefaultDrawPeriod(e.target.value)}
              placeholder="e.g. Shrawan 1–15, 2083"
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="bulk-default-date" className="block text-[11px] font-semibold text-slate-600">
              Purchase Date
            </label>
            <input
              id="bulk-default-date"
              type="date"
              value={defaultDate}
              onChange={(e) => setDefaultDate(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label htmlFor="bulk-default-merchant" className="block text-[11px] font-semibold text-slate-600">
            Merchant / Store (Optional default)
          </label>
          <input
            id="bulk-default-merchant"
            type="text"
            value={defaultMerchant}
            onChange={(e) => setDefaultMerchant(e.target.value)}
            placeholder="e.g. Multiple Retailers"
            className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:border-emerald-600 outline-none"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2.5 pt-1">
        <button
          type="button"
          onClick={onBack}
          className="w-1/3 py-2.5 px-3 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-semibold transition-colors"
        >
          Back
        </button>

        <button
          type="button"
          id="btn-confirm-bulk-save"
          onClick={handleSaveValid}
          disabled={parseResult.validNew.length === 0}
          className={`w-2/3 py-2.5 px-4 rounded-lg text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5 ${
            parseResult.validNew.length > 0
              ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white cursor-pointer'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Save {parseResult.validNew.length} New Coupons</span>
        </button>
      </div>

      {/* Local Safety Banner */}
      <TrustBanner
        type="info"
        text="Coupons are stored in local offline browser storage. Leading zeros are safely preserved as strings."
      />
    </div>
  );
};
