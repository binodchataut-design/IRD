import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  HelpCircle, 
  Ticket, 
  Store, 
  Calendar, 
  FileText, 
  QrCode, 
  CreditCard, 
  Wallet, 
  Banknote, 
  Building2, 
  User, 
  Sparkles, 
  ArrowRight, 
  Check, 
  ShieldAlert, 
  Info,
  Clock
} from 'lucide-react';
import { 
  ScreenName, 
  PaymentMethod, 
  PurchasePurpose, 
  SellerPanOption, 
  TransactionCategory,
  TransactionEligibilityInput 
} from '../types/transaction';
import { eligibilityService } from '../services/eligibilityService';
import { transactionService } from '../services/transactionService';
import { nepaliDateService } from '../services/nepaliDateService';
import { TrustBanner } from '../components/common/TrustBanner';

interface CheckEligibilityScreenProps {
  onNavigate: (
    screen: ScreenName, 
    params?: { 
      transactionId?: string;
      prefillCoupon?: {
        merchantName?: string;
        amount?: number;
        date?: string;
        paymentMethod?: string;
        invoiceNumber?: string;
        fromTransactionId?: string;
      };
    }
  ) => void;
  onBack: () => void;
}

export const CheckEligibilityScreen: React.FC<CheckEligibilityScreenProps> = ({
  onNavigate,
  onBack,
}) => {
  const today = new Date().toISOString().split('T')[0];

  // Form states
  const [amount, setAmount] = useState<string>('250');
  const [paymentMethod, setPaymentMethod] = useState<string>('QR / Digital Payment');
  const [purpose, setPurpose] = useState<PurchasePurpose>('personal');
  const [sellerPan, setSellerPan] = useState<SellerPanOption>('yes');
  const [sellerPanNumber, setSellerPanNumber] = useState<string>('601928374');
  const [sellerName, setSellerName] = useState<string>('Local Grocery Mart');
  const [category, setCategory] = useState<TransactionCategory>('normal_goods');
  const [date, setDate] = useState<string>(today);
  const [invoiceNumber, setInvoiceNumber] = useState<string>('');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Computed draw period
  const drawInfo = useMemo(() => {
    return nepaliDateService.getDrawPeriodInfo(date);
  }, [date]);

  // Current eligibility calculation
  const numericAmount = parseFloat(amount) || 0;
  const currentInput: TransactionEligibilityInput = useMemo(() => ({
    amount: numericAmount,
    paymentMethod: paymentMethod as any,
    purpose,
    sellerPan,
    sellerPanNumber: sellerPanNumber.trim() || undefined,
    sellerName: sellerName.trim() || undefined,
    category,
    date,
    invoiceNumber: invoiceNumber.trim() || undefined,
  }), [numericAmount, paymentMethod, purpose, sellerPan, sellerPanNumber, sellerName, category, date, invoiceNumber]);

  const result = useMemo(() => {
    return eligibilityService.checkEligibility(currentInput);
  }, [currentInput]);

  // Preset tester loader
  const handleApplyPreset = (preset: 'eligible_qr' | 'exact_100' | 'electricity' | 'business' | 'cash' | 'unknown_pan') => {
    setSaveSuccessMsg(null);
    switch (preset) {
      case 'eligible_qr':
        setAmount('250');
        setPaymentMethod('QR / Digital Payment');
        setPurpose('personal');
        setSellerPan('yes');
        setSellerPanNumber('601928374');
        setSellerName('Valley Retail Department Store');
        setCategory('normal_goods');
        break;
      case 'exact_100':
        setAmount('100');
        setPaymentMethod('QR / Digital Payment');
        setPurpose('personal');
        setSellerPan('yes');
        setSellerPanNumber('302819201');
        setSellerName('Patan Stationery');
        setCategory('normal_goods');
        break;
      case 'electricity':
        setAmount('500');
        setPaymentMethod('Digital Wallet');
        setPurpose('personal');
        setSellerPan('yes');
        setSellerPanNumber('100482910');
        setSellerName('Nepal Electricity Authority (NEA)');
        setCategory('electricity');
        break;
      case 'business':
        setAmount('1000');
        setPaymentMethod('Mobile Banking');
        setPurpose('business');
        setSellerPan('yes');
        setSellerPanNumber('609123847');
        setSellerName('Tech Hardware Supplier');
        setCategory('normal_goods');
        break;
      case 'cash':
        setAmount('350');
        setPaymentMethod('Cash');
        setPurpose('personal');
        setSellerPan('yes');
        setSellerPanNumber('608374619');
        setSellerName('Fresh Mart');
        setCategory('normal_goods');
        break;
      case 'unknown_pan':
        setAmount('450');
        setPaymentMethod('QR / Digital Payment');
        setPurpose('personal');
        setSellerPan('dont_know');
        setSellerPanNumber('');
        setSellerName('Local Street Vendor');
        setCategory('normal_goods');
        break;
    }
  };

  // Convert check payment method to Transaction PaymentMethod
  const mapToTransactionPaymentMethod = (methodStr: string): PaymentMethod => {
    if (methodStr === 'Cash') return 'Cash';
    if (methodStr === 'Debit/Credit Card' || methodStr === 'Card') return 'Card';
    if (methodStr === 'Mobile Banking' || methodStr === 'Bank Transfer') return 'Bank Transfer';
    if (methodStr === 'QR / Digital Payment' || methodStr === 'Digital Wallet') return 'Digital Wallet';
    return 'Other';
  };

  // Action: Save as Awaiting Coupon
  const handleSaveAsAwaiting = () => {
    const created = transactionService.add({
      date,
      sellerName: sellerName.trim() || 'Unnamed Merchant',
      amount: numericAmount,
      paymentMethod: mapToTransactionPaymentMethod(paymentMethod),
      panVat: sellerPanNumber.trim() || undefined,
      sellerPanVat: sellerPanNumber.trim() || undefined,
      invoiceNumber: invoiceNumber.trim() || undefined,
      eligibilityStatus: 'awaiting_coupon',
      eligibilityReasons: result.reasons,
      notes: `Checked eligibility: ${result.title}. Awaiting 12-digit prize coupon from payment app/IRD.`,
    });

    setSaveSuccessMsg('Transaction saved as "Awaiting Coupon". Opening transactions list...');
    setTimeout(() => {
      onNavigate('my_transactions');
    }, 600);
  };

  // Action: Save Transaction with current eligibility
  const handleSaveTransaction = () => {
    const created = transactionService.add({
      date,
      sellerName: sellerName.trim() || 'Unnamed Merchant',
      amount: numericAmount,
      paymentMethod: mapToTransactionPaymentMethod(paymentMethod),
      panVat: sellerPanNumber.trim() || undefined,
      sellerPanVat: sellerPanNumber.trim() || undefined,
      invoiceNumber: invoiceNumber.trim() || undefined,
      eligibilityStatus: result.status,
      eligibilityReasons: result.reasons,
      notes: `Checked eligibility: ${result.title}.`,
    });

    setSaveSuccessMsg(`Saved transaction as "${result.title}". Opening invoice details...`);
    setTimeout(() => {
      onNavigate('transaction_detail', { transactionId: created.id });
    }, 600);
  };

  // Action: Yes - Add Coupon directly
  const handleGoToAddCoupon = () => {
    // Also save transaction record so it's tracked
    const created = transactionService.add({
      date,
      sellerName: sellerName.trim() || 'Unnamed Merchant',
      amount: numericAmount,
      paymentMethod: mapToTransactionPaymentMethod(paymentMethod),
      panVat: sellerPanNumber.trim() || undefined,
      sellerPanVat: sellerPanNumber.trim() || undefined,
      invoiceNumber: invoiceNumber.trim() || undefined,
      eligibilityStatus: 'awaiting_coupon',
      eligibilityReasons: result.reasons,
    });

    onNavigate('add_coupon', {
      prefillCoupon: {
        merchantName: sellerName.trim() || undefined,
        amount: numericAmount > 0 ? numericAmount : undefined,
        date,
        paymentMethod: mapToTransactionPaymentMethod(paymentMethod),
        invoiceNumber: invoiceNumber.trim() || undefined,
        fromTransactionId: created.id,
      }
    });
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-20">
      {/* Top Card / Overview */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900">
              Check Transaction Eligibility
            </h2>
          </div>
          <span className="text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded">
            IRD Helper
          </span>
        </div>
        <p className="text-xs font-semibold text-emerald-700">
          मेरो कारोबार योग्य छ कि छैन?
        </p>
        <p className="text-xs text-slate-500 leading-relaxed">
          Answer a few simple questions to see if your transaction appears to qualify for the IRD Taxpayer Incentive Gift Scheme based on official provisions.
        </p>

        {/* Quick Test Presets */}
        <div className="pt-2 border-t border-slate-100">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Test Preset Scenarios:
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
            <button
              type="button"
              id="preset-btn-eligible"
              onClick={() => handleApplyPreset('eligible_qr')}
              className="text-[10px] bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 px-2 py-1 rounded-md font-semibold whitespace-nowrap"
            >
              NPR 250 QR Personal
            </button>
            <button
              type="button"
              id="preset-btn-100"
              onClick={() => handleApplyPreset('exact_100')}
              className="text-[10px] bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 px-2 py-1 rounded-md font-semibold whitespace-nowrap"
            >
              NPR 100 (Exact)
            </button>
            <button
              type="button"
              id="preset-btn-electricity"
              onClick={() => handleApplyPreset('electricity')}
              className="text-[10px] bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 px-2 py-1 rounded-md font-semibold whitespace-nowrap"
            >
              NPR 500 Electricity
            </button>
            <button
              type="button"
              id="preset-btn-business"
              onClick={() => handleApplyPreset('business')}
              className="text-[10px] bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 px-2 py-1 rounded-md font-semibold whitespace-nowrap"
            >
              NPR 1,000 Business
            </button>
            <button
              type="button"
              id="preset-btn-cash"
              onClick={() => handleApplyPreset('cash')}
              className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 px-2 py-1 rounded-md font-semibold whitespace-nowrap"
            >
              Cash Purchase
            </button>
            <button
              type="button"
              id="preset-btn-unknown-pan"
              onClick={() => handleApplyPreset('unknown_pan')}
              className="text-[10px] bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 px-2 py-1 rounded-md font-semibold whitespace-nowrap"
            >
              Unknown Seller PAN
            </button>
          </div>
        </div>
      </div>

      {saveSuccessMsg && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs font-semibold text-emerald-900">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* 5-Question Interactive Form */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 pb-2 border-b border-slate-100">
          Transaction Questionnaire
        </h3>

        {/* 1. Purchase Amount */}
        <div className="space-y-1.5">
          <label htmlFor="elig-amount" className="block text-xs font-bold text-slate-900 flex items-center justify-between">
            <span>1. Purchase Amount (NPR / रू) *</span>
            <span className="text-[10px] text-slate-400 font-normal">
              Rule: Must be MORE than NPR 100
            </span>
          </label>
          <div className="relative flex items-center">
            <span className="absolute left-3 text-xs font-bold text-slate-500">रू</span>
            <input
              id="elig-amount"
              type="number"
              min="0"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className={`w-full pl-8 pr-3 py-2 text-xs font-bold rounded-lg border outline-none ${
                numericAmount > 100 
                  ? 'border-emerald-300 text-slate-900 focus:border-emerald-600 bg-white' 
                  : numericAmount > 0 
                  ? 'border-rose-300 text-rose-900 bg-rose-50/30 focus:border-rose-500' 
                  : 'border-slate-200 text-slate-800'
              }`}
            />
          </div>
          {numericAmount > 0 && numericAmount <= 100 && (
            <p className="text-[11px] font-semibold text-rose-600 flex items-center gap-1 mt-1">
              <XCircle className="w-3.5 h-3.5 shrink-0" />
              <span>NPR {numericAmount} does not qualify (must be strictly more than NPR 100).</span>
            </p>
          )}
        </div>

        {/* 2. Payment Method */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-900">
            2. Payment Method *
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {[
              { id: 'QR / Digital Payment', label: 'QR / Fonepay', icon: QrCode },
              { id: 'Mobile Banking', label: 'Mobile Banking', icon: Building2 },
              { id: 'Debit/Credit Card', label: 'Card / POS', icon: CreditCard },
              { id: 'Digital Wallet', label: 'Digital Wallet', icon: Wallet },
              { id: 'Cash', label: 'Cash', icon: Banknote },
              { id: 'Other / Unknown', label: 'Other / Unknown', icon: HelpCircle },
            ].map((item) => {
              const isSelected = paymentMethod === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  id={`btn-payment-${item.id.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                  onClick={() => setPaymentMethod(item.id)}
                  className={`py-2 px-2.5 rounded-lg border text-left text-xs font-semibold flex items-center gap-1.5 transition-all ${
                    isSelected
                      ? item.id === 'Cash'
                        ? 'bg-rose-50 border-rose-400 text-rose-900 ring-1 ring-rose-300'
                        : 'bg-emerald-50 border-emerald-600 text-emerald-900 ring-1 ring-emerald-600'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-emerald-700' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Purchase Purpose */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-900">
            3. Purchase Purpose *
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'personal', label: 'Personal Use', note: 'Individual consumer' },
              { id: 'business', label: 'Business / Commercial', note: 'Firm / Company' },
              { id: 'government', label: 'Government / Public', note: 'Office purchase' },
              { id: 'unknown', label: 'Unknown', note: 'Unspecified' },
            ].map((p) => {
              const isSelected = purpose === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  id={`btn-purpose-${p.id}`}
                  onClick={() => setPurpose(p.id as PurchasePurpose)}
                  className={`p-2.5 rounded-lg border text-left text-xs transition-all ${
                    isSelected
                      ? p.id === 'personal'
                        ? 'bg-emerald-50 border-emerald-600 text-emerald-900 ring-1 ring-emerald-600'
                        : 'bg-rose-50 border-rose-400 text-rose-900 ring-1 ring-rose-300'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="font-bold">{p.label}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{p.note}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Seller PAN & Invoicing */}
        <div className="space-y-2 pt-1 border-t border-slate-100">
          <label className="block text-xs font-bold text-slate-900">
            4. Seller Information &amp; PAN
          </label>
          <div className="flex items-center gap-2">
            {[
              { id: 'yes', label: 'Yes, PAN Available' },
              { id: 'no', label: 'No PAN' },
              { id: 'dont_know', label: "Don't Know" },
            ].map((opt) => {
              const isSelected = sellerPan === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  id={`btn-sellerpan-${opt.id}`}
                  onClick={() => setSellerPan(opt.id as SellerPanOption)}
                  className={`flex-1 py-1.5 px-2 text-xs font-semibold rounded-lg border text-center transition-all ${
                    isSelected
                      ? opt.id === 'yes'
                        ? 'bg-emerald-50 border-emerald-600 text-emerald-900 ring-1 ring-emerald-600'
                        : opt.id === 'no'
                        ? 'bg-rose-50 border-rose-400 text-rose-900 ring-1 ring-rose-300'
                        : 'bg-amber-50 border-amber-400 text-amber-900 ring-1 ring-amber-300'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <div>
              <label htmlFor="elig-seller-name" className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Seller Name (Optional)
              </label>
              <input
                id="elig-seller-name"
                type="text"
                value={sellerName}
                onChange={(e) => setSellerName(e.target.value)}
                placeholder="e.g. Sagarmatha Bakery"
                className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-emerald-600"
              />
            </div>
            <div>
              <label htmlFor="elig-seller-pan" className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Seller PAN # (Optional)
              </label>
              <input
                id="elig-seller-pan"
                type="text"
                value={sellerPanNumber}
                onChange={(e) => setSellerPanNumber(e.target.value)}
                placeholder="9-digit PAN (e.g. 601928374)"
                className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:border-emerald-600"
              />
            </div>
          </div>
        </div>

        {/* 5. Transaction Category */}
        <div className="space-y-1.5 pt-1 border-t border-slate-100">
          <label htmlFor="elig-category" className="block text-xs font-bold text-slate-900">
            5. Transaction Type / Goods Category *
          </label>
          <select
            id="elig-category"
            value={category}
            onChange={(e) => setCategory(e.target.value as TransactionCategory)}
            className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 font-semibold focus:outline-none focus:border-emerald-600"
          >
            <option value="normal_goods">Normal goods / Retail / Restaurant / Service (Qualifying)</option>
            <option value="vehicle">Vehicle-related / Auto Parts (Qualifying)</option>
            <option value="other">Other retail goods (Qualifying)</option>
            <option value="electricity">Electricity Bill (Excluded)</option>
            <option value="telephone_internet">Telephone / Internet Bill (Excluded)</option>
            <option value="airline">Airline Ticket (Excluded)</option>
            <option value="transport_freight">Transport / Freight (Excluded)</option>
            <option value="dont_know">Don't Know (Needs verification)</option>
          </select>
        </div>

        {/* Date & Optional Invoice Number for Saving */}
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
          <div>
            <label htmlFor="elig-date" className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Transaction Date
            </label>
            <input
              id="elig-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-emerald-600"
            />
          </div>
          <div>
            <label htmlFor="elig-invoice" className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Invoice # (Optional)
            </label>
            <input
              id="elig-invoice"
              type="text"
              value={invoiceNumber}
              onChange={(e) => setInvoiceNumber(e.target.value)}
              placeholder="e.g. INV-8821"
              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-emerald-600"
            />
          </div>
        </div>
      </div>

      {/* RESULT CARD: 3 States */}
      <div className={`p-5 rounded-xl border shadow-sm space-y-3.5 transition-all ${
        result.status === 'likely_eligible'
          ? 'bg-emerald-50/80 border-emerald-300'
          : result.status === 'likely_not_eligible'
          ? 'bg-rose-50/80 border-rose-300'
          : 'bg-amber-50/80 border-amber-300'
      }`}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            {result.status === 'likely_eligible' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            ) : result.status === 'likely_not_eligible' ? (
              <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            )}
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider opacity-75 block">
                Preliminary Evaluation
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                {result.statusLabel}
              </h3>
            </div>
          </div>

          <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
            result.status === 'likely_eligible'
              ? 'bg-emerald-200/80 text-emerald-900'
              : result.status === 'likely_not_eligible'
              ? 'bg-rose-200/80 text-rose-900'
              : 'bg-amber-200/80 text-amber-900'
          }`}>
            {result.title}
          </span>
        </div>

        {/* Reasons Breakdown */}
        <div className="space-y-1.5">
          <h4 className="text-[11px] font-bold text-slate-800 uppercase tracking-wide">
            Key Factors:
          </h4>
          <ul className="space-y-1 text-xs text-slate-700">
            {result.reasons.map((reason, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-slate-400 mt-0.5">•</span>
                <span>{reason}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Draw Period Indicator */}
        <div className="p-3 bg-white/80 rounded-lg border border-slate-200 text-xs space-y-1">
          <div className="flex items-center gap-1.5 text-slate-800 font-semibold">
            <Clock className="w-3.5 h-3.5 text-emerald-600" />
            <span>Estimated Draw Period:</span>
            <span className="text-emerald-700 font-bold">{drawInfo.drawPeriod}</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Expected announcement: <span className="text-slate-700 font-medium">{drawInfo.expectedAnnouncement}</span>
          </p>
        </div>

        {/* FEATURE 3: DIGITAL PAYMENT WARNING */}
        {result.digitalWarning && (
          <div className="p-3 bg-white border border-amber-200 rounded-lg space-y-1 text-xs text-slate-800 shadow-2xs">
            <div className="flex items-center gap-1.5 font-bold text-amber-800">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Important Digital Payment Notice</span>
            </div>
            <p className="text-[11px] text-slate-700 leading-relaxed">
              {result.digitalWarning}
            </p>
            <p className="text-[11px] font-semibold text-emerald-800">
              📌 Keep your invoice/receipt until the draw is completed.
            </p>
          </div>
        )}

        {/* Caveat & Next Steps */}
        <div className="space-y-1.5 pt-2 border-t border-slate-200/60 text-xs">
          {result.caveats.map((c, i) => (
            <p key={i} className="text-[11px] text-slate-600 italic">
              * {c}
            </p>
          ))}
        </div>
      </div>

      {/* FEATURE 4: CONNECT WITH COUPON MANAGER */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-start gap-2">
          <Ticket className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-xs font-bold text-slate-900">
              Do you already have a Prize Coupon Number?
            </h4>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Check your eSewa, Khalti, or Mobile Banking transaction receipt for a 12-digit number.
            </p>
          </div>
        </div>

        <div className="space-y-2 pt-1">
          {/* Yes - Add Coupon */}
          <button
            type="button"
            id="btn-elig-yes-add-coupon"
            onClick={handleGoToAddCoupon}
            className="w-full py-2.5 px-3.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all"
          >
            <Ticket className="w-4 h-4" />
            <span>Yes — Enter 12-Digit Coupon Now</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            {/* Not yet - Save as Awaiting */}
            <button
              type="button"
              id="btn-elig-awaiting-coupon"
              onClick={handleSaveAsAwaiting}
              className="py-2 px-2.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1"
            >
              <span>Not Yet (Save Awaiting)</span>
            </button>

            {/* Save Transaction */}
            <button
              type="button"
              id="btn-elig-save-tx"
              onClick={handleSaveTransaction}
              className="py-2 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1"
            >
              <span>Save Record Only</span>
            </button>
          </div>
        </div>
      </div>

      {/* Compact Trust & Disclaimer */}
      <TrustBanner 
        type="user-data"
        text="Rasid Khata is an independent helper app. This result is not an official IRD eligibility confirmation. Your transaction records are stored on this device."
      />
    </div>
  );
};
