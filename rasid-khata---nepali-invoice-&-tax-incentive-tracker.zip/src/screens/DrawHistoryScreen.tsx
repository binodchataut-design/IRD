import React, { useState } from 'react';
import { 
  Trophy, 
  Calendar, 
  ExternalLink, 
  PlusCircle, 
  Layers, 
  RotateCcw, 
  Trash2, 
  ChevronDown, 
  ChevronUp, 
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  BookOpen,
  X
} from 'lucide-react';
import { drawService } from '../services/drawService';
import { couponService } from '../services/couponService';
import { formatCouponNumber, parseWinningNumbersText } from '../utils/couponUtils';
import { DrawAnnouncement, ScreenName } from '../types/transaction';
import { TrustBanner } from '../components/common/TrustBanner';

interface DrawHistoryScreenProps {
  onNavigate: (screen: ScreenName, params?: { checkWinningNumbers?: string[] }) => void;
}

export const DrawHistoryScreen: React.FC<DrawHistoryScreenProps> = ({ onNavigate }) => {
  const [draws, setDraws] = useState<DrawAnnouncement[]>(() => drawService.getAll());
  const [expandedDrawId, setExpandedDrawId] = useState<string | null>(null);

  // Add Draw Modal State
  const [isAddingDraw, setIsAddingDraw] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newPeriod, setNewPeriod] = useState<string>('Bhadra 1–15, 2083');
  const [newDate, setNewDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [newNumbersText, setNewNumbersText] = useState<string>('');
  const [newSourceUrl, setNewSourceUrl] = useState<string>('https://ird.gov.np/notices');
  const [newNotes, setNewNotes] = useState<string>('');
  const [addError, setAddError] = useState<string | null>(null);

  const refreshDraws = () => {
    setDraws(drawService.getAll());
  };

  const toggleExpand = (id: string) => {
    setExpandedDrawId(prev => (prev === id ? null : id));
  };

  const handleDeleteDraw = (id: string, title: string) => {
    if (window.confirm(`Delete announcement "${title}"?`)) {
      drawService.delete(id);
      refreshDraws();
    }
  };

  const handleCheckDraw = (draw: DrawAnnouncement) => {
    onNavigate('winner_checker', { checkWinningNumbers: draw.winningNumbers });
  };

  const handleSaveNewDraw = (e: React.FormEvent) => {
    e.preventDefault();
    setAddError(null);

    const parsed = parseWinningNumbersText(newNumbersText);
    if (parsed.validWinningNumbers.length === 0) {
      setAddError('Please enter at least one valid 12-digit winning number.');
      return;
    }

    drawService.add({
      title: newTitle.trim() || `Draw (${newPeriod})`,
      drawPeriod: newPeriod.trim() || 'Fiscal Draw',
      announcementDate: newDate,
      winningNumbers: parsed.validWinningNumbers,
      sourceUrl: newSourceUrl.trim() || 'https://ird.gov.np',
      notes: newNotes.trim() || undefined,
    });

    setIsAddingDraw(false);
    setNewTitle('');
    setNewNumbersText('');
    setNewNotes('');
    refreshDraws();
  };

  const handleResetDraws = () => {
    if (window.confirm('Reset to default IRD sample draw records?')) {
      drawService.resetToDefault();
      refreshDraws();
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-20">
      {/* Header Info */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold">
              <Trophy className="w-4 h-4 text-teal-700" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Draw Announcements</h2>
              <p className="text-xs text-slate-500 font-medium">
                {draws.length} recorded winner announcement cycles
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={handleResetDraws}
              title="Reset default draws"
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setIsAddingDraw(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 shadow-xs"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Record Draw</span>
            </button>
          </div>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Historical winner numbers announced by the Inland Revenue Department. Check all your saved coupons against any draw with one tap.
        </p>
      </div>

      {/* Persistent Disclaimer */}
      <TrustBanner
        type="disclaimer"
        text="Draw results recorded here reflect manual entries from official IRD announcements. Official verification & claims must be submitted to IRD."
      />

      {/* List of Draws */}
      <div className="space-y-3">
        {draws.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-3 shadow-sm">
            <Trophy className="w-8 h-8 text-slate-300 mx-auto" />
            <h3 className="text-xs font-bold text-slate-800">No draws recorded</h3>
            <button
              type="button"
              onClick={() => setIsAddingDraw(true)}
              className="px-3.5 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-semibold"
            >
              Record First Draw
            </button>
          </div>
        ) : (
          draws.map(draw => {
            const isExpanded = expandedDrawId === draw.id;

            return (
              <div
                key={draw.id}
                id={`draw-card-${draw.id}`}
                className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:border-slate-300 transition-all space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 leading-snug">
                      {draw.title}
                    </h3>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                      <span className="bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200 px-1.5 py-0.2 rounded">
                        {draw.drawPeriod}
                      </span>
                      <span>•</span>
                      <div className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>{draw.announcementDate}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleDeleteDraw(draw.id, draw.title)}
                    className="text-slate-300 hover:text-rose-600 p-1 transition-colors"
                    title="Delete draw"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Draw Info Bar */}
                <div className="flex items-center justify-between text-xs text-slate-600 pt-1 border-t border-slate-100">
                  <span className="text-[11px]">
                    Winning Numbers: <strong className="font-mono text-slate-900">{draw.winningNumbers.length}</strong>
                  </span>

                  <button
                    type="button"
                    onClick={() => toggleExpand(draw.id)}
                    className="text-emerald-700 hover:text-emerald-800 font-semibold text-[11px] flex items-center gap-0.5"
                  >
                    <span>{isExpanded ? 'Hide Numbers' : 'View Numbers'}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* Expanded Winning Numbers Grid */}
                {isExpanded && (
                  <div className="p-3 bg-slate-50 rounded-lg space-y-2 border border-slate-100 animate-fadeIn">
                    <div className="text-[10px] font-bold text-slate-600 uppercase tracking-wider">
                      Announced 12-Digit Prize Numbers
                    </div>
                    <div className="grid grid-cols-2 gap-1.5 font-mono text-[11px] text-slate-800">
                      {draw.winningNumbers.map((num, i) => (
                        <div key={i} className="bg-white border border-slate-200 px-2 py-1 rounded text-center font-bold">
                          {formatCouponNumber(num)}
                        </div>
                      ))}
                    </div>
                    {draw.notes && (
                      <p className="text-[10px] text-slate-500 italic pt-1">
                        {draw.notes}
                      </p>
                    )}
                  </div>
                )}

                {/* 1-Tap Check Button */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => handleCheckDraw(draw)}
                    className="flex-1 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
                  >
                    <Trophy className="w-3.5 h-3.5 text-amber-300" />
                    <span>Check My Coupons Against This Draw</span>
                  </button>

                  {draw.sourceUrl && (
                    <a
                      href={draw.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 border border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-slate-800 rounded-lg transition-colors shrink-0"
                      title="View Official Source"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add New Draw Announcement Modal */}
      {isAddingDraw && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-teal-600" />
                <span>Record New Winner Announcement</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddingDraw(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {addError && (
              <div className="bg-rose-50 border border-rose-200 rounded-lg p-2.5 text-xs text-rose-800 font-medium">
                {addError}
              </div>
            )}

            <form onSubmit={handleSaveNewDraw} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="block font-bold text-slate-800">
                  Draw Title / Description
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Bhadra 1–15, 2083 Lottery Draw"
                  className="w-full p-2.5 rounded-lg border border-slate-300 outline-none focus:border-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="block font-medium text-slate-700">Scheme Period</label>
                  <input
                    type="text"
                    value={newPeriod}
                    onChange={(e) => setNewPeriod(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block font-medium text-slate-700">Announcement Date</label>
                  <input
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block font-bold text-slate-800">
                  Winning Numbers (Paste 12-digit numbers) *
                </label>
                <textarea
                  rows={4}
                  value={newNumbersText}
                  onChange={(e) => setNewNumbersText(e.target.value)}
                  placeholder={`007 315 254 493\n002 928 817 811\n003 066 779 589`}
                  className="w-full font-mono text-xs p-2.5 rounded-lg border border-slate-300 outline-none focus:border-emerald-600"
                />
              </div>

              <div className="space-y-1">
                <label className="block font-medium text-slate-700">Official Source URL</label>
                <input
                  type="url"
                  value={newSourceUrl}
                  onChange={(e) => setNewSourceUrl(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 outline-none font-mono text-[11px]"
                />
              </div>

              <div className="space-y-1">
                <label className="block font-medium text-slate-700">Notes</label>
                <input
                  type="text"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Optional context"
                  className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingDraw(false)}
                  className="px-3 py-2 border border-slate-200 rounded-lg text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700"
                >
                  Save Draw
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
