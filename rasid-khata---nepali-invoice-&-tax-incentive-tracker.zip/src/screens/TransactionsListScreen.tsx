import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Receipt, 
  Calendar, 
  ChevronRight, 
  Plus, 
  Wallet, 
  CreditCard, 
  Banknote, 
  Landmark, 
  HelpCircle,
  FileCheck2,
  X,
  Ticket,
  Sparkles,
  CheckCircle2,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { Transaction, PaymentMethod, ScreenName, EligibilityStatus } from '../types/transaction';
import { transactionService } from '../services/transactionService';

interface TransactionsListScreenProps {
  onNavigate: (screen: ScreenName, params?: { 
    transactionId?: string;
    prefillCoupon?: {
      merchantName?: string;
      amount?: number;
      date?: string;
      paymentMethod?: string;
      invoiceNumber?: string;
      fromTransactionId?: string;
    };
  }) => void;
}

export const TransactionsListScreen: React.FC<TransactionsListScreenProps> = ({
  onNavigate,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedMethod, setSelectedMethod] = useState<string>('all');

  const allTransactions = useMemo(() => {
    return transactionService.getAll();
  }, []);

  const filteredTransactions = useMemo(() => {
    let list = transactionService.search(searchQuery);
    if (selectedMethod !== 'all') {
      list = list.filter(t => t.paymentMethod === selectedMethod);
    }
    return list;
  }, [searchQuery, selectedMethod]);

  const totalAmount = useMemo(() => {
    return filteredTransactions.reduce((acc, curr) => {
      const val = typeof curr.amount === 'number' && !isNaN(curr.amount) && isFinite(curr.amount) ? curr.amount : 0;
      return acc + val;
    }, 0);
  }, [filteredTransactions]);

  const getPaymentMethodIcon = (method: PaymentMethod) => {
    switch (method) {
      case 'Digital Wallet':
        return <Wallet className="w-3 h-3 text-purple-600" />;
      case 'Card':
        return <CreditCard className="w-3 h-3 text-blue-600" />;
      case 'Cash':
        return <Banknote className="w-3 h-3 text-emerald-600" />;
      case 'Bank Transfer':
        return <Landmark className="w-3 h-3 text-amber-600" />;
      default:
        return <HelpCircle className="w-3 h-3 text-slate-500" />;
    }
  };

  const getStatusBadge = (status?: EligibilityStatus, couponNumber?: string) => {
    if (couponNumber || status === 'coupon_added') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 px-1.5 py-0.5 rounded">
          <Ticket className="w-2.5 h-2.5" />
          Coupon Added
        </span>
      );
    }
    if (status === 'awaiting_coupon') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.5 rounded">
          <AlertTriangle className="w-2.5 h-2.5" />
          Awaiting Coupon
        </span>
      );
    }
    if (status === 'likely_eligible') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded">
          <CheckCircle2 className="w-2.5 h-2.5" />
          Likely Eligible
        </span>
      );
    }
    if (status === 'likely_not_eligible') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200 px-1.5 py-0.5 rounded">
          <XCircle className="w-2.5 h-2.5" />
          Likely Not Eligible
        </span>
      );
    }
    if (status === 'needs_verification') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200 px-1.5 py-0.5 rounded">
          <AlertTriangle className="w-2.5 h-2.5" />
          Needs Verification
        </span>
      );
    }
    return (
      <span className="text-[9px] font-medium text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
        Not Checked
      </span>
    );
  };

  const formatAmount = (num: number) => {
    if (typeof num !== 'number' || isNaN(num) || !isFinite(num)) {
      return '0.00';
    }
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 2,
      minimumFractionDigits: 0
    }).format(num);
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-12">
      {/* Header & Quick Counter Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-900">My Transactions</h2>
            <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
              {filteredTransactions.length}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Personal offline invoice and payment records
          </p>
        </div>

        <button
          id="btn-add-tx-from-list"
          onClick={() => onNavigate('add_transaction')}
          className="bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-semibold px-3 py-2 rounded-lg flex items-center gap-1.5 shadow-sm transition-all"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Bill</span>
        </button>
      </div>

      {/* Simple Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          id="search-transactions-input"
          type="text"
          placeholder="Search seller, PAN, or invoice number..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-white border border-slate-200 rounded-lg pl-8 pr-8 py-2 text-xs text-slate-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 placeholder:text-slate-400"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Payment Method Quick Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar text-xs">
        {['all', 'Digital Wallet', 'Card', 'Cash', 'Bank Transfer'].map((filter) => {
          const isSelected = selectedMethod === filter;
          return (
            <button
              key={filter}
              id={`filter-chip-${filter.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setSelectedMethod(filter)}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider whitespace-nowrap transition-colors border ${
                isSelected
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {filter === 'all' ? 'All Methods' : filter}
            </button>
          );
        })}
      </div>

      {/* Summary Total Pill */}
      {filteredTransactions.length > 0 && (
        <div className="bg-slate-50 border border-slate-200/80 rounded-lg px-3.5 py-2.5 flex items-center justify-between text-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Filtered Total:</span>
          <span className="text-slate-900 font-bold text-xs">
            रू {formatAmount(totalAmount)}
          </span>
        </div>
      )}

      {/* Chronological Transaction List */}
      <div className="space-y-2.5">
        {filteredTransactions.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-3 shadow-sm">
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">No transactions found</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                {searchQuery || selectedMethod !== 'all'
                  ? 'Try adjusting your search query or payment filter.'
                  : 'You have not added any purchase records yet.'}
              </p>
            </div>
            <button
              id="empty-state-add-btn"
              onClick={() => onNavigate('add_transaction')}
              className="mt-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-2 rounded-lg inline-flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record First Transaction</span>
            </button>
          </div>
        ) : (
          filteredTransactions.map((tx) => (
            <div
              key={tx.id}
              id={`tx-item-${tx.id}`}
              onClick={() => onNavigate('transaction_detail', { transactionId: tx.id })}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-3.5 cursor-pointer shadow-sm transition-all group"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  {/* Date & Invoice No */}
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      {tx.date}
                    </span>
                    {tx.invoiceNumber && (
                      <span className="text-[9px] font-mono bg-slate-100 text-slate-600 px-1 py-0.5 rounded">
                        #{tx.invoiceNumber}
                      </span>
                    )}
                  </div>

                  {/* Seller Name */}
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-bold text-slate-900 truncate group-hover:text-emerald-700">
                      {tx.sellerName}
                    </h3>
                    {getStatusBadge(tx.eligibilityStatus, tx.couponNumber)}
                  </div>

                  {/* Payment Method Badge & Photo Indicator */}
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-slate-50 border border-slate-200 text-slate-700 px-1.5 py-0.5 rounded">
                      {getPaymentMethodIcon(tx.paymentMethod)}
                      {tx.paymentMethod}
                    </span>

                    {tx.sellerPanVat && (
                      <span className="text-[10px] text-slate-400 font-mono">
                        PAN: {tx.sellerPanVat}
                      </span>
                    )}

                    {tx.couponNumber && (
                      <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                        🎟️ {tx.couponNumber.slice(0, 3)}...{tx.couponNumber.slice(-4)}
                      </span>
                    )}

                    {tx.invoicePhotoUrl && (
                      <span className="text-[9px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded flex items-center gap-0.5 font-medium">
                        <FileCheck2 className="w-2.5 h-2.5" />
                        Bill photo
                      </span>
                    )}
                  </div>

                  {/* Quick Action when Awaiting Coupon */}
                  {tx.eligibilityStatus === 'awaiting_coupon' && !tx.couponNumber && (
                    <div className="mt-2 pt-1.5 border-t border-slate-100 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onNavigate('add_coupon', {
                            prefillCoupon: {
                              merchantName: tx.sellerName,
                              amount: tx.amount,
                              date: tx.date,
                              paymentMethod: tx.paymentMethod,
                              invoiceNumber: tx.invoiceNumber,
                              fromTransactionId: tx.id,
                            }
                          });
                        }}
                        className="text-[10px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded-md flex items-center gap-1 transition-colors"
                      >
                        <Ticket className="w-3 h-3" />
                        <span>Add Prize Coupon</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Amount & Arrow */}
                <div className="text-right shrink-0 flex flex-col items-end justify-between self-stretch">
                  <div className="text-xs font-bold text-emerald-600">
                    रू {formatAmount(tx.amount)}
                  </div>
                  <div className="text-[10px] text-slate-400 group-hover:text-emerald-700 font-medium flex items-center gap-0.5 mt-auto">
                    <span>Details</span>
                    <ChevronRight className="w-3 h-3" />
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
