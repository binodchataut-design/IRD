import React, { useState, useRef } from 'react';
import { 
  Download, 
  Upload, 
  FileSpreadsheet, 
  Database, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw, 
  Trash2, 
  FileText, 
  ArrowLeft,
  Info,
  HardDrive,
  Ticket,
  Receipt,
  Check,
  AlertCircle,
  Copy,
  ClipboardPaste
} from 'lucide-react';
import { ScreenName, BackupValidationResult, RestoreMode, RestoreResult } from '../types/transaction';
import { backupService } from '../services/backupService';
import { exportUtils } from '../utils/exportUtils';
import { transactionService } from '../services/transactionService';
import { couponService } from '../services/couponService';
import { drawService } from '../services/drawService';

interface DataBackupScreenProps {
  onNavigate: (screen: ScreenName) => void;
  onBack?: () => void;
}

export const DataBackupScreen: React.FC<DataBackupScreenProps> = ({
  onNavigate,
  onBack,
}) => {
  // Storage Stats State
  const [stats, setStats] = useState(() => backupService.getStorageStats());

  // Feedback Notification State
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error' | 'info';
    title: string;
    message: string;
  } | null>(null);

  // Restore Staging State
  const [stagedFile, setStagedFile] = useState<{
    name: string;
    size: number;
    rawText: string;
    validation: BackupValidationResult;
  } | null>(null);
  const [restoreMode, setRestoreMode] = useState<RestoreMode>('merge');
  const [confirmReplaceChecked, setConfirmReplaceChecked] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Danger Action Modals
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showPasteModal, setShowPasteModal] = useState(false);
  const [pastedJsonText, setPastedJsonText] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const refreshStats = () => {
    setStats(backupService.getStorageStats());
  };

  // 1. Export JSON Backup
  const handleExportJson = () => {
    try {
      const result = backupService.exportBackupFile();
      setFeedback({
        type: 'success',
        title: 'Backup Downloaded Successfully',
        message: `Saved ${result.filename} (${Math.round(result.sizeBytes / 1024)} KB) with ${stats.transactionCount} invoices and ${stats.couponCount} coupons.`,
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'Export Failed',
        message: err?.message || 'Could not generate backup file. Please try again.',
      });
    }
  };

  // 1b. Copy JSON Backup to Clipboard
  const handleCopyJson = async () => {
    try {
      const result = await backupService.copyBackupToClipboard();
      setFeedback({
        type: 'success',
        title: 'Backup Copied to Clipboard',
        message: `Complete JSON snapshot payload (${Math.round(result.sizeBytes / 1024)} KB) copied. You can paste it into a file or another browser.`,
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'Copy Failed',
        message: err?.message || 'Could not copy backup JSON to clipboard.',
      });
    }
  };

  // 1c. Process Pasted JSON
  const handleProcessPastedJson = () => {
    if (!pastedJsonText.trim()) {
      setFeedback({
        type: 'error',
        title: 'Empty Input',
        message: 'Please paste your Rasid Khata backup JSON text.',
      });
      return;
    }
    const validation = backupService.validateBackupJson(pastedJsonText);
    setStagedFile({
      name: 'pasted-backup-payload.json',
      size: new Blob([pastedJsonText]).size,
      rawText: pastedJsonText,
      validation,
    });
    setConfirmReplaceChecked(false);
    setRestoreMode('merge');
    setShowPasteModal(false);
    setPastedJsonText('');
  };

  // 2. Export Invoices CSV
  const handleExportInvoicesCsv = () => {
    try {
      const allTx = transactionService.getAll();
      if (allTx.length === 0) {
        setFeedback({
          type: 'info',
          title: 'No Invoices Found',
          message: 'There are no purchase invoices recorded to export.',
        });
        return;
      }
      const result = exportUtils.exportTransactionsToCsv(allTx);
      setFeedback({
        type: 'success',
        title: 'Invoices CSV Exported',
        message: `Exported ${result.count} invoice records to ${result.filename} with UTF-8 Nepali support.`,
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'CSV Export Failed',
        message: err?.message || 'Failed to export invoices CSV.',
      });
    }
  };

  // 3. Export Coupons CSV
  const handleExportCouponsCsv = () => {
    try {
      const allCoupons = couponService.getAll();
      if (allCoupons.length === 0) {
        setFeedback({
          type: 'info',
          title: 'No Coupons Found',
          message: 'There are no 12-digit prize coupons recorded to export.',
        });
        return;
      }
      const result = exportUtils.exportCouponsToCsv(allCoupons);
      setFeedback({
        type: 'success',
        title: 'Coupons CSV Exported',
        message: `Exported ${result.count} coupon records to ${result.filename} (leading zeros preserved).`,
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'CSV Export Failed',
        message: err?.message || 'Failed to export coupons CSV.',
      });
    }
  };

  // 4. File Upload Handler
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const validation = backupService.validateBackupJson(content);
      setStagedFile({
        name: file.name,
        size: file.size,
        rawText: content,
        validation,
      });
      setConfirmReplaceChecked(false);
      setRestoreMode('merge');
    };
    reader.onerror = () => {
      setFeedback({
        type: 'error',
        title: 'File Read Error',
        message: 'Could not read the selected file.',
      });
    };
    reader.readAsText(file);

    // Reset input value so same file can be selected again
    e.target.value = '';
  };

  // 5. Execute Restore
  const handleExecuteRestore = () => {
    if (!stagedFile || !stagedFile.validation.isValid || !stagedFile.validation.backupData) {
      return;
    }

    if (restoreMode === 'replace' && !confirmReplaceChecked) {
      setFeedback({
        type: 'error',
        title: 'Confirmation Required',
        message: 'Please check the box confirming you wish to replace your current records.',
      });
      return;
    }

    setIsProcessing(true);
    try {
      const result: RestoreResult = backupService.restoreBackup(
        stagedFile.validation.backupData,
        restoreMode
      );

      if (result.success) {
        refreshStats();
        setStagedFile(null);
        setFeedback({
          type: 'success',
          title: `Data Restored (${restoreMode === 'replace' ? 'Replaced' : 'Merged'})`,
          message: `Successfully imported ${result.transactionsImported} invoices and ${result.couponsImported} coupons.${
            restoreMode === 'merge' && (result.transactionsSkipped > 0 || result.couponsSkipped > 0)
              ? ` Skipped duplicates: ${result.transactionsSkipped} invoices, ${result.couponsSkipped} coupons.`
              : ''
          }`,
        });
      } else {
        setFeedback({
          type: 'error',
          title: 'Restore Failed',
          message: result.error || 'An unexpected error occurred during restoration.',
        });
      }
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'Restore Error',
        message: err?.message || 'Failed to restore backup.',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // 6. Reset to Initial Mock Data
  const handleResetToDemo = () => {
    transactionService.resetToMock();
    couponService.resetToMock();
    drawService.resetToDefault();
    refreshStats();
    setShowResetConfirm(false);
    setFeedback({
      type: 'info',
      title: 'Demo Data Reset',
      message: 'Restored the 25 sample invoices and 28 prize coupons for testing.',
    });
  };

  // 7. Clear All Storage
  const handleClearAll = () => {
    transactionService.clearAll();
    couponService.clearAll();
    refreshStats();
    setShowClearConfirm(false);
    setFeedback({
      type: 'info',
      title: 'Storage Cleared',
      message: 'All local invoice records and coupons have been cleared.',
    });
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 pb-12">
      {/* Top Breadcrumb / Title Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {onBack && (
            <button
              onClick={onBack}
              className="p-1.5 -ml-1 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900">
              Data &amp; Backup (डाटा तथा ब्याकअप)
            </h2>
            <p className="text-xs text-slate-500">
              Manage offline storage, export spreadsheets, and restore your records safely.
            </p>
          </div>
        </div>
      </div>

      {/* Notification / Feedback Banner */}
      {feedback && (
        <div
          className={`p-4 rounded-xl border flex items-start gap-3 transition-all ${
            feedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : feedback.type === 'error'
              ? 'bg-red-50 border-red-200 text-red-900'
              : 'bg-blue-50 border-blue-200 text-blue-900'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : feedback.type === 'error' ? (
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          ) : (
            <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          )}
          <div className="flex-1 text-xs">
            <h4 className="font-bold">{feedback.title}</h4>
            <p className="mt-0.5 leading-relaxed">{feedback.message}</p>
          </div>
          <button
            onClick={() => setFeedback(null)}
            className="text-slate-400 hover:text-slate-700 text-xs font-semibold px-1"
          >
            ✕
          </button>
        </div>
      )}

      {/* Offline Storage Status & Trust Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-xs relative overflow-hidden">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              100% Offline-First Storage
            </div>
            <h3 className="text-base font-bold text-white pt-1">
              Your Data Stays on Your Device
            </h3>
            <p className="text-xs text-slate-300 max-w-md leading-relaxed">
              Rasid Khata does not upload or sync your bills to external servers. Export backups regularly so you can restore your data whenever needed.
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-teal-300 shrink-0">
            <HardDrive className="w-5 h-5" />
          </div>
        </div>

        {/* Live Storage Metrics Grid */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3 mt-4 pt-4 border-t border-slate-800 text-center">
          <div className="bg-white/5 rounded-xl p-2.5">
            <div className="text-lg sm:text-xl font-bold text-white">
              {stats.transactionCount}
            </div>
            <div className="text-[10px] sm:text-[11px] text-slate-400">
              Invoices Recorded
            </div>
          </div>
          <div className="bg-white/5 rounded-xl p-2.5">
            <div className="text-lg sm:text-xl font-bold text-emerald-400">
              {stats.couponCount}
            </div>
            <div className="text-[10px] sm:text-[11px] text-slate-400">
              12-Digit Coupons
            </div>
          </div>
          <div className="bg-white/5 rounded-xl p-2.5">
            <div className="text-lg sm:text-xl font-bold text-teal-300">
              {stats.storageSizeKb} <span className="text-xs font-normal">KB</span>
            </div>
            <div className="text-[10px] sm:text-[11px] text-slate-400">
              Local Storage Used
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 1: Full JSON Backup & Restore */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Database className="w-4 h-4 text-emerald-700" />
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Full Backup &amp; Restore (JSON)
          </h3>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Create a full snapshot of your invoices, coupons, and custom draws in a single versioned <code className="text-emerald-800 bg-emerald-50 px-1 py-0.5 rounded font-mono">.json</code> file.
        </p>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          {/* Export JSON Button */}
          <button
            id="export-json-backup-btn"
            onClick={handleExportJson}
            className="flex items-center justify-center gap-2 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white px-4 py-3 rounded-xl text-xs font-bold shadow-xs transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export Full Backup (.json)</span>
          </button>

          {/* Copy JSON Button */}
          <button
            id="copy-json-backup-btn"
            onClick={handleCopyJson}
            className="flex items-center justify-center gap-2 bg-white hover:bg-slate-50 active:bg-slate-100 text-emerald-800 border border-emerald-300 px-4 py-3 rounded-xl text-xs font-bold shadow-2xs transition-colors"
          >
            <Copy className="w-4 h-4 text-emerald-600" />
            <span>Copy Backup to Clipboard</span>
          </button>

          {/* Trigger File Picker */}
          <label
            id="restore-file-picker-label"
            htmlFor="restore-file-input"
            className="flex items-center justify-center gap-2 bg-white hover:bg-slate-50 active:bg-slate-100 text-slate-700 border border-slate-300 px-4 py-3 rounded-xl text-xs font-bold cursor-pointer transition-colors"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            <span>Select Backup File to Restore</span>
            <input
              id="restore-file-input"
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleFileSelect}
              className="hidden"
            />
          </label>

          {/* Paste JSON Modal Trigger */}
          <button
            id="paste-json-backup-trigger-btn"
            onClick={() => setShowPasteModal(true)}
            className="flex items-center justify-center gap-2 bg-white hover:bg-slate-50 active:bg-slate-100 text-slate-700 border border-slate-300 px-4 py-3 rounded-xl text-xs font-bold transition-colors"
          >
            <ClipboardPaste className="w-4 h-4 text-slate-500" />
            <span>Paste Backup JSON Directly</span>
          </button>
        </div>

        {/* Pre-Restore Inspection Modal / Staging Card */}
        {stagedFile && (
          <div className="mt-4 border-2 border-emerald-600/40 bg-emerald-50/40 rounded-xl p-4 space-y-4 animate-in fade-in">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-700" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900">
                    Inspecting: {stagedFile.name}
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    File size: {Math.round(stagedFile.size / 1024)} KB
                  </p>
                </div>
              </div>
              <button
                onClick={() => setStagedFile(null)}
                className="text-xs text-slate-400 hover:text-slate-700 font-semibold px-2 py-1"
              >
                Cancel
              </button>
            </div>

            {/* Validation Outcome */}
            {!stagedFile.validation.isValid ? (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-xs text-red-900 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Backup File Validation Failed</div>
                  <div className="mt-0.5 text-red-800 leading-relaxed">
                    {stagedFile.validation.error}
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {/* Validated Stats */}
                <div className="bg-white border border-slate-200 rounded-lg p-3 text-xs grid grid-cols-3 gap-2 text-center">
                  <div>
                    <div className="text-slate-400 text-[10px]">Invoices</div>
                    <div className="font-bold text-slate-900">
                      {stagedFile.validation.stats?.transactionCount}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-[10px]">Coupons</div>
                    <div className="font-bold text-emerald-700">
                      {stagedFile.validation.stats?.couponCount}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-[10px]">Export Date</div>
                    <div className="font-semibold text-slate-700 text-[11px] truncate">
                      {stagedFile.validation.stats?.exportedAt
                        ? new Date(stagedFile.validation.stats.exportedAt).toLocaleDateString()
                        : 'N/A'}
                    </div>
                  </div>
                </div>

                {/* Mode Selector */}
                <div className="space-y-2 pt-1">
                  <span className="text-xs font-bold text-slate-800">
                    Choose Restoration Method:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label
                      className={`p-3 rounded-lg border text-xs cursor-pointer flex items-start gap-2.5 transition-all ${
                        restoreMode === 'merge'
                          ? 'border-emerald-600 bg-white shadow-2xs'
                          : 'border-slate-200 bg-slate-50/60 opacity-80'
                      }`}
                    >
                      <input
                        type="radio"
                        name="restoreMode"
                        value="merge"
                        checked={restoreMode === 'merge'}
                        onChange={() => setRestoreMode('merge')}
                        className="mt-0.5 text-emerald-600 focus:ring-emerald-500"
                      />
                      <div>
                        <div className="font-bold text-slate-900">Merge with Current Data</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          Adds new items without deleting existing records. Duplicates are skipped.
                        </div>
                      </div>
                    </label>

                    <label
                      className={`p-3 rounded-lg border text-xs cursor-pointer flex items-start gap-2.5 transition-all ${
                        restoreMode === 'replace'
                          ? 'border-amber-600 bg-white shadow-2xs'
                          : 'border-slate-200 bg-slate-50/60 opacity-80'
                      }`}
                    >
                      <input
                        type="radio"
                        name="restoreMode"
                        value="replace"
                        checked={restoreMode === 'replace'}
                        onChange={() => setRestoreMode('replace')}
                        className="mt-0.5 text-amber-600 focus:ring-amber-500"
                      />
                      <div>
                        <div className="font-bold text-slate-900">Replace All Current Data</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          Overwrites all existing invoices and coupons with the backup file.
                        </div>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Replacement Confirmation Checkbox */}
                {restoreMode === 'replace' && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-900">
                    <label className="flex items-start gap-2.5 cursor-pointer">
                      <input
                        id="confirm-replace-checkbox"
                        type="checkbox"
                        checked={confirmReplaceChecked}
                        onChange={(e) => setConfirmReplaceChecked(e.target.checked)}
                        className="mt-0.5 rounded text-amber-600 focus:ring-amber-500"
                      />
                      <span className="font-medium leading-relaxed">
                        I understand this will permanently overwrite my current {stats.transactionCount} invoices and {stats.couponCount} coupons with the backup file.
                      </span>
                    </label>
                  </div>
                )}

                {/* Confirm Restore Button */}
                <button
                  id="execute-restore-btn"
                  onClick={handleExecuteRestore}
                  disabled={isProcessing || (restoreMode === 'replace' && !confirmReplaceChecked)}
                  className={`w-full py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors ${
                    isProcessing || (restoreMode === 'replace' && !confirmReplaceChecked)
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>{isProcessing ? 'Restoring Data...' : `Confirm & Restore (${restoreMode === 'merge' ? 'Merge' : 'Replace'})`}</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* SECTION 2: CSV Data Exports */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Spreadsheet Exports (CSV)
          </h3>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Download tabular CSV spreadsheets for use in Microsoft Excel, Apple Numbers, Google Sheets, or tax filing reviews.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          {/* Export Invoices CSV */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                <Receipt className="w-4 h-4 text-emerald-700" />
                <span>Invoices &amp; Bills CSV</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Includes purchase date, merchant, amount, payment method, PAN/VAT, invoice #, and eligibility.
              </p>
            </div>
            <button
              id="export-invoices-csv-btn"
              onClick={handleExportInvoicesCsv}
              className="w-full flex items-center justify-center gap-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 px-3 py-2 rounded-lg text-xs font-bold transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Invoices CSV</span>
            </button>
          </div>

          {/* Export Coupons CSV */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                <Ticket className="w-4 h-4 text-emerald-700" />
                <span>Prize Coupons CSV</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Includes 12-digit coupon numbers formatted to preserve leading zeros in Excel and Numbers.
              </p>
            </div>
            <button
              id="export-coupons-csv-btn"
              onClick={handleExportCouponsCsv}
              className="w-full flex items-center justify-center gap-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 px-3 py-2 rounded-lg text-xs font-bold transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Coupons CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 3: Storage Maintenance & Reset */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <RefreshCw className="w-4 h-4 text-slate-600" />
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Storage Maintenance &amp; Reset
          </h3>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Manage demo records or reset local storage for testing and data cleanup.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 pt-1">
          {/* Reset Demo Data */}
          <button
            id="reset-demo-data-btn"
            onClick={() => setShowResetConfirm(true)}
            className="flex-1 flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 px-4 py-2.5 rounded-xl text-xs font-semibold transition-colors"
          >
            <RefreshCw className="w-4 h-4 text-slate-500" />
            <span>Reset Demo Dataset</span>
          </button>

          {/* Clear Storage */}
          <button
            id="clear-all-data-btn"
            onClick={() => setShowClearConfirm(true)}
            className="flex-1 flex items-center justify-center gap-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 px-4 py-2.5 rounded-xl text-xs font-semibold transition-colors"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
            <span>Clear All Local Data</span>
          </button>
        </div>
      </div>

      {/* Confirmation Modal: Reset Demo */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-slate-900">
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                <RefreshCw className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold">Reset Demo Dataset?</h4>
                <p className="text-xs text-slate-500">Restore 25 sample invoices and 28 coupons</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              This will reload the initial sample dataset representing realistic Nepali grocery, pharmacy, and electronic purchases.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleResetToDemo}
                className="px-4 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-900 rounded-lg"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal: Clear All */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-red-900">
              <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-red-600">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold">Clear All Local Records?</h4>
                <p className="text-xs text-red-500">This action cannot be undone</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to delete all saved invoices and coupons from this device? We recommend exporting a JSON backup first.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAll}
                className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg"
              >
                Yes, Clear All
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Paste JSON Modal */}
      {showPasteModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-slate-900">
                <ClipboardPaste className="w-5 h-5 text-emerald-700" />
                <h4 className="text-sm font-bold">Paste Backup JSON Content</h4>
              </div>
              <button
                onClick={() => {
                  setShowPasteModal(false);
                  setPastedJsonText('');
                }}
                className="text-slate-400 hover:text-slate-700 text-xs font-semibold px-2"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Paste the full JSON string from a previous Rasid Khata backup. The structure and version will be strictly verified before restoring.
            </p>
            <div>
              <textarea
                id="paste-backup-json-textarea"
                value={pastedJsonText}
                onChange={(e) => setPastedJsonText(e.target.value)}
                placeholder='{"app": "Rasid Khata", "backupVersion": 1, "transactions": [...], "coupons": [...]}'
                rows={8}
                className="w-full font-mono text-xs p-3 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 bg-slate-50 text-slate-800"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                onClick={() => {
                  setShowPasteModal(false);
                  setPastedJsonText('');
                }}
                className="px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                id="validate-pasted-json-btn"
                onClick={handleProcessPastedJson}
                disabled={!pastedJsonText.trim()}
                className={`px-4 py-2 text-xs font-bold rounded-lg ${
                  !pastedJsonText.trim()
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                }`}
              >
                Validate &amp; Inspect Backup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
