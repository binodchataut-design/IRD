import React, { useState } from 'react';
import { 
  PlusCircle, 
  Receipt, 
  ArrowRight, 
  ShieldCheck, 
  Sparkles, 
  Trophy, 
  Ticket, 
  ChevronRight,
  Clock,
  AlertTriangle,
  QrCode,
  FileCheck2,
  ChevronDown,
  ChevronUp,
  Database
} from 'lucide-react';

import { ScreenName } from '../types/transaction';
import { irdInfoService } from '../services/irdInfoService';
import { transactionService } from '../services/transactionService';
import { couponService } from '../services/couponService';
import { drawService } from '../services/drawService';
import { nepaliDateService } from '../services/nepaliDateService';

interface HomeScreenProps {
  onNavigate: (screen: ScreenName, params?: { selectedNoticeId?: string; checkWinningNumbers?: string[] }) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onNavigate }) => {
  const [showHowItWorks, setShowHowItWorks] = useState<boolean>(true);
  const latestNotices = irdInfoService.getLatest(3);
  const transactions = transactionService.getAll();
  const coupons = couponService.getAll();
  const draws = drawService.getAll();

  const awaitingCouponCount = transactions.filter(t => t.eligibilityStatus === 'awaiting_coupon').length;
  const currentDrawCycle = nepaliDateService.getCurrentCycle();

  return (
    <div className="flex-1 flex flex-col p-4 space-y-4 max-w-lg mx-auto w-full pb-20">
      {/* App Identity & Explanation Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow-xs shrink-0">
              <span>र</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="font-bold text-base tracking-tight text-slate-900">
                  Rasid Khata
                </h2>
                <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 px-1.5 py-0.2 rounded">
                  रसिद खाता
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                Nepal IRD Taxpayer Incentive &amp; Coupon Checker
              </p>
            </div>
          </div>
          <span className="text-[10px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
            Personal Helper
          </span>
        </div>

        {/* Value Explanation in Callout Box */}
        <div className="p-3 bg-emerald-50/60 rounded-lg border border-emerald-100 text-xs leading-relaxed text-emerald-950 font-medium space-y-1">
          <p>
            Track your purchases, check tax lottery eligibility, and check 12-digit prize coupon numbers against official IRD winning draws.
          </p>
        </div>

        {/* Local & Unofficial Guarantee */}
        <div className="flex items-center justify-between pt-1 text-[10px] text-slate-400 font-medium border-t border-slate-100">
          <span className="flex items-center gap-1 text-slate-600">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>100% Offline Local Storage</span>
          </span>
          <span>Unofficial independent app</span>
        </div>
      </div>

      {/* FEATURE: MY IRD TRACKING SUMMARY CARD */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              My IRD Tracking
            </h3>
          </div>
          <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
            Cycle: {currentDrawCycle.drawPeriod.split(',')[0]}
          </span>
        </div>

        {/* 4 Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {/* Coupons Saved */}
          <div 
            onClick={() => onNavigate('my_coupons')}
            className="p-2.5 bg-emerald-50/60 border border-emerald-200 rounded-lg cursor-pointer hover:bg-emerald-100/60 transition-colors"
          >
            <div className="text-[10px] font-bold uppercase text-emerald-800 flex items-center gap-1">
              <Ticket className="w-3 h-3 text-emerald-600" />
              <span>Coupons</span>
            </div>
            <div className="text-lg font-mono font-bold text-emerald-950 mt-1">
              {coupons.length}
            </div>
            <div className="text-[9px] text-emerald-700">Saved 12-digit</div>
          </div>

          {/* Awaiting Coupons */}
          <div 
            onClick={() => onNavigate('my_transactions')}
            className="p-2.5 bg-amber-50/60 border border-amber-200 rounded-lg cursor-pointer hover:bg-amber-100/60 transition-colors"
          >
            <div className="text-[10px] font-bold uppercase text-amber-800 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3 text-amber-600" />
              <span>Awaiting</span>
            </div>
            <div className="text-lg font-mono font-bold text-amber-950 mt-1">
              {awaitingCouponCount}
            </div>
            <div className="text-[9px] text-amber-700">Need 12-digit</div>
          </div>

          {/* Total Invoices */}
          <div 
            onClick={() => onNavigate('my_transactions')}
            className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100 transition-colors"
          >
            <div className="text-[10px] font-bold uppercase text-slate-600 flex items-center gap-1">
              <Receipt className="w-3 h-3 text-slate-500" />
              <span>Invoices</span>
            </div>
            <div className="text-lg font-mono font-bold text-slate-900 mt-1">
              {transactions.length}
            </div>
            <div className="text-[9px] text-slate-500">Tracked bills</div>
          </div>

          {/* IRD Draws */}
          <div 
            onClick={() => onNavigate('draw_history')}
            className="p-2.5 bg-teal-50/60 border border-teal-200 rounded-lg cursor-pointer hover:bg-teal-100/60 transition-colors"
          >
            <div className="text-[10px] font-bold uppercase text-teal-800 flex items-center gap-1">
              <Clock className="w-3 h-3 text-teal-600" />
              <span>Draws</span>
            </div>
            <div className="text-lg font-mono font-bold text-teal-950 mt-1">
              {draws.length}
            </div>
            <div className="text-[9px] text-teal-700">Announced</div>
          </div>
        </div>

        {/* Current Draw Cycle Pill */}
        <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-600">
            <Clock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span className="text-[11px]">Next Announcement:</span>
            <span className="font-semibold text-slate-800 text-[11px]">{currentDrawCycle.expectedAnnouncement}</span>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('draw_history')}
            className="text-[10px] font-bold text-emerald-700 hover:underline"
          >
            View Cycles →
          </button>
        </div>
      </div>

      {/* FEATURE 1: CHECK TRANSACTION ELIGIBILITY PROMINENT ACTION */}
      <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-5 rounded-2xl shadow-md space-y-3 relative overflow-hidden">
        <div className="space-y-1 relative z-10">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-200 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              <span>New Helper Tool</span>
            </span>
            <span className="text-[10px] font-bold bg-white/20 px-2 py-0.5 rounded text-white">
              Instant Check
            </span>
          </div>
          <h3 className="text-base font-bold text-white leading-tight">
            Check Transaction Eligibility
          </h3>
          <p className="text-xs text-emerald-100 font-medium">
            मेरो कारोबार योग्य छ कि छैन? — Find out if your purchase qualifies for the IRD gift lottery.
          </p>
        </div>

        <div className="pt-1 flex items-center gap-2 relative z-10">
          <button
            id="home-btn-check-eligibility"
            type="button"
            onClick={() => onNavigate('check_eligibility')}
            className="w-full py-2.5 px-4 bg-white hover:bg-emerald-50 active:bg-slate-100 text-emerald-950 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-emerald-700" />
            <span>Check My Purchase (5 Quick Questions)</span>
            <ArrowRight className="w-4 h-4 text-emerald-700 ml-0.5" />
          </button>
        </div>
      </div>

      {/* Primary Feature Highlight: WINNER CHECKER */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white p-5 rounded-2xl shadow-md space-y-3 relative overflow-hidden">
        <div className="flex items-start justify-between relative z-10">
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5" />
              <span>Core Tool</span>
            </span>
            <h3 className="text-base font-bold text-white leading-tight">
              Winner Number Checker
            </h3>
            <p className="text-xs text-slate-300">
              Have winning numbers been announced? Compare all your saved coupons in 1 second.
            </p>
          </div>
        </div>

        <div className="pt-1 flex items-center gap-2 relative z-10">
          <button
            id="home-hero-btn-check-winners"
            type="button"
            onClick={() => onNavigate('winner_checker')}
            className="flex-1 py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-slate-950 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 shadow-sm"
          >
            <Trophy className="w-4 h-4 text-amber-900" />
            <span>Check My {coupons.length} Coupons</span>
          </button>
        </div>
      </div>

      {/* Main Quick Action Cards Grid */}
      <div className="grid grid-cols-2 gap-3">
        {/* My Coupons Card */}
        <div 
          onClick={() => onNavigate('my_coupons')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-300 hover:bg-slate-50/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center">
              <Ticket className="w-4 h-4" />
            </div>
            <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-100/60 px-2 py-0.5 rounded-full">
              {coupons.length}
            </span>
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-700">
              My Coupons
            </h4>
            <p className="text-[11px] text-slate-500 leading-tight mt-0.5">
              12-digit prize numbers
            </p>
          </div>
        </div>

        {/* Add Coupons Card */}
        <div 
          onClick={() => onNavigate('add_coupon')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-300 hover:bg-slate-50/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center">
              <PlusCircle className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded">
              Add New
            </span>
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-700">
              Add Coupon
            </h4>
            <p className="text-[11px] text-slate-500 leading-tight mt-0.5">
              Single or bulk entry
            </p>
          </div>
        </div>

        {/* Add Invoices / Bills Card */}
        <div 
          onClick={() => onNavigate('add_transaction')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-300 hover:bg-slate-50/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
              <Receipt className="w-4 h-4" />
            </div>
            <span className="text-[10px] text-slate-400 font-semibold">
              New Bill
            </span>
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 group-hover:text-slate-700">
              Add Invoice
            </h4>
            <p className="text-[11px] text-slate-500 leading-tight mt-0.5">
              Record purchase &amp; photo
            </p>
          </div>
        </div>

        {/* My Invoice Records Card */}
        <div 
          onClick={() => onNavigate('my_transactions')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-300 hover:bg-slate-50/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
              <FileCheck2 className="w-4 h-4" />
            </div>
            <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-full">
              {transactions.length}
            </span>
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 group-hover:text-slate-700">
              Invoice Records
            </h4>
            <p className="text-[11px] text-slate-500 leading-tight mt-0.5">
              Saved VAT bills
            </p>
          </div>
        </div>
      </div>

      {/* FEATURE: DATA & BACKUP PROMPT CARD */}
      <div 
        id="home-card-data-backup"
        onClick={() => onNavigate('data_backup')}
        className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-300 hover:bg-slate-50/60 cursor-pointer transition-all flex items-center justify-between group"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-teal-50 border border-teal-200 text-teal-700 flex items-center justify-center shrink-0">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h4 className="text-xs font-bold text-slate-900 group-hover:text-teal-700">
                Data &amp; Backup (डाटा तथा ब्याकअप)
              </h4>
              <span className="text-[9px] font-bold bg-teal-100/70 text-teal-800 px-1.5 py-0.2 rounded">
                Phase 2
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              Export full JSON backups, download CSV spreadsheets &amp; restore
            </p>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600 group-hover:translate-x-0.5 transition-all" />
      </div>


      {/* FEATURE 4: EDUCATIONAL "HOW IT WORKS" FLOW */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div 
          onClick={() => setShowHowItWorks(!showHowItWorks)}
          className="flex items-center justify-between cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-emerald-50 text-emerald-700 flex items-center justify-center text-xs font-bold">
              ?
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900">
                How the IRD Incentive Scheme Works
              </h3>
              <p className="text-[10px] text-slate-400">
                ५-चरण प्रक्रिया (5-Step Process)
              </p>
            </div>
          </div>
          <button 
            type="button"
            className="text-slate-400 hover:text-slate-600 p-1"
          >
            {showHowItWorks ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        {showHowItWorks && (
          <div className="pt-2 border-t border-slate-100 space-y-2.5">
            {[
              {
                step: '1',
                title: 'Shop & Pay Digitally (> NPR 100)',
                desc: 'Pay for personal goods via QR (Fonepay/eSewa/Khalti), Card, or Mobile Banking at a PAN registered seller.',
                badge: 'Qualification',
                icon: QrCode
              },
              {
                step: '2',
                title: 'Get Electronic Invoice & Coupon',
                desc: 'Look for the 12-digit prize coupon number in your payment SMS/app or on the seller’s electronic invoice.',
                badge: '12-Digit Code',
                icon: Receipt
              },
              {
                step: '3',
                title: 'Check Eligibility in Rasid Khata',
                desc: 'Use the 5-question helper to confirm your purchase category and payment rules.',
                badge: 'Helper Tool',
                icon: Sparkles
              },
              {
                step: '4',
                title: 'Save Coupon Numbers Locally',
                desc: 'Store 10, 50, or 500+ coupons in your Rasid Khata coupon manager for the current draw cycle.',
                badge: 'Offline Safe',
                icon: Ticket
              },
              {
                step: '5',
                title: 'Check Winning Draws in 1 Tap',
                desc: 'When IRD announces winning numbers, paste the official list or load the draw to check all your coupons instantly.',
                badge: '1-Click Match',
                icon: Trophy
              },
            ].map((item) => {
              const StepIcon = item.icon;
              return (
                <div key={item.step} className="flex items-start gap-2.5 text-xs">
                  <div className="w-6 h-6 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                    {item.step}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-900">{item.title}</span>
                      <span className="text-[9px] font-semibold bg-slate-100 text-slate-600 px-1 py-0.2 rounded shrink-0">
                        {item.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-snug mt-0.5">
                      {item.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Latest IRD Information Preview Section */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Latest IRD Guidelines &amp; Notices
          </h3>
          <button
            id="home-view-all-notices"
            onClick={() => onNavigate('ird_info')}
            className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-0.5"
          >
            <span>View all</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Headline Items */}
        <div className="space-y-3">
          {latestNotices.map((notice) => (
            <div
              key={notice.id}
              id={`home-notice-${notice.id}`}
              onClick={() => onNavigate('ird_info', { selectedNoticeId: notice.id })}
              className={`pl-3 cursor-pointer transition-colors group ${
                notice.isOfficialSource
                  ? 'border-l-2 border-emerald-500 hover:border-emerald-600'
                  : 'border-l-2 border-slate-300 hover:border-slate-500'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-0.5">
                <h4 className="text-xs font-bold text-slate-800 group-hover:text-emerald-700 line-clamp-1 leading-snug">
                  {notice.title}
                </h4>
              </div>
              <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
                <span className={`px-1.5 py-0.5 rounded font-semibold text-[9px] border ${
                  notice.sourceType === 'current_programme'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : notice.sourceType === 'legal_provision'
                    ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                    : notice.sourceType === 'official_announcement'
                    ? 'bg-teal-50 text-teal-800 border-teal-200'
                    : 'bg-slate-100 text-slate-700 border-slate-200'
                }`}>
                  {notice.sourceType === 'current_programme'
                    ? 'Programme'
                    : notice.sourceType === 'legal_provision'
                    ? 'Legal / Tax'
                    : notice.sourceType === 'official_announcement'
                    ? 'Update'
                    : 'App Guide'}
                </span>
                <span>•</span>
                <span className="truncate max-w-[130px]">{notice.sourceOrganization.split('(')[0].trim()}</span>
                {notice.publicationDate && (
                  <>
                    <span>•</span>
                    <span>{notice.publicationDate}</span>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Footer Disclaimer */}
        <div className="pt-2 border-t border-slate-100">
          <p className="text-[9px] text-slate-400 text-center leading-tight uppercase font-medium">
            Official third-party information only. Not generated or verified by this app.
          </p>
        </div>
      </div>
    </div>
  );
};
