import React, { useState, useMemo } from 'react';
import { 
  Ticket, 
  Search, 
  PlusCircle, 
  Layers, 
  Trophy, 
  Trash2, 
  Edit3, 
  Calendar, 
  Store, 
  Copy, 
  Check, 
  Filter, 
  RotateCcw,
  Sparkles,
  AlertCircle,
  X,
  FileText,
  CreditCard
} from 'lucide-react';
import { couponService } from '../services/couponService';
import { formatCouponNumber, normalizeCouponNumber, isValidCouponNumber } from '../utils/couponUtils';
import { Coupon, ScreenName, PaymentMethod } from '../types/transaction';
import { TrustBanner } from '../components/common/TrustBanner';

interface MyCouponsScreenProps {
  onNavigate: (screen: ScreenName, params?: { checkWinningNumbers?: string[] }) => void;
}

export const MyCouponsScreen: React.FC<MyCouponsScreenProps> = ({ onNavigate }) => {
  const [coupons, setCoupons] = useState<Coupon[]>(() => couponService.getAll());
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [drawPeriodFilter, setDrawPeriodFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Edit Modal State
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [editCouponNumber, setEditCouponNumber] = useState<string>('');
  const [editMerchant, setEditMerchant] = useState<string>('');
  const [editAmount, setEditAmount] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('');
  const [editDrawPeriod, setEditDrawPeriod] = useState<string>('');
  const [editInvoice, setEditInvoice] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [editError, setEditError] = useState<string | null>(null);

  const refreshList = () => {
    setCoupons(couponService.getAll());
  };

  // Distinct draw periods for filter
  const distinctDrawPeriods = useMemo(() => {
    const set = new Set<string>();
    coupons.forEach(c => {
      if (c.drawPeriod) set.add(c.drawPeriod);
    });
    return Array.from(set);
  }, [coupons]);

  // Filtered and searched list
  const filteredCoupons = useMemo(() => {
    return couponService.search(searchQuery, drawPeriodFilter);
  }, [coupons, searchQuery, drawPeriodFilter]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = (id: string, num: string) => {
    if (window.confirm(`Delete coupon ${formatCouponNumber(num)} from your records?`)) {
      couponService.delete(id);
      refreshList();
    }
  };

  const handleStartEdit = (coupon: Coupon) => {
    setEditingCoupon(coupon);
    setEditCouponNumber(coupon.couponNumber);
    setEditMerchant(coupon.merchantName || '');
    setEditAmount(coupon.amount !== undefined ? String(coupon.amount) : '');
    setEditDate(coupon.date || '');
    setEditDrawPeriod(coupon.drawPeriod || '');
    setEditInvoice(coupon.invoiceNumber || '');
    setEditNotes(coupon.notes || '');
    setEditError(null);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCoupon) return;

    const norm = normalizeCouponNumber(editCouponNumber);
    if (!isValidCouponNumber(norm)) {
      setEditError(`Coupon must be exactly 12 digits (currently ${norm.length} digits).`);
      return;
    }

    const numAmount = editAmount ? parseFloat(editAmount) : undefined;

    const res = couponService.update(editingCoupon.id, {
      couponNumber: norm,
      merchantName: editMerchant || undefined,
      amount: numAmount,
      date: editDate || undefined,
      drawPeriod: editDrawPeriod || undefined,
      invoiceNumber: editInvoice || undefined,
      notes: editNotes || undefined,
    });

    if (res.success) {
      setEditingCoupon(null);
      refreshList();
    } else {
      setEditError(res.error || 'Failed to update coupon.');
    }
  };

  const handleResetSample = () => {
    if (window.confirm('Reset to standard sample 28 coupons for testing?')) {
      couponService.resetToMock();
      refreshList();
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-20">
      {/* Top Banner / Summary Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Ticket className="w-4 h-4 text-emerald-700" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">My Coupons</h2>
              <p className="text-xs text-slate-500 font-medium">
                {coupons.length} {coupons.length === 1 ? 'coupon' : 'coupons'} saved on this device
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleResetSample}
            title="Reset sample data"
            className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 p-1.5 rounded-lg hover:bg-slate-100 transition-colors flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset Sample</span>
          </button>
        </div>

        {/* Prominent High-Value Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
          {/* Core Check Winners CTA */}
          <button
            id="coupons-btn-check-winners"
            type="button"
            onClick={() => onNavigate('winner_checker')}
            className="sm:col-span-3 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2 group"
          >
            <Trophy className="w-4 h-4 text-amber-300" />
            <span>Check Winners Against Announced Numbers</span>
          </button>

          {/* Add Single Coupon */}
          <button
            id="coupons-btn-add-single"
            type="button"
            onClick={() => onNavigate('add_coupon')}
            className="py-2 px-3 border border-slate-200 hover:bg-slate-50 active:bg-slate-100 text-slate-800 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 sm:col-span-1"
          >
            <PlusCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span>Add Single</span>
          </button>

          {/* Bulk Add Coupons */}
          <button
            id="coupons-btn-bulk-add"
            type="button"
            onClick={() => onNavigate('bulk_add_coupons')}
            className="py-2 px-3 border border-slate-200 hover:bg-slate-50 active:bg-slate-100 text-slate-800 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 sm:col-span-2"
          >
            <Layers className="w-3.5 h-3.5 text-indigo-600" />
            <span>Bulk Add (Paste 20–500+)</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm space-y-2.5">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="input-search-coupons"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search coupon number, merchant, period..."
            className="w-full text-xs pl-9 pr-8 py-2 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:bg-white focus:border-emerald-600 outline-none transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Draw Period Filter Tabs */}
        {distinctDrawPeriods.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            <button
              onClick={() => setDrawPeriodFilter('all')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors whitespace-nowrap ${
                drawPeriodFilter === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Periods ({coupons.length})
            </button>

            {distinctDrawPeriods.map(period => {
              const count = coupons.filter(c => c.drawPeriod === period).length;
              return (
                <button
                  key={period}
                  onClick={() => setDrawPeriodFilter(period)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors whitespace-nowrap ${
                    drawPeriodFilter === period
                      ? 'bg-emerald-700 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {period} ({count})
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Coupon List Container */}
      <div className="space-y-3">
        {filteredCoupons.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-3 shadow-sm">
            <Ticket className="w-10 h-10 text-slate-300 mx-auto" />
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                {searchQuery || drawPeriodFilter !== 'all' ? 'No matching coupons found' : 'No coupons saved yet'}
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                {searchQuery || drawPeriodFilter !== 'all'
                  ? 'Try changing your search term or filter options.'
                  : 'Add your 12-digit prize coupon numbers from electronic invoices.'}
              </p>
            </div>
            <div className="pt-2 flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => onNavigate('add_coupon')}
                className="px-3.5 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold shadow-xs"
              >
                Add Single Coupon
              </button>
              <button
                type="button"
                onClick={() => onNavigate('bulk_add_coupons')}
                className="px-3.5 py-2 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50"
              >
                Bulk Paste
              </button>
            </div>
          </div>
        ) : (
          filteredCoupons.map(coupon => {
            const isCopied = copiedId === coupon.id;
            const formatted = formatCouponNumber(coupon.couponNumber);

            return (
              <div
                key={coupon.id}
                id={`coupon-card-${coupon.id}`}
                className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:border-slate-300 transition-all space-y-2.5"
              >
                {/* Top Row: Formatted Number & Copy Button */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></div>
                    <span className="font-mono text-sm font-bold text-slate-900 tracking-wider">
                      {formatted}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleCopy(coupon.id, coupon.couponNumber)}
                      className="p-1.5 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors text-[11px] flex items-center gap-1 font-medium"
                      title="Copy coupon number"
                    >
                      {isCopied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-700 text-[10px] font-bold">Copied</span>
                        </>
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleStartEdit(coupon)}
                      className="p-1.5 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                      title="Edit coupon"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDelete(coupon.id, coupon.couponNumber)}
                      className="p-1.5 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Delete coupon"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Middle Info: Merchant & Amount */}
                <div className="flex items-center justify-between gap-2 text-xs flex-wrap">
                  {coupon.merchantName ? (
                    <div className="flex items-center gap-1 text-slate-700 font-medium truncate max-w-[240px]">
                      <Store className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{coupon.merchantName}</span>
                    </div>
                  ) : (
                    <span className="text-slate-400 italic text-[11px]">No merchant specified</span>
                  )}

                  {coupon.amount !== undefined && (
                    <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                      Rs. {coupon.amount.toLocaleString('en-IN')}
                    </span>
                  )}
                </div>

                {/* Bottom Metadata: Draw Period & Date */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500 flex-wrap gap-1">
                  <div className="flex items-center gap-1 text-emerald-800 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded font-medium">
                    <span>{coupon.drawPeriod || 'Shrawan 1–15, 2083'}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {coupon.invoiceNumber && (
                      <span className="font-mono text-slate-500">
                        Inv: {coupon.invoiceNumber}
                      </span>
                    )}
                    {coupon.date && (
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>{coupon.date}</span>
                      </div>
                    )}
                  </div>
                </div>

                {coupon.notes && (
                  <p className="text-[10px] text-slate-500 italic bg-slate-50 p-1.5 rounded">
                    {coupon.notes}
                  </p>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Edit Coupon Modal */}
      {editingCoupon && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl border border-slate-200 animate-scaleUp max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-emerald-600" />
                <span>Edit Coupon</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingCoupon(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {editError && (
              <div className="bg-rose-50 border border-rose-200 rounded-lg p-2.5 text-xs text-rose-800 font-medium">
                {editError}
              </div>
            )}

            <form onSubmit={handleSaveEdit} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="block font-bold text-slate-800">
                  12-Digit Coupon Number *
                </label>
                <input
                  type="text"
                  value={editCouponNumber}
                  onChange={(e) => setEditCouponNumber(e.target.value)}
                  className="w-full font-mono text-sm font-bold p-2.5 rounded-lg border border-slate-300 outline-none focus:border-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="block font-medium text-slate-700">Merchant</label>
                  <input
                    type="text"
                    value={editMerchant}
                    onChange={(e) => setEditMerchant(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block font-medium text-slate-700">Amount (Rs.)</label>
                  <input
                    type="number"
                    value={editAmount}
                    onChange={(e) => setEditAmount(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="block font-medium text-slate-700">Date</label>
                  <input
                    type="date"
                    value={editDate}
                    onChange={(e) => setEditDate(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block font-medium text-slate-700">Draw Period</label>
                  <input
                    type="text"
                    value={editDrawPeriod}
                    onChange={(e) => setEditDrawPeriod(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block font-medium text-slate-700">Invoice #</label>
                <input
                  type="text"
                  value={editInvoice}
                  onChange={(e) => setEditInvoice(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="block font-medium text-slate-700">Notes</label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingCoupon(null)}
                  className="px-3 py-2 border border-slate-200 rounded-lg text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
