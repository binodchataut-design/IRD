import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Calendar, 
  ExternalLink, 
  ChevronDown, 
  ChevronUp, 
  Sparkles,
  FileText,
  ShieldCheck,
  BookOpen,
  Info,
  CheckCircle2,
  HelpCircle,
  Scale,
  Bell,
  Layers,
  ArrowRight
} from 'lucide-react';
import { irdInfoService } from '../services/irdInfoService';
import { TrustBanner } from '../components/common/TrustBanner';
import { IRDNotice, IRDSourceType } from '../types/transaction';

interface IRDInfoScreenProps {
  initialSelectedNoticeId?: string;
}

type LayerFilter = 'all' | IRDSourceType;

interface SectionConfig {
  key: IRDSourceType;
  sectionTitle: string;
  sectionSubtitle: string;
  badgeLabel: string;
  badgeStyle: string;
  icon: React.ComponentType<{ className?: string }>;
  isOfficial: boolean;
}

const LAYER_CONFIGS: Record<IRDSourceType, SectionConfig> = {
  current_programme: {
    key: 'current_programme',
    sectionTitle: 'CURRENT PROGRAMME',
    sectionSubtitle: 'Official information specific to the current taxpayer incentive programme',
    badgeLabel: 'Official Programme Rule',
    badgeStyle: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    icon: Sparkles,
    isOfficial: true,
  },
  legal_provision: {
    key: 'legal_provision',
    sectionTitle: 'LEGAL / TAX INFORMATION',
    sectionSubtitle: 'Relevant official tax provisions & statutory framework',
    badgeLabel: 'Official Legal Provision',
    badgeStyle: 'bg-indigo-100 text-indigo-900 border-indigo-300',
    icon: Scale,
    isOfficial: true,
  },
  official_announcement: {
    key: 'official_announcement',
    sectionTitle: 'OFFICIAL UPDATES',
    sectionSubtitle: 'Latest official notices, circulars and public announcements',
    badgeLabel: 'Official Announcement',
    badgeStyle: 'bg-teal-100 text-teal-900 border-teal-300',
    icon: Bell,
    isOfficial: true,
  },
  app_explanation: {
    key: 'app_explanation',
    sectionTitle: 'APP GUIDE',
    sectionSubtitle: 'Plain-language Rasid Khata educational explanations',
    badgeLabel: 'App Explanation',
    badgeStyle: 'bg-slate-100 text-slate-800 border-slate-300',
    icon: BookOpen,
    isOfficial: false,
  },
};

const SECTIONS_ORDER: IRDSourceType[] = [
  'current_programme',
  'legal_provision',
  'official_announcement',
  'app_explanation',
];

export const IRDInfoScreen: React.FC<IRDInfoScreenProps> = ({
  initialSelectedNoticeId,
}) => {
  const allNotices = irdInfoService.getAll();
  const [filterLayer, setFilterLayer] = useState<LayerFilter>('all');
  const [expandedNoticeId, setExpandedNoticeId] = useState<string | null>(
    initialSelectedNoticeId || null
  );

  const toggleExpand = (id: string) => {
    setExpandedNoticeId(prev => (prev === id ? null : id));
  };

  // Group notices by layer
  const noticesByLayer = useMemo(() => {
    const map: Record<IRDSourceType, IRDNotice[]> = {
      current_programme: [],
      legal_provision: [],
      official_announcement: [],
      app_explanation: [],
    };

    allNotices.forEach(notice => {
      const type = notice.sourceType || (notice.isOfficialSource ? 'official_announcement' : 'app_explanation');
      if (map[type]) {
        map[type].push(notice);
      } else {
        map.app_explanation.push(notice);
      }
    });

    return map;
  }, [allNotices]);

  // Active visible sections based on filter
  const visibleSections = useMemo(() => {
    if (filterLayer === 'all') {
      return SECTIONS_ORDER;
    }
    return [filterLayer];
  }, [filterLayer]);

  const totalVisibleCount = useMemo(() => {
    if (filterLayer === 'all') return allNotices.length;
    return noticesByLayer[filterLayer]?.length || 0;
  }, [filterLayer, allNotices, noticesByLayer]);

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-16">
      {/* Screen Header Overview */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900">IRD Information Architecture</h2>
          <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded flex items-center gap-1">
            <Layers className="w-3 h-3 text-emerald-600" />
            <span>4 Source Layers</span>
          </span>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          Structured tax notices, statutory provisions, official circulars, and educational guides organized into four distinct source layers.
        </p>
      </div>

      {/* Persistent Independence Notice Banner */}
      <TrustBanner 
        type="disclaimer" 
        text="Official Source Notice: Rasid Khata is an independent application and is not affiliated with the Inland Revenue Department (IRD) Nepal. Government information is presented alongside plain-language app explanations for educational reference."
      />

      {/* Four-Layer Source Legend / Guide */}
      <div className="bg-slate-900 text-white rounded-xl p-4 shadow-sm border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400 shrink-0" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Content Source Distinction
            </h3>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Hierarchy v2</span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-[11px]">
          <div className="bg-slate-800/80 p-2 rounded-lg border border-slate-700 space-y-0.5">
            <div className="flex items-center gap-1 text-emerald-400 font-bold text-[10px]">
              <Sparkles className="w-3 h-3" />
              <span>1. Current Programme</span>
            </div>
            <p className="text-slate-300 text-[10px] leading-tight">
              Specific to active incentive scheme rules.
            </p>
          </div>

          <div className="bg-slate-800/80 p-2 rounded-lg border border-slate-700 space-y-0.5">
            <div className="flex items-center gap-1 text-indigo-400 font-bold text-[10px]">
              <Scale className="w-3 h-3" />
              <span>2. Legal Provision</span>
            </div>
            <p className="text-slate-300 text-[10px] leading-tight">
              General VAT Act & billing regulations.
            </p>
          </div>

          <div className="bg-slate-800/80 p-2 rounded-lg border border-slate-700 space-y-0.5">
            <div className="flex items-center gap-1 text-teal-400 font-bold text-[10px]">
              <Bell className="w-3 h-3" />
              <span>3. Official Updates</span>
            </div>
            <p className="text-slate-300 text-[10px] leading-tight">
              Time-sensitive circulars & advisories.
            </p>
          </div>

          <div className="bg-slate-800/80 p-2 rounded-lg border border-slate-700 space-y-0.5">
            <div className="flex items-center gap-1 text-slate-300 font-bold text-[10px]">
              <BookOpen className="w-3 h-3 text-slate-400" />
              <span>4. App Guide</span>
            </div>
            <p className="text-slate-300 text-[10px] leading-tight">
              Plain-language Rasid Khata explanations.
            </p>
          </div>
        </div>
      </div>

      {/* Layer Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
        <button
          id="filter-layer-all"
          onClick={() => setFilterLayer('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border whitespace-nowrap ${
            filterLayer === 'all'
              ? 'bg-slate-900 text-white border-slate-900'
              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
          }`}
        >
          All Layers ({allNotices.length})
        </button>

        <button
          id="filter-layer-programme"
          onClick={() => setFilterLayer('current_programme')}
          className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 whitespace-nowrap ${
            filterLayer === 'current_programme'
              ? 'bg-emerald-700 text-white border-emerald-700'
              : 'bg-white text-emerald-800 border-emerald-200 hover:bg-emerald-50'
          }`}
        >
          <Sparkles className="w-3 h-3" />
          <span>Current Programme ({noticesByLayer.current_programme.length})</span>
        </button>

        <button
          id="filter-layer-legal"
          onClick={() => setFilterLayer('legal_provision')}
          className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 whitespace-nowrap ${
            filterLayer === 'legal_provision'
              ? 'bg-indigo-700 text-white border-indigo-700'
              : 'bg-white text-indigo-800 border-indigo-200 hover:bg-indigo-50'
          }`}
        >
          <Scale className="w-3 h-3" />
          <span>Legal Provisions ({noticesByLayer.legal_provision.length})</span>
        </button>

        <button
          id="filter-layer-announcement"
          onClick={() => setFilterLayer('official_announcement')}
          className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 whitespace-nowrap ${
            filterLayer === 'official_announcement'
              ? 'bg-teal-700 text-white border-teal-700'
              : 'bg-white text-teal-800 border-teal-200 hover:bg-teal-50'
          }`}
        >
          <Bell className="w-3 h-3" />
          <span>Official Updates ({noticesByLayer.official_announcement.length})</span>
        </button>

        <button
          id="filter-layer-explanation"
          onClick={() => setFilterLayer('app_explanation')}
          className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 whitespace-nowrap ${
            filterLayer === 'app_explanation'
              ? 'bg-slate-700 text-white border-slate-700'
              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <BookOpen className="w-3 h-3" />
          <span>App Guide ({noticesByLayer.app_explanation.length})</span>
        </button>
      </div>

      {/* Main 4-Section Content List */}
      <div className="space-y-6 pt-1">
        {totalVisibleCount === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-2 shadow-sm">
            <HelpCircle className="w-8 h-8 text-slate-400 mx-auto" />
            <h4 className="text-xs font-bold text-slate-800">No items in this layer</h4>
            <p className="text-xs text-slate-500">No records have been populated under this section yet.</p>
          </div>
        ) : (
          visibleSections.map(sectionKey => {
            const config = LAYER_CONFIGS[sectionKey];
            const sectionItems = noticesByLayer[sectionKey];
            const IconComponent = config.icon;

            if (sectionItems.length === 0 && filterLayer === 'all') {
              return null; // Skip empty sections in 'all' view
            }

            return (
              <div key={sectionKey} id={`section-${sectionKey}`} className="space-y-3">
                {/* Section Header */}
                <div className="border-b border-slate-200 pb-2 space-y-0.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <IconComponent className={`w-4 h-4 ${
                        config.key === 'current_programme'
                          ? 'text-emerald-600'
                          : config.key === 'legal_provision'
                          ? 'text-indigo-600'
                          : config.key === 'official_announcement'
                          ? 'text-teal-600'
                          : 'text-slate-600'
                      }`} />
                      <h3 className="text-xs font-black text-slate-900 tracking-wider">
                        {config.sectionTitle}
                      </h3>
                    </div>
                    <span className="text-[10px] font-semibold text-slate-400">
                      {sectionItems.length} {sectionItems.length === 1 ? 'record' : 'records'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-snug">
                    {config.sectionSubtitle}
                  </p>
                </div>

                {/* Section Items */}
                <div className="space-y-3">
                  {sectionItems.map((notice: IRDNotice) => {
                    const isExpanded = expandedNoticeId === notice.id;
                    const isOfficial = Boolean(notice.isOfficialSource);

                    return (
                      <div
                        key={notice.id}
                        id={`ird-notice-card-${notice.id}`}
                        className={`bg-white border rounded-xl p-4 transition-all shadow-sm ${
                          notice.sourceType === 'current_programme'
                            ? isExpanded ? 'border-emerald-600 ring-1 ring-emerald-600/20' : 'border-emerald-200'
                            : notice.sourceType === 'legal_provision'
                            ? isExpanded ? 'border-indigo-600 ring-1 ring-indigo-600/20' : 'border-indigo-200'
                            : notice.sourceType === 'official_announcement'
                            ? isExpanded ? 'border-teal-600 ring-1 ring-teal-600/20' : 'border-teal-200'
                            : isExpanded ? 'border-slate-400 ring-1 ring-slate-400/20' : 'border-slate-200'
                        }`}
                      >
                        {/* Top Header: Badge & Date */}
                        <div className="flex items-center justify-between gap-2 mb-2.5 flex-wrap">
                          <div className="flex items-center gap-1.5">
                            {/* Layer Badge */}
                            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border flex items-center gap-1 ${config.badgeStyle}`}>
                              <IconComponent className="w-3 h-3" />
                              <span>{config.badgeLabel}</span>
                            </span>

                            {/* Secondary Category Tag */}
                            {notice.category && (
                              <span className="text-[9px] font-semibold text-slate-500 bg-slate-50 border border-slate-200 px-1.5 py-0.5 rounded">
                                {notice.category}
                              </span>
                            )}
                          </div>

                          {/* Publication Date (if available) */}
                          {notice.publicationDate && (
                            <div className="flex items-center gap-1 text-[10px] text-slate-400 shrink-0">
                              <Calendar className="w-3 h-3 text-slate-400" />
                              <span>{notice.publicationDate}</span>
                            </div>
                          )}
                        </div>

                        {/* Title */}
                        <h4 
                          onClick={() => toggleExpand(notice.id)}
                          className="text-xs font-bold text-slate-900 leading-snug cursor-pointer hover:text-emerald-700 transition-colors"
                        >
                          {notice.title}
                        </h4>

                        {/* Summary / Educational Text */}
                        <div className="mt-2">
                          <p className={`text-xs leading-relaxed ${
                            notice.summary.includes('Pending verification') 
                              ? 'text-amber-800 bg-amber-50/70 p-2 rounded-lg border border-amber-200/80 font-medium'
                              : 'text-slate-600'
                          }`}>
                            {notice.summary}
                          </p>
                        </div>

                        {/* Effective Date Range (if available) */}
                        {(notice.effectiveFrom || notice.effectiveTo) && (
                          <div className="mt-2 text-[10px] text-slate-500 bg-slate-50 px-2 py-1 rounded border border-slate-100 flex items-center gap-1.5 flex-wrap">
                            <span className="font-semibold text-slate-700">Validity Period:</span>
                            {notice.effectiveFrom && (
                              <span>From {notice.effectiveFrom}</span>
                            )}
                            {notice.effectiveTo ? (
                              <span>to {notice.effectiveTo}</span>
                            ) : (
                              <span>(Ongoing)</span>
                            )}
                          </div>
                        )}

                        {/* Expandable Details Pane */}
                        {isExpanded && (
                          <div className="mt-3 pt-3 border-t border-slate-100 space-y-2 bg-slate-50 -mx-4 -mb-4 p-4 rounded-b-xl">
                            <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                              <div className="flex items-center gap-1.5">
                                <FileText className="w-3.5 h-3.5 text-slate-500" />
                                <span>{isOfficial ? 'Full Text & Statutory Reference' : 'App Guide & Explanatory Context'}</span>
                              </div>
                            </div>

                            <p className="text-xs text-slate-600 leading-relaxed break-words">
                              {notice.details || notice.summary}
                            </p>

                            {/* Verification Line */}
                            {notice.lastVerifiedAt && (
                              <div className="pt-2 border-t border-slate-200/60 text-[10px] text-slate-500 flex items-center justify-between">
                                <span>
                                  {isOfficial 
                                    ? `Verified from official source: ${notice.lastVerifiedAt}`
                                    : `Guide reviewed: ${notice.lastVerifiedAt}`}
                                </span>
                                {notice.programmeId && (
                                  <span className="font-mono text-[9px] text-slate-400">
                                    Ref: {notice.programmeId}
                                  </span>
                                )}
                              </div>
                            )}

                            {!isOfficial && (
                              <div className="p-2 bg-slate-100 rounded text-[10px] text-slate-600 italic">
                                Note: This is an informal educational guide provided by Rasid Khata. It is not an official government statute or binding tax ruling.
                              </div>
                            )}
                          </div>
                        )}

                        {/* Card Footer: Source Organization & Action Link */}
                        <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-[10px]">
                          <div className="flex items-center gap-1.5 text-slate-500 min-w-0">
                            <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span className="font-medium truncate max-w-[200px]" title={notice.sourceOrganization}>
                              {notice.sourceOrganization}
                            </span>
                          </div>

                          <div className="flex items-center gap-3">
                            <button
                              type="button"
                              onClick={() => toggleExpand(notice.id)}
                              className="text-slate-500 hover:text-slate-800 font-semibold flex items-center gap-0.5"
                            >
                              <span>{isExpanded ? 'Less' : 'Details'}</span>
                              {isExpanded ? (
                                <ChevronUp className="w-3.5 h-3.5" />
                              ) : (
                                <ChevronDown className="w-3.5 h-3.5" />
                              )}
                            </button>

                            <a
                              href={notice.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className={`font-semibold inline-flex items-center gap-1 hover:underline ${
                                isOfficial 
                                  ? 'text-emerald-700 hover:text-emerald-800' 
                                  : 'text-slate-700 hover:text-slate-900'
                              }`}
                            >
                              <span>{isOfficial ? 'View official source' : 'View reference'}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Official IRD Portal Direct Link Footer */}
      <div className="p-4 bg-white border border-slate-200 rounded-xl text-xs text-slate-600 flex items-center justify-between shadow-sm">
        <div>
          <span className="font-bold text-xs block text-slate-900">Official IRD Web Portal</span>
          <span className="text-[10px] text-slate-400">Visit ird.gov.np for official tax gazettes, circulars & PAN search</span>
        </div>
        <a
          href="https://ird.gov.np"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg font-semibold text-emerald-800 hover:bg-emerald-100 flex items-center gap-1 text-[10px] shrink-0"
        >
          <span>ird.gov.np</span>
          <ExternalLink className="w-3 h-3 text-emerald-700" />
        </a>
      </div>
    </div>
  );
};
