import React, { useState, useMemo } from 'react';
import { 
  Trophy, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  ExternalLink, 
  RefreshCw, 
  Calendar, 
  Store, 
  ArrowRight,
  ShieldCheck,
  BookmarkPlus,
  HelpCircle,
  Clock,
  Check,
  Download,
  Printer,
  FileCheck
} from 'lucide-react';
import { couponService } from '../services/couponService';
import { drawService } from '../services/drawService';
import { transactionService } from '../services/transactionService';
import { parseWinningNumbersText, formatCouponNumber, normalizeCouponNumber } from '../utils/couponUtils';
import { ScreenName, WinnerCheckResult, DrawAnnouncement, ClaimReportData } from '../types/transaction';
import { TrustBanner } from '../components/common/TrustBanner';
import { exportUtils } from '../utils/exportUtils';

interface WinnerCheckerScreenProps {
  onNavigate: (screen: ScreenName) => void;
  initialWinningNumbers?: string[];
  onSelectClaimReport?: (data: ClaimReportData) => void;
}


// Sample winning numbers where some match the default coupons
const SAMPLE_WINNING_NUMBERS = `007 315 254 493
007 755 590 670
002 928 817 811
003 066 779 589
015 611 059 075
009 917 833 245
004 128 930 192
005 829 104 728
008 273 910 482
002 938 475 619
006 918 273 645
011 293 847 560
003 829 104 857
009 283 746 150
004 928 173 645
001 928 374 650`;

const SAMPLE_NON_WINNING_NUMBERS = `099 111 222 333
088 222 333 444
077 333 444 555
066 444 555 666
055 555 666 777
044 666 777 888`;

export const WinnerCheckerScreen: React.FC<WinnerCheckerScreenProps> = ({ 
  onNavigate,
  initialWinningNumbers,
  onSelectClaimReport 
}) => {
  const allSavedCoupons = couponService.getAll();
  const allDrawAnnouncements = drawService.getAll();

  const [inputMode, setInputMode] = useState<'paste' | 'history'>('paste');
  const [rawWinningText, setRawWinningText] = useState<string>(
    initialWinningNumbers && initialWinningNumbers.length > 0
      ? initialWinningNumbers.join('\n')
      : ''
  );
  const [selectedDrawId, setSelectedDrawId] = useState<string>(
    allDrawAnnouncements.length > 0 ? allDrawAnnouncements[0].id : ''
  );

  const [checkResult, setCheckResult] = useState<WinnerCheckResult | null>(null);
  const [isChecking, setIsChecking] = useState<boolean>(false);

  // Parse winning numbers from text
  const parsedTextWinners = useMemo(() => {
    return parseWinningNumbersText(rawWinningText);
  }, [rawWinningText]);

  // Handle checking for paste mode
  const handleCheckPasted = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (parsedTextWinners.validWinningNumbers.length === 0) return;

    setIsChecking(true);
    setTimeout(() => {
      const result = couponService.checkWinners(parsedTextWinners.validWinningNumbers, {
        title: 'Custom Entered Winning Numbers',
      });
      setCheckResult(result);
      setIsChecking(false);
      // Scroll to result
      window.scrollTo({ top: 300, behavior: 'smooth' });
    }, 200);
  };

  // Handle checking for draw history mode
  const handleCheckFromDraw = (draw: DrawAnnouncement) => {
    setIsChecking(true);
    setTimeout(() => {
      const result = couponService.checkWinners(draw.winningNumbers, {
        title: draw.title,
        drawPeriod: draw.drawPeriod,
        announcementDate: draw.announcementDate,
      });
      setCheckResult(result);
      setIsChecking(false);
      window.scrollTo({ top: 300, behavior: 'smooth' });
    }, 200);
  };

  const handleLoadWinningSample = () => {
    setInputMode('paste');
    setRawWinningText(SAMPLE_WINNING_NUMBERS);
    setCheckResult(null);
  };

  const handleLoadNonWinningSample = () => {
    setInputMode('paste');
    setRawWinningText(SAMPLE_NON_WINNING_NUMBERS);
    setCheckResult(null);
  };

  // Export Winner Check Result CSV
  const handleExportCheckCsv = () => {
    if (!checkResult) return;
    exportUtils.exportWinnerCheckToCsv(checkResult, checkResult.drawInfo?.drawPeriod);
  };

  // Open Claim Report
  const handleOpenClaimReport = (match: { userCoupon: any; matchedWinningNumber: string; drawTitle?: string; drawPeriod?: string; announcementDate?: string }) => {
    const allTx = transactionService.getAll();
    const matchedTx = allTx.find(
      tx => (tx.couponNumber && normalizeCouponNumber(tx.couponNumber) === match.userCoupon.couponNumber) ||
            (match.userCoupon.invoiceNumber && tx.invoiceNumber === match.userCoupon.invoiceNumber)
    );

    const reportData: ClaimReportData = {
      matchedCoupon: match.userCoupon,
      matchedWinningNumber: match.matchedWinningNumber,
      drawTitle: match.drawTitle || checkResult?.drawInfo?.title,
      drawPeriod: match.drawPeriod || checkResult?.drawInfo?.drawPeriod,
      announcementDate: match.announcementDate || checkResult?.drawInfo?.announcementDate,
      sourceUrl: 'https://ird.gov.np',
      sourceName: 'Inland Revenue Department (IRD Nepal)',
      associatedTransaction: matchedTx,
    };

    if (onSelectClaimReport) {
      onSelectClaimReport(reportData);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full space-y-4 pb-24">

      {/* Screen Title & High-Value Explanation */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-100 border border-amber-200 text-amber-800 flex items-center justify-center font-bold shadow-xs shrink-0">
              <Trophy className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">
                Winner Number Checker
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Check your {allSavedCoupons.length} saved coupons against IRD winning numbers
              </p>
            </div>
          </div>
        </div>

        <div className="p-2.5 bg-emerald-50/70 border border-emerald-100 rounded-lg text-xs text-emerald-900 font-medium">
          Answer the core question: &ldquo;Did any of my saved prize coupons win?&rdquo;
        </div>
      </div>

      {/* Input Mode Selector */}
      <div className="bg-white p-1.5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-1 text-xs font-semibold">
        <button
          type="button"
          id="tab-mode-paste"
          onClick={() => setInputMode('paste')}
          className={`flex-1 py-2 px-3 rounded-lg transition-all text-center flex items-center justify-center gap-1.5 ${
            inputMode === 'paste'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Paste Announced Numbers</span>
        </button>

        <button
          type="button"
          id="tab-mode-history"
          onClick={() => setInputMode('history')}
          className={`flex-1 py-2 px-3 rounded-lg transition-all text-center flex items-center justify-center gap-1.5 ${
            inputMode === 'history'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Select Past Draw ({allDrawAnnouncements.length})</span>
        </button>
      </div>

      {/* Mode 1: Paste Winning Numbers Card */}
      {inputMode === 'paste' && (
        <form onSubmit={handleCheckPasted} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3.5">
          <div className="flex items-center justify-between">
            <label htmlFor="input-winning-numbers" className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <span>Announced 12-Digit Winning Numbers</span>
            </label>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleLoadWinningSample}
                className="text-[10px] font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded transition-colors"
                title="Paste realistic winning numbers"
              >
                Sample (Match)
              </button>
              <button
                type="button"
                onClick={handleLoadNonWinningSample}
                className="text-[10px] font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-200 px-2 py-0.5 rounded transition-colors"
                title="Paste numbers with zero match"
              >
                Sample (No Match)
              </button>
            </div>
          </div>

          <textarea
            id="input-winning-numbers"
            rows={5}
            value={rawWinningText}
            onChange={(e) => setRawWinningText(e.target.value)}
            placeholder={`Paste 12-digit winning numbers announced by IRD (e.g.):\n007 315 254 493\n007 755 590 670\n002 928 817 811\n003 066 779 589`}
            className="w-full font-mono text-xs p-3 rounded-lg border border-slate-300 text-slate-900 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100 outline-none resize-y"
          />

          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-slate-500 text-[11px]">
              Detected: <strong className="font-mono text-slate-800">{parsedTextWinners.validWinningNumbers.length}</strong> valid winning numbers
            </span>

            {rawWinningText && (
              <button
                type="button"
                onClick={() => { setRawWinningText(''); setCheckResult(null); }}
                className="text-[11px] text-slate-400 hover:text-slate-700 font-semibold"
              >
                Clear input
              </button>
            )}
          </div>

          {/* Compare Button */}
          <button
            type="submit"
            id="btn-run-winner-check"
            disabled={parsedTextWinners.validWinningNumbers.length === 0 || isChecking}
            className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 ${
              parsedTextWinners.validWinningNumbers.length > 0 && !isChecking
                ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white cursor-pointer'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Trophy className="w-4 h-4 text-amber-300" />
            <span>
              {isChecking 
                ? 'Comparing Numbers...' 
                : `Compare Against My ${allSavedCoupons.length} Saved Coupons`}
            </span>
          </button>
        </form>
      )}

      {/* Mode 2: Draw History Selector Card */}
      {inputMode === 'history' && (
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800">
              Select an Official IRD Draw Announcement
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('draw_history')}
              className="text-[11px] text-emerald-700 font-semibold hover:underline"
            >
              Manage Draws
            </button>
          </div>

          <div className="space-y-2.5">
            {allDrawAnnouncements.map(draw => (
              <div
                key={draw.id}
                id={`draw-select-card-${draw.id}`}
                className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 hover:border-emerald-300 hover:bg-emerald-50/30 transition-all space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">{draw.title}</span>
                  <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    <span>{draw.announcementDate}</span>
                  </span>
                </div>

                <div className="text-[11px] text-slate-600 flex items-center justify-between">
                  <span>Cycle: <strong>{draw.drawPeriod}</strong></span>
                  <span className="font-mono text-slate-500">
                    {draw.winningNumbers.length} winning numbers
                  </span>
                </div>

                <button
                  type="button"
                  id={`btn-check-draw-${draw.id}`}
                  onClick={() => handleCheckFromDraw(draw)}
                  className="w-full mt-1 py-2 px-3 bg-white hover:bg-emerald-600 hover:text-white border border-slate-200 hover:border-emerald-600 text-slate-800 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 shadow-2xs"
                >
                  <Trophy className="w-3.5 h-3.5 text-amber-500" />
                  <span>Check Against This Draw ({draw.winningNumbers.length} Numbers)</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* RESULT DISPLAY SECTION */}
      {checkResult && (
        <div id="winner-check-results" className="space-y-4 animate-fadeIn">
          {checkResult.matches.length > 0 ? (
            /* MATCH FOUND VIEW */
            <div className="bg-white border-2 border-emerald-500 rounded-2xl p-5 shadow-lg space-y-4">
              {/* Match Header Banner */}
              <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-xl p-4 shadow-sm text-center space-y-1">
                <span className="text-2xl block">🎉</span>
                <h3 className="text-base font-black tracking-wide uppercase">
                  MATCH FOUND
                </h3>
                <p className="text-xs text-emerald-100 font-medium">
                  {checkResult.matches.length} of your saved {checkResult.matches.length === 1 ? 'coupon matches' : 'coupons match'} an announced winning number!
                </p>
              </div>

              {/* Scannable Summary */}
              <div className="p-3 bg-slate-50 rounded-lg text-xs text-slate-600 space-y-1.5 border border-slate-100">
                <div className="flex items-center justify-between">
                  <span>Saved Coupons Checked:</span>
                  <strong className="font-mono text-slate-900">{checkResult.checkedCouponCount}</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span>Announced Winning Numbers:</span>
                  <strong className="font-mono text-slate-900">{checkResult.winningNumberCount}</strong>
                </div>
                {checkResult.drawInfo?.title && (
                  <div className="flex items-center justify-between pt-1 border-t border-slate-200/60">
                    <span>Draw Reference:</span>
                    <strong className="text-slate-800 text-[11px] truncate max-w-[200px]">{checkResult.drawInfo.title}</strong>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-200/60 flex items-center justify-end">
                  <button
                    id="export-winner-check-csv-btn"
                    onClick={handleExportCheckCsv}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-lg transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export Results (CSV)</span>
                  </button>
                </div>
              </div>

              {/* Matched Coupons List */}
              <div className="space-y-3 pt-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Matched Coupon Details</span>
                </h4>

                {checkResult.matches.map((match, idx) => (
                  <div
                    key={idx}
                    className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-4 space-y-3 shadow-2xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded">
                        Match #{idx + 1}
                      </span>
                      {match.userCoupon.drawPeriod && (
                        <span className="text-[10px] font-semibold text-slate-500">
                          {match.userCoupon.drawPeriod}
                        </span>
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="text-xs text-slate-600">Your coupon:</div>
                      <div className="font-mono text-base font-black text-emerald-950 tracking-wider bg-white p-2 rounded-lg border border-emerald-200">
                        {formatCouponNumber(match.userCoupon.couponNumber)}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="text-xs text-slate-600">Matched winning number:</div>
                      <div className="font-mono text-sm font-bold text-slate-800 tracking-wider bg-white/80 p-1.5 rounded border border-slate-200">
                        {formatCouponNumber(match.matchedWinningNumber)}
                      </div>
                    </div>

                    {/* Metadata */}
                    <div className="pt-2 border-t border-emerald-200/60 text-xs text-slate-600 flex items-center justify-between flex-wrap gap-1">
                      {match.userCoupon.merchantName && (
                        <div className="flex items-center gap-1 font-medium">
                          <Store className="w-3.5 h-3.5 text-slate-400" />
                          <span>{match.userCoupon.merchantName}</span>
                        </div>
                      )}
                      {match.userCoupon.amount !== undefined && (
                        <span className="font-bold text-slate-800">
                          Rs. {match.userCoupon.amount.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>

                    {match.userCoupon.invoiceNumber && (
                      <div className="text-[10px] text-slate-500 font-mono">
                        Invoice Ref: {match.userCoupon.invoiceNumber}
                      </div>
                    )}

                    {/* Open Claim Dossier Button */}
                    <div className="pt-1">
                      <button
                        id={`view-claim-dossier-btn-${idx}`}
                        onClick={() => handleOpenClaimReport(match)}
                        className="w-full flex items-center justify-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white py-2 px-3 rounded-lg text-xs font-bold shadow-xs transition-colors"
                      >
                        <FileCheck className="w-4 h-4" />
                        <span>View / Print Claim Dossier (दावी रिपोर्ट)</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Crucial Legal Verification Disclaimer */}
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl space-y-1.5 text-xs text-amber-900 leading-relaxed">
                <div className="flex items-center gap-1.5 font-bold text-amber-950">
                  <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>Important Verification Notice</span>
                </div>
                <p>
                  Your saved coupon number matches an announced winning coupon number.
                </p>
                <p className="text-[11px] text-amber-800">
                  Please verify the result and claim requirements through the official IRD source. Rasid Khata is an independent tool and does not officially grant or claim prizes.
                </p>
                <div className="pt-1.5 flex justify-end">
                  <a
                    href="https://ird.gov.np"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-950 hover:underline bg-amber-100/80 px-2.5 py-1 rounded"
                  >
                    <span>Visit Official IRD Portal</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          ) : (
            /* NO MATCH VIEW */
            <div className="bg-white border border-slate-200 rounded-2xl p-6 text-center shadow-sm space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <HelpCircle className="w-6 h-6" />
              </div>

              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-800">
                  No matching winning coupon found.
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                  Checked <strong className="text-slate-800 font-mono">{checkResult.checkedCouponCount}</strong> of your saved coupons against <strong className="text-slate-800 font-mono">{checkResult.winningNumberCount}</strong> announced winning numbers.
                </p>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs text-slate-600 text-left space-y-1">
                <span className="font-semibold text-slate-700 block text-[11px]">Next Steps:</span>
                <p className="text-[11px] text-slate-500">
                  Keep recording your electronic invoices and prize coupon numbers for upcoming fortnightly and monthly IRD draws.
                </p>
              </div>

              <div className="pt-2 flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => onNavigate('add_coupon')}
                  className="px-3.5 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold"
                >
                  Add More Coupons
                </button>
                <button
                  type="button"
                  onClick={() => setCheckResult(null)}
                  className="px-3.5 py-2 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50"
                >
                  Check Again
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Official Independence & Matching Disclaimer */}
      <TrustBanner
        type="disclaimer"
        text="Rasid Khata only compares the coupon numbers you save with the winning numbers entered into the app. Final eligibility, verification and prize claims are determined by the Inland Revenue Department."
      />
    </div>
  );
};
