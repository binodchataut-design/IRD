import { Transaction, Coupon, WinnerCheckResult } from '../types/transaction';
import { formatCouponNumber } from './couponUtils';

/**
 * Escapes a cell value for standard CSV format.
 * - Wraps in quotes if it contains commas, double quotes, or newlines.
 * - Escapes inner double quotes as ""
 */
function escapeCsvCell(val: string | number | undefined | null): string {
  if (val === undefined || val === null) {
    return '""';
  }
  const str = String(val);
  // Replace newlines with spaces or preserve within quotes
  const sanitized = str.replace(/\r?\n/g, ' ');
  if (sanitized.includes(',') || sanitized.includes('"') || sanitized.includes('\n')) {
    return `"${sanitized.replace(/"/g, '""')}"`;
  }
  return `"${sanitized}"`;
}

/**
 * Downloads a CSV string with UTF-8 Byte Order Mark (\uFEFF) to ensure
 * Nepali Unicode characters and formatted text open seamlessly in Microsoft Excel,
 * Apple Numbers, and Google Sheets.
 */
function downloadCsv(csvContent: string, filename: string): void {
  const bom = '\uFEFF';
  const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export const exportUtils = {
  /**
   * Generates and downloads a CSV export of all user transactions.
   */
  exportTransactionsToCsv: (transactions: Transaction[]): { filename: string; count: number } => {
    const headers = [
      'Date',
      'Merchant Name',
      'Amount (NPR)',
      'Payment Method',
      'Seller PAN/VAT',
      'Invoice Number',
      'Eligibility Status',
      'Coupon Number',
      'Notes',
      'Invoice Photo',
      'Recorded At',
    ];

    const rows = transactions.map((tx) => {
      const hasPhoto = Boolean(tx.photoReference || tx.invoicePhotoUrl);
      const photoStatus = hasPhoto ? 'Photo attached' : 'None';
      const panValue = tx.panVat || tx.sellerPanVat || '';
      // Format PAN/VAT as formula if numeric to preserve leading zeros in Excel
      const panFormatted = panValue ? (panValue.startsWith('0') ? `="${panValue}"` : escapeCsvCell(panValue)) : '""';

      return [
        escapeCsvCell(tx.date),
        escapeCsvCell(tx.sellerName),
        escapeCsvCell(tx.amount),
        escapeCsvCell(tx.paymentMethod),
        panFormatted,
        escapeCsvCell(tx.invoiceNumber || ''),
        escapeCsvCell(tx.eligibilityStatus || 'not_checked'),
        // Format coupon as string formula ="007315254493" to preserve leading zeros in Excel
        tx.couponNumber ? `="${tx.couponNumber}"` : '""',
        escapeCsvCell(tx.notes || ''),
        escapeCsvCell(photoStatus),
        escapeCsvCell(tx.createdAt),
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `rasid-khata-invoices-${dateStr}.csv`;

    downloadCsv(csvContent, filename);
    return { filename, count: transactions.length };
  },

  /**
   * Generates and downloads a CSV export of all 12-digit prize coupons.
   * Preserves leading zeros explicitly.
   */
  exportCouponsToCsv: (coupons: Coupon[]): { filename: string; count: number } => {
    const headers = [
      'Coupon Number (Formatted)',
      '12-Digit Raw String',
      'Draw Period',
      'Merchant Name',
      'Purchase Date',
      'Amount (NPR)',
      'Payment Method',
      'Invoice Number',
      'Notes',
      'Saved At',
    ];

    const rows = coupons.map((cp) => {
      const formatted = formatCouponNumber(cp.couponNumber);
      // Format 12-digit raw string with Excel formula ="007315254493" to prevent scientific notation or truncated leading zeros
      const rawFormula = `="${cp.couponNumber}"`;

      return [
        escapeCsvCell(formatted),
        rawFormula,
        escapeCsvCell(cp.drawPeriod || ''),
        escapeCsvCell(cp.merchantName || ''),
        escapeCsvCell(cp.date || ''),
        escapeCsvCell(cp.amount !== undefined ? cp.amount : ''),
        escapeCsvCell(cp.paymentMethod || ''),
        escapeCsvCell(cp.invoiceNumber || ''),
        escapeCsvCell(cp.notes || ''),
        escapeCsvCell(cp.createdAt),
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `rasid-khata-coupons-${dateStr}.csv`;

    downloadCsv(csvContent, filename);
    return { filename, count: coupons.length };
  },

  /**
   * Exports the results of a Winner Check run as a structured CSV report.
   */
  exportWinnerCheckToCsv: (
    checkResult: WinnerCheckResult,
    drawPeriodLabel?: string
  ): { filename: string; matchCount: number } => {
    const lines: string[] = [];

    // Header metadata block
    lines.push('=== RASID KHATA (रसिद खाता) - WINNER CHECK REPORT ===');
    lines.push(`"Report Generated At:",${escapeCsvCell(new Date().toLocaleString())}`);
    lines.push(`"Draw Period:",${escapeCsvCell(checkResult.drawInfo?.drawPeriod || drawPeriodLabel || 'Not specified')}`);
    lines.push(`"Draw Title:",${escapeCsvCell(checkResult.drawInfo?.title || 'Custom Winner Comparison')}`);
    lines.push(`"Announcement Date:",${escapeCsvCell(checkResult.drawInfo?.announcementDate || 'N/A')}`);
    lines.push(`"Total User Coupons Checked:",${checkResult.checkedCouponCount}`);
    lines.push(`"Total Winning Numbers Tested:",${checkResult.winningNumberCount}`);
    lines.push(`"Matches Found:",${checkResult.matches.length}`);
    lines.push('"Important Notice:","This report is a personal comparison generated by Rasid Khata (an independent helper app). It is NOT an official IRD winner certification. Always verify with official IRD publications at https://ird.gov.np before claiming."');
    lines.push(''); // Empty line before table

    // Data table
    const tableHeaders = [
      'Match Status',
      'Matched Coupon (Formatted)',
      '12-Digit Raw String',
      'Merchant Name',
      'Purchase Date',
      'Amount (NPR)',
      'Invoice Number',
      'Payment Method',
      'Notes',
    ];
    lines.push(tableHeaders.join(','));

    if (checkResult.matches.length > 0) {
      for (const match of checkResult.matches) {
        const cp = match.userCoupon;
        const formatted = formatCouponNumber(cp.couponNumber);
        const rawFormula = `="${cp.couponNumber}"`;

        lines.push([
          escapeCsvCell('MATCH FOUND'),
          escapeCsvCell(formatted),
          rawFormula,
          escapeCsvCell(cp.merchantName || ''),
          escapeCsvCell(cp.date || ''),
          escapeCsvCell(cp.amount !== undefined ? cp.amount : ''),
          escapeCsvCell(cp.invoiceNumber || ''),
          escapeCsvCell(cp.paymentMethod || ''),
          escapeCsvCell(cp.notes || ''),
        ].join(','));
      }
    } else {
      lines.push('"NO MATCHES FOUND","None of your saved coupons matched the tested winning numbers in this check.","","","","","","",""');
    }

    const csvContent = lines.join('\r\n');
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `rasid-khata-winner-check-${dateStr}.csv`;

    downloadCsv(csvContent, filename);
    return { filename, matchCount: checkResult.matches.length };
  },
};
