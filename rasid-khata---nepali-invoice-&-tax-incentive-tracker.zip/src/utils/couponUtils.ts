import { BulkParseResult } from '../types/transaction';

/**
 * Normalizes a coupon number string by removing all non-digit characters (spaces, hyphens, punctuation).
 * Preserves leading zeros.
 * 
 * Example: "007 315 254 493" -> "007315254493"
 * Example: "007-315-254-493" -> "007315254493"
 */
export function normalizeCouponNumber(input: string): string {
  if (!input) return '';
  return input.replace(/\D/g, '');
}

/**
 * Validates whether a normalized string is a valid 12-digit prize coupon number.
 */
export function isValidCouponNumber(normalized: string): boolean {
  return typeof normalized === 'string' && normalized.length === 12 && /^\d{12}$/.test(normalized);
}

/**
 * Formats a 12-digit coupon number into human-readable 3-digit groups.
 * 
 * Example: "007315254493" -> "007 315 254 493"
 */
export function formatCouponNumber(couponNumber: string): string {
  if (!couponNumber) return '';
  const digits = normalizeCouponNumber(couponNumber);
  if (digits.length === 12) {
    return `${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6, 9)} ${digits.slice(9, 12)}`;
  }
  // For partial or different length inputs, group every 3 digits
  return digits.replace(/(\d{3})(?=\d)/g, '$1 ').trim();
}

/**
 * Parses raw text (multi-line, comma-separated, space-grouped, or unformatted)
 * and extracts/categorizes 12-digit coupon numbers.
 */
export function parseBulkCouponsText(
  rawText: string,
  existingSavedNumbers: Set<string> | string[]
): BulkParseResult {
  const existingSet = existingSavedNumbers instanceof Set 
    ? existingSavedNumbers 
    : new Set(existingSavedNumbers.map(n => normalizeCouponNumber(n)));

  if (!rawText || !rawText.trim()) {
    return {
      totalExtracted: 0,
      validNew: [],
      duplicateInBatch: [],
      alreadySaved: [],
      invalidTokens: [],
    };
  }

  // Split input into lines or delimited tokens
  // Handle newlines, commas, semicolons, tabs, and multiple spaces
  const lines = rawText.split(/[\r\n;,]+/);
  
  const seenInBatch = new Set<string>();
  const validNew: string[] = [];
  const duplicateInBatch: string[] = [];
  const alreadySaved: string[] = [];
  const invalidTokens: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    // Check if line contains multiple space-separated tokens or if whole line is one coupon
    // Sometimes user pastes "007 315 254 493" (one coupon) or "007315254493 002928817811" (multiple)
    const normalizedLine = normalizeCouponNumber(trimmed);

    if (normalizedLine.length === 12 && /^\d{12}$/.test(normalizedLine)) {
      processExtractedNumber(normalizedLine);
    } else if (normalizedLine.length > 12 && normalizedLine.length % 12 === 0) {
      // Multiple concatenated 12-digit numbers
      for (let i = 0; i < normalizedLine.length; i += 12) {
        const chunk = normalizedLine.slice(i, i + 12);
        processExtractedNumber(chunk);
      }
    } else {
      // Try extracting individual whitespace tokens
      const tokens = trimmed.split(/\s+/);
      // If tokens can be combined to 12 digits (like 4 tokens of 3 digits: "007" "315" "254" "493")
      const combinedDigits = normalizeCouponNumber(tokens.join(''));
      if (combinedDigits.length === 12) {
        processExtractedNumber(combinedDigits);
      } else {
        // Evaluate each token individually
        let tokenProcessed = false;
        for (const token of tokens) {
          const normToken = normalizeCouponNumber(token);
          if (normToken.length === 12) {
            processExtractedNumber(normToken);
            tokenProcessed = true;
          }
        }
        if (!tokenProcessed && trimmed.length > 0) {
          invalidTokens.push(trimmed);
        }
      }
    }
  }

  function processExtractedNumber(num: string) {
    if (existingSet.has(num)) {
      alreadySaved.push(num);
    } else if (seenInBatch.has(num)) {
      duplicateInBatch.push(num);
    } else {
      seenInBatch.add(num);
      validNew.push(num);
    }
  }

  const totalExtracted = validNew.length + duplicateInBatch.length + alreadySaved.length;

  return {
    totalExtracted,
    validNew,
    duplicateInBatch,
    alreadySaved,
    invalidTokens,
  };
}

/**
 * Parses raw text of winning numbers announced by IRD.
 * Returns array of unique, normalized 12-digit winning numbers and any invalid lines.
 */
export function parseWinningNumbersText(rawText: string): {
  validWinningNumbers: string[];
  invalidTokens: string[];
} {
  if (!rawText || !rawText.trim()) {
    return { validWinningNumbers: [], invalidTokens: [] };
  }

  const lines = rawText.split(/[\r\n;,]+/);
  const seen = new Set<string>();
  const validWinningNumbers: string[] = [];
  const invalidTokens: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    const normalized = normalizeCouponNumber(trimmed);
    if (normalized.length === 12 && /^\d{12}$/.test(normalized)) {
      if (!seen.has(normalized)) {
        seen.add(normalized);
        validWinningNumbers.push(normalized);
      }
    } else if (normalized.length > 12 && normalized.length % 12 === 0) {
      for (let i = 0; i < normalized.length; i += 12) {
        const chunk = normalized.slice(i, i + 12);
        if (!seen.has(chunk)) {
          seen.add(chunk);
          validWinningNumbers.push(chunk);
        }
      }
    } else {
      // Check combined tokens
      const tokens = trimmed.split(/\s+/);
      const combined = normalizeCouponNumber(tokens.join(''));
      if (combined.length === 12 && /^\d{12}$/.test(combined)) {
        if (!seen.has(combined)) {
          seen.add(combined);
          validWinningNumbers.push(combined);
        }
      } else {
        invalidTokens.push(trimmed);
      }
    }
  }

  return { validWinningNumbers, invalidTokens };
}
