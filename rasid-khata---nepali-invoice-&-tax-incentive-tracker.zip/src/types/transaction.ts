export type PaymentMethod = 
  | 'Cash'
  | 'Card'
  | 'Digital Wallet'
  | 'Bank Transfer'
  | 'Other';

export type EligibilityStatus = 
  | 'not_checked'
  | 'likely_eligible'
  | 'likely_not_eligible'
  | 'needs_verification'
  | 'awaiting_coupon'
  | 'coupon_added';

export type PurchasePurpose = 
  | 'personal'
  | 'business'
  | 'government'
  | 'unknown';

export type SellerPanOption = 
  | 'yes'
  | 'no'
  | 'dont_know';

export type TransactionCategory = 
  | 'normal_goods'
  | 'electricity'
  | 'telephone_internet'
  | 'airline'
  | 'transport_freight'
  | 'vehicle'
  | 'other'
  | 'dont_know';

export interface TransactionEligibilityInput {
  amount: number;
  paymentMethod: PaymentMethod | 'QR / Digital Payment' | 'Mobile Banking' | 'Other / Unknown';
  purpose: PurchasePurpose;
  sellerPan: SellerPanOption;
  sellerPanNumber?: string;
  sellerName?: string;
  category: TransactionCategory;
  date?: string;
  invoiceNumber?: string;
}

export interface TransactionEligibilityResult {
  status: 'likely_eligible' | 'likely_not_eligible' | 'needs_verification';
  title: string;
  statusLabel: string;
  reasons: string[];
  caveats: string[];
  digitalWarning?: string;
  nextSteps: string[];
  evaluatedAt: string;
}

export interface Transaction {
  id: string;
  date: string; // YYYY-MM-DD
  sellerName: string;
  amount: number;
  paymentMethod: PaymentMethod;
  panVat?: string;
  sellerPanVat?: string; // Backwards-compatible alias
  invoiceNumber?: string;
  couponNumber?: string; // Optional reference to associated coupon
  eligibilityStatus?: EligibilityStatus;
  eligibilityReasons?: string[];
  notes?: string;
  photoReference?: string;
  invoicePhotoUrl?: string; // Backwards-compatible alias
  createdAt: string;
}

export type NewTransactionInput = {
  date: string;
  sellerName: string;
  amount: number;
  paymentMethod: PaymentMethod;
  panVat?: string;
  sellerPanVat?: string;
  invoiceNumber?: string;
  couponNumber?: string;
  eligibilityStatus?: EligibilityStatus;
  eligibilityReasons?: string[];
  notes?: string;
  photoReference?: string;
  invoicePhotoUrl?: string;
};

export interface Coupon {
  id: string;
  couponNumber: string; // Normalized 12-digit string (e.g. "007315254493")
  date?: string; // YYYY-MM-DD
  drawPeriod?: string; // e.g. "Shrawan 1–15, 2083"
  merchantName?: string;
  amount?: number;
  paymentMethod?: PaymentMethod | string;
  invoiceNumber?: string;
  notes?: string;
  createdAt: string; // ISO String
}

export type NewCouponInput = {
  couponNumber: string;
  date?: string;
  drawPeriod?: string;
  merchantName?: string;
  amount?: number;
  paymentMethod?: PaymentMethod | string;
  invoiceNumber?: string;
  notes?: string;
};

export interface DrawAnnouncement {
  id: string;
  title: string;
  drawPeriod: string;
  announcementDate: string;
  winningNumbers: string[]; // Normalized 12-digit strings
  sourceUrl?: string;
  sourceName?: string;
  notes?: string;
  createdAt: string;
}

export type NewDrawInput = {
  title: string;
  drawPeriod: string;
  announcementDate: string;
  winningNumbers: string[];
  sourceUrl?: string;
  sourceName?: string;
  notes?: string;
};

export interface CouponMatch {
  userCoupon: Coupon;
  matchedWinningNumber: string;
  drawTitle?: string;
  drawPeriod?: string;
  announcementDate?: string;
}

export interface WinnerCheckResult {
  checkedCouponCount: number;
  winningNumberCount: number;
  matches: CouponMatch[];
  checkedAt: string;
  drawInfo?: {
    title?: string;
    drawPeriod?: string;
    announcementDate?: string;
  };
}

export interface BulkParseResult {
  totalExtracted: number;
  validNew: string[];
  duplicateInBatch: string[];
  alreadySaved: string[];
  invalidTokens: string[];
}

export type IRDSourceType = 
  | 'current_programme'
  | 'legal_provision'
  | 'official_announcement'
  | 'app_explanation';

export interface IRDNotice {
  id: string;
  sourceType?: IRDSourceType;
  programmeId?: string;
  title: string;
  publicationDate?: string;
  effectiveFrom?: string;
  effectiveTo?: string;
  sourceOrganization: string;
  sourceUrl: string;
  category?: string;
  summary: string;
  details?: string;
  lastVerifiedAt?: string;
  isOfficialSource?: boolean;
}

export type ScreenName = 
  | 'home'
  | 'my_coupons'
  | 'add_coupon'
  | 'bulk_add_coupons'
  | 'winner_checker'
  | 'draw_history'
  | 'check_eligibility'
  | 'add_transaction'
  | 'my_transactions'
  | 'transaction_detail'
  | 'ird_info'
  | 'data_backup'
  | 'claim_report';

export interface RasidKhataBackupPayload {
  app: 'Rasid Khata';
  backupVersion: number;
  exportedAt: string;
  appNameNepali?: string;
  summary: {
    totalTransactions: number;
    totalCoupons: number;
    totalCustomDraws: number;
    hasPhotos: boolean;
  };
  transactions: Transaction[];
  coupons: Coupon[];
  customDraws: DrawAnnouncement[];
}

export interface BackupValidationResult {
  isValid: boolean;
  error?: string;
  backupData?: RasidKhataBackupPayload;
  stats?: {
    transactionCount: number;
    couponCount: number;
    customDrawCount: number;
    exportedAt: string;
    backupVersion: number;
    hasPhotos: boolean;
  };
}

export type RestoreMode = 'replace' | 'merge';

export interface RestoreResult {
  success: boolean;
  mode: RestoreMode;
  transactionsImported: number;
  transactionsSkipped: number;
  couponsImported: number;
  couponsSkipped: number;
  drawsImported: number;
  drawsSkipped: number;
  error?: string;
}

export interface ClaimReportData {
  matchedCoupon: Coupon;
  matchedWinningNumber: string;
  drawTitle?: string;
  drawPeriod?: string;
  announcementDate?: string;
  sourceUrl?: string;
  sourceName?: string;
  associatedTransaction?: Transaction;
}

