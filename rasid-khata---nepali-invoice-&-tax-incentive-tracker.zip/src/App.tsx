import React, { useState } from 'react';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { HomeScreen } from './screens/HomeScreen';
import { AddTransactionScreen } from './screens/AddTransactionScreen';
import { TransactionsListScreen } from './screens/TransactionsListScreen';
import { TransactionDetailScreen } from './screens/TransactionDetailScreen';
import { IRDInfoScreen } from './screens/IRDInfoScreen';
import { MyCouponsScreen } from './screens/MyCouponsScreen';
import { AddCouponScreen } from './screens/AddCouponScreen';
import { BulkAddCouponsScreen } from './screens/BulkAddCouponsScreen';
import { WinnerCheckerScreen } from './screens/WinnerCheckerScreen';
import { DrawHistoryScreen } from './screens/DrawHistoryScreen';
import { CheckEligibilityScreen } from './screens/CheckEligibilityScreen';
import { DataBackupScreen } from './screens/DataBackupScreen';
import { ClaimReportScreen } from './screens/ClaimReportScreen';
import { PrefillCouponData } from './screens/AddCouponScreen';
import { ScreenName, ClaimReportData } from './types/transaction';
import { Smartphone, Monitor, ShieldCheck, Wifi, Database } from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenName>('home');
  const [screenHistory, setScreenHistory] = useState<ScreenName[]>(['home']);
  const [selectedTransactionId, setSelectedTransactionId] = useState<string | undefined>(undefined);
  const [selectedNoticeId, setSelectedNoticeId] = useState<string | undefined>(undefined);
  const [activeCheckWinners, setActiveCheckWinners] = useState<string[] | undefined>(undefined);
  const [activePrefillCoupon, setActivePrefillCoupon] = useState<PrefillCouponData | undefined>(undefined);
  const [activeClaimReportData, setActiveClaimReportData] = useState<ClaimReportData | undefined>(undefined);
  const [isMobileFrameMode, setIsMobileFrameMode] = useState<boolean>(true);

  const navigateTo = (
    screen: ScreenName, 
    params?: { 
      transactionId?: string; 
      selectedNoticeId?: string;
      checkWinningNumbers?: string[];
      prefillCoupon?: PrefillCouponData;
      claimReportData?: ClaimReportData;
    }
  ) => {
    if (params?.transactionId) {
      setSelectedTransactionId(params.transactionId);
    }
    if (params?.selectedNoticeId) {
      setSelectedNoticeId(params.selectedNoticeId);
    }
    if (params?.checkWinningNumbers) {
      setActiveCheckWinners(params.checkWinningNumbers);
    }
    if (params?.prefillCoupon) {
      setActivePrefillCoupon(params.prefillCoupon);
    }
    if (params?.claimReportData) {
      setActiveClaimReportData(params.claimReportData);
    }
    setScreenHistory((prev) => [...prev, screen]);
    setCurrentScreen(screen);
    // Scroll to top upon screen navigation
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBack = () => {
    if (screenHistory.length > 1) {
      const nextHistory = [...screenHistory];
      nextHistory.pop();
      const previousScreen = nextHistory[nextHistory.length - 1];
      setScreenHistory(nextHistory);
      setCurrentScreen(previousScreen);
    } else {
      setCurrentScreen('home');
      setScreenHistory(['home']);
    }
  };

  // Dynamic header configuration based on current screen
  const getHeaderProps = () => {
    switch (currentScreen) {
      case 'home':
        return {
          title: 'Rasid Khata (रसिद खाता)',
          subtitle: 'Nepal Tax Incentive & Invoice Tracker',
          showBack: false,
          rightAction: (
            <button
              id="header-backup-btn"
              onClick={() => navigateTo('data_backup')}
              className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1"
              title="Data & Backup"
            >
              <Database className="w-4 h-4" />
            </button>
          ),
        };
      case 'add_transaction':
        return {
          title: 'Add Invoice',
          subtitle: 'Record Purchase & Bill',
          showBack: true,
          onBack: handleBack,
        };
      case 'my_transactions':
        return {
          title: 'My Invoices',
          subtitle: 'Saved Purchase Invoices',
          showBack: screenHistory.length > 1 && screenHistory[screenHistory.length - 2] !== 'my_transactions',
          onBack: handleBack,
        };
      case 'transaction_detail':
        return {
          title: 'Invoice Details',
          subtitle: 'Saved Personal Record',
          showBack: true,
          onBack: handleBack,
        };
      case 'my_coupons':
        return {
          title: 'My Prize Coupons',
          subtitle: '12-Digit Electronic Incentive Numbers',
          showBack: screenHistory.length > 1 && screenHistory[screenHistory.length - 2] !== 'my_coupons',
          onBack: handleBack,
        };
      case 'add_coupon':
        return {
          title: 'Add Single Coupon',
          subtitle: '12-Digit Number Entry',
          showBack: true,
          onBack: handleBack,
        };
      case 'bulk_add_coupons':
        return {
          title: 'Bulk Add Coupons',
          subtitle: 'Paste & Parse Multiple Numbers',
          showBack: true,
          onBack: handleBack,
        };
      case 'winner_checker':
        return {
          title: 'Winner Checker',
          subtitle: 'Compare Against IRD Numbers',
          showBack: screenHistory.length > 1 && screenHistory[screenHistory.length - 2] !== 'winner_checker',
          onBack: handleBack,
        };
      case 'draw_history':
        return {
          title: 'Draw Announcements',
          subtitle: 'IRD Winner Cycles',
          showBack: true,
          onBack: handleBack,
        };
      case 'ird_info':
        return {
          title: 'IRD Information',
          subtitle: 'Official Notices & Tax Guidelines',
          showBack: screenHistory.length > 1 && screenHistory[screenHistory.length - 2] !== 'ird_info',
          onBack: handleBack,
        };
      case 'check_eligibility':
        return {
          title: 'Eligibility Helper',
          subtitle: 'Check if Purchase Qualifies for Lottery',
          showBack: true,
          onBack: handleBack,
        };
      case 'data_backup':
        return {
          title: 'Data & Backup',
          subtitle: 'JSON Backups, CSV Export & Restore',
          showBack: true,
          onBack: handleBack,
        };
      case 'claim_report':
        return {
          title: 'Claim Preparation Dossier',
          subtitle: 'Independent Personal Verification Document',
          showBack: true,
          onBack: handleBack,
        };
      default:
        return {
          title: 'Rasid Khata',
          showBack: false,
        };
    }
  };

  const renderActiveScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen onNavigate={navigateTo} />;
      case 'add_transaction':
        return (
          <AddTransactionScreen
            onNavigate={navigateTo}
            onBack={handleBack}
          />
        );
      case 'my_transactions':
        return <TransactionsListScreen onNavigate={navigateTo} />;
      case 'transaction_detail':
        return (
          <TransactionDetailScreen
            transactionId={selectedTransactionId}
            onBack={handleBack}
            onNavigate={navigateTo}
          />
        );
      case 'my_coupons':
        return <MyCouponsScreen onNavigate={navigateTo} />;
      case 'add_coupon':
        return (
          <AddCouponScreen
            onNavigate={navigateTo}
            onBack={handleBack}
            prefillData={activePrefillCoupon}
          />
        );
      case 'bulk_add_coupons':
        return (
          <BulkAddCouponsScreen
            onNavigate={navigateTo}
            onBack={handleBack}
          />
        );
      case 'winner_checker':
        return (
          <WinnerCheckerScreen
            onNavigate={navigateTo}
            initialWinningNumbers={activeCheckWinners}
            onSelectClaimReport={(reportData) => navigateTo('claim_report', { claimReportData: reportData })}
          />
        );
      case 'draw_history':
        return <DrawHistoryScreen onNavigate={navigateTo} />;
      case 'ird_info':
        return <IRDInfoScreen initialSelectedNoticeId={selectedNoticeId} />;
      case 'check_eligibility':
        return (
          <CheckEligibilityScreen
            onNavigate={navigateTo}
            onBack={handleBack}
          />
        );
      case 'data_backup':
        return (
          <DataBackupScreen
            onNavigate={navigateTo}
            onBack={handleBack}
          />
        );
      case 'claim_report':
        return (
          <ClaimReportScreen
            reportData={activeClaimReportData}
            onBack={handleBack}
            onNavigate={navigateTo}
          />
        );
      default:
        return <HomeScreen onNavigate={navigateTo} />;
    }
  };


  return (
    <div className="min-h-screen bg-slate-100 flex flex-col items-center justify-start text-slate-800 font-sans antialiased selection:bg-teal-100 selection:text-teal-900">
      {/* Top Bar for Desktop Preview / Viewport Mode Switcher */}
      <div className="w-full bg-slate-900 text-slate-300 text-xs px-4 py-2 border-b border-slate-800 flex items-center justify-between z-50">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-white tracking-tight flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            Rasid Khata
          </span>
          <span className="hidden sm:inline text-slate-500">•</span>
          <span className="hidden sm:inline text-slate-400 text-[11px]">
            Incentive Coupon &amp; Winner Checker MVP
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-400 hidden md:inline">Preview Mode:</span>
          <button
            id="toggle-mobile-frame-btn"
            onClick={() => setIsMobileFrameMode(!isMobileFrameMode)}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded-lg text-xs font-medium border border-slate-700 transition-colors"
            title={isMobileFrameMode ? 'Switch to Full Width View' : 'Switch to Android Phone Mockup'}
          >
            {isMobileFrameMode ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-teal-400" />
                <span className="text-[11px]">Full Width</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-teal-400" />
                <span className="text-[11px]">Android Frame</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Container - Either Phone Frame on Desktop or Fluid Viewport on Mobile */}
      <div 
        className={`w-full transition-all duration-200 flex flex-col ${
          isMobileFrameMode 
            ? 'max-w-[430px] my-0 sm:my-5 sm:rounded-[32px] sm:shadow-2xl sm:border-[8px] sm:border-slate-800/90 overflow-hidden bg-slate-50 min-h-screen sm:min-h-[850px] relative' 
            : 'max-w-xl mx-auto bg-slate-50 min-h-screen shadow-sm'
        }`}
      >
        {/* Android Device Mockup Status Bar (visible when inside frame) */}
        {isMobileFrameMode && (
          <div className="bg-slate-900 text-slate-400 text-[10px] px-5 py-1.5 flex items-center justify-between select-none border-b border-slate-800/50">
            <span className="font-semibold text-slate-300">9:41</span>
            <div className="flex items-center gap-2">
              <Wifi className="w-3 h-3 text-slate-300" />
              <span className="font-medium text-[10px] text-slate-300">5G</span>
              <div className="w-4 h-2 rounded-2xs border border-slate-400 p-0.5 flex items-center">
                <div className="w-full h-full bg-slate-300 rounded-3xs"></div>
              </div>
            </div>
          </div>
        )}

        {/* Application Header */}
        <Header {...getHeaderProps()} />

        {/* Screen View Container */}
        <main className="flex-1 flex flex-col bg-slate-50 overflow-y-auto">
          {renderActiveScreen()}
        </main>

        {/* Persistent Bottom Navigation */}
        <BottomNav 
          currentScreen={currentScreen} 
          onNavigate={(screen) => navigateTo(screen)} 
        />
      </div>
    </div>
  );
}
