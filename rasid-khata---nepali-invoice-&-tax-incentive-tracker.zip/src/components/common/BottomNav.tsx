import React from 'react';
import { Home, Receipt, Ticket, Trophy, Info } from 'lucide-react';
import { ScreenName } from '../../types/transaction';

interface BottomNavProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentScreen, onNavigate }) => {
  const tabs: { id: ScreenName; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'my_transactions', label: 'Invoices', icon: Receipt },
    { id: 'my_coupons', label: 'Coupons', icon: Ticket },
    { id: 'winner_checker', label: 'Checker', icon: Trophy },
    { id: 'ird_info', label: 'IRD Info', icon: Info },
  ];

  return (
    <nav className="sticky bottom-0 z-30 bg-white border-t border-slate-200 px-2 py-1.5 pb-safe shadow-xs">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = 
            currentScreen === tab.id || 
            (tab.id === 'my_transactions' && currentScreen === 'transaction_detail') ||
            (tab.id === 'my_coupons' && (currentScreen === 'add_coupon' || currentScreen === 'bulk_add_coupons')) ||
            (tab.id === 'winner_checker' && currentScreen === 'draw_history');

          return (
            <button
              key={tab.id}
              id={`nav-tab-${tab.id}`}
              onClick={() => onNavigate(tab.id)}
              className={`flex flex-col items-center justify-center py-1 px-1.5 rounded-lg transition-all duration-150 min-w-[54px] min-h-[44px] ${
                isActive
                  ? 'text-emerald-700 font-semibold'
                  : 'text-slate-400 hover:text-slate-700 font-medium'
              }`}
            >
              <div
                className={`p-1 rounded-md transition-colors ${
                  isActive ? 'bg-emerald-50 text-emerald-700' : 'text-slate-500'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'stroke-[2.25]' : 'stroke-[1.75]'}`} />
              </div>
              <span className="text-[9px] uppercase tracking-wider font-semibold leading-tight mt-0.5">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
