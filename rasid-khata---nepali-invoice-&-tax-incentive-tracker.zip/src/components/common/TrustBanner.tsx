import React from 'react';
import { AlertCircle, Info, ShieldCheck } from 'lucide-react';

interface TrustBannerProps {
  type?: 'info' | 'user-data' | 'disclaimer';
  text?: string;
  className?: string;
}

export const TrustBanner: React.FC<TrustBannerProps> = ({
  type = 'info',
  text,
  className = '',
}) => {
  if (type === 'user-data') {
    return (
      <div className={`flex items-start gap-2.5 bg-amber-50/80 border border-amber-200/80 rounded-xl p-3 text-amber-900 text-xs leading-relaxed shadow-xs ${className}`}>
        <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-[11px] uppercase tracking-wider block text-amber-950">Your Saved Information</span>
          <span className="text-slate-700 text-xs">{text || 'This record contains user-entered data for personal expense tracking. It is not an official government verification or tax document.'}</span>
        </div>
      </div>
    );
  }

  if (type === 'disclaimer') {
    return (
      <div className={`flex items-start gap-2.5 bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-700 text-xs leading-relaxed shadow-xs ${className}`}>
        <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-[11px] uppercase tracking-wider block text-slate-800">Official Third-Party Information</span>
          <span className="text-slate-600 text-xs">{text || 'All notices are compiled from public announcements from the Inland Revenue Department (IRD) Nepal. This app is an independent helper tool and is not affiliated with or endorsed by the IRD.'}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex items-start gap-2 bg-emerald-50/80 border border-emerald-200/80 rounded-xl p-3 text-emerald-900 text-xs leading-relaxed shadow-xs ${className}`}>
      <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
      <div>{text}</div>
    </div>
  );
};
