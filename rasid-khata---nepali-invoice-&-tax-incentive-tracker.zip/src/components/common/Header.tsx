import React from 'react';
import { ArrowLeft, ShieldCheck, Receipt } from 'lucide-react';
import { ScreenName } from '../../types/transaction';

interface HeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  rightAction?: React.ReactNode;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  showBack = false,
  onBack,
  rightAction,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between min-h-[56px] shadow-xs">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        {showBack ? (
          <button
            id="header-back-btn"
            onClick={onBack}
            className="p-1.5 -ml-1 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 active:bg-slate-200 transition-colors"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        ) : (
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow-xs shrink-0">
            <span>र</span>
          </div>
        )}
        <div className="truncate">
          <h1 className="text-sm font-bold tracking-tight text-slate-900 truncate">
            {title}
          </h1>
          {subtitle && (
            <p className="text-[11px] text-slate-500 font-normal truncate">
              {subtitle}
            </p>
          )}
        </div>
      </div>

      {rightAction ? (
        <div className="flex items-center gap-2 shrink-0">{rightAction}</div>
      ) : (
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200/80 px-2.5 py-1 rounded-md shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Phase 1 Draft</span>
        </div>
      )}
    </header>
  );
};
