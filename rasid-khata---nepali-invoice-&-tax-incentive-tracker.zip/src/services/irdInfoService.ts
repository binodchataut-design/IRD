import { IRDNotice, IRDSourceType } from '../types/transaction';

/**
 * SOURCE HIERARCHY FOR VERIFIED CONTENT:
 * 1. IRD Official Website (https://ird.gov.np)
 * 2. Official IRD Programme Portal / Circular Gazettes
 * 3. Ministry of Finance / Government of Nepal Official Publications
 * 4. Other directly relevant official statutory publications
 * 
 * Note: News articles or social media reports are NEVER treated as sources of truth for legal or programme rules.
 */
const IRD_NOTICES: IRDNotice[] = [
  // Layer 1: CURRENT PROGRAMME (Official information specific to the current taxpayer incentive programme)
  {
    id: 'prog-cur-01',
    sourceType: 'current_programme',
    programmeId: 'nepal-ird-electronic-billing-consumer-incentive',
    title: 'Electronic Billing Consumer Tax Incentive Scheme (Current Fiscal Framework)',
    publicationDate: '2026-08-01',
    effectiveFrom: '2026-07-16',
    sourceOrganization: 'Inland Revenue Department (IRD Nepal)',
    sourceUrl: 'https://ird.gov.np',
    category: 'Current Programme Directive',
    summary: 'Pending verification from an official source.',
    details: 'Pending verification from an official source. Details regarding current consumer incentive modalities, eligible payment channels, and participation guidelines are determined strictly by official gazette circulars published at ird.gov.np.',
    lastVerifiedAt: '2026-08-17',
    isOfficialSource: true,
  },

  // Layer 2: LEGAL / TAX PROVISION (General provisions published by IRD or official authority)
  {
    id: 'legal-prov-01',
    sourceType: 'legal_provision',
    programmeId: 'nepal-tax-statutory-framework',
    title: 'Value Added Tax Act & Electronic Billing System Provisions',
    publicationDate: '2025-11-20',
    effectiveFrom: '2025-11-20',
    sourceOrganization: 'Ministry of Finance & IRD Legal Division',
    sourceUrl: 'https://ird.gov.np/legal-framework',
    category: 'Statutory Tax Provision',
    summary: 'General statutory provisions governing merchant obligations to issue authorized fiscal receipts and maintain electronic sales logs.',
    details: 'Under prevailing Nepal tax regulations and Value Added Tax directives, registered commercial entities are required to issue authentic invoices displaying their valid 9-digit PAN/VAT number. This is a general legal requirement and applies broadly across commercial retail transactions.',
    lastVerifiedAt: '2026-08-17',
    isOfficialSource: true,
  },

  // Layer 3: OFFICIAL ANNOUNCEMENTS (Time-sensitive official notices, announcements, and circulars)
  {
    id: 'ann-upd-01',
    sourceType: 'official_announcement',
    programmeId: 'nepal-ird-electronic-billing-consumer-incentive',
    title: 'Public Advisory on QR Code Invoices and Authorized Billing Software',
    publicationDate: '2026-07-28',
    effectiveFrom: '2026-07-28',
    effectiveTo: '2026-10-30',
    sourceOrganization: 'Inland Revenue Department — System & Monitoring Division',
    sourceUrl: 'https://ird.gov.np/notices',
    category: 'Public Advisory Circular',
    summary: 'Pending verification from an official source.',
    details: 'Pending verification from an official source. Registered taxpayers and consumers are advised to refer to the official IRD technical and public advisories published at ird.gov.np/notices for software approval and receipt verification guidelines.',
    lastVerifiedAt: '2026-08-17',
    isOfficialSource: true,
  },

  // Layer 4: APP EXPLANATION (Plain-language explanations written by Rasid Khata)
  {
    id: 'app-guide-01',
    sourceType: 'app_explanation',
    programmeId: 'rasid-khata-app-guide',
    title: 'How to Organize Personal Invoices and Payment Proofs',
    publicationDate: '2026-08-15',
    sourceOrganization: 'Rasid Khata Application',
    sourceUrl: 'https://ird.gov.np',
    category: 'App User Guide',
    summary: 'An educational overview explaining why tracking merchant PANs and saving bill receipts helps manage personal expenditure records.',
    details: 'This is an unofficial app explanation. Keeping a personal log of your daily retail purchases, digital wallet transaction references, and merchant PAN numbers simplifies personal record-keeping. When official tax incentive or reconciliation schemes are active, having organized digital records makes documentation easier. This guide is for personal reference and is not an official government rule.',
    lastVerifiedAt: '2026-08-17',
    isOfficialSource: false,
  },
  {
    id: 'app-guide-02',
    sourceType: 'app_explanation',
    programmeId: 'rasid-khata-app-guide',
    title: 'Understanding Merchant PAN and VAT Numbers on Invoices',
    publicationDate: '2026-07-10',
    sourceOrganization: 'Rasid Khata Application',
    sourceUrl: 'https://ird.gov.np',
    category: 'App Concept Guide',
    summary: 'An informal overview of what the 9-digit Permanent Account Number (PAN) printed on cash receipts represents.',
    details: 'This is an unofficial app explanation. In Nepal, businesses registered with the Inland Revenue Department are issued a 9-digit Permanent Account Number (PAN). When you make a retail purchase, the seller should provide an authorized bill containing this number. Recording this number ensures your personal ledger correctly records authentic commercial transactions.',
    lastVerifiedAt: '2026-08-17',
    isOfficialSource: false,
  }
];

export const irdInfoService = {
  getAll: (): IRDNotice[] => {
    return [...IRD_NOTICES];
  },

  getLatest: (limit = 3): IRDNotice[] => {
    return IRD_NOTICES.slice(0, limit);
  },

  getById: (id: string): IRDNotice | undefined => {
    return IRD_NOTICES.find(n => n.id === id);
  },

  getByLayer: (layer: IRDSourceType): IRDNotice[] => {
    return IRD_NOTICES.filter(n => (n.sourceType || 'app_explanation') === layer);
  },

  getBySourceType: (isOfficial: boolean): IRDNotice[] => {
    return IRD_NOTICES.filter(n => Boolean(n.isOfficialSource) === isOfficial);
  }
};


