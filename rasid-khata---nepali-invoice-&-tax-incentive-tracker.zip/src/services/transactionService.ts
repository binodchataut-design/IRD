import { Transaction, NewTransactionInput, PaymentMethod } from '../types/transaction';

const STORAGE_KEY = 'rasid_khata_transactions_v2';

// Realistic fictional 25-record dataset representing Nepali consumer purchases across ~15 days
const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-001',
    date: '2026-08-16',
    sellerName: 'Sagarmatha Bakery & Cafe',
    panVat: '601928374',
    sellerPanVat: '601928374',
    invoiceNumber: 'SB-8821',
    amount: 320,
    paymentMethod: 'Digital Wallet',
    notes: 'Morning tea and bakery items.',
    photoReference: 'https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-16T08:15:00Z',
  },
  {
    id: 'tx-002',
    date: '2026-08-15',
    sellerName: 'Annapurna Stationery & Gift House',
    panVat: '302819201',
    sellerPanVat: '302819201',
    invoiceNumber: 'AS-1049',
    amount: 450,
    paymentMethod: 'Card',
    notes: 'Notebooks and gel pens.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-15T11:20:00Z',
  },
  {
    id: 'tx-003',
    date: '2026-08-15',
    sellerName: 'Patan Stationery Hub',
    panVat: '609123847',
    sellerPanVat: '609123847',
    invoiceNumber: 'INV-2026-009',
    amount: 240,
    paymentMethod: 'Cash',
    notes: 'Photocopy and folder files.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-15T14:40:00Z',
  },
  {
    id: 'tx-004',
    date: '2026-08-14',
    sellerName: 'Lalitpur Electronics Express',
    panVat: undefined,
    sellerPanVat: undefined,
    invoiceNumber: 'INV-2026-009',
    amount: 480,
    paymentMethod: 'Digital Wallet',
    notes: 'USB-C charging cable.',
    photoReference: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-14T10:05:00Z',
  },
  {
    id: 'tx-005',
    date: '2026-08-14',
    sellerName: 'Shree Pashupati Organic Ayurvedic Herbs & Pure Himalayan Spices Processing & Wholesale Center',
    panVat: '100482910',
    sellerPanVat: '100482910',
    invoiceNumber: 'SPH-99214',
    amount: 390,
    paymentMethod: 'Cash',
    notes: 'Ginger powder and organic tea leaves.',
    photoReference: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-14T16:30:00Z',
  },
  {
    id: 'tx-006',
    date: '2026-08-13',
    sellerName: 'Everest IT Hardware & Office Equipments',
    panVat: '304918273',
    sellerPanVat: '304918273',
    invoiceNumber: 'EIT-2026-784',
    amount: 54850,
    paymentMethod: 'Bank Transfer',
    notes: 'Office monitor and ergonomic mesh chair.',
    photoReference: 'https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-13T09:45:00Z',
  },
  {
    id: 'tx-007',
    date: '2026-08-13',
    sellerName: 'Dhulikhel Fresh Veggie & Fruit Mart',
    panVat: undefined,
    sellerPanVat: undefined,
    invoiceNumber: undefined,
    amount: 180,
    paymentMethod: 'Cash',
    notes: 'Seasonal vegetables.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-13T17:10:00Z',
  },
  {
    id: 'tx-008',
    date: '2026-08-12',
    sellerName: 'Bagmati Auto Parts & Lubricants',
    panVat: '602938475',
    sellerPanVat: '602938475',
    invoiceNumber: 'BAP-4401',
    amount: 350,
    paymentMethod: 'Digital Wallet',
    notes: 'Scooter engine oil top up.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-12T13:25:00Z',
  },
  {
    id: 'tx-009',
    date: '2026-08-11',
    sellerName: 'Namaste Departmental Store',
    panVat: '301928374',
    sellerPanVat: '301928374',
    invoiceNumber: 'NDS-0922',
    amount: 420,
    paymentMethod: 'Card',
    notes: 'Snacks and kitchen detergent.',
    photoReference: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-11T19:00:00Z',
  },
  {
    id: 'tx-010',
    date: '2026-08-10',
    sellerName: 'Kantipur Books & Publishing Outlet',
    panVat: '600291834',
    sellerPanVat: '600291834',
    invoiceNumber: undefined,
    amount: 290,
    paymentMethod: 'Bank Transfer',
    notes: 'General knowledge study book.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-10T12:15:00Z',
  },
  {
    id: 'tx-011',
    date: '2026-08-10',
    sellerName: 'Himalayan Herbal Health Clinic',
    panVat: '109283746',
    sellerPanVat: '109283746',
    invoiceNumber: 'HH-5512',
    amount: 490,
    paymentMethod: 'Digital Wallet',
    notes: 'Herbal supplements and throat lozenges.',
    photoReference: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-10T15:30:00Z',
  },
  {
    id: 'tx-012',
    date: '2026-08-09',
    sellerName: 'Sunrise Quick Laundry Service',
    panVat: undefined,
    sellerPanVat: undefined,
    invoiceNumber: 'SQL-112',
    amount: 150,
    paymentMethod: 'Cash',
    notes: 'Ironing service.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-09T18:40:00Z',
  },
  {
    id: 'tx-013',
    date: '2026-08-08',
    sellerName: 'Gorkha Daily Dairy & Sweets',
    panVat: '608374619',
    sellerPanVat: '608374619',
    invoiceNumber: undefined,
    amount: 210,
    paymentMethod: 'Digital Wallet',
    notes: 'Fresh curd and paneer.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-08T07:50:00Z',
  },
  {
    id: 'tx-014',
    date: '2026-08-07',
    sellerName: 'Pokhara Kitchen Utensils & Crockery',
    panVat: '309182736',
    sellerPanVat: '309182736',
    invoiceNumber: 'PKU-7721',
    amount: 375,
    paymentMethod: 'Card',
    notes: 'Stainless steel coffee mug.',
    photoReference: 'https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-07T14:10:00Z',
  },
  {
    id: 'tx-015',
    date: '2026-08-06',
    sellerName: 'Trisuli General Hardware Supplies',
    panVat: undefined,
    sellerPanVat: undefined,
    invoiceNumber: undefined,
    amount: 280,
    paymentMethod: 'Cash',
    notes: 'Screws, anchors, and insulating tape.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-06T11:00:00Z',
  },
  {
    id: 'tx-016',
    date: '2026-08-06',
    sellerName: 'Chitwan Organic Poultry & Meat Shop',
    panVat: '604829103',
    sellerPanVat: '604829103',
    invoiceNumber: 'COP-3011',
    amount: 495,
    paymentMethod: 'Digital Wallet',
    notes: 'Fresh chicken breast.',
    photoReference: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-06T17:45:00Z',
  },
  {
    id: 'tx-017',
    date: '2026-08-05',
    sellerName: 'Lumbini Footwear & Shoe Care',
    panVat: '102938475',
    sellerPanVat: '102938475',
    invoiceNumber: 'LFS-889',
    amount: 360,
    paymentMethod: 'Bank Transfer',
    notes: 'Shoe polish and replacement laces.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-05T13:20:00Z',
  },
  {
    id: 'tx-018',
    date: '2026-08-05',
    sellerName: 'Janakpur Handloom & Textiles',
    panVat: undefined,
    sellerPanVat: undefined,
    invoiceNumber: 'JHT-045',
    amount: 410,
    paymentMethod: 'Cash',
    notes: 'Cotton hand towels.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-05T16:00:00Z',
  },
  {
    id: 'tx-019',
    date: '2026-08-04',
    sellerName: 'Mustang Mountain Tea Lounge',
    panVat: '605918273',
    sellerPanVat: '605918273',
    invoiceNumber: 'MMT-102',
    amount: 220,
    paymentMethod: 'Digital Wallet',
    notes: 'Special masala tea and cookies.',
    photoReference: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-04T10:30:00Z',
  },
  {
    id: 'tx-020',
    date: '2026-08-03',
    sellerName: 'Manaslu Sports & Outdoor Gear',
    panVat: '308271920',
    sellerPanVat: '308271920',
    invoiceNumber: 'MSG-6619',
    amount: 460,
    paymentMethod: 'Card',
    notes: 'Sports water bottle and sweatband.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-03T15:15:00Z',
  },
  {
    id: 'tx-021',
    date: '2026-08-03',
    sellerName: 'Karnali Organic Seed & Garden Store',
    panVat: undefined,
    sellerPanVat: undefined,
    invoiceNumber: undefined,
    amount: 190,
    paymentMethod: 'Cash',
    notes: 'Flower seeds and planting pot.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-03T18:00:00Z',
  },
  {
    id: 'tx-022',
    date: '2026-08-02',
    sellerName: 'Bandipur Bakery & Dessert Studio',
    panVat: '603819274',
    sellerPanVat: '603819274',
    invoiceNumber: 'BBD-409',
    amount: 310,
    paymentMethod: 'Digital Wallet',
    notes: 'Birthday pastry slices.',
    photoReference: 'https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1554415707-9e4966a642ed?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-02T12:40:00Z',
  },
  {
    id: 'tx-023',
    date: '2026-08-02',
    sellerName: 'Patan Craft & Handmade Paper Mart',
    panVat: '109384726',
    sellerPanVat: '109384726',
    invoiceNumber: 'PCH-221',
    amount: 270,
    paymentMethod: 'Bank Transfer',
    notes: 'Lokta craft notebooks.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-02T16:50:00Z',
  },
  {
    id: 'tx-024',
    date: '2026-08-01',
    sellerName: 'Boudha Optical & Eye Care Clinic',
    panVat: '307182930',
    sellerPanVat: '307182930',
    invoiceNumber: 'BOE-9041',
    amount: 480,
    paymentMethod: 'Card',
    notes: 'Lens cleaning solution and microfibre cloth.',
    photoReference: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80',
    invoicePhotoUrl: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80',
    createdAt: '2026-08-01T11:10:00Z',
  },
  {
    id: 'tx-025',
    date: '2026-08-01',
    sellerName: 'Biratnagar Refreshment & Juice Corner',
    panVat: undefined,
    sellerPanVat: undefined,
    invoiceNumber: undefined,
    amount: 130,
    paymentMethod: 'Cash',
    notes: 'Fresh sugarcane juice.',
    photoReference: undefined,
    invoicePhotoUrl: undefined,
    createdAt: '2026-08-01T14:30:00Z',
  }
];

/**
 * Validates and sanitizes a single raw transaction object
 */
function sanitizeTransaction(raw: unknown): Transaction | null {
  if (!raw || typeof raw !== 'object') return null;

  const item = raw as Record<string, unknown>;

  // Validate ID
  const id = typeof item.id === 'string' && item.id.trim().length > 0
    ? item.id.trim()
    : `tx-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

  // Validate Amount — ensure never NaN or infinite
  const rawAmount = typeof item.amount === 'number'
    ? item.amount
    : typeof item.amount === 'string'
      ? parseFloat(item.amount)
      : 0;

  const amount = !isNaN(rawAmount) && isFinite(rawAmount) && rawAmount >= 0 ? rawAmount : 0;

  // Validate Seller Name
  const sellerName = typeof item.sellerName === 'string' && item.sellerName.trim().length > 0
    ? item.sellerName.trim()
    : 'Unnamed Merchant';

  // Validate Date — YYYY-MM-DD format
  let date = typeof item.date === 'string' ? item.date.trim() : '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    date = new Date().toISOString().split('T')[0];
  }

  // Validate Payment Method
  const validMethods: PaymentMethod[] = ['Cash', 'Card', 'Digital Wallet', 'Bank Transfer', 'Other'];
  const paymentMethod: PaymentMethod = validMethods.includes(item.paymentMethod as PaymentMethod)
    ? (item.paymentMethod as PaymentMethod)
    : 'Other';

  // Optional string fields
  const panVat = typeof item.panVat === 'string'
    ? item.panVat.trim() || undefined
    : typeof item.sellerPanVat === 'string'
      ? item.sellerPanVat.trim() || undefined
      : undefined;

  const invoiceNumber = typeof item.invoiceNumber === 'string' && item.invoiceNumber.trim().length > 0
    ? item.invoiceNumber.trim()
    : undefined;

  const couponNumber = typeof item.couponNumber === 'string' && item.couponNumber.trim().length > 0
    ? item.couponNumber.trim()
    : undefined;

  const validStatuses = ['not_checked', 'likely_eligible', 'likely_not_eligible', 'needs_verification', 'awaiting_coupon', 'coupon_added'];
  const eligibilityStatus = typeof item.eligibilityStatus === 'string' && validStatuses.includes(item.eligibilityStatus)
    ? (item.eligibilityStatus as any)
    : couponNumber ? 'coupon_added' : undefined;

  const eligibilityReasons = Array.isArray(item.eligibilityReasons)
    ? item.eligibilityReasons.filter((r): r is string => typeof r === 'string')
    : undefined;

  const notes = typeof item.notes === 'string' && item.notes.trim().length > 0
    ? item.notes.trim()
    : undefined;

  const photoReference = typeof item.photoReference === 'string' && item.photoReference.trim().length > 0
    ? item.photoReference.trim()
    : typeof item.invoicePhotoUrl === 'string' && item.invoicePhotoUrl.trim().length > 0
      ? item.invoicePhotoUrl.trim()
      : undefined;

  const createdAt = typeof item.createdAt === 'string' && item.createdAt.trim().length > 0
    ? item.createdAt.trim()
    : new Date().toISOString();

  return {
    id,
    date,
    sellerName,
    amount,
    paymentMethod,
    panVat,
    sellerPanVat: panVat,
    invoiceNumber,
    couponNumber,
    eligibilityStatus,
    eligibilityReasons,
    notes,
    photoReference,
    invoicePhotoUrl: photoReference,
    createdAt
  };
}

/**
 * Safely load transactions from localStorage with corrupt-data protection
 */
function loadFromStorage(): Transaction[] {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return [...INITIAL_TRANSACTIONS];
    }

    const storedData = localStorage.getItem(STORAGE_KEY);
    if (!storedData) {
      // First run: Seed with initial dataset and persist
      saveToStorage(INITIAL_TRANSACTIONS);
      return [...INITIAL_TRANSACTIONS];
    }

    const parsed = JSON.parse(storedData);
    if (!Array.isArray(parsed)) {
      console.warn('[Rasid Khata] Corrupted storage format (not array). Falling back to empty transaction list.');
      return [];
    }

    const sanitizedList: Transaction[] = [];
    for (const item of parsed) {
      const sanitized = sanitizeTransaction(item);
      if (sanitized) {
        sanitizedList.push(sanitized);
      }
    }

    return sanitizedList;
  } catch (error) {
    console.error('[Rasid Khata] Failed to read or parse localStorage data:', error);
    // Graceful fallback: never crash the app
    return [];
  }
}

/**
 * Safely write transactions to localStorage
 */
function saveToStorage(transactions: Transaction[]): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return;
    }
    const serialized = JSON.stringify(transactions);
    localStorage.setItem(STORAGE_KEY, serialized);
  } catch (error) {
    console.error('[Rasid Khata] Failed to persist transactions to localStorage (quota or permission error):', error);
  }
}

// In-memory runtime cache synchronized with localStorage
let inMemoryTransactions: Transaction[] = loadFromStorage();

export const transactionService = {
  /**
   * Get all transactions ordered chronologically (newest first)
   */
  getAll: (): Transaction[] => {
    // Refresh from storage to guarantee fresh state across tabs/reloads
    inMemoryTransactions = loadFromStorage();
    return [...inMemoryTransactions].sort((a, b) => {
      const dateComparison = b.date.localeCompare(a.date);
      if (dateComparison !== 0) return dateComparison;
      return (b.createdAt || '').localeCompare(a.createdAt || '');
    });
  },

  /**
   * Get a single transaction by its stable unique ID
   */
  getById: (id: string): Transaction | undefined => {
    if (!id) return undefined;
    inMemoryTransactions = loadFromStorage();
    return inMemoryTransactions.find(tx => tx.id === id);
  },

  /**
   * Add a new transaction with validated data integrity
   */
  add: (input: NewTransactionInput): Transaction => {
    // Ensure amount is a strictly valid finite non-negative number
    const sanitizedAmount = typeof input.amount === 'number' && !isNaN(input.amount) && isFinite(input.amount)
      ? Math.max(0, input.amount)
      : 0;

    // Ensure valid date
    const sanitizedDate = input.date && /^\d{4}-\d{2}-\d{2}$/.test(input.date)
      ? input.date
      : new Date().toISOString().split('T')[0];

    const panValue = (input.panVat || input.sellerPanVat || '').trim() || undefined;
    const photoValue = (input.photoReference || input.invoicePhotoUrl || '').trim() || undefined;

    const newTx: Transaction = {
      id: `tx-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      date: sanitizedDate,
      sellerName: input.sellerName.trim() || 'Unnamed Merchant',
      amount: sanitizedAmount,
      paymentMethod: input.paymentMethod || 'Other',
      panVat: panValue,
      sellerPanVat: panValue,
      invoiceNumber: input.invoiceNumber?.trim() || undefined,
      couponNumber: input.couponNumber?.trim() || undefined,
      eligibilityStatus: input.eligibilityStatus || 'not_checked',
      eligibilityReasons: input.eligibilityReasons,
      notes: input.notes?.trim() || undefined,
      photoReference: photoValue,
      invoicePhotoUrl: photoValue,
      createdAt: new Date().toISOString(),
    };

    const current = loadFromStorage();
    const updated = [newTx, ...current];
    saveToStorage(updated);
    inMemoryTransactions = updated;

    return newTx;
  },

  /**
   * Update an existing transaction
   */
  update: (id: string, updates: Partial<NewTransactionInput>): Transaction | undefined => {
    const current = loadFromStorage();
    const index = current.findIndex(tx => tx.id === id);
    if (index === -1) return undefined;

    const existing = current[index];
    const rawUpdated = { ...existing, ...updates, id: existing.id, createdAt: existing.createdAt };
    const sanitized = sanitizeTransaction(rawUpdated);
    if (!sanitized) return undefined;

    current[index] = sanitized;
    saveToStorage(current);
    inMemoryTransactions = current;
    return sanitized;
  },

  /**
   * Delete a transaction by ID
   */
  delete: (id: string): boolean => {
    const current = loadFromStorage();
    const filtered = current.filter(tx => tx.id !== id);
    if (filtered.length === current.length) return false;

    saveToStorage(filtered);
    inMemoryTransactions = filtered;
    return true;
  },

  /**
   * Search transactions by seller name, PAN/VAT, invoice number, or payment method
   */
  search: (query: string): Transaction[] => {
    const all = transactionService.getAll();
    const q = query.trim().toLowerCase();
    if (!q) return all;

    return all.filter(tx => {
      const sellerMatch = (tx.sellerName || '').toLowerCase().includes(q);
      const panMatch = (tx.panVat || tx.sellerPanVat || '').toLowerCase().includes(q);
      const invoiceMatch = (tx.invoiceNumber || '').toLowerCase().includes(q);
      const methodMatch = (tx.paymentMethod || '').toLowerCase().includes(q);
      const notesMatch = (tx.notes || '').toLowerCase().includes(q);

      return sellerMatch || panMatch || invoiceMatch || methodMatch || notesMatch;
    });
  },

  /**
   * Reset to initial sample dataset (useful for testing and demoing)
   */
  resetToMock: (): void => {
    saveToStorage(INITIAL_TRANSACTIONS);
    inMemoryTransactions = [...INITIAL_TRANSACTIONS];
  },

  /**
   * Replace all transactions with a new array (used for restore: replace mode)
   */
  replaceAll: (transactions: Transaction[]): { imported: number } => {
    const sanitizedList: Transaction[] = [];
    for (const item of transactions) {
      const sanitized = sanitizeTransaction(item);
      if (sanitized) {
        sanitizedList.push(sanitized);
      }
    }
    saveToStorage(sanitizedList);
    inMemoryTransactions = sanitizedList;
    return { imported: sanitizedList.length };
  },

  /**
   * Merge new transactions into existing records (used for restore: merge mode)
   * Prevents duplicates by ID or identical (date + sellerName + amount + invoiceNumber)
   */
  mergeAll: (newTransactions: Transaction[]): { imported: number; skipped: number } => {
    const current = loadFromStorage();
    const existingIdSet = new Set(current.map(t => t.id));
    const existingSignatureSet = new Set(
      current.map(t => `${t.date}_${t.sellerName.toLowerCase().trim()}_${t.amount}_${(t.invoiceNumber || '').trim().toLowerCase()}`)
    );

    let imported = 0;
    let skipped = 0;
    const toAdd: Transaction[] = [];

    for (const item of newTransactions) {
      const sanitized = sanitizeTransaction(item);
      if (!sanitized) {
        skipped++;
        continue;
      }

      const sig = `${sanitized.date}_${sanitized.sellerName.toLowerCase().trim()}_${sanitized.amount}_${(sanitized.invoiceNumber || '').trim().toLowerCase()}`;

      if (existingIdSet.has(sanitized.id) || existingSignatureSet.has(sig)) {
        skipped++;
      } else {
        existingIdSet.add(sanitized.id);
        existingSignatureSet.add(sig);
        toAdd.push(sanitized);
        imported++;
      }
    }

    if (toAdd.length > 0) {
      const updated = [...toAdd, ...current].sort((a, b) => b.date.localeCompare(a.date));
      saveToStorage(updated);
      inMemoryTransactions = updated;
    }

    return { imported, skipped };
  },

  /**
   * Clear all transactions for empty state testing
   */
  clearAll: (): void => {
    saveToStorage([]);
    inMemoryTransactions = [];
  }
};


