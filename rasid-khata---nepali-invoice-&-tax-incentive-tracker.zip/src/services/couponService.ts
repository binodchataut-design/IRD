import { 
  Coupon, 
  NewCouponInput, 
  WinnerCheckResult, 
  CouponMatch, 
  BulkParseResult 
} from '../types/transaction';
import { 
  normalizeCouponNumber, 
  isValidCouponNumber, 
  parseBulkCouponsText 
} from '../utils/couponUtils';

const STORAGE_KEY = 'rasid_khata_coupons_v1';

// Initial realistic dataset of 28 sample coupons with 12-digit prize coupon numbers
// Includes leading zeros (e.g. '007315254493') and varied Nepali consumer expenses
const INITIAL_COUPONS: Coupon[] = [
  {
    id: 'cp-001',
    couponNumber: '007315254493',
    date: '2026-08-16',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Sagarmatha Bakery & Cafe',
    amount: 320,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'SB-8821',
    notes: 'Breakfast & coffee on Tripureshwor road',
    createdAt: '2026-08-16T08:15:00Z',
  },
  {
    id: 'cp-002',
    couponNumber: '002928817811',
    date: '2026-08-15',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Annapurna Stationery & Gift House',
    amount: 450,
    paymentMethod: 'Card',
    invoiceNumber: 'AS-1049',
    notes: 'Office supplies & pens',
    createdAt: '2026-08-15T11:20:00Z',
  },
  {
    id: 'cp-003',
    couponNumber: '003066779589',
    date: '2026-08-15',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Patan Stationery Hub',
    amount: 240,
    paymentMethod: 'Cash',
    invoiceNumber: 'INV-2026-009',
    notes: 'Photocopies and files',
    createdAt: '2026-08-15T14:40:00Z',
  },
  {
    id: 'cp-004',
    couponNumber: '015611059075',
    date: '2026-08-14',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Lalitpur Electronics Express',
    amount: 480,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'INV-2026-009',
    notes: 'Fast charging cable',
    createdAt: '2026-08-14T10:05:00Z',
  },
  {
    id: 'cp-005',
    couponNumber: '009917833245',
    date: '2026-08-14',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Shree Pashupati Organic Spices',
    amount: 390,
    paymentMethod: 'Cash',
    invoiceNumber: 'SPH-99214',
    notes: 'Organic tea & cardamom',
    createdAt: '2026-08-14T16:30:00Z',
  },
  {
    id: 'cp-006',
    couponNumber: '004128930192',
    date: '2026-08-13',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Everest IT Hardware Outlet',
    amount: 54850,
    paymentMethod: 'Bank Transfer',
    invoiceNumber: 'EIT-2026-784',
    notes: 'Monitor purchase with electronic tax invoice',
    createdAt: '2026-08-13T09:45:00Z',
  },
  {
    id: 'cp-007',
    couponNumber: '001827364510',
    date: '2026-08-13',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Dhulikhel Fresh Veggie & Fruit Mart',
    amount: 180,
    paymentMethod: 'Cash',
    invoiceNumber: undefined,
    notes: 'Seasonal groceries',
    createdAt: '2026-08-13T17:10:00Z',
  },
  {
    id: 'cp-008',
    couponNumber: '005829104728',
    date: '2026-08-12',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Bagmati Auto Parts & Lubricants',
    amount: 350,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'BAP-4401',
    notes: 'Scooter maintenance oil',
    createdAt: '2026-08-12T13:25:00Z',
  },
  {
    id: 'cp-009',
    couponNumber: '008273910482',
    date: '2026-08-11',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Namaste Departmental Store',
    amount: 420,
    paymentMethod: 'Card',
    invoiceNumber: 'NDS-0922',
    notes: 'Household kitchen essentials',
    createdAt: '2026-08-11T19:00:00Z',
  },
  {
    id: 'cp-010',
    couponNumber: '002938475619',
    date: '2026-08-10',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Kantipur Books & Publishing',
    amount: 290,
    paymentMethod: 'Bank Transfer',
    invoiceNumber: undefined,
    notes: 'Textbook purchase',
    createdAt: '2026-08-10T12:15:00Z',
  },
  {
    id: 'cp-011',
    couponNumber: '006918273645',
    date: '2026-08-10',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Himalayan Herbal Health Clinic',
    amount: 490,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'HH-5512',
    notes: 'Herbal syrup',
    createdAt: '2026-08-10T15:30:00Z',
  },
  {
    id: 'cp-012',
    couponNumber: '011293847560',
    date: '2026-08-09',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Sunrise Quick Laundry Service',
    amount: 150,
    paymentMethod: 'Cash',
    invoiceNumber: 'SQL-112',
    notes: 'Ironing service',
    createdAt: '2026-08-09T18:40:00Z',
  },
  {
    id: 'cp-013',
    couponNumber: '003829104857',
    date: '2026-08-08',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Gorkha Daily Dairy & Sweets',
    amount: 210,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: undefined,
    notes: 'Dahi & sweets',
    createdAt: '2026-08-08T07:50:00Z',
  },
  {
    id: 'cp-014',
    couponNumber: '007755590670',
    date: '2026-08-07',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Pokhara Kitchen Utensils & Crockery',
    amount: 375,
    paymentMethod: 'Card',
    invoiceNumber: 'PKU-7721',
    notes: 'Steel flask',
    createdAt: '2026-08-07T14:10:00Z',
  },
  {
    id: 'cp-015',
    couponNumber: '009283746150',
    date: '2026-08-06',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Trisuli General Hardware Supplies',
    amount: 280,
    paymentMethod: 'Cash',
    invoiceNumber: undefined,
    notes: 'Fixing tools and tapes',
    createdAt: '2026-08-06T11:00:00Z',
  },
  {
    id: 'cp-016',
    couponNumber: '004928173645',
    date: '2026-08-06',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Chitwan Organic Poultry & Meat',
    amount: 495,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'COP-3011',
    notes: 'Fresh chicken',
    createdAt: '2026-08-06T17:45:00Z',
  },
  {
    id: 'cp-017',
    couponNumber: '001928374650',
    date: '2026-08-05',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Lumbini Footwear & Shoe Care',
    amount: 360,
    paymentMethod: 'Bank Transfer',
    invoiceNumber: 'LFS-889',
    notes: 'Leather polish kit',
    createdAt: '2026-08-05T13:20:00Z',
  },
  {
    id: 'cp-018',
    couponNumber: '008192837465',
    date: '2026-08-05',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Janakpur Handloom & Textiles',
    amount: 410,
    paymentMethod: 'Cash',
    invoiceNumber: 'JHT-045',
    notes: 'Handwoven cloth',
    createdAt: '2026-08-05T16:00:00Z',
  },
  {
    id: 'cp-019',
    couponNumber: '005192837465',
    date: '2026-08-04',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Mustang Mountain Tea Lounge',
    amount: 220,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'MMT-102',
    notes: 'Special tea & bakery',
    createdAt: '2026-08-04T10:30:00Z',
  },
  {
    id: 'cp-020',
    couponNumber: '003928174650',
    date: '2026-08-03',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Manaslu Sports & Outdoor Gear',
    amount: 460,
    paymentMethod: 'Card',
    invoiceNumber: 'MSG-6619',
    notes: 'Sports bottle',
    createdAt: '2026-08-03T15:15:00Z',
  },
  {
    id: 'cp-021',
    couponNumber: '002819283746',
    date: '2026-08-03',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Karnali Organic Seed & Garden Store',
    amount: 190,
    paymentMethod: 'Cash',
    invoiceNumber: undefined,
    notes: 'Garden soil & seeds',
    createdAt: '2026-08-03T18:00:00Z',
  },
  {
    id: 'cp-022',
    couponNumber: '006819283746',
    date: '2026-08-02',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Bandipur Bakery & Dessert Studio',
    amount: 310,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'BBD-409',
    notes: 'Dessert cakes',
    createdAt: '2026-08-02T12:40:00Z',
  },
  {
    id: 'cp-023',
    couponNumber: '004819283746',
    date: '2026-08-02',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Patan Craft & Handmade Paper Mart',
    amount: 270,
    paymentMethod: 'Bank Transfer',
    invoiceNumber: 'PCH-221',
    notes: 'Lokta dairy book',
    createdAt: '2026-08-02T16:50:00Z',
  },
  {
    id: 'cp-024',
    couponNumber: '007819283746',
    date: '2026-08-01',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Boudha Optical & Eye Care Clinic',
    amount: 480,
    paymentMethod: 'Card',
    invoiceNumber: 'BOE-9041',
    notes: 'Lens cleaning solution',
    createdAt: '2026-08-01T11:10:00Z',
  },
  {
    id: 'cp-025',
    couponNumber: '001182938475',
    date: '2026-08-01',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Biratnagar Refreshment & Juice',
    amount: 130,
    paymentMethod: 'Cash',
    invoiceNumber: undefined,
    notes: 'Fresh juice',
    createdAt: '2026-08-01T14:30:00Z',
  },
  {
    id: 'cp-026',
    couponNumber: '009827364512',
    date: '2026-07-31',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Kathmandu Quick Print Center',
    amount: 340,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'KQP-119',
    notes: 'Document binding',
    createdAt: '2026-07-31T15:00:00Z',
  },
  {
    id: 'cp-027',
    couponNumber: '004738291045',
    date: '2026-07-30',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Bhaktapur Ceramic & Pottery Shop',
    amount: 520,
    paymentMethod: 'Card',
    invoiceNumber: 'BCS-78',
    notes: 'Clay tea cups set',
    createdAt: '2026-07-30T16:20:00Z',
  },
  {
    id: 'cp-028',
    couponNumber: '003728194056',
    date: '2026-07-29',
    drawPeriod: 'Shrawan 1–15, 2083',
    merchantName: 'Himalayan Coffee Beans & Roasters',
    amount: 650,
    paymentMethod: 'Digital Wallet',
    invoiceNumber: 'HCB-502',
    notes: 'Roasted Arabica coffee packet',
    createdAt: '2026-07-29T10:40:00Z',
  },
];

/**
 * Sanitizes and validates a single coupon record from storage.
 */
function sanitizeCoupon(raw: unknown): Coupon | null {
  if (!raw || typeof raw !== 'object') return null;
  const item = raw as Record<string, unknown>;

  const id = typeof item.id === 'string' && item.id.trim().length > 0
    ? item.id.trim()
    : `cp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

  const rawCouponNumber = typeof item.couponNumber === 'string' 
    ? item.couponNumber 
    : typeof item.couponNumber === 'number' 
      ? String(item.couponNumber) 
      : '';

  const normalized = normalizeCouponNumber(rawCouponNumber);
  if (!isValidCouponNumber(normalized)) {
    // If not a valid 12-digit number, ignore corrupted record
    return null;
  }

  let date = typeof item.date === 'string' ? item.date.trim() : undefined;
  if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    date = undefined;
  }

  const drawPeriod = typeof item.drawPeriod === 'string' && item.drawPeriod.trim().length > 0
    ? item.drawPeriod.trim()
    : undefined;

  const merchantName = typeof item.merchantName === 'string' && item.merchantName.trim().length > 0
    ? item.merchantName.trim()
    : undefined;

  const rawAmount = typeof item.amount === 'number'
    ? item.amount
    : typeof item.amount === 'string'
      ? parseFloat(item.amount)
      : undefined;

  const amount = rawAmount !== undefined && !isNaN(rawAmount) && isFinite(rawAmount) && rawAmount >= 0
    ? rawAmount
    : undefined;

  const paymentMethod = typeof item.paymentMethod === 'string' && item.paymentMethod.trim().length > 0
    ? item.paymentMethod.trim()
    : undefined;

  const invoiceNumber = typeof item.invoiceNumber === 'string' && item.invoiceNumber.trim().length > 0
    ? item.invoiceNumber.trim()
    : undefined;

  const notes = typeof item.notes === 'string' && item.notes.trim().length > 0
    ? item.notes.trim()
    : undefined;

  const createdAt = typeof item.createdAt === 'string' && item.createdAt.trim().length > 0
    ? item.createdAt.trim()
    : new Date().toISOString();

  return {
    id,
    couponNumber: normalized,
    date,
    drawPeriod,
    merchantName,
    amount,
    paymentMethod,
    invoiceNumber,
    notes,
    createdAt,
  };
}

/**
 * Safely load coupons from localStorage
 */
function loadFromStorage(): Coupon[] {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return [...INITIAL_COUPONS];
    }

    const storedData = localStorage.getItem(STORAGE_KEY);
    if (!storedData) {
      saveToStorage(INITIAL_COUPONS);
      return [...INITIAL_COUPONS];
    }

    const parsed = JSON.parse(storedData);
    if (!Array.isArray(parsed)) {
      return [];
    }

    const sanitizedList: Coupon[] = [];
    const seenNumbers = new Set<string>();

    for (const item of parsed) {
      const sanitized = sanitizeCoupon(item);
      if (sanitized && !seenNumbers.has(sanitized.couponNumber)) {
        seenNumbers.add(sanitized.couponNumber);
        sanitizedList.push(sanitized);
      }
    }

    return sanitizedList;
  } catch (error) {
    console.error('[Rasid Khata] Failed to read coupons from localStorage:', error);
    return [];
  }
}

/**
 * Safely write coupons to localStorage
 */
function saveToStorage(coupons: Coupon[]): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(coupons));
  } catch (error) {
    console.error('[Rasid Khata] Failed to save coupons to localStorage:', error);
  }
}

let inMemoryCoupons: Coupon[] = loadFromStorage();

export const couponService = {
  /**
   * Get all coupons ordered chronologically (newest date or creation first)
   */
  getAll: (): Coupon[] => {
    inMemoryCoupons = loadFromStorage();
    return [...inMemoryCoupons].sort((a, b) => {
      if (a.date && b.date) {
        const dateComp = b.date.localeCompare(a.date);
        if (dateComp !== 0) return dateComp;
      }
      return (b.createdAt || '').localeCompare(a.createdAt || '');
    });
  },

  /**
   * Get a single coupon by ID
   */
  getById: (id: string): Coupon | undefined => {
    if (!id) return undefined;
    inMemoryCoupons = loadFromStorage();
    return inMemoryCoupons.find(c => c.id === id);
  },

  /**
   * Find coupon by normalized 12-digit number
   */
  getByCouponNumber: (couponNumber: string): Coupon | undefined => {
    const norm = normalizeCouponNumber(couponNumber);
    if (!norm) return undefined;
    inMemoryCoupons = loadFromStorage();
    return inMemoryCoupons.find(c => c.couponNumber === norm);
  },

  /**
   * Add a single new coupon
   */
  add: (input: NewCouponInput): { success: boolean; coupon?: Coupon; error?: string } => {
    const normalized = normalizeCouponNumber(input.couponNumber);

    if (!isValidCouponNumber(normalized)) {
      return { 
        success: false, 
        error: `Coupon number must contain exactly 12 digits (currently ${normalized.length} digits).` 
      };
    }

    const current = loadFromStorage();
    const isDuplicate = current.some(c => c.couponNumber === normalized);

    if (isDuplicate) {
      return {
        success: false,
        error: `Coupon ${normalized} is already saved in your records.`,
      };
    }

    const newCoupon: Coupon = {
      id: `cp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      couponNumber: normalized,
      date: input.date && /^\d{4}-\d{2}-\d{2}$/.test(input.date) ? input.date : undefined,
      drawPeriod: input.drawPeriod?.trim() || undefined,
      merchantName: input.merchantName?.trim() || undefined,
      amount: typeof input.amount === 'number' && !isNaN(input.amount) && input.amount >= 0 ? input.amount : undefined,
      paymentMethod: input.paymentMethod || undefined,
      invoiceNumber: input.invoiceNumber?.trim() || undefined,
      notes: input.notes?.trim() || undefined,
      createdAt: new Date().toISOString(),
    };

    const updated = [newCoupon, ...current];
    saveToStorage(updated);
    inMemoryCoupons = updated;

    return { success: true, coupon: newCoupon };
  },

  /**
   * Add multiple coupons in bulk with optional default metadata
   */
  addBulk: (
    couponNumbers: string[],
    defaults?: {
      date?: string;
      drawPeriod?: string;
      merchantName?: string;
    }
  ): { addedCount: number; coupons: Coupon[] } => {
    const current = loadFromStorage();
    const existingSet = new Set(current.map(c => c.couponNumber));
    const newlyAdded: Coupon[] = [];

    for (const num of couponNumbers) {
      const norm = normalizeCouponNumber(num);
      if (isValidCouponNumber(norm) && !existingSet.has(norm)) {
        existingSet.add(norm);
        const newCoupon: Coupon = {
          id: `cp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}-${newlyAdded.length}`,
          couponNumber: norm,
          date: defaults?.date && /^\d{4}-\d{2}-\d{2}$/.test(defaults.date) ? defaults.date : undefined,
          drawPeriod: defaults?.drawPeriod?.trim() || undefined,
          merchantName: defaults?.merchantName?.trim() || undefined,
          createdAt: new Date().toISOString(),
        };
        newlyAdded.push(newCoupon);
      }
    }

    if (newlyAdded.length > 0) {
      const updated = [...newlyAdded, ...current];
      saveToStorage(updated);
      inMemoryCoupons = updated;
    }

    return { addedCount: newlyAdded.length, coupons: newlyAdded };
  },

  /**
   * Update an existing coupon
   */
  update: (id: string, updates: Partial<NewCouponInput>): { success: boolean; coupon?: Coupon; error?: string } => {
    const current = loadFromStorage();
    const index = current.findIndex(c => c.id === id);
    if (index === -1) {
      return { success: false, error: 'Coupon not found.' };
    }

    const existing = current[index];
    let nextCouponNumber = existing.couponNumber;

    if (updates.couponNumber !== undefined) {
      const norm = normalizeCouponNumber(updates.couponNumber);
      if (!isValidCouponNumber(norm)) {
        return { 
          success: false, 
          error: `Coupon number must contain exactly 12 digits (currently ${norm.length} digits).` 
        };
      }
      // Check duplicate against other coupons
      const duplicateExists = current.some((c, i) => i !== index && c.couponNumber === norm);
      if (duplicateExists) {
        return { success: false, error: `Coupon number ${norm} already exists in another record.` };
      }
      nextCouponNumber = norm;
    }

    const updatedCoupon: Coupon = {
      ...existing,
      couponNumber: nextCouponNumber,
      date: updates.date !== undefined ? (updates.date ? updates.date : undefined) : existing.date,
      drawPeriod: updates.drawPeriod !== undefined ? (updates.drawPeriod.trim() || undefined) : existing.drawPeriod,
      merchantName: updates.merchantName !== undefined ? (updates.merchantName.trim() || undefined) : existing.merchantName,
      amount: updates.amount !== undefined ? (typeof updates.amount === 'number' && !isNaN(updates.amount) ? updates.amount : undefined) : existing.amount,
      paymentMethod: updates.paymentMethod !== undefined ? updates.paymentMethod : existing.paymentMethod,
      invoiceNumber: updates.invoiceNumber !== undefined ? (updates.invoiceNumber.trim() || undefined) : existing.invoiceNumber,
      notes: updates.notes !== undefined ? (updates.notes.trim() || undefined) : existing.notes,
    };

    current[index] = updatedCoupon;
    saveToStorage(current);
    inMemoryCoupons = current;

    return { success: true, coupon: updatedCoupon };
  },

  /**
   * Delete a single coupon by ID
   */
  delete: (id: string): boolean => {
    const current = loadFromStorage();
    const filtered = current.filter(c => c.id !== id);
    if (filtered.length === current.length) return false;

    saveToStorage(filtered);
    inMemoryCoupons = filtered;
    return true;
  },

  /**
   * Search coupons by coupon number, merchant name, draw period, invoice #, or notes
   */
  search: (query: string, drawPeriodFilter?: string): Coupon[] => {
    const all = couponService.getAll();
    const q = query.trim().toLowerCase();
    const normalizedDigitsQuery = normalizeCouponNumber(query);

    return all.filter(coupon => {
      // Draw period filter
      if (drawPeriodFilter && drawPeriodFilter !== 'all') {
        if (coupon.drawPeriod !== drawPeriodFilter) return false;
      }

      if (!q) return true;

      const numberMatch = coupon.couponNumber.includes(normalizedDigitsQuery || q);
      const merchantMatch = (coupon.merchantName || '').toLowerCase().includes(q);
      const drawMatch = (coupon.drawPeriod || '').toLowerCase().includes(q);
      const invoiceMatch = (coupon.invoiceNumber || '').toLowerCase().includes(q);
      const notesMatch = (coupon.notes || '').toLowerCase().includes(q);

      return numberMatch || merchantMatch || drawMatch || invoiceMatch || notesMatch;
    });
  },

  /**
   * Check all saved coupons against a list of winning numbers.
   * Performs exact string matching after normalization.
   */
  checkWinners: (
    winningNumbers: string[],
    drawInfo?: { title?: string; drawPeriod?: string; announcementDate?: string }
  ): WinnerCheckResult => {
    const savedCoupons = couponService.getAll();
    
    // Normalize and deduplicate winning numbers
    const validWinningSet = new Set<string>();
    for (const win of winningNumbers) {
      const norm = normalizeCouponNumber(win);
      if (isValidCouponNumber(norm)) {
        validWinningSet.add(norm);
      }
    }

    const matches: CouponMatch[] = [];

    // Compare saved coupons against the set of winning numbers
    for (const userCoupon of savedCoupons) {
      if (validWinningSet.has(userCoupon.couponNumber)) {
        matches.push({
          userCoupon,
          matchedWinningNumber: userCoupon.couponNumber,
          drawTitle: drawInfo?.title,
          drawPeriod: drawInfo?.drawPeriod || userCoupon.drawPeriod,
          announcementDate: drawInfo?.announcementDate,
        });
      }
    }

    return {
      checkedCouponCount: savedCoupons.length,
      winningNumberCount: validWinningSet.size,
      matches,
      checkedAt: new Date().toISOString(),
      drawInfo,
    };
  },

  /**
   * Reset coupons to initial sample dataset (for demonstration and testing)
   */
  resetToMock: (): void => {
    saveToStorage(INITIAL_COUPONS);
    inMemoryCoupons = [...INITIAL_COUPONS];
  },

  /**
   * Replace all coupons with a new array (used for restore: replace mode)
   */
  replaceAll: (coupons: Coupon[]): { imported: number } => {
    const sanitizedList: Coupon[] = [];
    const seen = new Set<string>();
    for (const item of coupons) {
      const sanitized = sanitizeCoupon(item);
      if (sanitized && !seen.has(sanitized.couponNumber)) {
        seen.add(sanitized.couponNumber);
        sanitizedList.push(sanitized);
      }
    }
    saveToStorage(sanitizedList);
    inMemoryCoupons = sanitizedList;
    return { imported: sanitizedList.length };
  },

  /**
   * Merge new coupons into existing records (used for restore: merge mode)
   * Prevents duplicates by couponNumber (12-digit string exact match) or ID
   */
  mergeAll: (newCoupons: Coupon[]): { imported: number; skipped: number } => {
    const current = loadFromStorage();
    const existingNumberSet = new Set(current.map(c => c.couponNumber));
    const existingIdSet = new Set(current.map(c => c.id));

    let imported = 0;
    let skipped = 0;
    const toAdd: Coupon[] = [];

    for (const item of newCoupons) {
      const sanitized = sanitizeCoupon(item);
      if (!sanitized) {
        skipped++;
        continue;
      }

      if (existingNumberSet.has(sanitized.couponNumber) || existingIdSet.has(sanitized.id)) {
        skipped++;
      } else {
        existingNumberSet.add(sanitized.couponNumber);
        existingIdSet.add(sanitized.id);
        toAdd.push(sanitized);
        imported++;
      }
    }

    if (toAdd.length > 0) {
      const updated = [...toAdd, ...current].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      saveToStorage(updated);
      inMemoryCoupons = updated;
    }

    return { imported, skipped };
  },

  /**
   * Clear all coupons (for testing empty state)
   */
  clearAll: (): void => {
    saveToStorage([]);
    inMemoryCoupons = [];
  },
};

