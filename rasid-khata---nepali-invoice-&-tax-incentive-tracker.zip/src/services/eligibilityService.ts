import { 
  TransactionEligibilityInput, 
  TransactionEligibilityResult, 
  PaymentMethod 
} from '../types/transaction';

export const eligibilityService = {
  /**
   * Evaluates a transaction input against official IRD Taxpayer Incentive rules
   */
  checkEligibility: (input: TransactionEligibilityInput): TransactionEligibilityResult => {
    const reasons: string[] = [];
    const caveats: string[] = [];
    const nextSteps: string[] = [];

    const isDigitalMethod = [
      'QR / Digital Payment',
      'Mobile Banking',
      'Debit/Credit Card',
      'Card',
      'Digital Wallet',
      'Bank Transfer'
    ].includes(input.paymentMethod);

    const isCash = input.paymentMethod === 'Cash';
    const isUnknownMethod = input.paymentMethod === 'Other / Unknown' || input.paymentMethod === 'Other';

    // 1. Check Disqualifiers
    const disqualifiers: string[] = [];

    if (input.amount <= 100) {
      disqualifiers.push('Amount must be more than NPR 100 (NPR 100 or less does not qualify).');
    }

    if (isCash) {
      disqualifiers.push('Cash purchases do not generate electronic incentive coupons. Only electronic billing / digital payment modes qualify.');
    }

    if (input.purpose === 'business' || input.purpose === 'government') {
      disqualifiers.push('Business, commercial, and institutional/government purchases are excluded. Only individual consumer personal purchases qualify.');
    }

    if (input.category === 'electricity' || input.category === 'telephone_internet') {
      disqualifiers.push('Utility payments (electricity, telephone, and internet bills) are excluded from the consumer lottery scheme.');
    }

    if (input.category === 'airline' || input.category === 'transport_freight') {
      disqualifiers.push('Air tickets, public transport, and freight charges are currently excluded.');
    }

    if (input.sellerPan === 'no') {
      disqualifiers.push('Seller PAN/VAT information is missing. Transactions must be from PAN-registered businesses issuing electronic invoices.');
    }

    // A. LIKELY NOT ELIGIBLE
    if (disqualifiers.length > 0) {
      nextSteps.push('Keep invoices for personal tax accounting, but note this transaction is unlikely to receive an IRD lottery coupon.');
      nextSteps.push('For upcoming draws, prefer digital payments above NPR 100 for personal goods/services at PAN-registered stores.');

      return {
        status: 'likely_not_eligible',
        title: 'Likely Not Eligible',
        statusLabel: '❌ Likely not eligible',
        reasons: disqualifiers,
        caveats: [
          'Rasid Khata is an independent helper app. This result is not an official IRD eligibility confirmation.'
        ],
        nextSteps,
        evaluatedAt: new Date().toISOString(),
      };
    }

    // 2. Check Needs Verification items
    const verificationReasons: string[] = [];

    if (input.sellerPan === 'dont_know') {
      verificationReasons.push('Seller PAN status is unknown. The merchant must be registered with IRD and submit electronic invoices to CBMS.');
    }

    if (input.category === 'dont_know') {
      verificationReasons.push('Transaction category is unconfirmed. Verify that the purchased items are standard retail goods or services.');
    }

    if (input.purpose === 'unknown') {
      verificationReasons.push('Purchase purpose is unconfirmed. Only personal consumer purchases are eligible.');
    }

    if (isUnknownMethod) {
      verificationReasons.push('Payment mode cannot be verified as an approved electronic / digital channel.');
    }

    // Always note CBMS offline limitation for verification
    if (isDigitalMethod) {
      verificationReasons.push('Rasid Khata cannot verify offline whether the seller’s billing system successfully transmitted the invoice to IRD’s central CBMS.');
    }

    // B. NEEDS VERIFICATION
    if (
      input.sellerPan === 'dont_know' || 
      input.category === 'dont_know' || 
      input.purpose === 'unknown' || 
      isUnknownMethod
    ) {
      nextSteps.push('Check your bill or invoice slip for the seller’s 9-digit PAN/VAT number.');
      nextSteps.push('Check your payment app (eSewa, Khalti, Mobile Banking) to see if a 12-digit Prize Coupon Number was generated.');
      nextSteps.push('Keep your invoice/receipt until the draw is completed.');

      return {
        status: 'needs_verification',
        title: 'Needs Verification',
        statusLabel: '⚠️ Needs verification',
        reasons: verificationReasons,
        caveats: [
          'Rasid Khata is an independent helper app. This result is not an official IRD eligibility confirmation.',
          'Your digital payment may qualify, but Rasid Khata cannot verify whether the transaction was successfully reported/registered with IRD.'
        ],
        digitalWarning: isDigitalMethod
          ? 'Digital payment does not mean Rasid Khata can confirm your IRD coupon. Your Prize Coupon Number should come from the relevant payment app or the official IRD system when the transaction is successfully included.'
          : undefined,
        nextSteps,
        evaluatedAt: new Date().toISOString(),
      };
    }

    // C. LIKELY ELIGIBLE
    const eligibleReasons = [
      `Amount (NPR ${input.amount.toLocaleString('en-IN')}) is above the NPR 100 minimum threshold.`,
      'Purchased for personal individual consumer use.',
      `Payment method (${input.paymentMethod}) is an approved electronic/digital channel.`,
      'Seller is PAN-registered and issuing taxable electronic bills.',
    ];

    nextSteps.push('Check your payment app or SMS/invoice for your 12-digit Prize Coupon Number.');
    nextSteps.push('Save the 12-digit number in Rasid Khata’s Coupon Manager to check against winner announcements.');
    nextSteps.push('Keep your invoice/receipt safe until the fortnightly draw is concluded.');

    return {
      status: 'likely_eligible',
      title: 'Likely Eligible',
      statusLabel: '✅ Likely eligible based on the information you entered',
      reasons: eligibleReasons,
      caveats: [
        'This is a preliminary check by Rasid Khata. Final eligibility is determined by IRD.',
        'Rasid Khata is an independent helper app. This result is not an official IRD eligibility confirmation.'
      ],
      digitalWarning: isDigitalMethod
        ? 'Digital payment does not mean Rasid Khata can confirm your IRD coupon. Your Prize Coupon Number should come from the relevant payment app or the official IRD system when the transaction is successfully included. Keep your invoice/receipt until the draw is completed.'
        : undefined,
      nextSteps,
      evaluatedAt: new Date().toISOString(),
    };
  }
};
