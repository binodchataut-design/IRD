/**
 * Nepali Date & IRD Draw Period Helper Service
 * Reusable utility to compute estimated Nepali fiscal draw periods and announcement cycles.
 */

export interface DrawPeriodInfo {
  drawPeriod: string;
  expectedAnnouncement: string;
  cycleName: string;
  isExact: boolean;
}

export const nepaliDateService = {
  /**
   * Returns the current active scheme draw cycle
   */
  getCurrentCycle: (): DrawPeriodInfo => {
    const today = new Date().toISOString().split('T')[0];
    return nepaliDateService.getDrawPeriodInfo(today);
  },

  /**
   * Calculates the estimated Nepali draw cycle based on a Gregorian date (YYYY-MM-DD)
   */
  getDrawPeriodInfo: (dateStr?: string): DrawPeriodInfo => {
    if (!dateStr || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      return {
        drawPeriod: 'Current Scheme Cycle',
        expectedAnnouncement: 'Next scheduled IRD draw',
        cycleName: 'Fortnightly consumer draw',
        isExact: false,
      };
    }

    try {
      const parts = dateStr.split('-');
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10);
      const day = parseInt(parts[2], 10);

      // Fiscal Year 2083 BS (approx mid-July 2026 to mid-July 2027)
      if (year === 2026) {
        if (month === 7 && day >= 16) {
          return {
            drawPeriod: 'Shrawan 1–15, 2083',
            expectedAnnouncement: 'Shrawan 22, 2083 (Approx. Aug 7, 2026)',
            cycleName: 'Shrawan 1st Half Draw',
            isExact: true,
          };
        } else if (month === 7 && day < 16) {
          return {
            drawPeriod: 'Ashadh 16–31, 2083',
            expectedAnnouncement: 'Shrawan 7, 2083 (Approx. July 22, 2026)',
            cycleName: 'Ashadh 2nd Half Draw',
            isExact: true,
          };
        } else if (month === 8 && day <= 16) {
          return {
            drawPeriod: 'Shrawan 16–31, 2083',
            expectedAnnouncement: 'Bhadra 6, 2083 (Approx. Aug 22, 2026)',
            cycleName: 'Shrawan 2nd Half Draw',
            isExact: true,
          };
        } else if (month === 8 && day > 16) {
          return {
            drawPeriod: 'Bhadra 1–15, 2083',
            expectedAnnouncement: 'Bhadra 22, 2083 (Approx. Sept 7, 2026)',
            cycleName: 'Bhadra 1st Half Draw',
            isExact: true,
          };
        } else if (month === 9 && day <= 16) {
          return {
            drawPeriod: 'Bhadra 16–31, 2083',
            expectedAnnouncement: 'Ashwin 6, 2083 (Approx. Sept 22, 2026)',
            cycleName: 'Bhadra 2nd Half Draw',
            isExact: true,
          };
        } else if (month === 9 && day > 16) {
          return {
            drawPeriod: 'Ashwin 1–15, 2083',
            expectedAnnouncement: 'Ashwin 22, 2083 (Approx. Oct 8, 2026)',
            cycleName: 'Ashwin 1st Half Draw',
            isExact: true,
          };
        }
      }

      // Default fallback
      return {
        drawPeriod: 'Based on transaction date',
        expectedAnnouncement: 'Following the 15-day billing cycle',
        cycleName: 'Fortnightly consumer draw',
        isExact: false,
      };
    } catch {
      return {
        drawPeriod: 'Based on transaction date',
        expectedAnnouncement: 'Following the 15-day billing cycle',
        cycleName: 'Fortnightly consumer draw',
        isExact: false,
      };
    }
  },
};
