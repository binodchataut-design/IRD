import { DrawAnnouncement, NewDrawInput } from '../types/transaction';
import { normalizeCouponNumber, isValidCouponNumber } from '../utils/couponUtils';

const STORAGE_KEY = 'rasid_khata_draw_history_v1';

// Initial realistic draw records from IRD announcements
const INITIAL_DRAWS: DrawAnnouncement[] = [
  {
    id: 'draw-001',
    title: 'First Draw (Shrawan 1–15, 2083)',
    drawPeriod: 'Shrawan 1–15, 2083',
    announcementDate: '2026-08-07',
    winningNumbers: [
      '007315254493',
      '007755590670',
      '002928817811',
      '003066779589',
      '015611059075',
      '009917833245',
      '004128930192',
      '005829104728',
      '008273910482',
      '002938475619',
      '006918273645',
      '011293847560',
      '003829104857',
      '009283746150',
      '004928173645',
      '001928374650'
    ],
    sourceUrl: 'https://ird.gov.np/notices',
    sourceName: 'Inland Revenue Department (IRD Nepal)',
    notes: 'Official draw for electronic billing incentive coupons issued between Shrawan 1–15, 2083.',
    createdAt: '2026-08-07T12:00:00Z',
  },
  {
    id: 'draw-002',
    title: 'Second Draw (Shrawan 16–31, 2083)',
    drawPeriod: 'Shrawan 16–31, 2083',
    announcementDate: '2026-08-22',
    winningNumbers: [
      '008192837465',
      '005192837465',
      '003928174650',
      '002819283746',
      '006819283746',
      '004819283746',
      '007819283746',
      '001182938475',
      '009827364512',
      '004738291045',
      '003728194056',
      '019283746510',
      '018273645920',
      '017263548910',
      '016253489102',
      '015243981023'
    ],
    sourceUrl: 'https://ird.gov.np/notices',
    sourceName: 'Inland Revenue Department (IRD Nepal)',
    notes: 'Second fortnightly consumer incentive draw announced for Shrawan second half.',
    createdAt: '2026-08-22T14:30:00Z',
  }
];

function sanitizeDraw(raw: unknown): DrawAnnouncement | null {
  if (!raw || typeof raw !== 'object') return null;
  const item = raw as Record<string, unknown>;

  const id = typeof item.id === 'string' && item.id.trim().length > 0
    ? item.id.trim()
    : `draw-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

  const title = typeof item.title === 'string' && item.title.trim().length > 0
    ? item.title.trim()
    : 'Untitled Draw Announcement';

  const drawPeriod = typeof item.drawPeriod === 'string' && item.drawPeriod.trim().length > 0
    ? item.drawPeriod.trim()
    : 'Current Fiscal Draw';

  const announcementDate = typeof item.announcementDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(item.announcementDate.trim())
    ? item.announcementDate.trim()
    : new Date().toISOString().split('T')[0];

  const winningNumbersRaw = Array.isArray(item.winningNumbers) ? item.winningNumbers : [];
  const normalizedWinners: string[] = [];
  const seen = new Set<string>();

  for (const win of winningNumbersRaw) {
    const norm = normalizeCouponNumber(String(win));
    if (isValidCouponNumber(norm) && !seen.has(norm)) {
      seen.add(norm);
      normalizedWinners.push(norm);
    }
  }

  const sourceUrl = typeof item.sourceUrl === 'string' && item.sourceUrl.trim().length > 0
    ? item.sourceUrl.trim()
    : 'https://ird.gov.np';

  const sourceName = typeof item.sourceName === 'string' && item.sourceName.trim().length > 0
    ? item.sourceName.trim()
    : 'Inland Revenue Department (IRD Nepal)';

  const notes = typeof item.notes === 'string' && item.notes.trim().length > 0
    ? item.notes.trim()
    : undefined;

  const createdAt = typeof item.createdAt === 'string' && item.createdAt.trim().length > 0
    ? item.createdAt.trim()
    : new Date().toISOString();

  return {
    id,
    title,
    drawPeriod,
    announcementDate,
    winningNumbers: normalizedWinners,
    sourceUrl,
    sourceName,
    notes,
    createdAt,
  };
}

function loadFromStorage(): DrawAnnouncement[] {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return [...INITIAL_DRAWS];
    }

    const storedData = localStorage.getItem(STORAGE_KEY);
    if (!storedData) {
      saveToStorage(INITIAL_DRAWS);
      return [...INITIAL_DRAWS];
    }

    const parsed = JSON.parse(storedData);
    if (!Array.isArray(parsed)) return [];

    const sanitizedList: DrawAnnouncement[] = [];
    for (const item of parsed) {
      const sanitized = sanitizeDraw(item);
      if (sanitized) sanitizedList.push(sanitized);
    }
    return sanitizedList;
  } catch (error) {
    console.error('[Rasid Khata] Failed to read draw history from localStorage:', error);
    return [];
  }
}

function saveToStorage(draws: DrawAnnouncement[]): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(draws));
  } catch (error) {
    console.error('[Rasid Khata] Failed to write draw history to localStorage:', error);
  }
}

let inMemoryDraws: DrawAnnouncement[] = loadFromStorage();

export const drawService = {
  getAll: (): DrawAnnouncement[] => {
    inMemoryDraws = loadFromStorage();
    return [...inMemoryDraws].sort((a, b) => b.announcementDate.localeCompare(a.announcementDate));
  },

  getById: (id: string): DrawAnnouncement | undefined => {
    if (!id) return undefined;
    inMemoryDraws = loadFromStorage();
    return inMemoryDraws.find(d => d.id === id);
  },

  add: (input: NewDrawInput): DrawAnnouncement => {
    const seen = new Set<string>();
    const validWinners: string[] = [];

    for (const num of input.winningNumbers) {
      const norm = normalizeCouponNumber(num);
      if (isValidCouponNumber(norm) && !seen.has(norm)) {
        seen.add(norm);
        validWinners.push(norm);
      }
    }

    const newDraw: DrawAnnouncement = {
      id: `draw-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title: input.title.trim() || 'New Draw Announcement',
      drawPeriod: input.drawPeriod.trim() || 'Fiscal Draw',
      announcementDate: input.announcementDate && /^\d{4}-\d{2}-\d{2}$/.test(input.announcementDate)
        ? input.announcementDate
        : new Date().toISOString().split('T')[0],
      winningNumbers: validWinners,
      sourceUrl: input.sourceUrl?.trim() || 'https://ird.gov.np',
      sourceName: input.sourceName?.trim() || 'Inland Revenue Department (IRD Nepal)',
      notes: input.notes?.trim() || undefined,
      createdAt: new Date().toISOString(),
    };

    const current = loadFromStorage();
    const updated = [newDraw, ...current];
    saveToStorage(updated);
    inMemoryDraws = updated;

    return newDraw;
  },

  delete: (id: string): boolean => {
    const current = loadFromStorage();
    const filtered = current.filter(d => d.id !== id);
    if (filtered.length === current.length) return false;

    saveToStorage(filtered);
    inMemoryDraws = filtered;
    return true;
  },

  /**
   * Replace all custom draws with a new array
   */
  replaceAll: (draws: DrawAnnouncement[]): { imported: number } => {
    const sanitizedList: DrawAnnouncement[] = [];
    for (const item of draws) {
      const sanitized = sanitizeDraw(item);
      if (sanitized) sanitizedList.push(sanitized);
    }
    saveToStorage(sanitizedList);
    inMemoryDraws = sanitizedList;
    return { imported: sanitizedList.length };
  },

  /**
   * Merge draws into existing records
   */
  mergeAll: (newDraws: DrawAnnouncement[]): { imported: number; skipped: number } => {
    const current = loadFromStorage();
    const existingIdSet = new Set(current.map(d => d.id));
    const existingTitleSet = new Set(current.map(d => `${d.drawPeriod}_${d.title.toLowerCase().trim()}`));

    let imported = 0;
    let skipped = 0;
    const toAdd: DrawAnnouncement[] = [];

    for (const item of newDraws) {
      const sanitized = sanitizeDraw(item);
      if (!sanitized) {
        skipped++;
        continue;
      }

      const key = `${sanitized.drawPeriod}_${sanitized.title.toLowerCase().trim()}`;
      if (existingIdSet.has(sanitized.id) || existingTitleSet.has(key)) {
        skipped++;
      } else {
        existingIdSet.add(sanitized.id);
        existingTitleSet.add(key);
        toAdd.push(sanitized);
        imported++;
      }
    }

    if (toAdd.length > 0) {
      const updated = [...toAdd, ...current].sort((a, b) => b.announcementDate.localeCompare(a.announcementDate));
      saveToStorage(updated);
      inMemoryDraws = updated;
    }

    return { imported, skipped };
  },

  resetToDefault: (): void => {
    saveToStorage(INITIAL_DRAWS);
    inMemoryDraws = [...INITIAL_DRAWS];
  },
};

