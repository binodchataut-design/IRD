package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = BrandNavy,
    onPrimary = Color.White,
    primaryContainer = BrandNavyLight,
    onPrimaryContainer = BrandNavy,
    secondary = BrandGreen,
    onSecondary = Color.White,
    secondaryContainer = BrandGreenBg,
    onSecondaryContainer = BrandGreen,
    tertiary = Amber500,
    onTertiary = Color.White,
    tertiaryContainer = Amber50,
    onTertiaryContainer = Amber600,
    background = PageBackground,
    onBackground = Slate900,
    surface = CardBackground,
    onSurface = Slate900,
    surfaceVariant = Slate100,
    onSurfaceVariant = Slate700,
    outline = Slate300,
    outlineVariant = Slate200,
    error = Red600,
    onError = Color.White,
    errorContainer = Red50,
    onErrorContainer = Red600
)

@Composable
fun BillLinusTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun RasidKhataTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) = BillLinusTheme(darkTheme = darkTheme, content = content)

