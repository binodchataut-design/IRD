package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.Coupon
import com.example.model.ManualResultCheck
import com.example.model.ScreenName
import com.example.service.DrawResultService
import com.example.ui.MainViewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppHeader
import com.example.ui.theme.Amber100
import com.example.ui.theme.Amber400
import com.example.ui.theme.Amber500
import com.example.ui.theme.Amber600
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Red100
import com.example.ui.theme.Red600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.utils.CouponUtils

@Composable
fun WinnerCheckerScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    val resultChecks by viewModel.resultChecks.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val lastCheck by viewModel.lastCheckResult.collectAsState()
    val context = LocalContext.current

    var winningInputText by remember { mutableStateOf("") }
    var drawTitleInput by remember { mutableStateOf("") }
    var showClearHistoryDialog by remember { mutableStateOf(false) }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text(AppStrings.get("winner.clear_history", lang)) },
            text = { Text(AppStrings.get("winner.clear_history_confirm", lang)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearHistoryDialog = false
                        viewModel.clearResultChecks()
                    },
                    modifier = Modifier.testTag("confirm_clear_history")
                ) {
                    Text(AppStrings.get("common.delete", lang), color = Red600)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text(AppStrings.get("common.cancel", lang))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("winner.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = currentScreen,
                lang = lang,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Official Portal Notice Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Amber400,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.get("ird.official_results", lang),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = AppStrings.get("ird.results_from_ird", lang),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Slate400,
                                fontSize = 12.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DrawResultService.IRD_PRIZE_PORTAL_URL))
                                context.startActivity(intent)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("btn_open_official_portal"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                Icons.Default.OpenInNew,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = AppStrings.get("ird.open_official_results", lang),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Manual Winner Checker Input Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = Amber500,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.get("winner.manual_section", lang),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Text(
                            text = AppStrings.get("winner.manual_hint", lang),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Slate500,
                                fontSize = 12.sp
                            )
                        )

                        OutlinedTextField(
                            value = drawTitleInput,
                            onValueChange = { drawTitleInput = it },
                            label = { Text(AppStrings.get("winner.draw_title", lang)) },
                            placeholder = { Text(AppStrings.get("winner.draw_title_placeholder", lang)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_draw_title"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = winningInputText,
                            onValueChange = { winningInputText = it },
                            placeholder = { Text(AppStrings.get("winner.paste_placeholder", lang)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .testTag("input_winning_numbers_textarea"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Button(
                            onClick = {
                                if (winningInputText.isNotBlank()) {
                                    viewModel.checkWinners(winningInputText, drawTitleInput)
                                }
                            },
                            enabled = winningInputText.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_check_winners_submit"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = AppStrings.get("winner.manual_check_btn", lang),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Results Spotlight (if last check exists)
            if (lastCheck != null) {
                item {
                    val result = lastCheck!!
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (result.matched) Emerald100 else Slate100
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (result.matched) Icons.Default.EmojiEvents else Icons.Default.Info,
                                        contentDescription = null,
                                        tint = if (result.matched) Emerald600 else Slate500,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (result.matched) AppStrings.get("winner.match_found", lang)
                                        else AppStrings.get("winner.no_match", lang),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (result.matched) Emerald600 else Slate700
                                        )
                                    )
                                }
                            }

                            Text(
                                text = if (result.matched) AppStrings.get("winner.result_matches", lang)
                                else AppStrings.get("winner.result_no_match", lang),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = if (result.matched) MaterialTheme.colorScheme.onSurface else Slate500,
                                    fontSize = 13.sp
                                )
                            )

                            if (result.matched) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    result.matchedCouponNumbers.forEach { num ->
                                        val matchCoupon = coupons.find { it.couponNumber == num }
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = Color.White,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(
                                                        text = CouponUtils.formatCouponNumber(num),
                                                        style = MaterialTheme.typography.titleMedium.copy(
                                                            fontWeight = FontWeight.Bold,
                                                            color = Emerald600
                                                        )
                                                    )
                                                    if (matchCoupon?.merchantName != null) {
                                                        Text(
                                                            text = matchCoupon.merchantName,
                                                            style = MaterialTheme.typography.labelSmall.copy(color = Slate500)
                                                        )
                                                    }
                                                }
                                                if (matchCoupon != null) {
                                                    Button(
                                                        onClick = {
                                                            viewModel.openClaimReport(
                                                                coupon = matchCoupon,
                                                                drawTitle = result.drawTitle
                                                            )
                                                        },
                                                        shape = RoundedCornerShape(8.dp),
                                                        colors = ButtonDefaults.buttonColors(containerColor = Emerald600),
                                                        modifier = Modifier.testTag("btn_claim_winner_${matchCoupon.id}")
                                                    ) {
                                                        Text(
                                                            text = AppStrings.get("common.claim_report", lang),
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Check History Section
            if (resultChecks.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = AppStrings.get("winner.history_section", lang),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        IconButton(
                            onClick = { showClearHistoryDialog = true },
                            modifier = Modifier.testTag("btn_clear_history")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear History", tint = Slate400)
                        }
                    }
                }

                items(resultChecks) { check ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = check.drawTitle ?: check.drawPeriod ?: AppStrings.get("winner.entered_manually", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = "${check.enteredResults.size} numbers checked • ${check.checkedAt.take(10)}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Slate500)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (check.matched) Emerald100 else Slate100
                            ) {
                                Text(
                                    text = if (check.matched) "${check.matchedCouponNumbers.size} Matches" else "No Match",
                                    color = if (check.matched) Emerald600 else Slate500,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
