package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RasidKhataRepository
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.ClaimReportData
import com.example.model.Coupon
import com.example.model.CouponPrefillData
import com.example.model.EligibilityPrefillData
import com.example.model.EligibilityStatus
import com.example.model.ManualResultCheck
import com.example.model.PaymentMethod
import com.example.model.ScreenName
import com.example.model.Transaction
import com.example.service.EligibilityService
import com.example.service.TransactionEligibilityInput
import com.example.utils.CouponUtils
import com.example.utils.DrawPeriodInfo
import com.example.utils.NepaliDateUtils
import com.example.utils.SampleData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = RasidKhataRepository(application)

    val language: StateFlow<AppLanguage> = repository.language
    val hasCompletedWelcome: StateFlow<Boolean> = repository.hasCompletedWelcome
    val transactions: StateFlow<List<Transaction>> = repository.transactions
    val coupons: StateFlow<List<Coupon>> = repository.coupons
    val resultChecks: StateFlow<List<ManualResultCheck>> = repository.resultChecks

    private val _currentScreen = MutableStateFlow(ScreenName.HOME)
    val currentScreen: StateFlow<ScreenName> = _currentScreen.asStateFlow()

    private val screenStack = ArrayDeque<ScreenName>()

    private val _selectedInvoiceId = MutableStateFlow<String?>(null)
    val selectedInvoiceId: StateFlow<String?> = _selectedInvoiceId.asStateFlow()

    private val _editingInvoiceId = MutableStateFlow<String?>(null)
    val editingInvoiceId: StateFlow<String?> = _editingInvoiceId.asStateFlow()

    private val _editingCouponId = MutableStateFlow<String?>(null)
    val editingCouponId: StateFlow<String?> = _editingCouponId.asStateFlow()

    private val _linkedInvoiceId = MutableStateFlow<String?>(null)
    val linkedInvoiceId: StateFlow<String?> = _linkedInvoiceId.asStateFlow()

    private val _claimReportData = MutableStateFlow<ClaimReportData?>(null)
    val claimReportData: StateFlow<ClaimReportData?> = _claimReportData.asStateFlow()

    private val _eligibilityPrefill = MutableStateFlow<EligibilityPrefillData?>(null)
    val eligibilityPrefill: StateFlow<EligibilityPrefillData?> = _eligibilityPrefill.asStateFlow()

    private val _couponPrefill = MutableStateFlow<CouponPrefillData?>(null)
    val couponPrefill: StateFlow<CouponPrefillData?> = _couponPrefill.asStateFlow()

    private val _lastCheckResult = MutableStateFlow<ManualResultCheck?>(null)
    val lastCheckResult: StateFlow<ManualResultCheck?> = _lastCheckResult.asStateFlow()

    val currentDrawInfo: StateFlow<DrawPeriodInfo> = language.combine(_currentScreen) { lang, _ ->
        NepaliDateUtils.getCurrentDrawPeriod(lang)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        NepaliDateUtils.getCurrentDrawPeriod(AppLanguage.EN)
    )

    fun navigateTo(screen: ScreenName) {
        if (_currentScreen.value != screen) {
            screenStack.addLast(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (screenStack.isNotEmpty()) {
            _currentScreen.value = screenStack.removeLast()
            true
        } else {
            false
        }
    }

    fun toggleLanguage() {
        repository.toggleLanguage()
    }

    fun setLanguage(lang: AppLanguage) {
        repository.setLanguage(lang)
    }

    fun completeWelcome() {
        repository.completeWelcome()
    }

    fun selectInvoice(id: String) {
        _selectedInvoiceId.value = id
        navigateTo(ScreenName.INVOICE_DETAIL)
    }

    fun openAddInvoice(invoiceIdToEdit: String? = null) {
        _editingInvoiceId.value = invoiceIdToEdit
        navigateTo(ScreenName.ADD_INVOICE)
    }

    fun openEditInvoice(id: String) {
        _editingInvoiceId.value = id
        navigateTo(ScreenName.ADD_INVOICE)
    }

    fun openAddCoupon(
        prefill: CouponPrefillData? = null,
        couponIdToEdit: String? = null,
        linkedInvoiceId: String? = null
    ) {
        _couponPrefill.value = prefill
        _editingCouponId.value = couponIdToEdit
        _linkedInvoiceId.value = linkedInvoiceId
        navigateTo(ScreenName.ADD_COUPON)
    }

    fun openEditCoupon(id: String) {
        _editingCouponId.value = id
        _linkedInvoiceId.value = null
        _couponPrefill.value = null
        navigateTo(ScreenName.ADD_COUPON)
    }

    fun openBulkAddCoupons() {
        navigateTo(ScreenName.BULK_ADD_COUPONS)
    }

    fun openEligibilityChecker(prefill: EligibilityPrefillData? = null) {
        _eligibilityPrefill.value = prefill
        navigateTo(ScreenName.CHECK_ELIGIBILITY)
    }

    fun openVerifyVendor() {
        navigateTo(ScreenName.VERIFY_VENDOR)
    }

    fun openDataBackup() {
        navigateTo(ScreenName.DATA_BACKUP)
    }

    fun openClaimReport(coupon: Coupon, drawTitle: String? = null, announcementDate: String? = null) {
        val matchingTx = transactions.value.find {
            it.couponNumber == coupon.couponNumber ||
                    (coupon.invoiceNumber != null && it.invoiceNumber == coupon.invoiceNumber)
        }
        _claimReportData.value = ClaimReportData(
            coupon = coupon,
            transaction = matchingTx,
            drawTitle = drawTitle ?: coupon.drawPeriod,
            drawPeriod = coupon.drawPeriod,
            announcementDate = announcementDate
        )
        navigateTo(ScreenName.CLAIM_REPORT)
    }

    fun saveTransaction(
        sellerName: String,
        amount: Double,
        paymentMethod: PaymentMethod,
        panVat: String?,
        invoiceNumber: String?,
        couponNumber: String?,
        date: String,
        notes: String?
    ): Transaction {
        val normCoupon = if (!couponNumber.isNullOrBlank()) CouponUtils.normalizeCouponNumber(couponNumber) else null
        val eligibility = EligibilityService.checkEligibility(
            TransactionEligibilityInput(
                amount = amount,
                paymentMethod = paymentMethod,
                sellerPanNumber = panVat,
                sellerName = sellerName,
                date = date,
                invoiceNumber = invoiceNumber
            )
        )

        val status = if (!normCoupon.isNullOrBlank() && CouponUtils.isValidCouponNumber(normCoupon)) {
            EligibilityStatus.COUPON_ADDED
        } else if (eligibility.status == EligibilityStatus.LIKELY_ELIGIBLE) {
            EligibilityStatus.AWAITING_COUPON
        } else {
            eligibility.status
        }

        val tx = Transaction(
            id = SampleData.generateId(),
            date = date.ifBlank { LocalDate.now().format(DateTimeFormatter.ISO_DATE) },
            sellerName = sellerName.trim(),
            amount = amount,
            paymentMethod = paymentMethod,
            panVat = panVat?.trim()?.ifBlank { null },
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            couponNumber = normCoupon,
            eligibilityStatus = status,
            notes = notes?.trim()?.ifBlank { null },
            createdAt = java.time.Instant.now().toString()
        )

        repository.addTransaction(tx)

        // If a valid 12-digit coupon was entered on the invoice, check if coupon already exists or save coupon record
        if (normCoupon != null && CouponUtils.isValidCouponNumber(normCoupon)) {
            val drawInfo = NepaliDateUtils.getDrawPeriodForDate(tx.date, language.value)
            val existingCoupon = coupons.value.find {
                it.couponNumber == normCoupon || (tx.invoiceNumber != null && it.invoiceNumber == tx.invoiceNumber)
            }
            if (existingCoupon != null) {
                val updatedCoupon = existingCoupon.copy(
                    couponNumber = normCoupon,
                    date = tx.date,
                    drawPeriod = drawInfo.drawPeriod,
                    merchantName = tx.sellerName,
                    amount = tx.amount,
                    paymentMethod = AppStrings.getPaymentMethodLabel(tx.paymentMethod, AppLanguage.EN),
                    invoiceNumber = tx.invoiceNumber,
                    notes = tx.notes
                )
                repository.updateCoupon(updatedCoupon)
            } else {
                val coupon = Coupon(
                    id = SampleData.generateId(),
                    couponNumber = normCoupon,
                    date = tx.date,
                    drawPeriod = drawInfo.drawPeriod,
                    merchantName = tx.sellerName,
                    amount = tx.amount,
                    paymentMethod = AppStrings.getPaymentMethodLabel(tx.paymentMethod, AppLanguage.EN),
                    invoiceNumber = tx.invoiceNumber,
                    notes = tx.notes,
                    createdAt = java.time.Instant.now().toString()
                )
                repository.addCoupon(coupon)
            }
        }

        return tx
    }

    fun updateTransaction(
        id: String,
        sellerName: String,
        amount: Double,
        paymentMethod: PaymentMethod,
        panVat: String?,
        invoiceNumber: String?,
        couponNumber: String?,
        date: String,
        notes: String?
    ): Transaction? {
        val existing = transactions.value.find { it.id == id } ?: return null
        val normCoupon = if (!couponNumber.isNullOrBlank()) CouponUtils.normalizeCouponNumber(couponNumber) else null
        val eligibility = EligibilityService.checkEligibility(
            TransactionEligibilityInput(
                amount = amount,
                paymentMethod = paymentMethod,
                sellerPanNumber = panVat,
                sellerName = sellerName,
                date = date,
                invoiceNumber = invoiceNumber
            )
        )

        val status = if (!normCoupon.isNullOrBlank() && CouponUtils.isValidCouponNumber(normCoupon)) {
            EligibilityStatus.COUPON_ADDED
        } else if (eligibility.status == EligibilityStatus.LIKELY_ELIGIBLE) {
            EligibilityStatus.AWAITING_COUPON
        } else {
            eligibility.status
        }

        val updatedTx = existing.copy(
            date = date.ifBlank { existing.date },
            sellerName = sellerName.trim(),
            amount = amount,
            paymentMethod = paymentMethod,
            panVat = panVat?.trim()?.ifBlank { null },
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            couponNumber = normCoupon,
            eligibilityStatus = status,
            notes = notes?.trim()?.ifBlank { null }
        )

        repository.updateTransaction(updatedTx)
        _selectedInvoiceId.value = id
        _editingInvoiceId.value = null

        // Sync associated coupon if present
        if (normCoupon != null && CouponUtils.isValidCouponNumber(normCoupon)) {
            val drawInfo = NepaliDateUtils.getDrawPeriodForDate(updatedTx.date, language.value)
            val existingCoupon = coupons.value.find {
                it.couponNumber == normCoupon ||
                        (existing.couponNumber != null && it.couponNumber == existing.couponNumber) ||
                        (existing.invoiceNumber != null && it.invoiceNumber == existing.invoiceNumber) ||
                        (updatedTx.invoiceNumber != null && it.invoiceNumber == updatedTx.invoiceNumber)
            }
            if (existingCoupon != null) {
                val updatedCoupon = existingCoupon.copy(
                    couponNumber = normCoupon,
                    merchantName = updatedTx.sellerName,
                    amount = updatedTx.amount,
                    paymentMethod = AppStrings.getPaymentMethodLabel(updatedTx.paymentMethod, AppLanguage.EN),
                    invoiceNumber = updatedTx.invoiceNumber,
                    date = updatedTx.date,
                    notes = updatedTx.notes ?: existingCoupon.notes
                )
                repository.updateCoupon(updatedCoupon)
            } else {
                val newCoupon = Coupon(
                    id = SampleData.generateId(),
                    couponNumber = normCoupon,
                    date = updatedTx.date,
                    drawPeriod = drawInfo.drawPeriod,
                    merchantName = updatedTx.sellerName,
                    amount = updatedTx.amount,
                    paymentMethod = AppStrings.getPaymentMethodLabel(updatedTx.paymentMethod, AppLanguage.EN),
                    invoiceNumber = updatedTx.invoiceNumber,
                    notes = updatedTx.notes,
                    createdAt = java.time.Instant.now().toString()
                )
                repository.addCoupon(newCoupon)
            }
        }

        return updatedTx
    }

    fun deleteTransaction(id: String) {
        repository.deleteTransaction(id)
        if (_currentScreen.value == ScreenName.INVOICE_DETAIL && _selectedInvoiceId.value == id) {
            navigateBack()
        }
    }

    fun saveCoupon(
        couponNumber: String,
        merchantName: String?,
        amount: Double?,
        drawPeriod: String?,
        invoiceNumber: String?,
        notes: String?
    ): Boolean {
        val norm = CouponUtils.normalizeCouponNumber(couponNumber)
        if (!CouponUtils.isValidCouponNumber(norm)) return false

        val dateStr = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
        val period = drawPeriod ?: NepaliDateUtils.getDrawPeriodForDate(dateStr, language.value).drawPeriod

        val coupon = Coupon(
            id = SampleData.generateId(),
            couponNumber = norm,
            date = dateStr,
            drawPeriod = period,
            merchantName = merchantName?.trim()?.ifBlank { null },
            amount = amount,
            paymentMethod = null,
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            notes = notes?.trim()?.ifBlank { null },
            createdAt = java.time.Instant.now().toString()
        )

        repository.addCoupon(coupon)

        // Automatically update linked transaction if specified, or matching by invoice number
        val linkedId = _linkedInvoiceId.value
        if (linkedId != null) {
            val tx = transactions.value.find { it.id == linkedId }
            if (tx != null) {
                val updatedTx = tx.copy(
                    couponNumber = norm,
                    eligibilityStatus = EligibilityStatus.COUPON_ADDED,
                    invoiceNumber = tx.invoiceNumber ?: invoiceNumber?.trim()?.ifBlank { null }
                )
                repository.updateTransaction(updatedTx)
            }
        } else if (!coupon.invoiceNumber.isNullOrBlank()) {
            val tx = transactions.value.find { it.invoiceNumber == coupon.invoiceNumber }
            if (tx != null) {
                val updatedTx = tx.copy(
                    couponNumber = norm,
                    eligibilityStatus = EligibilityStatus.COUPON_ADDED
                )
                repository.updateTransaction(updatedTx)
            }
        }

        _couponPrefill.value = null
        _editingCouponId.value = null
        _linkedInvoiceId.value = null
        return true
    }

    fun updateCoupon(
        id: String,
        couponNumber: String,
        merchantName: String?,
        amount: Double?,
        drawPeriod: String?,
        invoiceNumber: String?,
        notes: String?
    ): Boolean {
        val norm = CouponUtils.normalizeCouponNumber(couponNumber)
        if (!CouponUtils.isValidCouponNumber(norm)) return false

        val existing = coupons.value.find { it.id == id } ?: return false
        val updatedCoupon = existing.copy(
            couponNumber = norm,
            merchantName = merchantName?.trim()?.ifBlank { null },
            amount = amount,
            drawPeriod = drawPeriod ?: existing.drawPeriod,
            invoiceNumber = invoiceNumber?.trim()?.ifBlank { null },
            notes = notes?.trim()?.ifBlank { null }
        )

        repository.updateCoupon(updatedCoupon)

        // Update any matching transaction so it reflects the updated coupon number & invoice details
        val linkedId = _linkedInvoiceId.value
        val txToUpdate = if (linkedId != null) {
            transactions.value.find { it.id == linkedId }
        } else {
            transactions.value.find {
                it.couponNumber == existing.couponNumber ||
                        (existing.invoiceNumber != null && it.invoiceNumber == existing.invoiceNumber) ||
                        (updatedCoupon.invoiceNumber != null && it.invoiceNumber == updatedCoupon.invoiceNumber)
            }
        }

        if (txToUpdate != null) {
            val updatedTx = txToUpdate.copy(
                couponNumber = norm,
                eligibilityStatus = EligibilityStatus.COUPON_ADDED,
                invoiceNumber = updatedCoupon.invoiceNumber ?: txToUpdate.invoiceNumber
            )
            repository.updateTransaction(updatedTx)
        }

        _editingCouponId.value = null
        _linkedInvoiceId.value = null
        _couponPrefill.value = null
        return true
    }

    fun saveBulkCoupons(
        couponNumbers: List<String>,
        defaultMerchant: String?
    ): Int {
        val dateStr = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
        val period = NepaliDateUtils.getDrawPeriodForDate(dateStr, language.value).drawPeriod
        val list = couponNumbers.map { num ->
            Coupon(
                id = SampleData.generateId(),
                couponNumber = num,
                date = dateStr,
                drawPeriod = period,
                merchantName = defaultMerchant?.trim()?.ifBlank { null },
                amount = null,
                paymentMethod = null,
                invoiceNumber = null,
                notes = null,
                createdAt = java.time.Instant.now().toString()
            )
        }
        repository.addBulkCoupons(list)
        return list.size
    }

    fun deleteCoupon(id: String) {
        repository.deleteCoupon(id)
    }

    fun checkWinners(
        inputText: String,
        drawTitle: String?
    ): ManualResultCheck {
        val rawLines = inputText.split(Regex("[\\r\\n;,\\s]+"))
            .map { CouponUtils.normalizeCouponNumber(it) }
            .filter { it.length == 12 }
            .distinct()

        val savedNumbers = coupons.value.map { it.couponNumber }.toSet()
        val matched = rawLines.filter { savedNumbers.contains(it) }

        val check = ManualResultCheck(
            id = SampleData.generateId(),
            drawTitle = drawTitle?.trim()?.ifBlank { null },
            drawPeriod = currentDrawInfo.value.drawPeriod,
            enteredResults = rawLines,
            matchedCouponNumbers = matched,
            matched = matched.isNotEmpty(),
            checkedAt = java.time.Instant.now().toString()
        )

        _lastCheckResult.value = check
        repository.addResultCheck(check)
        return check
    }

    fun clearResultChecks() {
        repository.clearResultChecks()
    }

    fun exportData(): String {
        return repository.exportJson()
    }

    fun exportBackupJson(): String {
        return repository.exportJson()
    }

    fun importData(json: String): Boolean {
        return repository.importJson(json)
    }

    fun restoreBackupJson(json: String): Boolean {
        return repository.importJson(json)
    }

    fun loadSampleData() {
        repository.loadSampleData()
    }

    fun clearAllData() {
        repository.clearAllData()
    }
}
