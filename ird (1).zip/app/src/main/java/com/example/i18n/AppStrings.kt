package com.example.i18n

import com.example.model.AppLanguage
import com.example.model.EligibilityStatus
import com.example.model.PaymentMethod
import com.example.service.EligibilityReason

object AppStrings {

    private val STRINGS: Map<String, Pair<String, String>> = mapOf(
        "app.name" to Pair("Bill Linus", "बिल लिनुहोस्"),
        "app.scheme_tag" to Pair("TAX INVOICE LOTTERY", "कर चलानी लटरी"),
        "app.disclaimer_full" to Pair(
            "Unofficial helper app. Not affiliated with IRD Nepal. Always verify with official IRD sources.",
            "अनौपचारिक सहायक ऐप। आन्तरिक राजस्व विभागसँग सम्बन्धित छैन। आधिकारिक स्रोतबाट जाँच्नुहोस्।"
        ),
        "common.back" to Pair("Back", "पछाडि"),
        "common.save" to Pair("Save", "सुरक्षित गर्नुहोस्"),
        "common.copy" to Pair("Copy", "प्रतिलिपि"),
        "common.delete" to Pair("Delete", "हटाउनुहोस्"),
        "common.cancel" to Pair("Cancel", "रद्द गर्नुहोस्"),
        "common.confirm" to Pair("Confirm", "पुष्टि गर्नुहोस्"),
        "common.edit" to Pair("Edit", "सम्पादन"),
        "common.close" to Pair("Close", "बन्द गर्नुहोस्"),
        "common.optional" to Pair("Optional", "वैकल्पिक"),
        "common.required" to Pair("Required", "अनिवार्य"),
        "common.add" to Pair("Add", "थप्नुहोस्"),
        "common.back_btn" to Pair("Back", "पछाडि"),
        "common.print" to Pair("Print", "मुद्रण"),
        "common.claim_report" to Pair("Claim Report", "दाबी प्रतिवेदन"),
        "common.not_provided" to Pair("Not provided", "प्रदान गरिएको छैन"),
        "common.not_specified" to Pair("Not specified", "निर्दिष्ट छैन"),
        "common.optional_label" to Pair("Optional", "वैकल्पिक"),

        "nav.home" to Pair("Home", "गृह"),
        "nav.invoices" to Pair("Invoices", "चलानी"),
        "nav.coupons" to Pair("Coupons", "कुपन"),
        "nav.winner" to Pair("Winner", "विजेता"),
        "nav.guide" to Pair("Guide", "गाइड"),

        "welcome.title" to Pair("Bill Linus", "बिल लिनुहोस्"),
        "welcome.tagline" to Pair(
            "Track your purchase invoices and prize coupons for the IRD Tax Invoice Lottery",
            "आन्तरिक राजस्व विभागको कर चलानी लटरीका लागि आफ्नो खरिद चलानी र पुरस्कार कुपन ट्र्याक गर्नुहोस्"
        ),
        "welcome.get_started" to Pair("Get Started", "सुरु गर्नुहोस्"),
        "welcome.feature_1" to Pair("Track invoices & coupons", "चलानी र कुपन ट्र्याक गर्नुहोस्"),
        "welcome.feature_2" to Pair("Check winning numbers", "विजयी नम्बर जाँच्नुहोस्"),
        "welcome.feature_3" to Pair("Generate claim reports", "दाबी प्रतिवेदन बनाउनुहोस्"),
        "welcome.hero_title_1" to Pair("Track every receipt.", "हरेक रसिद ट्र्याक गर्नुहोस्।"),
        "welcome.hero_title_2" to Pair("Never miss a draw.", "कुनै ड्र नछुटाउनुहोस्।"),
        "welcome.hero_desc" to Pair(
            "Keep your purchase invoices and 12-digit prize coupons organized for Nepal's IRD Tax Invoice Lottery.",
            "नेपालको आन्तरिक राजस्व विभागको कर चलानी लटरीका लागि आफ्नो खरिद चलानी र १२-अंकीय पुरस्कार कुपन व्यवस्थित राख्नुहोस्।"
        ),
        "welcome.note" to Pair("Your data stays on your device. No account required.", "तपाईंको डाटा तपाईंको डिभाइसमै रहन्छ। खाता आवश्यक छैन।"),
        "welcome.lang_ne" to Pair("नेपालीमा हेर्नुहोस्", "नेपालीमा हेर्नुहोस्"),
        "welcome.lang_en" to Pair("View in English", "View in English"),

        "home.title" to Pair("Dashboard", "ड्यासबोर्ड"),
        "home.subtitle" to Pair("Your lottery coupon overview", "तपाईंको लटरी कुपन अवलोकन"),
        "home.stat_invoices" to Pair("Invoices", "चलानी"),
        "home.stat_coupons" to Pair("Coupons", "कुपन"),
        "home.stat_eligible" to Pair("Eligible", "योग्य"),
        "home.stat_total_spent" to Pair("Total Spent", "कुल खर्च"),
        "home.current_draw" to Pair("Current Draw Period", "हालको ड्र अवधि"),
        "home.expected_announcement" to Pair("Expected Announcement", "अपेक्षित घोषणा"),
        "home.quick_actions" to Pair("Quick Actions", "छिटो कार्य"),
        "home.add_invoice" to Pair("Add Invoice", "चलानी थप्नुहोस्"),
        "home.add_coupon" to Pair("Add Coupon", "कुपन थप्नुहोस्"),
        "home.check_winner" to Pair("Check Winner", "विजेता जाँच्नुहोस्"),
        "home.verify_vendor" to Pair("Verify Vendor", "विक्रेता जाँच्नुहोस्"),
        "home.recent_invoices" to Pair("Recent Invoices", "भर्खरका चलानी"),
        "home.recent_coupons" to Pair("Recent Coupons", "भर्खरका कुपन"),
        "home.view_all" to Pair("View All", "सबै हेर्नुहोस्"),
        "home.banner_tag" to Pair("LIVE TRACKING", "लाइव ट्र्याकिङ"),
        "home.banner_title" to Pair("Your records, neatly organized.", "तपाईंका रेकर्ड, व्यवस्थित।"),
        "home.banner_desc" to Pair("Stay ready for every fortnightly IRD draw.", "हरेक पाक्षिक ड्रका लागि तयार रहनुहोस्।"),
        "home.current_cycle" to Pair("CURRENT CYCLE", "हालको चक्र"),
        "home.draw_hint" to Pair("Fortnightly consumer draw • Keep saving eligible coupons", "पाक्षिक उपभोक्ता ड्र • योग्य कुपन सुरक्षित गर्दै जानुहोस्"),
        "home.record_purchase" to Pair("Record a Purchase", "खरिद रेकर्ड गर्नुहोस्"),
        "home.record_purchase_desc" to Pair("Start here — add a bill to track eligibility and coupons", "यहाँबाट सुरु गर्नुहोस् — योग्यता र कुपन ट्र्याक गर्न चलानी थप्नुहोस्"),
        "home.more_actions" to Pair("More Actions", "थप कार्य"),

        "invoices.title" to Pair("Invoices", "चलानी"),
        "invoices.subtitle" to Pair("Your purchase records", "तपाईंको खरिद रेकर्ड"),
        "invoices.empty_title" to Pair("No invoices yet", "अहिलेसम्म चलानी छैन"),
        "invoices.empty_desc" to Pair("Add your first purchase invoice to start tracking", "ट्र्याकिङ सुरु गर्न पहिलो खरिद चलानी थप्नुहोस्"),
        "invoices.add" to Pair("Add Invoice", "चलानी थप्नुहोस्"),

        "add_invoice.title" to Pair("Add Invoice", "चलानी थप्नुहोस्"),
        "add_invoice.subtitle" to Pair("Record a new purchase", "नयाँ खरिद रेकर्ड गर्नुहोस्"),
        "add_invoice.section_purchase" to Pair("Purchase Details", "खरिद विवरण"),
        "add_invoice.section_payment" to Pair("Payment Method", "भुक्तानी विधि"),
        "add_invoice.section_tax_coupon" to Pair("Invoice & PAN", "चलानी र प्यान"),
        "add_invoice.merchant_name" to Pair("Seller/Merchant Name", "विक्रेता/व्यापारी नाम"),
        "add_invoice.merchant_placeholder" to Pair("e.g. Bhatbhateni Supermarket", "जस्तै भातभातेनी सुपरमार्केट"),
        "add_invoice.amount_npr" to Pair("Amount (NPR)", "रकम (रु)"),
        "add_invoice.amount_placeholder" to Pair("e.g. 1500", "जस्तै १५००"),
        "add_invoice.date_label" to Pair("Date", "मिति"),
        "add_invoice.draw_cycle_estimate" to Pair("Draw cycle", "ड्र चक्र"),
        "add_invoice.payment_mode" to Pair("Payment Mode", "भुक्तानी मोड"),
        "add_invoice.pan_vat" to Pair("PAN/VAT Number", "प्यान/भ्याट नम्बर"),
        "add_invoice.invoice_number" to Pair("Invoice Number", "चलानी नम्बर"),
        "add_invoice.coupon_number" to Pair("Coupon Number", "कुपन नम्बर"),
        "add_invoice.notes" to Pair("Notes", "टिप्पणी"),
        "add_invoice.save_btn" to Pair("Save Invoice", "चलानी सुरक्षित गर्नुहोस्"),
        "add_invoice.save_success" to Pair("Invoice saved successfully", "चलानी सफलतापूर्वक सुरक्षित भयो"),
        "add_invoice.eligibility_preview" to Pair("Eligibility Preview", "योग्यता पूर्वावलोकन"),
        "add_invoice.saved_title" to Pair("Purchase saved", "खरिद सुरक्षित भयो"),
        "add_invoice.saved_desc" to Pair("Your purchase has been recorded. What would you like to do next?", "तपाईंको खरिद रेकर्ड भयो। अब तपाईं के गर्न चाहनुहुन्छ?"),
        "add_invoice.next_check_eligibility" to Pair("Check Eligibility", "योग्यता जाँच्नुहोस्"),
        "add_invoice.next_add_coupon" to Pair("Add Coupon", "कुपन थप्नुहोस्"),
        "add_invoice.next_done" to Pair("Done", "सकियो"),
        "add_invoice.coupon_placeholder" to Pair("12-digit number (optional)", "१२-अंकीय नम्बर (वैकल्पिक)"),
        "add_invoice.notes_placeholder" to Pair("Add a note about this purchase", "यो खरिदबारे टिप्पणी थप्नुहोस्"),
        "add_invoice.pan_placeholder" to Pair("e.g. 601928374", "जस्तै ६०१९२८३७४"),
        "add_invoice.invoice_placeholder" to Pair("e.g. INV-2083-001", "जस्तै INV-2083-001"),

        "invoice_detail.title" to Pair("Invoice Details", "चलानी विवरण"),
        "invoice_detail.seller" to Pair("Seller", "विक्रेता"),
        "invoice_detail.amount" to Pair("Amount", "रकम"),
        "invoice_detail.date" to Pair("Date", "मिति"),
        "invoice_detail.payment" to Pair("Payment Method", "भुक्तानी विधि"),
        "invoice_detail.pan" to Pair("PAN/VAT", "प्यान/भ्याट"),
        "invoice_detail.invoice_no" to Pair("Invoice No.", "चलानी नं."),
        "invoice_detail.coupon" to Pair("Coupon", "कुपन"),
        "invoice_detail.coupon_number" to Pair("Coupon Number", "कुपन नम्बर"),
        "invoice_detail.notes" to Pair("Notes", "टिप्पणी"),
        "invoice_detail.eligibility" to Pair("Eligibility Status", "योग्यता स्थिति"),
        "invoice_detail.eligibility_label" to Pair("Eligibility Status", "योग्यता स्थिति"),
        "invoice_detail.draw_period" to Pair("Draw Period", "ड्र अवधि"),
        "invoice_detail.deleted" to Pair("Invoice deleted", "चलानी हटाइयो"),
        "invoice_detail.awaiting_coupon" to Pair("Awaiting Coupon", "कुपन बाँकी"),
        "invoice_detail.no_notes" to Pair("No notes recorded", "कुनै टिप्पणी छैन"),
        "invoice_detail.not_found" to Pair("Invoice not found", "चलानी फेला परेन"),
        "invoice_detail.not_found_desc" to Pair("The requested invoice record could not be loaded", "अनुरोध गरिएको चलानी रेकर्ड फेला परेन"),

        "coupons.title" to Pair("Coupons", "कुपन"),
        "coupons.subtitle" to Pair("Your prize coupon numbers", "तपाईंको पुरस्कार कुपन नम्बर"),
        "coupons.empty_title" to Pair("No coupons yet", "अहिलेसम्म कुपन छैन"),
        "coupons.empty_desc" to Pair("Add your 12-digit prize coupon numbers", "आफ्नो १२-अंकीय पुरस्कार कुपन नम्बर थप्नुहोस्"),
        "coupons.empty_hint" to Pair("After recording a purchase, add its coupon number here to track it.", "खरिद रेकर्ड गरेपछि, यसको कुपन नम्बर यहाँ थपेर ट्र्याक गर्नुहोस्।"),
        "coupons.add" to Pair("Add Coupon", "कुपन थप्नुहोस्"),
        "coupons.bulk_add" to Pair("Bulk Add", "थप थप्नुहोस्"),
        "coupons.saved_coupons" to Pair("Saved coupons", "सुरक्षित कुपन"),
        "coupons.current_cycle" to Pair("Current cycle", "हालको चक्र"),
        "coupons.current_draw_label" to Pair("Current draw", "हालको ड्र"),
        "coupons.previous_draw_label" to Pair("Previous draw", "अघिल्लो ड्र"),
        "coupons.awaiting_result" to Pair("Awaiting result", "नतिजा बाँकी"),
        "coupons.check_my_coupons" to Pair("Check My Coupons", "मेरा कुपन जाँच्नुहोस्"),
        "coupons.coupons_in_draw" to Pair("coupons in this draw", "यो ड्रमा कुपन"),
        "coupons.expected_announcement" to Pair("Result expected", "नतिजा अपेक्षित"),
        "coupon.no_merchant" to Pair("No merchant", "व्यापारी छैन"),
        "coupon.current_draw" to Pair("Current draw", "हालको ड्र"),

        "add_coupon.title" to Pair("Add Coupon", "कुपन थप्नुहोस्"),
        "add_coupon.subtitle" to Pair("Enter a 12-digit prize coupon", "१२-अंकीय पुरस्कार कुपन दर्ता गर्नुहोस्"),
        "add_coupon.card_title" to Pair("Coupon Details", "कुपन विवरण"),
        "add_coupon.coupon_label" to Pair("Coupon Number", "कुपन नम्बर"),
        "add_coupon.coupon_placeholder" to Pair("e.g. 007315254493", "जस्तै ००७३१५२५४४९३"),
        "add_coupon.digits_counter" to Pair("/12 digits", "/१२ अंक"),
        "add_coupon.merchant_name" to Pair("Merchant Name", "व्यापारी नाम"),
        "add_coupon.merchant_placeholder" to Pair("e.g. Daraz", "जस्तै दाराज"),
        "add_coupon.draw_period" to Pair("Draw Period", "ड्र अवधि"),
        "add_coupon.invoice_ref" to Pair("Invoice Reference", "चलानी सन्दर्भ"),
        "add_coupon.invoice_placeholder" to Pair("e.g. INV-2083-001", "जस्तै INV-2083-001"),
        "add_coupon.amount_npr" to Pair("Amount (NPR)", "रकम (रु)"),
        "add_coupon.amount_placeholder" to Pair("e.g. 1500", "जस्तै १५००"),
        "add_coupon.save_btn" to Pair("Save Coupon", "कुपन सुरक्षित गर्नुहोस्"),
        "add_coupon.save_success" to Pair("Coupon saved successfully", "कुपन सफलतापूर्वक सुरक्षित भयो"),

        "bulk.title" to Pair("Bulk Add Coupons", "थप कुपन थप्नुहोस्"),
        "bulk.subtitle" to Pair("Paste multiple coupon numbers", "धेरै कुपन नम्बर पेस्ट गर्नुहोस्"),
        "bulk.card_title" to Pair("Paste Coupon Numbers", "कुपन नम्बर पेस्ट गर्नुहोस्"),
        "bulk.instruction" to Pair(
            "Enter one coupon per line, or separate with commas or spaces. Non-digits are automatically stripped.",
            "प्रति लाइन एक कुपन दर्ता गर्नुहोस् वा अल्पविराम/खाली ठाउँले छुट्याउनुहोस्। गैर-अंकहरू स्वतः हटाइनेछन्।"
        ),
        "bulk.placeholder" to Pair(
            "007315254493\n007315254494\n007315254495",
            "००७३१५२५४४९३\n००७३१५२५४४९४\n००७३१५२५४४९५"
        ),
        "bulk.total_found" to Pair("Found", "फेला पर्‍यो"),
        "bulk.valid_new" to Pair("New", "नयाँ"),
        "bulk.duplicates" to Pair("Duplicates", "नक्कली"),
        "bulk.already_saved" to Pair("Saved", "सुरक्षित"),
        "bulk.invalid" to Pair("Invalid", "अमान्य"),
        "bulk.save_success" to Pair("coupons saved successfully", "कुपन सुरक्षित भयो"),
        "bulk.merchant_label" to Pair("Default Merchant (optional)", "पूर्वनिर्धारित व्यापारी (वैकल्पिक)"),
        "bulk.merchant_placeholder" to Pair("e.g. Daraz or Bhatbhateni", "जस्तै दाराज वा भातभातेनी"),
        "bulk.save_btn" to Pair("Save", "सुरक्षित गर्नुहोस्"),
        "bulk.coupons_word" to Pair("coupons", "कुपन"),

        "winner.title" to Pair("Winner Checker", "विजेता जाँच"),
        "winner.subtitle" to Pair("Check your coupons against winning numbers", "विजयी नम्बरसँग आफ्नो कुपन जाँच्नुहोस्"),
        "winner.manual_section" to Pair("Check Winning Numbers", "विजयी नम्बरहरू जाँच्नुहोस्"),
        "winner.manual_hint" to Pair(
            "Paste the 12-digit winning coupon numbers announced by IRD.",
            "आन्तरिक राजस्व विभागद्वारा घोषित १२-अंकीय विजयी कुपन नम्बरहरू टाँस्नुहोस्।"
        ),
        "winner.draw_title" to Pair("Draw Title (optional)", "ड्र शीर्षक (वैकल्पिक)"),
        "winner.draw_title_placeholder" to Pair("e.g. 2083 Bhadra 1st Half Draw", "जस्तै २०८३ भदौ पहिलो हाफ ड्र"),
        "winner.paste_placeholder" to Pair(
            "Paste winning 12-digit coupon numbers here...\ne.g. 007315254493",
            "विजयी १२-अंकीय कुपन नम्बरहरू यहाँ टाँस्नुहोस्...\nजस्तै ००७३१५२५४४९३"
        ),
        "winner.manual_check_btn" to Pair("Check My Numbers", "मेरा नम्बरहरू जाँच्नुहोस्"),
        "winner.invalid_result" to Pair("Some entered lines are not valid 12-digit coupon numbers.", "केही दर्ता गरिएका लाइनहरू मान्य १२-अंकीय कुपन नम्बर होइनन्।"),
        "winner.no_match" to Pair("No winning matches found", "कुनै विजयी म्याच फेला परेन"),
        "winner.result_no_match" to Pair("None of your saved coupons matched these winning numbers. Keep saving your receipts for next time!", "तपाईंको कुनै पनि कुपन यी विजयी नम्बरहरूसँग मिलेन। अर्को पटकका लागि रसिदहरू सुरक्षित राख्नुहोस्!"),
        "winner.match_found" to Pair("Winning Match Found!", "विजयी म्याच फेला पर्‍यो!"),
        "winner.matches_found" to Pair("Winning Matches Found!", "विजयी म्याचहरू फेला पर्‍यो!"),
        "winner.result_matches" to Pair("Congratulations! You have matching coupon(s) for this draw.", "बधाई छ! यो ड्रका लागि तपाईंको कुपन म्याच भएको छ।"),
        "winner.saved_coupon" to Pair("Saved Coupon", "सुरक्षित कुपन"),
        "winner.result_source" to Pair("Result Source", "नतिजा स्रोत"),
        "winner.entered_manually" to Pair("Manually Entered", "म्यानुअल दर्ता"),
        "winner.verify_official" to Pair("Always verify winning status on the official IRD portal before claiming.", "दाबी गर्नुअघि सधैं आधिकारिक आन्तरिक राजस्व पोर्टलमा विजयी स्थिति प्रमाणित गर्नुहोस्।"),
        "winner.total_checked" to Pair("Coupons Checked", "जाँचिएका कुपन"),
        "winner.winning_numbers" to Pair("Winning Numbers", "विजयी नम्बर"),
        "winner.matches_label" to Pair("Matches", "म्याचहरू"),
        "winner.history_section" to Pair("Check History", "जाँच इतिहास"),
        "winner.history_empty" to Pair("No previous checks recorded yet.", "अहिलेसम्म कुनै अघिल्लो जाँच रेकर्ड गरिएको छैन।"),
        "winner.matched_coupon" to Pair("Match Found", "म्याच फेला पर्‍यो"),
        "winner.not_matched_coupon" to Pair("No Match", "म्याच भएन"),
        "winner.entered_result" to Pair("Entered", "दर्ता"),
        "winner.checked" to Pair("Checked", "जाँचिएको"),
        "winner.clear_history" to Pair("Clear History", "इतिहास मेटाउनुहोस्"),
        "winner.clear_history_confirm" to Pair("Are you sure you want to clear your winner check history?", "के तपाईं निश्चित रूपमा आफ्नो विजेता जाँच इतिहास मेटाउन चाहनुहुन्छ?"),
        "winner.history_cleared" to Pair("Check history cleared", "जाँच इतिहास मेटाइयो"),

        "ird.official_results" to Pair("Official IRD Prize Portal", "आधिकारिक आन्तरिक राजस्व पुरस्कार पोर्टल"),
        "ird.results_from_ird" to Pair("The Inland Revenue Department of Nepal conducts regular fortnightly draws.", "नेपालको आन्तरिक राजस्व विभागले नियमित पाक्षिक ड्र सञ्चालन गर्दछ।"),
        "ird.rasid_not_verify" to Pair("Bill Linus is a personal helper app and does not automatically alter official government records.", "बिल लिनुहोस् (Bill Linus) एक व्यक्तिगत सहायक ऐप हो।"),
        "ird.result_source_unavailable" to Pair("Direct API not available", "प्रत्यक्ष API उपलब्ध छैन"),
        "ird.auto_unavailable" to Pair("The government prize portal requires direct human verification.", "सरकारी पुरस्कार पोर्टलमा प्रत्यक्ष मानव प्रमाणीकरण आवश्यक हुन्छ।"),
        "ird.authoritative_source" to Pair("Use the official portal link below to view live announcements.", "प्रत्यक्ष घोषणाहरू हेर्न तलको आधिकारिक पोर्टल लिङ्क प्रयोग गर्नुहोस्।"),
        "ird.official_confirmation_required" to Pair("Official Confirmation Required", "आधिकारिक प्रमाणीकरण आवश्यक"),
        "ird.check_portal_hint" to Pair("Please visit prize.ird.gov.np to file your official claim.", "आफ्नो आधिकारिक दाबी दर्ता गर्न कृपया prize.ird.gov.np मा जानुहोस्।"),
        "ird.not_checked" to Pair("Not checked with official portal yet", "आधिकारिक पोर्टलमा अझै जाँचिएको छैन"),
        "ird.open_official_results" to Pair("Open Official Prize Portal", "आधिकारिक पुरस्कार पोर्टल खोल्नुहोस्"),

        "claim.title" to Pair("Claim Report", "दाबी प्रतिवेदन"),
        "claim.subtitle" to Pair("Print-ready report for claiming your prize", "पुरस्कार दाबी गर्न मुद्रण-योग्य प्रतिवेदन"),
        "claim.subtitle_alt" to Pair("Prize Claim Summary", "पुरस्कार दाबी सारांश"),
        "claim.report_record" to Pair("Official Consumer Lottery Record", "आधिकारिक उपभोक्ता लटरी रेकर्ड"),
        "claim.winning_coupon" to Pair("Winning Coupon Match", "विजयी कुपन म्याच"),
        "claim.winning_coupon_number" to Pair("Winning 12-Digit Coupon Number", "विजयी १२-अंकीय कुपन नम्बर"),
        "claim.default_draw" to Pair("Fortnightly Consumer Draw", "पाक्षिक उपभोक्ता ड्र"),
        "claim.draw_title" to Pair("Draw", "ड्र"),
        "claim.draw_period" to Pair("Draw Period", "ड्र अवधि"),
        "claim.announcement_date" to Pair("Announcement Date", "घोषणा मिति"),
        "claim.purchase_details" to Pair("Purchase Details", "खरिद विवरण"),
        "claim.seller" to Pair("Seller / Merchant", "विक्रेता / व्यापारी"),
        "claim.amount" to Pair("Purchase Amount", "खरिद रकम"),
        "claim.date" to Pair("Invoice Date", "चलानी मिति"),
        "claim.payment" to Pair("Payment Method", "भुक्तानी विधि"),
        "claim.pan" to Pair("Seller PAN/VAT", "विक्रेता प्यान/भ्याट"),
        "claim.invoice_no" to Pair("Invoice Number", "चलानी नम्बर"),
        "claim.print" to Pair("Print / Share Report", "प्रतिवेदन मुद्रण / सेयर गर्नुहोस्"),
        "claim.print_short" to Pair("Print", "मुद्रण"),
        "claim.disclaimer" to Pair(
            "This summary is prepared for your personal submission to the Inland Revenue Department (IRD) Nepal. Take this record along with your digital payment proof and original receipt.",
            "यो सारांश आन्तरिक राजस्व विभाग (IRD) नेपालमा तपाईंको व्यक्तिगत पेशका लागि तयार गरिएको हो। यो रेकर्ड साथमा डिजिटल भुक्तानी प्रमाण र मौलिक रसिद लिएर जानुहोस्।"
        ),
        "claim.no_report" to Pair("No Claim Data", "कुनै दाबी डाटा छैन"),
        "claim.no_report_desc" to Pair("Select a winning coupon from the Winner Checker to generate a claim report.", "दाबी प्रतिवेदन बनाउन विजेता जाँचबाट विजयी कुपन छान्नुहोस्।"),

        "ird_info.title" to Pair("IRD Taxpayer Prize Guide", "करदाता प्रोत्साहन उपहार गाइड"),
        "ird_info.subtitle" to Pair("Official Guidelines & Winning Prizes", "आधिकारिक कार्यविधि तथा पुरस्कार"),
        "ird_info.know_your_rights" to Pair("TAXPAYER INCENTIVE SCHEME", "करदाता प्रोत्साहन योजना"),
        "ird_info.lottery_title" to Pair("Nepal IRD Prize Program", "नेपाल आन्तरिक राजस्व उपहार कार्यक्रम"),
        "ird_info.hero_desc" to Pair(
            "Promoting genuine tax invoice collection and digital payments with Daily Rs 1 Lakh and Fortnightly Rs 10 Lakh Bumper prizes.",
            "दैनिक रु १ लाख र पाक्षिक रु १० लाख बम्पर नगद पुरस्कारसहित वास्तविक कर बिजक र डिजिटल भुक्तानीलाई प्रोत्साहन।"
        ),
        "ird_info.what_is" to Pair("What is the Taxpayer Incentive Program?", "करदाता प्रोत्साहन उपहार कार्यक्रम के हो?"),
        "ird_info.what_is_desc" to Pair(
            "The Inland Revenue Department (IRD) of Nepal runs the official Taxpayer Incentive Prize Program (ird.gov.np/category/prize-program). Consumers purchasing goods/services over Rs. 100 with valid VAT/PAN tax invoices enter draws for Daily Rs. 1 Lakh and Bumper Rs. 10 Lakh cash prizes, plus 10% instant VAT refund on electronic payments.",
            "नेपालको आन्तरिक राजस्व विभागले आधिकारिक करदाता प्रोत्साहन उपहार कार्यक्रम सञ्चालन गरेको छ। रु १०० भन्दा बढीको खरिदमा आधिकारिक कर बिजक प्राप्त गरी दैनिक रु १ लाख र पाक्षिक रु १० लाख बम्पर पुरस्कार जित्न सकिन्छ, साथै डिजिटल भुक्तानीमा १०% तत्काल भ्याट फिर्ता हुन्छ।"
        ),
        "ird_info.how_to" to Pair("Participation & Claim Rules", "सहभागी हुने र दाबी गर्ने नियमहरू"),
        "ird_info.how_to_1" to Pair("1. Demand valid VAT/PAN Tax Invoice on purchases over NPR 100", "१. रु १०० भन्दा माथिको खरिदमा प्यान/भ्याट कर बिजक माग्नुहोस्"),
        "ird_info.how_to_2" to Pair("2. Pay digitally (auto-enrolled) or upload cash invoice on prize.ird.gov.np", "२. डिजिटल भुक्तानी (स्वतः दर्ता) वा नगद बिल prize.ird.gov.np मा दर्ता गर्नुहोस्"),
        "ird_info.how_to_3" to Pair("3. Obtain your 12-digit prize coupon & save in Bill Linus", "३. १२-अंकीय कुपन नम्बर प्राप्त गरी बिल लिनुहोस् (Bill Linus) मा सुरक्षित राख्नुहोस्"),
        "ird_info.how_to_4" to Pair("4. Draws held twice monthly (16th and end of each Nepali month)", "४. महिनाको १६ गते र अन्तिम दिन हुने स्वचालित ड्र नतिजा जाँच्नुहोस्"),
        "ird_info.how_to_5" to Pair("5. Claim within 15 days at nearest IRO/TSO tax office with original invoice", "५. सक्कल कर बिजकसहित १५ दिन भित्र नजिकको कर कार्यालयमा दाबी गर्नुहोस्"),
        "ird_info.prizes" to Pair("Official Prize Amounts", "आधिकारिक पुरस्कार राशि"),
        "ird_info.first_prize" to Pair("Fortnightly Bumper Prize: NPR 10,00,000", "पाक्षिक बम्पर पुरस्कार: रु १०,००,०००"),
        "ird_info.second_prize" to Pair("Daily Cash Prize: NPR 1,00,000 (Net)", "दैनिक नगद पुरस्कार: रु १,००,००० (कर कट्टी पछि)"),
        "ird_info.third_prize" to Pair("Instant 10% VAT Cashback on Digital Payments", "डिजिटल भुक्तानीमा १०% तत्काल भ्याट फिर्ता"),
        "ird_info.reminder" to Pair("Official Portal Access", "आधिकारिक पोर्टल पहुँच"),
        "ird_info.reminder_desc" to Pair("Check live announcements, directives, and winner lists on prize.ird.gov.np & ird.gov.np/category/prize-program.", "live घोषणाहरू, कार्यविधि र विजेता सूची prize.ird.gov.np र ird.gov.np मा हेर्नुहोस्।"),
        "ird_info.visit_ird" to Pair("Visit prize.ird.gov.np", "prize.ird.gov.np खोल्नुहोस्"),
        "ird_info.check_eligibility_link" to Pair("Check Purchase Eligibility", "खरिद योग्यता जाँच्नुहोस्"),
        "ird_info.verify_seller_link" to Pair("Verify Seller PAN / VAT", "विक्रेता प्यान / भ्याट जाँच्नुहोस्"),
        "ird_info.data_backup_link" to Pair("Backup & Data Management", "ब्याकअप र डाटा व्यवस्थापन"),

        "eligibility.title" to Pair("Eligibility Calculator", "योग्यता क्यालकुलेटर"),
        "eligibility.subtitle" to Pair("Check if your purchase qualifies for prize coupons", "तपाईंको खरिद पुरस्कार कुपनका लागि योग्य छ कि छैन जाँच्नुहोस्"),
        "eligibility.purchase_details" to Pair("Transaction Criteria", "कारोबार मापदण्ड"),
        "eligibility.seller_name" to Pair("Seller Name (Optional)", "विक्रेता नाम (वैकल्पिक)"),
        "eligibility.seller_placeholder" to Pair("e.g. Supermarket or Cafe", "जस्तै सुपरमार्केट वा क्याफे"),
        "eligibility.amount_placeholder" to Pair("e.g. 500", "जस्तै ५००"),
        "eligibility.payment_method" to Pair("Payment Method", "भुक्तानी विधि"),
        "eligibility.seller_pan" to Pair("Seller PAN Number (Optional)", "विक्रेता प्यान नम्बर (वैकल्पिक)"),
        "eligibility.pan_placeholder" to Pair("9-digit PAN number", "९-अंकीय प्यान नम्बर"),
        "eligibility.check_btn" to Pair("Calculate Eligibility", "योग्यता गणना गर्नुहोस्"),
        "eligibility.likely_eligible_msg" to Pair("Likely Eligible for Prize Coupon!", "पुरस्कार कुपनका लागि योग्य हुने सम्भावना छ!"),
        "eligibility.likely_not_msg" to Pair("Likely Not Eligible", "योग्य नहुने सम्भावना छ"),
        "eligibility.verification_msg" to Pair("Needs Seller PAN Verification", "विक्रेता प्यान प्रमाणीकरण आवश्यक"),

        "verify_vendor.title" to Pair("Verify Vendor", "विक्रेता जाँच"),
        "verify_vendor.subtitle" to Pair("Search & verify 9-digit seller PAN/VAT", "९-अंकीय विक्रेता प्यान/भ्याट खोज र प्रमाणित गर्नुहोस्"),
        "verify_vendor.track_a_header" to Pair("Official IRD PAN Search", "आधिकारिक आन्तरिक राजस्व प्यान खोज"),
        "verify_vendor.track_a_desc" to Pair("Enter the 9-digit PAN from your receipt. Copy it and check active registration on the official tax portal.", "तपाईंको रसिदबाट ९-अंकीय प्यान दर्ता गर्नुहोस्। प्रतिलिपि गरेर आधिकारिक कर पोर्टलमा सक्रिय दर्ता जाँच्नुहोस्।"),
        "verify_vendor.track_b_header" to Pair("Test Purchase Scheme Rules", "खरिद योजना नियम परीक्षण"),
        "verify_vendor.track_b_desc" to Pair("Run our rule checker to confirm whether this vendor transaction satisfies minimum amount & digital payment requirements.", "न्यूनतम रकम र डिजिटल भुक्तानी आवश्यकताहरू पूरा गर्दछ कि गर्दैन पुष्टि गर्न हाम्रो नियम जाँचकर्ता चलाउनुहोस्।"),
        "verify_vendor.pan_label" to Pair("Seller PAN (9 digits)", "विक्रेता प्यान (९ अंक)"),
        "verify_vendor.pan_placeholder" to Pair("e.g. 601928374", "जस्तै ६०१९२८३७४"),
        "verify_vendor.seller_pan" to Pair("Seller PAN", "विक्रेता प्यान"),
        "verify_vendor.copy_pan" to Pair("Copy PAN", "प्यान प्रतिलिपि"),
        "verify_vendor.invalid_pan" to Pair("PAN must be exactly 9 numeric digits", "प्यान ठीक ९ अंकको हुनुपर्छ"),
        "verify_vendor.pan_hint" to Pair("Copy this PAN and verify seller registration status directly on the official IRD portal.", "यो प्यान प्रतिलिपि गर्नुहोस् र आधिकारिक आन्तरिक राजस्व पोर्टलमा विक्रेता दर्ता स्थिति सिधै प्रमाणित गर्नुहोस्।"),
        "verify_vendor.disclaimer" to Pair("Verification takes place on the official Government of Nepal tax system.", "प्रमाणीकरण आधिकारिक नेपाल सरकार कर प्रणालीमा हुन्छ।"),
        "verify_vendor.verify_on_ird" to Pair("Search PAN on Official IRD Portal", "आधिकारिक पोर्टलमा प्यान खोज्नुहोस्"),
        "verify_vendor.check_eligibility" to Pair("Check Transaction Eligibility", "कारोबार योग्यता जाँच्नुहोस्"),
        "verify_vendor.pan_copied" to Pair("PAN copied to clipboard", "प्यान क्लिपबोर्डमा प्रतिलिपि गरियो"),
        "verify_vendor.back_guide" to Pair("Back to Guide", "गाइडमा फर्कनुहोस्"),

        "data_backup.title" to Pair("Backup & Restore", "ब्याकअप र पुनर्स्थापना"),
        "data_backup.subtitle" to Pair("Manage your local offline data", "आफ्नो स्थानीय अफलाइन डाटा व्यवस्थापन गर्नुहोस्"),
        "data_backup.summary_invoices" to Pair("Invoices Saved", "सुरक्षित चलानी"),
        "data_backup.summary_coupons" to Pair("Coupons Saved", "सुरक्षित कुपन"),
        "data_backup.summary_draws" to Pair("Announcements", "घोषणाहरू"),
        "data_backup.export_title" to Pair("Export Backup (JSON)", "ब्याकअप निर्यात (JSON)"),
        "data_backup.export_desc" to Pair("Download a backup JSON file containing all your recorded invoices, coupons, and history.", "तपाईंका सबै रेकर्ड गरिएका चलानी, कुपन, र इतिहास समावेश भएको ब्याकअप JSON फाइल डाउनलोड गर्नुहोस्।"),
        "data_backup.export" to Pair("Export Data", "डाटा निर्यात गर्नुहोस्"),
        "data_backup.exported" to Pair("Data exported successfully", "डाटा सफलतापूर्वक निर्यात भयो"),
        "data_backup.import_title" to Pair("Restore from Backup", "ब्याकअपबाट पुनर्स्थापना"),
        "data_backup.import_desc" to Pair("Paste or load a valid JSON backup file to restore previously saved records.", "पहिले सुरक्षित रेकर्ड पुनर्स्थापना गर्न मान्य JSON ब्याकअप फाइल लोड गर्नुहोस्।"),
        "data_backup.choose_file" to Pair("Import Backup JSON", "ब्याकअप JSON आयात गर्नुहोस्"),
        "data_backup.imported" to Pair("Data imported successfully", "डाटा सफलतापूर्वक आयात भयो"),
        "data_backup.import_failed" to Pair("Invalid backup format", "अमान्य ब्याकअप ढाँचा"),
        "data_backup.clear_title" to Pair("Clear All Stored Data", "सबै सुरक्षित डाटा मेटाउनुहोस्"),
        "data_backup.clear_desc" to Pair("Reset all records to factory state. This action cannot be undone.", "सबै रेकर्डहरू रिसेट गर्नुहोस्। यो कार्य पूर्ववत गर्न सकिँदैन।"),
        "data_backup.clear" to Pair("Reset All Data", "सबै डाटा रिसेट गर्नुहोस्"),
        "data_backup.clear_confirm" to Pair("Are you sure you want to delete all saved invoices and coupons? This cannot be undone.", "के तपाईं निश्चित रूपमा सबै सुरक्षित चलानी र कुपन मेटाउन चाहनुहुन्छ? यो पूर्ववत गर्न सकिँदैन।"),
        "data_backup.cleared" to Pair("All records cleared", "सबै रेकर्डहरू मेटाइयो"),

        // Eligibility Reasons
        "eligibility.reason_min_amount" to Pair("Amount is less than minimum NPR 100 threshold", "रकम न्यूनतम रु १०० भन्दा कम छ"),
        "eligibility.reason_business_gov" to Pair("Business and Government purchases are not eligible for consumer lottery", "व्यापारिक तथा सरकारी खरिद उपभोक्ता लटरीका लागि योग्य छैन"),
        "eligibility.reason_cash" to Pair(
            "Cash payment is eligible: Register tax invoice on the IRD portal (prize.ird.gov.np) to obtain your 12-digit lucky coupon number.",
            "नगद भुक्तानी योग्य छ: १२-अंकीय लक्की कुपन नम्बर प्राप्त गर्न IRD पोर्टल (prize.ird.gov.np) मा कर चलानी दर्ता गर्नुहोस्।"
        ),
        "eligibility.cash_info_title" to Pair("Cash Payment: Eligible with IRD Registration", "नगद भुक्तानी: IRD दर्ता गरेपछि योग्य"),
        "eligibility.cash_info_desc" to Pair(
            "As per government rules, cash purchases are eligible! Please collect the official tax invoice and register/update the bill details on the IRD incentive program website to get your coupon number for record keeping and lucky draw tracking.",
            "सरकारी नियम अनुसार नगद खरिद पनि योग्य छ! कृपया आधिकारिक कर चलानी लिनुहोस् र लक्की नम्बर ट्र्याक गर्न तथा रेकर्ड राख्न IRD प्रोत्साहन कार्यक्रमको वेबसाइटमा विवरण दर्ता गरी कुपन नम्बर प्राप्त गर्नुहोस्।"
        ),
        "eligibility.open_ird_portal" to Pair("Open IRD Incentive Portal (prize.ird.gov.np)", "IRD प्रोत्साहन पोर्टल खोल्नुहोस् (prize.ird.gov.np)"),
        "eligibility.reason_other_payment" to Pair("Payment method must be digital or cash with tax invoice registration", "भुक्तानी विधि डिजिटल वा कर चलानी दर्तासहितको नगद हुनुपर्छ"),
        "eligibility.reason_non_digital" to Pair("Non-digital payment method detected", "गैर-डिजिटल भुक्तानी विधि पत्ता लाग्यो"),
        "eligibility.reason_exempt_category" to Pair("Exempt utility or transport category", "छूट प्राप्त उपयोगिता वा यातायात श्रेणी"),
        "eligibility.reason_no_pan" to Pair("Seller must be PAN/VAT registered", "विक्रेता प्यान/भ्याट दर्ता हुनुपर्छ"),
        "eligibility.reason_pan_unknown" to Pair("Seller PAN is unconfirmed", "विक्रेता प्यान पुष्टि भएको छैन"),
        "eligibility.reason_pan_digits" to Pair("PAN number must be 9 digits", "प्यान नम्बर ९ अंकको हुनुपर्छ"),
        "eligibility.reason_all_met" to Pair("All IRD Consumer Lottery criteria met!", "सबै आन्तरिक राजस्व उपभोक्ता लटरी मापदण्ड पूरा भयो!"),
        "eligibility.reason_verify_pan" to Pair("Verify seller 9-digit PAN to ensure full eligibility", "पूर्ण योग्यता सुनिश्चित गर्न विक्रेता ९-अंकीय प्यान प्रमाणित गर्नुहोस्")
    )

    fun get(key: String, lang: AppLanguage): String {
        val pair = STRINGS[key] ?: return key
        return if (lang == AppLanguage.NE) pair.second else pair.first
    }

    fun getPaymentMethodLabel(method: PaymentMethod, lang: AppLanguage): String {
        return when (method) {
            PaymentMethod.DIGITAL_WALLET -> if (lang == AppLanguage.NE) "डिजिटल वालेट (eSewa/Khalti)" else "Digital Wallet (eSewa/Khalti)"
            PaymentMethod.QR_PAYMENT -> if (lang == AppLanguage.NE) "QR भुक्तानी (Fonepay)" else "QR Payment (Fonepay)"
            PaymentMethod.MOBILE_BANKING -> if (lang == AppLanguage.NE) "मोबाइल बैंकिङ" else "Mobile Banking"
            PaymentMethod.CARD -> if (lang == AppLanguage.NE) "कार्ड (Debit/Credit)" else "Card (Debit/Credit)"
            PaymentMethod.CASH -> if (lang == AppLanguage.NE) "नगद (Cash)" else "Cash"
            PaymentMethod.BANK_TRANSFER -> if (lang == AppLanguage.NE) "बैंक ट्रान्सफर (ConnectIPS)" else "Bank Transfer (ConnectIPS)"
            PaymentMethod.OTHER -> if (lang == AppLanguage.NE) "अन्य" else "Other"
        }
    }

    fun getStatusLabel(status: EligibilityStatus, lang: AppLanguage): String {
        return when (status) {
            EligibilityStatus.COUPON_ADDED -> if (lang == AppLanguage.NE) "कुपन दर्ता भयो" else "Coupon Added"
            EligibilityStatus.AWAITING_COUPON -> if (lang == AppLanguage.NE) "कुपन बाँकी" else "Awaiting Coupon"
            EligibilityStatus.LIKELY_ELIGIBLE -> if (lang == AppLanguage.NE) "योग्य" else "Likely Eligible"
            EligibilityStatus.NEEDS_VERIFICATION -> if (lang == AppLanguage.NE) "प्यान जाँच बाँकी" else "Needs Verification"
            EligibilityStatus.LIKELY_NOT_ELIGIBLE -> if (lang == AppLanguage.NE) "अयोग्य" else "Not Eligible"
            EligibilityStatus.NOT_CHECKED -> if (lang == AppLanguage.NE) "जाँचिएको छैन" else "Not Checked"
        }
    }

    fun getReason(reason: EligibilityReason, lang: AppLanguage): String {
        val raw = get(reason.key, lang)
        var result = raw
        for ((k, v) in reason.params) {
            result = result.replace("{$k}", v)
        }
        return result
    }
}
