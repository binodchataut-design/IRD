package com.example.utils

data class BillData(
    val sellerName: String = "",
    val pan: String = "",
    val invoiceNumber: String = "",
    val date: String = "",
    val amount: String = ""
)

object BillDataUtils {

    fun normalizeAmount(value: String): String {
        if (value.isBlank()) return ""
        var cleaned = value.lowercase()
        cleaned = cleaned.replace("rs.", "").replace("rs", "").replace("npr.", "").replace("npr", "")
        cleaned = cleaned.replace("रू", "").replace("रु", "").replace("।", "")
        cleaned = cleaned.replace(",", "").replace(" ", "")
        val match = Regex("\\d+(?:\\.\\d{1,2})?").find(cleaned)
        return match?.value ?: ""
    }

    fun normalizeDate(value: String): String {
        if (value.isBlank()) return ""
        val isoMatch = Regex("(\\d{4})-(\\d{2})-(\\d{2})").find(value)
        if (isoMatch != null) return isoMatch.value
        val slashMatch = Regex("(\\d{1,2})[/.](\\d{1,2})[/.](\\d{2,4})").find(value)
        if (slashMatch != null) {
            val (d, m, y) = slashMatch.destructured
            val year = if (y.length == 2) "20$y" else y
            val mm = m.padStart(2, '0')
            val dd = d.padStart(2, '0')
            return "$year-$mm-$dd"
        }
        return ""
    }

    fun normalizePan(value: String): String {
        return value.filter { it.isDigit() }
    }

    fun normalizeBillData(data: BillData): BillData {
        return BillData(
            sellerName = data.sellerName.trim(),
            pan = normalizePan(data.pan),
            invoiceNumber = data.invoiceNumber.trim(),
            date = normalizeDate(data.date),
            amount = normalizeAmount(data.amount)
        )
    }

    fun isFieldConflict(current: String, candidate: String): Boolean {
        val c = current.trim()
        val cand = candidate.trim()
        return c.isNotEmpty() && cand.isNotEmpty() && !c.equals(cand, ignoreCase = true)
    }

    fun hasAnyConflict(current: BillData, candidate: BillData): Boolean {
        return isFieldConflict(current.sellerName, candidate.sellerName) ||
                isFieldConflict(current.pan, candidate.pan) ||
                isFieldConflict(current.invoiceNumber, candidate.invoiceNumber) ||
                isFieldConflict(current.date, candidate.date) ||
                isFieldConflict(current.amount, candidate.amount)
    }
}
