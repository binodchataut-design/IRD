package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.repository.AppRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Rasid Khata", appName)
  }

  @Test
  fun `welcome onboarding persistence test`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = AppRepository(context)
    
    // Initially false for new installation
    assertFalse(repository.hasSeenWelcome())

    // Setting to true persists correctly
    repository.setHasSeenWelcome(true)
    assertTrue(repository.hasSeenWelcome())

    // Resetting works
    repository.setHasSeenWelcome(false)
    assertFalse(repository.hasSeenWelcome())
  }

  @Test
  fun `welcome strings bilingual availability`() {
    val keys = listOf(
      "welcome.tag",
      "welcome.skip",
      "welcome.next",
      "welcome.back",
      "welcome.get_started",
      "welcome.card1.title",
      "welcome.card2.title",
      "welcome.card3.title",
      "info.foreign.header",
      "info.foreign.pan_title",
      "info.foreign.tax_title"
    )

    for (key in keys) {
      val en = AppStrings.get(key, AppLanguage.ENGLISH)
      val ne = AppStrings.get(key, AppLanguage.NEPALI)
      assertNotNull("EN string for $key should exist", en)
      assertNotNull("NE string for $key should exist", ne)
      assertTrue("EN string for $key must not be key", en != key)
      assertTrue("NE string for $key must not be key", ne != key)
    }
  }
}
