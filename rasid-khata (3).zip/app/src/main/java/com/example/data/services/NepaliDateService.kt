package com.example.data.services

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class DrawPeriodInfo(
    val drawPeriod: String,
    val expectedAnnouncement: String,
    val cycleName: String,
    val isExact: Boolean
)

data class BsDate(
    val year: Int,
    val month: Int, // 1 = Baisakh, 12 = Chaitra
    val day: Int
)

data class AdDate(
    val year: Int,
    val month: Int, // 1 = Jan, 12 = Dec
    val day: Int
)

/**
 * Service for Gregorian (AD) to Bikram Sambat (BS) conversion and
 * dynamic IRD fortnightly lottery draw cycle detection.
 */
object NepaliDateService {

    private val MONTH_NAMES_EN = arrayOf(
        "", "Baisakh", "Jestha", "Ashadh", "Shrawan", "Bhadra",
        "Ashwin", "Kartik", "Mangsir", "Poush", "Magh", "Falgun", "Chaitra"
    )

    private val MONTH_NAMES_NP = arrayOf(
        "", "बैशाख", "जेठ", "असार", "साउन", "भदौ",
        "असोज", "कात्तिक", "मंसिर", "पुष", "माघ", "फागुन", "चैत"
    )

    private val GREGORIAN_MONTH_SHORT = arrayOf(
        "", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"
    )

    // Base Reference: 2000 Baisakh 1 BS = 1943 April 14 AD (Wednesday)
    private const val START_BS_YEAR = 2000
    private const val START_AD_YEAR = 1943
    private const val START_AD_MONTH = 4  // April
    private const val START_AD_DAY = 14

    // Number of days in each BS month (1 to 12) for BS years 2000 to 2090
    private val BS_CALENDAR_DATA = arrayOf(
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2000
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2001
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2002
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2003
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2004
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2005
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2006
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2007
        intArrayOf(31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 29, 31), // 2008
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2009
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2010
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2011
        intArrayOf(31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30), // 2012
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2013
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2014
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2015
        intArrayOf(31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30), // 2016
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2017
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2018
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2019
        intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30), // 2020
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2021
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30), // 2022
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2023
        intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30), // 2024
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2025
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2026
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2027
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2028
        intArrayOf(31, 31, 32, 31, 32, 30, 30, 29, 30, 29, 30, 30), // 2029
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2030
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2031
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2032
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2033
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2034
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2035
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2036
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2037
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2038
        intArrayOf(31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 29, 31), // 2039
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2040
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2041
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2042
        intArrayOf(31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30), // 2043
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2044
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2045
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2046
        intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30), // 2047
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2048
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30), // 2049
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2050
        intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30), // 2051
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2052
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30), // 2053
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2054
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2055
        intArrayOf(31, 31, 32, 31, 32, 30, 30, 29, 30, 29, 30, 30), // 2056
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2057
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2058
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2059
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2060
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2061
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2062
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2063
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2064
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2065
        intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30), // 2066
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2067
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30), // 2068
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2069
        intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30), // 2070
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2071
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30), // 2072
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2073
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2074
        intArrayOf(31, 31, 32, 31, 32, 30, 30, 29, 30, 29, 30, 30), // 2075
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2076
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2077
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2078
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2079
        intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30), // 2080
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2081
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2082
        intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30), // 2083
        intArrayOf(31, 31, 32, 31, 31, 30, 30, 30, 29, 30, 30, 30), // 2084
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2085
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31), // 2086
        intArrayOf(31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30), // 2087
        intArrayOf(31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30), // 2088
        intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31), // 2089
        intArrayOf(30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31)  // 2090
    )

    /**
     * Get the number of days in a given BS month.
     */
    fun getDaysInBsMonth(bsYear: Int, bsMonth: Int): Int {
        val yearIndex = bsYear - START_BS_YEAR
        if (yearIndex < 0 || yearIndex >= BS_CALENDAR_DATA.size || bsMonth !in 1..12) {
            return 30
        }
        return BS_CALENDAR_DATA[yearIndex][bsMonth - 1]
    }

    /**
     * Convert Gregorian (AD) Date to Bikram Sambat (BS) Date.
     */
    fun convertAdToBs(adYear: Int, adMonth: Int, adDay: Int): BsDate? {
        try {
            val baseCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                clear()
                set(START_AD_YEAR, START_AD_MONTH - 1, START_AD_DAY, 0, 0, 0)
            }
            val targetCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                clear()
                set(adYear, adMonth - 1, adDay, 0, 0, 0)
            }

            var diffDays = ((targetCal.timeInMillis - baseCal.timeInMillis) / (1000 * 60 * 60 * 24)).toInt()
            if (diffDays < 0) return null

            var bsYear = START_BS_YEAR
            var bsMonth = 1
            var bsDay = 1

            var yearIdx = 0
            while (yearIdx < BS_CALENDAR_DATA.size) {
                var monthIdx = 0
                while (monthIdx < 12) {
                    val daysInMonth = BS_CALENDAR_DATA[yearIdx][monthIdx]
                    if (diffDays < daysInMonth) {
                        bsYear = START_BS_YEAR + yearIdx
                        bsMonth = monthIdx + 1
                        bsDay = diffDays + 1
                        return BsDate(bsYear, bsMonth, bsDay)
                    }
                    diffDays -= daysInMonth
                    monthIdx++
                }
                yearIdx++
            }
            return null
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * Convert Bikram Sambat (BS) Date to Gregorian (AD) Date.
     */
    fun convertBsToAd(bsYear: Int, bsMonth: Int, bsDay: Int): AdDate? {
        try {
            val targetYearIdx = bsYear - START_BS_YEAR
            if (targetYearIdx < 0 || targetYearIdx >= BS_CALENDAR_DATA.size || bsMonth !in 1..12) {
                return null
            }
            val daysInTargetMonth = BS_CALENDAR_DATA[targetYearIdx][bsMonth - 1]
            if (bsDay < 1 || bsDay > daysInTargetMonth) {
                return null
            }

            var totalDays = 0
            for (y in 0 until targetYearIdx) {
                for (m in 0 until 12) {
                    totalDays += BS_CALENDAR_DATA[y][m]
                }
            }
            for (m in 0 until (bsMonth - 1)) {
                totalDays += BS_CALENDAR_DATA[targetYearIdx][m]
            }
            totalDays += (bsDay - 1)

            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                clear()
                set(START_AD_YEAR, START_AD_MONTH - 1, START_AD_DAY, 0, 0, 0)
                add(Calendar.DAY_OF_YEAR, totalDays)
            }

            return AdDate(
                year = cal.get(Calendar.YEAR),
                month = cal.get(Calendar.MONTH) + 1,
                day = cal.get(Calendar.DAY_OF_MONTH)
            )
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * Add days to a BS Date and compute the resulting BS Date.
     */
    fun addDaysToBsDate(bsDate: BsDate, daysToAdd: Int): BsDate {
        var currentYear = bsDate.year
        var currentMonth = bsDate.month
        var currentDay = bsDate.day + daysToAdd

        while (true) {
            val daysInMonth = getDaysInBsMonth(currentYear, currentMonth)
            if (currentDay <= daysInMonth) {
                break
            }
            currentDay -= daysInMonth
            currentMonth++
            if (currentMonth > 12) {
                currentMonth = 1
                currentYear++
            }
        }
        return BsDate(currentYear, currentMonth, currentDay)
    }

    fun getCurrentCycle(): DrawPeriodInfo {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = sdf.format(Date())
        return getDrawPeriodInfo(today)
    }

    /**
     * Dynamically converts Gregorian date to Bikram Sambat, detects the fortnightly
     * IRD lottery draw cycle, and calculates expected announcement dates.
     */
    fun getDrawPeriodInfo(dateStr: String?): DrawPeriodInfo {
        val fallback = DrawPeriodInfo(
            drawPeriod = "Current Scheme Cycle",
            expectedAnnouncement = "Following the 15-day billing cycle",
            cycleName = "Fortnightly consumer draw",
            isExact = false
        )

        if (dateStr.isNullOrBlank() || !dateStr.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
            return fallback
        }

        return try {
            val parts = dateStr.split("-")
            val adYear = parts[0].toInt()
            val adMonth = parts[1].toInt()
            val adDay = parts[2].toInt()

            val bsDate = convertAdToBs(adYear, adMonth, adDay) ?: return fallback

            val bsMonthName = MONTH_NAMES_EN.getOrElse(bsDate.month) { "Month" }
            val daysInMonth = getDaysInBsMonth(bsDate.year, bsDate.month)

            val isFirstHalf = bsDate.day <= 15
            val drawPeriod = if (isFirstHalf) {
                "$bsMonthName 1–15, ${bsDate.year}"
            } else {
                "$bsMonthName 16–$daysInMonth, ${bsDate.year}"
            }

            val cycleName = if (isFirstHalf) {
                "$bsMonthName 1st Half Draw"
            } else {
                "$bsMonthName 2nd Half Draw"
            }

            // Fortnight end date: either Day 15 or End of Month
            val fortnightEndBsDate = if (isFirstHalf) {
                BsDate(bsDate.year, bsDate.month, 15)
            } else {
                BsDate(bsDate.year, bsDate.month, daysInMonth)
            }

            // IRD announces draw results exactly 1 week (7 days) after the fortnight ends
            val announcementBsDate = addDaysToBsDate(fortnightEndBsDate, 7)
            val announcementAdDate = convertBsToAd(
                announcementBsDate.year,
                announcementBsDate.month,
                announcementBsDate.day
            )

            val announcementMonthName = MONTH_NAMES_EN.getOrElse(announcementBsDate.month) { "" }
            val expectedAnnouncement = if (announcementAdDate != null) {
                val adMonthStr = GREGORIAN_MONTH_SHORT.getOrElse(announcementAdDate.month) { "" }
                "$announcementMonthName ${announcementBsDate.day}, ${announcementBsDate.year} (Approx. $adMonthStr ${announcementAdDate.day}, ${announcementAdDate.year})"
            } else {
                "$announcementMonthName ${announcementBsDate.day}, ${announcementBsDate.year}"
            }

            DrawPeriodInfo(
                drawPeriod = drawPeriod,
                expectedAnnouncement = expectedAnnouncement,
                cycleName = cycleName,
                isExact = true
            )
        } catch (e: Exception) {
            fallback
        }
    }
}

/*
 * =========================================================================
 * VERIFICATION & TEST CASES:
 * =========================================================================
 * 1. Today's Date:
 *    - Gregorian: 2026-08-17 -> BS: 2083 Bhadra 1
 *    - Result:
 *      drawPeriod = "Bhadra 1–15, 2083"
 *      expectedAnnouncement = "Bhadra 22, 2083 (Approx. Sept 7, 2026)"
 *      cycleName = "Bhadra 1st Half Draw"
 *      isExact = true
 *
 * 2. Second Half of BS Month:
 *    - Gregorian: 2026-08-01 -> BS: 2083 Shrawan 17
 *    - Result:
 *      drawPeriod = "Shrawan 16–32, 2083"
 *      expectedAnnouncement = "Bhadra 7, 2083 (Approx. Aug 23, 2026)"
 *      cycleName = "Shrawan 2nd Half Draw"
 *      isExact = true
 *
 * 3. BS New Year & Gregorian Year Boundary (Mid-April):
 *    - Gregorian: 2026-04-10 -> BS: 2082 Chaitra 28 (Year 2082 ending)
 *    - Result:
 *      drawPeriod = "Chaitra 16–31, 2082"
 *      expectedAnnouncement = "Baisakh 7, 2083 (Approx. Apr 20, 2026)"
 *      cycleName = "Chaitra 2nd Half Draw"
 *      isExact = true
 *
 *    - Gregorian: 2026-04-16 -> BS: 2083 Baisakh 3 (New Year 2083 start)
 *    - Result:
 *      drawPeriod = "Baisakh 1–15, 2083"
 *      expectedAnnouncement = "Baisakh 22, 2083 (Approx. May 5, 2026)"
 *      cycleName = "Baisakh 1st Half Draw"
 *      isExact = true
 *
 * 4. Future Cycle (Beyond 2026):
 *    - Gregorian: 2028-11-20 -> BS: 2085 Mangsir 5
 *    - Result:
 *      drawPeriod = "Mangsir 1–15, 2085"
 *      expectedAnnouncement = "Mangsir 22, 2085 (Approx. Dec 7, 2028)"
 *      cycleName = "Mangsir 1st Half Draw"
 *      isExact = true
 * =========================================================================
 */

