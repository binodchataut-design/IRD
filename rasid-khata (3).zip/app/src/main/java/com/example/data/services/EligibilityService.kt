package com.example.data.services

import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.models.EligibilityStatus
import com.example.data.models.PaymentMethod
import com.example.data.models.PurchasePurpose
import com.example.data.models.SellerPanOption
import com.example.data.models.TransactionCategory
import com.example.data.models.TransactionEligibilityInput
import com.example.data.models.TransactionEligibilityResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EligibilityService {
    /**
     * Evaluates a transaction input against official IRD Taxpayer Incentive rules
     * and Fortnightly Prize Coupon eligibility guidelines.
     */
    fun checkEligibility(
        input: TransactionEligibilityInput,
        lang: AppLanguage = AppLanguage.ENGLISH
    ): TransactionEligibilityResult {
        val reasons = mutableListOf<String>()
        val caveats = mutableListOf<String>()
        val nextSteps = mutableListOf<String>()

        val isDigitalMethod = input.paymentMethod in listOf(
            PaymentMethod.DIGITAL_WALLET,
            PaymentMethod.QR_PAYMENT,
            PaymentMethod.MOBILE_BANKING,
            PaymentMethod.CARD,
            PaymentMethod.BANK_TRANSFER
        )

        val isCash = input.paymentMethod == PaymentMethod.CASH
        val isUnknownMethod = input.paymentMethod == PaymentMethod.OTHER

        // 1. Check Disqualifiers
        val disqualifiers = mutableListOf<String>()

        if (input.amount <= 100) {
            disqualifiers.add(
                if (lang == AppLanguage.NEPALI)
                    "रकम रु. १०० भन्दा बढी हुनुपर्छ (रु. १०० वा कममा IRD लटरी कुपन प्राप्त हुँदैन) ।"
                else
                    "Amount must be more than NPR 100 (NPR 100 or less does not qualify for IRD lottery prize coupons)."
            )
        }

        if (isCash) {
            disqualifiers.add(
                if (lang == AppLanguage.NEPALI)
                    "नगद भुक्तानीमा विद्युतीय प्रोत्साहन लटरी कुपन प्राप्त हुँदैन । तोकिएको डिजिटल भुक्तानी आवश्यक छ ।"
                else
                    "Cash purchases do not generate electronic incentive prize coupons. Approved digital/electronic payments qualify."
            )
        }

        if (input.purpose == PurchasePurpose.BUSINESS || input.purpose == PurchasePurpose.GOVERNMENT) {
            disqualifiers.add(
                if (lang == AppLanguage.NEPALI)
                    "व्यापारिक, संस्थागत तथा सरकारी खरिद यस योजनामा समावेश छैन । केवल व्यक्तिगत उपभोक्ता खरिद मात्र मान्य हुन्छ ।"
                else
                    "Business, commercial, and institutional/government purchases are excluded. Only individual consumer personal purchases qualify."
            )
        }

        if (input.category == TransactionCategory.ELECTRICITY || input.category == TransactionCategory.TELEPHONE_INTERNET) {
            disqualifiers.add(
                if (lang == AppLanguage.NEPALI)
                    "उपयोगिता बिलहरू (विद्युत, टेलिफोन, इन्टरनेट) उपभोक्ता प्रोत्साहन लटरी योजनामा समावेश छैनन् ।"
                else
                    "Utility bills (electricity, telephone, internet) are excluded from the consumer taxpayer incentive lottery scheme."
            )
        }

        if (input.category == TransactionCategory.AIRLINE || input.category == TransactionCategory.TRANSPORT_FREIGHT) {
            disqualifiers.add(
                if (lang == AppLanguage.NEPALI)
                    "हवाई टिकट, सार्वजनिक यातायात तथा ढुवानी खर्च यस योजनामा समावेश छैन ।"
                else
                    "Air tickets, public transport, and freight charges are currently excluded from the consumer lottery scheme."
            )
        }

        if (input.sellerPan == SellerPanOption.NO) {
            disqualifiers.add(
                if (lang == AppLanguage.NEPALI)
                    "बिक्रेताको प्यान/भ्याट दर्ता छैन वा सादा बिल हो । दर्ता भएको आधिकारिक विद्युतीय बिल हुनुपर्छ ।"
                else
                    "Seller PAN/VAT information is missing. Transactions must be from registered businesses issuing authorized electronic tax bills."
            )
        }

        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val evaluatedAt = sdf.format(Date())

        // A. LIKELY NOT ELIGIBLE
        if (disqualifiers.isNotEmpty()) {
            if (lang == AppLanguage.NEPALI) {
                nextSteps.add("आफ्नो रेकर्डका लागि बिल राख्नुहोस्, तर यसमा IRD लटरी कुपन प्राप्त हुने सम्भावना छैन ।")
                nextSteps.add("आगामी पाक्षिक गोलाप्रथाका लागि प्यान दर्ता पसलमा रु. १०० भन्दा माथि QR/वालेटबाट भुक्तानी गर्नुहोस् ।")
            } else {
                nextSteps.add("Keep invoices for personal records, but note this transaction is unlikely to receive an IRD lottery prize coupon.")
                nextSteps.add("For upcoming draws, pay via digital wallet/QR above NPR 100 for personal goods at PAN-registered stores.")
            }

            return TransactionEligibilityResult(
                status = EligibilityStatus.LIKELY_NOT_ELIGIBLE,
                title = if (lang == AppLanguage.NEPALI) "योग्य नहुन सक्ने (Likely Not Eligible)" else "Likely Not Eligible",
                statusLabel = if (lang == AppLanguage.NEPALI) "IRD लटरी कुपनका लागि अयोग्य हुन सक्छ" else "Likely not eligible for IRD Prize Coupon Lottery",
                reasons = disqualifiers,
                caveats = listOf(
                    if (lang == AppLanguage.NEPALI) "रसिद खाता एक स्वतन्त्र सहयोगी एप हो । यो आधिकारिक IRD निर्णय होइन ।"
                    else "Rasid Khata is an independent helper app. This result is not an official IRD eligibility confirmation."
                ),
                digitalWarning = null,
                nextSteps = nextSteps,
                evaluatedAt = evaluatedAt
            )
        }

        // 2. Check Needs Verification items
        val verificationReasons = mutableListOf<String>()

        if (input.sellerPan == SellerPanOption.DONT_KNOW) {
            verificationReasons.add(
                if (lang == AppLanguage.NEPALI)
                    "बिक्रेताको प्यान स्थिति निश्चित छैन । बिक्रेता IRD को विद्युतीय बिलिङ प्रणाली (CBMS) मा दर्ता हुनुपर्छ ।"
                else
                    "Seller PAN status is unconfirmed. The merchant must be registered with IRD and submit electronic invoices to CBMS."
            )
        }

        if (input.category == TransactionCategory.DONT_KNOW) {
            verificationReasons.add(
                if (lang == AppLanguage.NEPALI)
                    "सामानको वर्ग निश्चित छैन । खरिद गरिएका सामान करयोग्य खुद्रा उपभोग्य वस्तु हुनुपर्छ ।"
                else
                    "Transaction category is unconfirmed. Verify that the purchased items are standard taxable retail goods/services."
            )
        }

        if (input.purpose == PurchasePurpose.UNKNOWN) {
            verificationReasons.add(
                if (lang == AppLanguage.NEPALI)
                    "खरिदको उद्देश्य स्पष्ट छैन । केवल व्यक्तिगत उपभोग मात्र मान्य हुन्छ ।"
                else
                    "Purchase purpose is unconfirmed. Only personal consumer purchases are eligible."
            )
        }

        if (isUnknownMethod) {
            verificationReasons.add(
                if (lang == AppLanguage.NEPALI)
                    "भुक्तानी माध्यम स्वीकृत डिजिटल च्यानल हो कि होइन पुष्टि हुन सकेन ।"
                else
                    "Payment mode cannot be verified as an approved electronic/digital channel."
            )
        }

        if (isDigitalMethod) {
            verificationReasons.add(
                if (lang == AppLanguage.NEPALI)
                    "बिक्रेताको बिलिङ सफ्टवेयरले IRD को केन्द्रीय CBMS मा विवरण पठाएको पुष्टि अफलाइन गर्न सकिँदैन ।"
                else
                    "Rasid Khata cannot verify offline whether the seller's billing software successfully transmitted the invoice to IRD's central CBMS."
            )
        }

        // B. NEEDS VERIFICATION
        if (input.sellerPan == SellerPanOption.DONT_KNOW ||
            input.category == TransactionCategory.DONT_KNOW ||
            input.purpose == PurchasePurpose.UNKNOWN ||
            isUnknownMethod
        ) {
            if (lang == AppLanguage.NEPALI) {
                nextSteps.add("आफ्नो बिलमा ९-अंकको प्यान/भ्याट नम्बर उल्लेख भए नभएको जाँच गर्नुहोस् ।")
                nextSteps.add("आफ्नो भुक्तानी एप (eSewa, Khalti, Mobile Banking) मा १२ अंकको कुपन नम्बर आए नआएको हेर्नुहोस् ।")
                nextSteps.add("पाक्षिक गोलाप्रथा सम्पन्न नभएसम्म बिल/रसिद सुरक्षित राख्नुहोस् ।")
            } else {
                nextSteps.add("Check your bill or invoice slip for the seller's 9-digit PAN/VAT number.")
                nextSteps.add("Check your payment app (eSewa, Khalti, Mobile Banking) to see if a 12-digit Prize Coupon Number was generated.")
                nextSteps.add("Keep your invoice/receipt until the fortnightly draw is completed.")
            }

            return TransactionEligibilityResult(
                status = EligibilityStatus.NEEDS_VERIFICATION,
                title = if (lang == AppLanguage.NEPALI) "रुजु आवश्यक (Needs Verification)" else "Needs Verification",
                statusLabel = if (lang == AppLanguage.NEPALI) "बिक्रेता तथा भुक्तानी च्यानलसँग थप पुष्टि आवश्यक" else "Needs verification with seller & payment channel",
                reasons = verificationReasons,
                caveats = listOf(
                    if (lang == AppLanguage.NEPALI) "रसिद खाता एक स्वतन्त्र सहयोगी एप हो । यो आधिकारिक IRD निर्णय होइन ।"
                    else "Rasid Khata is an independent helper app. This result is not an official IRD eligibility confirmation."
                ),
                digitalWarning = if (isDigitalMethod) {
                    if (lang == AppLanguage.NEPALI)
                        "डिजिटल भुक्तानीले स्वतः कुपनको ग्यारेन्टी गर्दैन । कारोबार सम्पन्न हुँदा भुक्तानी एप वा IRD प्रणालीबाट १२ अंकको कुपन जारी हुनुपर्छ ।"
                    else
                        "Digital payment does not automatically guarantee an IRD coupon. Your 12-digit Prize Coupon Number should come from the payment app (eSewa, Khalti, Fonepay) or the official IRD system when the transaction is successfully logged."
                } else null,
                nextSteps = nextSteps,
                evaluatedAt = evaluatedAt
            )
        }

        // C. LIKELY ELIGIBLE
        val eligibleReasons = if (lang == AppLanguage.NEPALI) {
            listOf(
                "रकम (NPR ${String.format(Locale.US, "%,.2f", input.amount)}) रु. १०० भन्दा माथि छ ।",
                "व्यक्तिगत घरायसी उपभोगका लागि खरिद गरिएको हो ।",
                "भुक्तानी विधि (${input.paymentMethod.getLocalizedName(lang)}) स्वीकृत डिजिटल माध्यम हो ।",
                "बिक्रेता प्यान दर्ता भएको र विद्युतीय कर बिजक जारी गर्ने हो ।"
            )
        } else {
            listOf(
                "Amount (NPR ${String.format(Locale.US, "%,.2f", input.amount)}) is above the NPR 100 threshold.",
                "Purchased for personal individual consumer use.",
                "Payment method (${input.paymentMethod.displayName}) is an approved electronic/digital channel.",
                "Seller is PAN-registered and issuing taxable electronic bills."
            )
        }

        if (lang == AppLanguage.NEPALI) {
            nextSteps.add("आफ्नो भुक्तानी एप (eSewa, Khalti, मोबाइल बैंकिङ) वा SMS मा १२ अंकको कुपन नम्बर हेर्नुहोस् ।")
            nextSteps.add("उक्त १२ अंकको कुपन रसिद खाताको कुपन प्रबन्धकमा सुरक्षित गरी गोलाप्रथा नतिजा जाँच गर्नुहोस् ।")
            nextSteps.add("पाक्षिक गोलाप्रथा सम्पन्न नभएसम्म आफ्नो सक्कल बिल सुरक्षित राख्नुहोस् ।")
        } else {
            nextSteps.add("Check your payment app (eSewa, Khalti, Mobile Banking) or SMS for your 12-digit Prize Coupon Number.")
            nextSteps.add("Save the 12-digit number in Rasid Khata's Coupon Manager to check against official winner announcements.")
            nextSteps.add("Keep your invoice/receipt safe until the fortnightly draw is concluded.")
        }

        return TransactionEligibilityResult(
            status = EligibilityStatus.LIKELY_ELIGIBLE,
            title = if (lang == AppLanguage.NEPALI) "योग्य हुने सम्भावना (Likely Eligible)" else "Likely Eligible",
            statusLabel = if (lang == AppLanguage.NEPALI) "IRD लटरी कुपनका लागि योग्य हुने सम्भावना उच्च छ" else "Likely eligible for IRD Prize Coupon Lottery",
            reasons = eligibleReasons,
            caveats = listOf(
                if (lang == AppLanguage.NEPALI) "यो नेपालको कर निर्देशिकामा आधारित प्रारम्भिक विश्लेषण हो । अन्तिम निर्णय IRD नेपालको हुनेछ ।"
                else "This is a preliminary check by Rasid Khata based on Nepal tax directives. Final eligibility is determined by IRD Nepal.",
                if (lang == AppLanguage.NEPALI) "रसिद खाता आन्तरिक राजस्व विभागसँग आबद्ध नभएको स्वतन्त्र एप हो ।"
                else "Rasid Khata is an independent helper app and is not affiliated with the Inland Revenue Department."
            ),
            digitalWarning = if (isDigitalMethod) {
                if (lang == AppLanguage.NEPALI)
                    "डिजिटल भुक्तानी भए तापनि १२ अंकको कुपन नम्बर भुक्तानी एप वा IRD प्रणालीबाट प्राप्त हुनुपर्छ । बिल सुरक्षित राख्नुहोस् !"
                else
                    "Digital payment does not mean Rasid Khata can confirm your IRD coupon. Your Prize Coupon Number should come from the relevant payment app or the official IRD system. Keep your receipt safe!"
            } else null,
            nextSteps = nextSteps,
            evaluatedAt = evaluatedAt
        )
    }
}
