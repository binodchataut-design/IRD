package com.example.data.models

import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings

enum class PaymentMethod(val displayName: String) {
    DIGITAL_WALLET("Digital Wallet"),
    QR_PAYMENT("QR / Digital Payment"),
    MOBILE_BANKING("Mobile Banking"),
    CARD("Card"),
    CASH("Cash"),
    BANK_TRANSFER("Bank Transfer"),
    OTHER("Other");

    fun getLocalizedName(lang: AppLanguage): String {
        return when (this) {
            DIGITAL_WALLET -> AppStrings.get("payment.wallet", lang)
            QR_PAYMENT -> AppStrings.get("payment.qr", lang)
            MOBILE_BANKING -> AppStrings.get("payment.mobile_banking", lang)
            CARD -> AppStrings.get("payment.card", lang)
            CASH -> AppStrings.get("payment.cash", lang)
            BANK_TRANSFER -> AppStrings.get("payment.bank_transfer", lang)
            OTHER -> AppStrings.get("payment.other", lang)
        }
    }

    companion object {
        fun fromString(value: String): PaymentMethod {
            return entries.firstOrNull { 
                it.name.equals(value, ignoreCase = true) || 
                it.displayName.equals(value, ignoreCase = true) 
            } ?: DIGITAL_WALLET
        }
    }
}

enum class EligibilityStatus(val label: String, val badgeColorHex: Long) {
    NOT_CHECKED("Not Checked", 0xFF64748B),
    LIKELY_ELIGIBLE("Likely Eligible", 0xFF059669),
    LIKELY_NOT_ELIGIBLE("Likely Not Eligible", 0xFFDC2626),
    NEEDS_VERIFICATION("Needs Verification", 0xFFD97706),
    AWAITING_COUPON("Awaiting Coupon", 0xFFD97706),
    COUPON_ADDED("Coupon Linked", 0xFF0D9488);

    fun getLocalizedLabel(lang: AppLanguage): String {
        return when (this) {
            NOT_CHECKED -> AppStrings.get("status.not_checked", lang)
            LIKELY_ELIGIBLE -> AppStrings.get("status.likely_eligible", lang)
            LIKELY_NOT_ELIGIBLE -> AppStrings.get("status.likely_not_eligible", lang)
            NEEDS_VERIFICATION -> AppStrings.get("status.needs_verification", lang)
            AWAITING_COUPON -> AppStrings.get("status.awaiting_coupon", lang)
            COUPON_ADDED -> AppStrings.get("status.coupon_added", lang)
        }
    }

    companion object {
        fun fromString(value: String?): EligibilityStatus {
            if (value == null) return NOT_CHECKED
            return entries.firstOrNull { 
                it.name.equals(value, ignoreCase = true) || 
                it.name.replace("_", "").equals(value.replace("_", ""), ignoreCase = true) 
            } ?: NOT_CHECKED
        }
    }
}

enum class PurchasePurpose(val displayName: String) {
    PERSONAL("Personal / Consumer Use"),
    BUSINESS("Business / Commercial Expense"),
    GOVERNMENT("Government / Institutional"),
    UNKNOWN("Unspecified / Unknown");

    fun getLocalizedName(lang: AppLanguage): String {
        return when (this) {
            PERSONAL -> if (lang == AppLanguage.NEPALI) "व्यक्तिगत तथा घरायसी उपभोग" else "Personal / Consumer Use"
            BUSINESS -> if (lang == AppLanguage.NEPALI) "व्यापारिक तथा संस्थागत खर्च" else "Business / Commercial Expense"
            GOVERNMENT -> if (lang == AppLanguage.NEPALI) "सरकारी तथा सार्वजनिक निकाय" else "Government / Institutional"
            UNKNOWN -> if (lang == AppLanguage.NEPALI) "नखुलेको / अन्य" else "Unspecified / Unknown"
        }
    }
}

enum class SellerPanOption(val displayName: String) {
    YES("Yes (9-Digit PAN/VAT Registered)"),
    NO("No (Unregistered / Plain Cash Bill)"),
    DONT_KNOW("Not Sure / To Be Verified");

    fun getLocalizedName(lang: AppLanguage): String {
        return when (this) {
            YES -> if (lang == AppLanguage.NEPALI) "छ (९-अंकको प्यान/भ्याट दर्ता भएको)" else "Yes (9-Digit PAN/VAT Registered)"
            NO -> if (lang == AppLanguage.NEPALI) "छैन (सादा बिल वा दर्ता नभएको)" else "No (Unregistered / Plain Cash Bill)"
            DONT_KNOW -> if (lang == AppLanguage.NEPALI) "थाहा छैन (पछि रुजु गरिने)" else "Not Sure / To Be Verified"
        }
    }
}

enum class TransactionCategory(val displayName: String, val isEligible: Boolean) {
    NORMAL_GOODS("Standard Goods & Retail", true),
    FOOD_RESTAURANT("Restaurant & Cafe Dining", true),
    ELECTRONICS("Electronics & Appliances", true),
    CLOTHING("Clothing & Lifestyle", true),
    ELECTRICITY("Electricity Utility (NEA)", false),
    TELEPHONE_INTERNET("Telephone & Internet Bill", false),
    AIRLINE("Airlines & Air Tickets", false),
    TRANSPORT_FREIGHT("Public Transport & Freight", false),
    VEHICLE("Automobile / Heavy Machinery", true),
    OTHER("Other Consumer Goods", true),
    DONT_KNOW("Unspecified Category", true);

    fun getLocalizedName(lang: AppLanguage): String {
        return when (this) {
            NORMAL_GOODS -> if (lang == AppLanguage.NEPALI) "सामान्य उपभोग्य सामान तथा खुद्रा" else "Standard Goods & Retail"
            FOOD_RESTAURANT -> if (lang == AppLanguage.NEPALI) "रेस्टुरेन्ट तथा खाना/खाजा" else "Restaurant & Cafe Dining"
            ELECTRONICS -> if (lang == AppLanguage.NEPALI) "विद्युतीय तथा इलेक्ट्रोनिक्स उपकरण" else "Electronics & Appliances"
            CLOTHING -> if (lang == AppLanguage.NEPALI) "लत्ताकपडा तथा जुत्ताचप्पल" else "Clothing & Lifestyle"
            ELECTRICITY -> if (lang == AppLanguage.NEPALI) "विद्युत महसुल (NEA)" else "Electricity Utility (NEA)"
            TELEPHONE_INTERNET -> if (lang == AppLanguage.NEPALI) "टेलिफोन तथा इन्टरनेट बिल" else "Telephone & Internet Bill"
            AIRLINE -> if (lang == AppLanguage.NEPALI) "हवाई टिकट (Airline Tickets)" else "Airlines & Air Tickets"
            TRANSPORT_FREIGHT -> if (lang == AppLanguage.NEPALI) "यातायात तथा ढुवानी" else "Public Transport & Freight"
            VEHICLE -> if (lang == AppLanguage.NEPALI) "सवारी साधन वा मेसिनरी" else "Automobile / Heavy Machinery"
            OTHER -> if (lang == AppLanguage.NEPALI) "अन्य उपभोक्ता वस्तुहरू" else "Other Consumer Goods"
            DONT_KNOW -> if (lang == AppLanguage.NEPALI) "खुल्न बाँकी वर्ग" else "Unspecified Category"
        }
    }
}

data class Transaction(
    val id: String,
    val date: String, // YYYY-MM-DD
    val sellerName: String,
    val amount: Double,
    val paymentMethod: PaymentMethod,
    val panVat: String? = null,
    val invoiceNumber: String? = null,
    val couponNumber: String? = null, // 12-digit prize coupon
    val eligibilityStatus: EligibilityStatus = EligibilityStatus.NOT_CHECKED,
    val eligibilityReasons: List<String> = emptyList(),
    val notes: String? = null,
    val photoReference: String? = null,
    val createdAt: String = ""
)

data class Coupon(
    val id: String,
    val couponNumber: String, // Normalized 12-digit string e.g. "007315254493"
    val date: String? = null, // YYYY-MM-DD
    val drawPeriod: String? = null, // e.g. "Shrawan 1–15, 2083"
    val merchantName: String? = null,
    val amount: Double? = null,
    val paymentMethod: String? = null,
    val invoiceNumber: String? = null,
    val notes: String? = null,
    val createdAt: String = ""
)

data class DrawAnnouncement(
    val id: String,
    val title: String,
    val drawPeriod: String,
    val announcementDate: String, // YYYY-MM-DD
    val winningNumbers: List<String>, // Normalized 12-digit strings
    val sourceUrl: String = "https://ird.gov.np/notices",
    val sourceName: String = "Inland Revenue Department (IRD Nepal)",
    val notes: String? = null,
    val createdAt: String = ""
)

data class CouponMatch(
    val userCoupon: Coupon,
    val matchedWinningNumber: String,
    val drawTitle: String,
    val drawPeriod: String,
    val announcementDate: String,
    val sourceUrl: String = "https://ird.gov.np",
    val sourceName: String = "Inland Revenue Department (IRD Nepal)"
)

data class WinnerCheckResult(
    val checkedCouponCount: Int,
    val winningNumberCount: Int,
    val matches: List<CouponMatch>,
    val checkedAt: String,
    val drawInfoTitle: String? = null,
    val drawPeriod: String? = null,
    val announcementDate: String? = null
)

data class BulkParseResult(
    val totalExtracted: Int,
    val validNew: List<String>,
    val duplicateInBatch: List<String>,
    val alreadySaved: List<String>,
    val invalidTokens: List<String>
)

enum class IRDSourceType(val displayName: String) {
    CURRENT_PROGRAMME("Current Programme Directive"),
    LEGAL_PROVISION("Statutory Tax Provision"),
    OFFICIAL_ANNOUNCEMENT("Public Advisory Circular"),
    APP_EXPLANATION("App User Guide")
}

data class IRDNotice(
    val id: String,
    val sourceType: IRDSourceType = IRDSourceType.APP_EXPLANATION,
    val programmeId: String = "nepal-ird-electronic-billing-consumer-incentive",
    val title: String,
    val publicationDate: String = "",
    val effectiveFrom: String? = null,
    val effectiveTo: String? = null,
    val sourceOrganization: String,
    val sourceUrl: String,
    val category: String,
    val summary: String,
    val details: String,
    val lastVerifiedAt: String = "2026-08-17",
    val isOfficialSource: Boolean = true
)

data class TransactionEligibilityInput(
    val amount: Double,
    val paymentMethod: PaymentMethod,
    val purpose: PurchasePurpose,
    val sellerPan: SellerPanOption,
    val sellerPanNumber: String? = null,
    val sellerName: String? = null,
    val category: TransactionCategory,
    val date: String? = null,
    val invoiceNumber: String? = null
)

data class TransactionEligibilityResult(
    val status: EligibilityStatus,
    val title: String,
    val statusLabel: String,
    val reasons: List<String>,
    val caveats: List<String>,
    val digitalWarning: String? = null,
    val nextSteps: List<String>,
    val evaluatedAt: String = ""
)

data class ClaimReportData(
    val matchedCoupon: Coupon,
    val matchedWinningNumber: String,
    val drawTitle: String,
    val drawPeriod: String,
    val announcementDate: String,
    val sourceUrl: String = "https://ird.gov.np/notices",
    val sourceName: String = "Inland Revenue Department (IRD Nepal)",
    val associatedTransaction: Transaction? = null
)

data class BackupStats(
    val transactionCount: Int,
    val couponCount: Int,
    val customDrawCount: Int,
    val exportedAt: String
)
