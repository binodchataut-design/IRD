package com.example.data.localization

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import com.example.data.models.EligibilityStatus
import com.example.data.models.PaymentMethod
import com.example.data.models.PurchasePurpose
import com.example.data.models.SellerPanOption
import com.example.data.models.TransactionCategory
import java.text.NumberFormat
import java.util.Locale

val LocalAppLanguage = staticCompositionLocalOf { AppLanguage.ENGLISH }

@Composable
fun appString(key: String, vararg args: Any): String {
    val lang = LocalAppLanguage.current
    return AppStrings.get(key, lang, *args)
}

object AppStrings {

    private val enMap = mapOf(
        // App identity
        "app.name" to "Rasid Khata",
        "app.tagline" to "Consumer Incentive Lottery & Bill Tracker",
        "app.scheme_tag" to "CONSUMER INCENTIVE SCHEME • IRD LOTTERY",
        "app.unofficial_disclaimer" to "Independent Consumer Helper App • Not directly affiliated with IRD Nepal",
        "app.disclaimer_full" to "Rasid Khata is an independent helper app. For official announcements, verification, and prize claims, please visit ird.gov.np.",

        // Navigation
        "nav.home" to "Home",
        "nav.invoices" to "Invoices",
        "nav.coupons" to "Coupons",
        "nav.winner" to "Winner",
        "nav.guide" to "Guide",

        // Common actions & labels
        "common.back" to "Back",
        "common.save" to "Save",
        "common.cancel" to "Cancel",
        "common.delete" to "Delete",
        "common.edit" to "Edit",
        "common.close" to "Close",
        "common.copy" to "Copy",
        "common.copied" to "Copied to clipboard!",
        "common.search" to "Search",
        "common.filter" to "Filter",
        "common.all" to "All",
        "common.details" to "Details",
        "common.clear" to "Clear",
        "common.confirm" to "Confirm",
        "common.optional" to "Optional",
        "common.required" to "Required",
        "common.npr" to "NPR",
        "common.approx" to "Approx.",
        "common.date" to "Date",
        "common.records" to "records",
        "common.language" to "Language",
        "common.english" to "English",
        "common.nepali" to "नेपाली (Nepali)",
        "common.select_language" to "Select App Language",

        // Home Screen
        "home.title" to "Rasid Khata",
        "home.subtitle" to "Electronic billing lottery tracker & coupon vault",
        "home.add_invoice_cta" to "+ Add Invoice / Purchase",
        "home.stat_saved_coupons" to "Saved Coupons",
        "home.stat_awaiting_coupons" to "Awaiting Coupon",
        "home.stat_next_draw" to "Next Draw Cycle",
        "home.action_awaiting_title" to "Coupons Pending (%d Invoices)",
        "home.action_awaiting_desc" to "Register the 12-digit prize coupon code received on your bills",
        "home.action_check_title" to "Check Lottery Winners",
        "home.action_check_desc" to "Your %d coupons are securely saved for the draw",
        "home.action_onboarding_title" to "Record Your First Purchase",
        "home.action_onboarding_desc" to "Add QR/digital payment invoices to save prize coupons",
        "home.ird_guide_link" to "IRD Guidelines & 5-Step Scheme Guide",
        "home.backup_link" to "Data Backup, CSV Export & Language Settings",
        "home.disclaimer_short" to "Independent consumer helper app • Not directly affiliated with Inland Revenue Department (IRD)",

        // Invoices / Transactions List Screen
        "invoices.title" to "Invoices & Purchases",
        "invoices.subtitle" to "Recorded bills and coupon statuses (%d records)",
        "invoices.search_placeholder" to "Search by merchant, PAN, invoice, or coupon...",
        "invoices.filter_all" to "All",
        "invoices.filter_coupon_linked" to "Coupon Linked",
        "invoices.filter_awaiting" to "Awaiting Coupon",
        "invoices.filter_digital" to "Digital / QR",
        "invoices.filter_cash" to "Cash",
        "invoices.filter_with_pan" to "With PAN",
        "invoices.total_filtered_amount" to "Total: %s",
        "invoices.empty_title" to "No Invoices Found",
        "invoices.empty_desc" to "No invoices match your current search or filter. Record new digital purchases to track coupons.",
        "invoices.add_button" to "+ Add Invoice",

        // Add Transaction Screen
        "add_tx.title" to "Add Purchase Invoice",
        "add_tx.subtitle" to "Record Bill & Link 12-Digit Prize Coupon",
        "add_tx.sec_purchase" to "1. Purchase Details",
        "add_tx.merchant_label" to "Merchant / Store Name *",
        "add_tx.merchant_placeholder" to "e.g. Sagarmatha Bakery, Bhatbhateni",
        "add_tx.amount_label" to "Total Invoice Amount (NPR) *",
        "add_tx.amount_placeholder" to "e.g. 1250.00",
        "add_tx.payment_method_label" to "Payment Method *",
        "add_tx.date_label" to "Transaction Date (YYYY-MM-DD) *",
        "add_tx.draw_period_detected" to "Draw Period: %s",
        "add_tx.sec_tax" to "2. Bill & Tax Details (Optional)",
        "add_tx.pan_label" to "Seller PAN / VAT Number",
        "add_tx.pan_placeholder" to "e.g. 601234567 (9 digits)",
        "add_tx.invoice_num_label" to "Invoice / Bill Number",
        "add_tx.invoice_num_placeholder" to "e.g. INV-2083-0941",
        "add_tx.sec_coupon" to "3. 12-Digit Prize Coupon (Optional)",
        "add_tx.coupon_label" to "Prize Coupon Code",
        "add_tx.coupon_placeholder" to "e.g. 007315254493 (12 digits)",
        "add_tx.coupon_helper" to "Enter the 12-digit code provided on your digital receipt or SMS. You can also link this later.",
        "add_tx.notes_label" to "Personal Notes / Items",
        "add_tx.notes_placeholder" to "e.g. Groceries and dairy items",
        "add_tx.live_preview_title" to "Live Scheme Eligibility Preview",
        "add_tx.save_button" to "Save Invoice & Coupon",
        "add_tx.validation_error" to "Please provide merchant name and valid bill amount.",

        // Transaction Detail Screen
        "tx_detail.title" to "Invoice Details",
        "tx_detail.subtitle" to "Purchase record and linked coupon verification",
        "tx_detail.merchant" to "Merchant / Seller",
        "tx_detail.amount" to "Invoice Amount",
        "tx_detail.date" to "Transaction Date",
        "tx_detail.payment_method" to "Payment Method",
        "tx_detail.pan_vat" to "Seller PAN/VAT",
        "tx_detail.invoice_no" to "Invoice Number",
        "tx_detail.created_at" to "Recorded On",
        "tx_detail.coupon_section" to "Linked IRD Prize Coupon",
        "tx_detail.no_coupon" to "No 12-digit coupon linked yet. Link the coupon received on your digital bill to participate in the lottery.",
        "tx_detail.link_coupon_btn" to "Link 12-Digit Coupon",
        "tx_detail.dialog_link_title" to "Link 12-Digit Prize Coupon",
        "tx_detail.dialog_link_desc" to "Enter the exact 12-digit prize coupon code from your receipt:",
        "tx_detail.dialog_save_btn" to "Link Coupon",
        "tx_detail.eligibility_analysis" to "Scheme Eligibility Analysis",
        "tx_detail.reasons_heading" to "Evaluation Factors:",
        "tx_detail.notes_section" to "Personal Notes",
        "tx_detail.delete_invoice_btn" to "Delete Invoice",
        "tx_detail.delete_confirm_title" to "Delete this invoice?",
        "tx_detail.delete_confirm_desc" to "This will permanently remove this invoice record from your local storage.",

        // Coupons Screen
        "coupons.title" to "My Prize Coupons",
        "coupons.subtitle" to "12-digit lottery entries for IRD draws (%d coupons)",
        "coupons.search_placeholder" to "Search coupons by number, merchant, or cycle...",
        "coupons.add_single" to "+ Add Coupon",
        "coupons.add_bulk" to "Bulk Import",
        "coupons.empty_title" to "No Coupons Registered",
        "coupons.empty_desc" to "Save your 12-digit prize coupon codes from digital payment receipts to check against fortnightly lottery draws.",
        "coupons.check_winners_cta" to "Check Against Lottery Draws",
        "coupons.card_cycle" to "Draw Cycle",
        "coupons.card_merchant" to "Merchant",
        "coupons.card_invoice" to "Invoice",
        "coupons.delete_confirm" to "Remove coupon %s?",

        // Add Coupon Screen
        "add_coupon.title" to "Add Prize Coupon",
        "add_coupon.subtitle" to "Register 12-digit IRD lottery coupon code",
        "add_coupon.number_label" to "12-Digit Coupon Number *",
        "add_coupon.number_placeholder" to "e.g. 007315254493",
        "add_coupon.number_helper" to "Must be exactly 12 digits. Leading zeros are preserved.",
        "add_coupon.sec_details" to "Transaction & Cycle Info (Optional)",
        "add_coupon.date_label" to "Purchase Date (YYYY-MM-DD)",
        "add_coupon.cycle_label" to "Assigned Draw Cycle",
        "add_coupon.merchant_label" to "Merchant / Shop Name",
        "add_coupon.merchant_placeholder" to "e.g. QFX Cinemas",
        "add_coupon.amount_label" to "Amount Paid (NPR)",
        "add_coupon.invoice_label" to "Invoice Number",
        "add_coupon.notes_label" to "Notes",
        "add_coupon.save_btn" to "Save Prize Coupon",

        // Bulk Add Coupons Screen
        "bulk_coupons.title" to "Bulk Coupon Import",
        "bulk_coupons.subtitle" to "Paste multiple 12-digit numbers from SMS or bills",
        "bulk_coupons.input_label" to "Paste Coupon Numbers or Raw Text",
        "bulk_coupons.input_placeholder" to "Paste text containing coupon codes e.g.:\n007315254493\n007755590670\n002928817811",
        "bulk_coupons.paste_helper" to "The intelligent parser extracts all valid 12-digit coupon codes automatically, ignoring extra text, commas, and punctuation.",
        "bulk_coupons.sample_btn" to "Load Sample Codes",
        "bulk_coupons.clear_btn" to "Clear Input",
        "bulk_coupons.summary_heading" to "Extraction Summary",
        "bulk_coupons.total_found" to "Total Codes Found: %d",
        "bulk_coupons.valid_new" to "Ready to Import (New): %d",
        "bulk_coupons.already_saved" to "Already in Saved Coupons: %d",
        "bulk_coupons.duplicates_in_text" to "Duplicates in Input: %d",
        "bulk_coupons.import_btn" to "Import %d Valid Coupons",

        // Winner Checker Screen
        "winner.title" to "Lottery Winner Checker",
        "winner.subtitle" to "Match saved coupons against official IRD announcements",
        "winner.tab_official" to "Official IRD Draws",
        "winner.tab_custom" to "Custom Winning Numbers",
        "winner.select_draw_label" to "Select Draw Announcement:",
        "winner.check_now_btn" to "Check %d Saved Coupons",
        "winner.custom_input_label" to "Paste Winning Numbers",
        "winner.custom_input_placeholder" to "Enter official 12-digit winning numbers separated by spaces, commas, or new lines...",
        "winner.custom_input_helper" to "Detected %d valid winning numbers to test against your vault.",
        "winner.check_custom_btn" to "Check Against Custom Numbers (%d)",
        "winner.no_coupons_warning" to "You have no saved coupons yet. Add coupons from your invoices first to check for prizes.",
        "winner.match_found_title" to "🎉 CONGRATULATIONS! MATCH FOUND!",
        "winner.match_found_desc" to "You have %d winning coupon match(es) for this draw! Prepare your claim dossier immediately.",
        "winner.no_match_title" to "No Winning Matches Found",
        "winner.no_match_desc" to "Checked %d saved coupons against %d winning numbers. None of your coupons matched in this cycle.",
        "winner.dossier_btn" to "Prepare Official Claim Dossier",
        "winner.matched_card_title" to "Winning Coupon #%s",
        "winner.draw_cycle_tag" to "Draw: %s • Announced: %s",

        // Draw History Screen
        "draw_hist.title" to "IRD Draw Announcements",
        "draw_hist.subtitle" to "Official fortnightly consumer lottery results archive",
        "draw_hist.add_custom_btn" to "+ Add Draw Notice",
        "draw_hist.card_period" to "Draw Fortnight",
        "draw_hist.card_date" to "Announcement Date",
        "draw_hist.card_winning_count" to "%d Winning Numbers Announced",
        "draw_hist.view_winning_numbers" to "View All Winning Numbers",
        "draw_hist.check_coupons_btn" to "Check My Coupons Against This Draw",
        "draw_hist.source_label" to "Source: %s",
        "draw_hist.dialog_title" to "Add Official Draw Notice",
        "draw_hist.dialog_title_field" to "Draw Title *",
        "draw_hist.dialog_period_field" to "Draw Period (e.g. Bhadra 1–15, 2083) *",
        "draw_hist.dialog_date_field" to "Announcement Date (YYYY-MM-DD) *",
        "draw_hist.dialog_numbers_field" to "12-Digit Winning Numbers (separated by space/newline) *",
        "draw_hist.dialog_save_btn" to "Save Announcement",

        // Check Eligibility Screen
        "eligibility.title" to "Eligibility Calculator",
        "eligibility.subtitle" to "Verify bill qualification under official IRD rules",
        "eligibility.step1_amount" to "1. Total Bill Amount",
        "eligibility.amount_field" to "Purchase Amount (NPR)",
        "eligibility.amount_warning_low" to "Amount is NPR 100 or below. The IRD scheme requires bills above NPR 100.",
        "eligibility.step2_payment" to "2. Payment Method",
        "eligibility.payment_cash_warning" to "Cash bills do not qualify for IRD electronic prize coupons.",
        "eligibility.step3_purpose" to "3. Purchase Purpose",
        "eligibility.purpose_biz_warning" to "Business/commercial expenses are excluded from the consumer incentive scheme.",
        "eligibility.step4_pan" to "4. Merchant Tax Registration (PAN/VAT)",
        "eligibility.step5_category" to "5. Goods & Service Category",
        "eligibility.result_heading" to "Evaluation Result",
        "eligibility.digital_warning_title" to "Important Note on Digital Payments:",
        "eligibility.reasons_title" to "Rule Breakdown:",
        "eligibility.next_steps_title" to "Recommended Next Steps:",
        "eligibility.disclaimer_title" to "Compliance Caveats:",

        // IRD Info & Guidelines Screen
        "ird_info.title" to "IRD Guidelines & Notices",
        "ird_info.subtitle" to "Official consumer incentive directives and FAQ",
        "ird_info.guide_heading" to "How the IRD Lottery Scheme Works",
        "ird_info.step1_title" to "1. Make a Digital Purchase",
        "ird_info.step1_desc" to "Purchase personal goods or services above NPR 100 and pay via QR code, digital wallet (eSewa, Khalti), mobile banking, or card at any PAN-registered store.",
        "ird_info.step2_title" to "2. Receive Electronic Tax Invoice",
        "ird_info.step2_desc" to "The seller issues an authorized electronic bill transmitted in real-time to IRD's Central Billing Monitoring System (CBMS).",
        "ird_info.step3_title" to "3. Obtain 12-Digit Prize Coupon",
        "ird_info.step3_desc" to "A unique 12-digit prize coupon number is automatically generated and displayed on your receipt or sent via SMS/payment app.",
        "ird_info.step4_title" to "4. Fortnightly Lottery Draw",
        "ird_info.step4_desc" to "IRD conducts public computerized lottery draws twice a month (every fortnight) and publishes winning numbers on ird.gov.np.",
        "ird_info.step5_title" to "5. Claim Cash Prizes",
        "ird_info.step5_desc" to "Winners submit their original bill, digital payment proof, citizenship copy, and PAN to the nearest Inland Revenue Office (IRO) within 15 days.",
        "ird_info.notices_heading" to "Official Circulars & Tax Directives",
        "ird_info.portal_link" to "Visit Official IRD Portal (ird.gov.np)",

        // IRD Info Screen Additional Keys
        "info.title" to "IRD Guidelines & 5-Step Guide",
        "info.subtitle" to "Consumer incentive scheme, eligibility & lottery rules",
        "info.how_it_works_header" to "How the IRD Lottery Scheme Works",
        "info.step_1" to "1. Buy Goods / Service",
        "info.step_1_sub" to "Buy from PAN/VAT registered seller",
        "info.step_2" to "2. Pay Electronically",
        "info.step_2_sub" to "Pay digitally (QR, Wallet, Card, e-Banking)",
        "info.step_3" to "3. Get 12-Digit Prize Coupon",
        "info.step_3_sub" to "Get 12-digit Coupon on invoice or SMS",
        "info.step_4" to "4. Fortnightly Lottery Draw",
        "info.step_4_sub" to "IRD fortnightly computerized lottery draw",
        "info.step_5" to "5. Check Results & Claim Prizes",
        "info.step_5_sub" to "Instant 1-tap winner verification & claim in 15 days",
        "info.scheme_title" to "Government Consumer Incentive Programme",
        "info.scheme_desc" to "Under the Value Added Tax & Electronic Billing Directives, consumers paying digitally at registered sellers are automatically entered into fortnightly computerized lottery draws with cash prizes up to NPR 50,000.",
        "info.conditions_header" to "Eligibility Requirements",
        "info.cond_1" to "Purchase amount must be above NPR 100",
        "info.cond_2" to "Must be for personal/household consumer use (not business)",
        "info.cond_3" to "Payment must be via approved digital channels (QR, Wallet, Mobile Banking, Card)",
        "info.cond_4" to "Seller must be PAN/VAT registered and issue electronic invoices",
        "info.cond_5" to "Personal PAN is mandatory to claim prize payouts",
        "info.prize_structure_header" to "Lottery Prize Structure (Per Fortnight)",
        "info.prize_1st_label" to "1st Prize (1 Winner)",
        "info.prize_2nd_label" to "2nd Prize (1 Winner)",
        "info.prize_3rd_label" to "3rd Prize (1 Winner)",
        "info.prize_cons_label" to "Consolation Prizes (10 Winners)",
        "info.open_calculator_btn" to "Check My Bill Eligibility (Calculator)",

        // IRD Info - Foreign Visitors & Residents Section
        "info.foreign.header" to "For Foreign Visitors & Residents",
        "info.foreign.badge" to "Eligibility & PAN Guide",
        "info.foreign.intro" to "Essential guidance on lottery entry, mandatory personal PAN rules, and prize disbursement for tourists, expatriates, and foreign passport holders in Nepal.",
        "info.foreign.pan_title" to "1. Personal PAN Requirement for Prize Claims",
        "info.foreign.pan_desc" to "Any digital payment above NPR 100 at a registered merchant generates a lottery coupon entry. However, to claim and receive prize money, IRD regulations strictly mandate a personal Permanent Account Number (PAN) in the claimant's own name. Without a valid Nepali PAN, prize disbursement cannot be processed.",
        "info.foreign.docs_title" to "2. Accepted Identity Documents & 15-Day Deadline",
        "info.foreign.docs_desc" to "Prize claims must be submitted to the nearest Inland Revenue Office (IRO) or Taxpayer Service Office (TSO) within 15 calendar days of the draw publication. Foreign nationals holding a Nepali PAN may present a valid Passport along with their PAN card, original purchase invoice, payment transaction reference, and Nepali bank account details.",
        "info.foreign.invoice_title" to "3. Original Physical Invoice is Mandatory",
        "info.foreign.invoice_desc" to "Even when coupon numbers are automatically issued via digital wallets or QR payment apps, the original physical tax invoice issued by the seller must be presented during claim verification. Losing or discarding the original invoice forfeits the prize claim.",
        "info.foreign.tax_title" to "4. 25% Windfall Tax Withholding",
        "info.foreign.tax_desc" to "All lottery prize winnings under Nepal tax law are subject to a 25% windfall tax (आकस्मिक लाभ कर). This tax is deducted at source by the government prior to prize payout, meaning the winner receives the net amount and no additional tax return filing is required for this prize.",
        "info.foreign.inquiry_title" to "5. Official Inquiries & Clarifications",
        "info.foreign.inquiry_desc" to "Rules regarding whether a tourist or short-term visa holder can obtain a personal PAN depend on residency and immigration status. For individual eligibility questions that this app cannot confirm, please visit or contact your nearest Inland Revenue Office (IRO) or visit ird.gov.np.",

        // Welcome / Onboarding Screen
        "welcome.tag" to "QUICK GUIDE & ONBOARDING",
        "welcome.skip" to "Skip",
        "welcome.next" to "Next",
        "welcome.back" to "Back",
        "welcome.get_started" to "Get Started",
        "welcome.step_indicator" to "Step %d of %d",
        "welcome.card1.title" to "What is Rasid Khata?",
        "welcome.card1.subtitle" to "Consumer bill tracker & lottery helper",
        "welcome.card1.body" to "Rasid Khata helps you record purchases, organize 12-digit prize coupon codes, and check whether your bills won cash prizes in Nepal government's shopping lottery.",
        "welcome.card1.point1" to "Track QR and digital payment invoices",
        "welcome.card1.point2" to "Check fortnightly IRD lottery results in 1 tap",
        "welcome.card2.title" to "Can I Actually Participate?",
        "welcome.card2.subtitle" to "Entry vs. Prize Claim Rules",
        "welcome.card2.body" to "Entering the draw just requires a bill or digital payment over NPR 100 at a PAN-registered seller. But WINNING requires a personal PAN in your own name to claim the prize — this is mandatory, not optional.",
        "welcome.card2.point1" to "A personal PAN in your own name is mandatory to claim any prize.",
        "welcome.card2.point2" to "Whether a foreign national or tourist can obtain a personal PAN depends on residency and visa status. This app cannot confirm that for you — check with your nearest Inland Revenue Office (IRO) if unsure.",
        "welcome.card2.point3" to "Nepali citizens and residents: this is straightforward if you already have a PAN.",
        "welcome.card3.title" to "Helping Someone Else?",
        "welcome.card3.subtitle" to "Track coupons on behalf of others",
        "welcome.card3.body" to "You can also use this app to help a Nepali family member, friend, or staff member track their coupons and check draw results, even if you personally cannot claim a prize.",
        "welcome.card3.point1" to "Keep everyone's digital receipts and prize coupons organized",
        "welcome.card3.point2" to "Generate official claim dossiers when a coupon wins",

        // Data & Backup Screen
        "backup.title" to "Data & Backup",
        "backup.subtitle" to "Language, local storage, backup & restore",
        "backup.lang_card_title" to "App Language / भाषा छनोट",
        "backup.lang_card_desc" to "Switch between English and Nepali. Preferences are saved locally on this device.",
        "backup.storage_card_title" to "Offline Local Storage Status",
        "backup.storage_card_desc" to "All your invoices, coupons, and draw history are stored 100% locally on your phone. No data is sent to external servers.",
        "backup.invoices_pill" to "Invoices",
        "backup.coupons_pill" to "Coupons",
        "backup.export_heading" to "Backup & Export Options",
        "backup.export_json_title" to "Full Backup (JSON)",
        "backup.export_json_desc" to "Copy a complete JSON backup of all transactions, coupons, and draws.",
        "backup.copy_json_btn" to "Copy JSON to Clipboard",
        "backup.export_csv_invoices" to "Export Invoices as CSV",
        "backup.export_csv_coupons" to "Export Coupons as CSV",
        "backup.restore_heading" to "Restore Data from JSON",
        "backup.restore_input_label" to "Paste Backup JSON String",
        "backup.restore_merge_btn" to "Merge with Existing Data",
        "backup.restore_replace_btn" to "Replace All Data",
        "backup.danger_heading" to "Danger Zone & Testing",
        "backup.load_demo_btn" to "Load Sample Demo Data",
        "backup.clear_all_btn" to "Clear All Local Data",
        "backup.clear_dialog_title" to "Clear all local data?",
        "backup.clear_dialog_desc" to "This will erase all recorded invoices, prize coupons, and custom draws from your phone storage. This action cannot be undone.",

        // Claim Report Screen
        "claim.title" to "Prize Claim Dossier",
        "claim.subtitle" to "Official IRD prize claiming checklist and paperwork",
        "claim.copy_dossier_btn" to "Copy Full Claim Dossier",
        "claim.dossier_copied" to "Claim dossier copied to clipboard!",
        "claim.winner_card_title" to "Winning Prize Coupon",
        "claim.draw_details_title" to "Draw & Transaction Details",
        "claim.docs_heading" to "Mandatory Documents Checklist for IRO",
        "claim.doc1" to "Original Tax Invoice / Electronic Receipt Slip",
        "claim.doc2" to "Digital Payment Confirmation Slip / Transaction Reference",
        "claim.doc3" to "Copy of Nepali Citizenship Certificate",
        "claim.doc4" to "Copy of Personal Permanent Account Number (PAN) Card",
        "claim.doc5" to "Cancelled Cheque or Bank Account Statement Copy",
        "claim.deadline_heading" to "Statutory 15-Day Claim Deadline",
        "claim.deadline_desc" to "As per IRD consumer incentive regulations, prize claims must be presented at the nearest Inland Revenue Office (IRO) or Taxpayer Service Office (TSO) within 15 calendar days from the official draw announcement date.",

        // Status badges
        "status.coupon_added" to "Coupon Linked",
        "status.awaiting_coupon" to "Awaiting Coupon",
        "status.likely_eligible" to "Likely Eligible",
        "status.needs_verification" to "Needs Verification",
        "status.likely_not_eligible" to "Not Eligible",
        "status.not_checked" to "Not Checked",

        // Enums & Option Labels
        "payment.digital_wallet" to "Digital Wallet (eSewa / Khalti)",
        "payment.qr_payment" to "QR / Digital Payment (Fonepay)",
        "payment.mobile_banking" to "Mobile Banking App",
        "payment.card" to "Debit / Credit Card",
        "payment.cash" to "Cash (Ineligible for Prize Scheme)",
        "payment.bank_transfer" to "Direct Bank Transfer (IPS/ConnectIPS)",
        "payment.other" to "Other Payment Channel",

        "purpose.personal" to "Personal / Consumer Use (Eligible)",
        "purpose.business" to "Business / Commercial Expense (Ineligible)",
        "purpose.government" to "Government / Institutional (Ineligible)",
        "purpose.unknown" to "Unspecified / Unknown",

        "pan.yes" to "Yes (9-Digit Registered PAN/VAT)",
        "pan.no" to "No (Unregistered / Plain Cash Bill)",
        "pan.dont_know" to "Not Sure / To Be Verified",

        "category.normal_goods" to "Standard Retail Goods & Shopping",
        "category.food_restaurant" to "Restaurant & Cafe Dining",
        "category.electronics" to "Electronics & Home Appliances",
        "category.clothing" to "Clothing & Lifestyle Items",
        "category.electricity" to "Electricity Utility Bill (NEA - Ineligible)",
        "category.telephone_internet" to "Telephone & Internet Bill (Ineligible)",
        "category.airline" to "Air Tickets & Aviation (Ineligible)",
        "category.transport_freight" to "Public Transport & Freight (Ineligible)",
        "category.vehicle" to "Automobile & Heavy Machinery",
        "category.other" to "Other Consumer Goods",
        "category.dont_know" to "Unspecified Category"
    )

    private val neMap = mapOf(
        // App identity
        "app.name" to "रसिद खाता",
        "app.tagline" to "उपभोक्ता प्रोत्साहन लटरी तथा रसिद ट्र्याकर",
        "app.scheme_tag" to "उपभोक्ता प्रोत्साहन योजना • IRD LOTTERY",
        "app.unofficial_disclaimer" to "स्वतन्त्र उपभोक्ता सहयोग एप • आन्तरिक राजस्व विभाग (IRD) सँग प्रत्यक्ष सम्बद्ध छैन",
        "app.disclaimer_full" to "रसिद खाता (Rasid Khata) एक स्वतन्त्र निजी सहयोग एप हो । आधिकारिक सूचना, नतिजा पुष्टि तथा पुरस्कार दाबीका लागि कृपया ird.gov.np हेर्नुहोला ।",

        // Navigation
        "nav.home" to "गृह",
        "nav.invoices" to "कारोबार",
        "nav.coupons" to "कुपन",
        "nav.winner" to "नतिजा",
        "nav.guide" to "जानकारी",

        // Common actions & labels
        "common.back" to "पछाडि",
        "common.save" to "सुरक्षित गर्नुहोस्",
        "common.cancel" to "रद्द गर्नुहोस्",
        "common.delete" to "मेटाउनुहोस्",
        "common.edit" to "सम्पादन",
        "common.close" to "बन्द गर्नुहोस्",
        "common.copy" to "प्रतिलिपि (कपी)",
        "common.copied" to "क्लिपबोर्डमा कपी भयो!",
        "common.search" to "खोज्नुहोस्",
        "common.filter" to "फिल्टर",
        "common.all" to "सबै",
        "common.details" to "विवरण",
        "common.clear" to "खाली गर्नुहोस्",
        "common.confirm" to "पुष्टि गर्नुहोस्",
        "common.optional" to "ऐच्छिक",
        "common.required" to "अनिवार्य",
        "common.npr" to "रु",
        "common.approx" to "करिब",
        "common.date" to "मिति",
        "common.records" to "संख्या",
        "common.language" to "भाषा (Language)",
        "common.english" to "English (अंग्रेजी)",
        "common.nepali" to "नेपाली",
        "common.select_language" to "एपको भाषा छनोट गर्नुहोस्",

        // Home Screen
        "home.title" to "रसिद खाता",
        "home.subtitle" to "विद्युतीय बिलिङ लटरी ट्र्याकर तथा कुपन खाता",
        "home.add_invoice_cta" to "+ नयाँ कारोबार / रसिद थप्नुहोस्",
        "home.stat_saved_coupons" to "कुपन सुरक्षित",
        "home.stat_awaiting_coupons" to "कुपन बाँकी",
        "home.stat_next_draw" to "अर्को नतिजा",
        "home.action_awaiting_title" to "कुपन जोड्नु बाँकी (%d रसिद)",
        "home.action_awaiting_desc" to "रसिदमा प्राप्त १२-अंकको कुपन कोड दर्ता गर्नुहोस्",
        "home.action_check_title" to "लटरी नतिजा जाँच्नुहोस्",
        "home.action_check_desc" to "तपाईंका %d कुपनहरू गोलाप्रथामा सुरक्षित छन्",
        "home.action_onboarding_title" to "पहिलो कारोबार दर्ता गर्नुहोस्",
        "home.action_onboarding_desc" to "QR/डिजिटल भुक्तानी रसिद थपेर कुपन सुरक्षित राख्नुहोस्",
        "home.ird_guide_link" to "IRD कानूनी निर्देशिका तथा ५-चरण जानकारी",
        "home.backup_link" to "डेटा ब्याकअप, CSV निर्यात तथा भाषा सेटिङ",
        "home.disclaimer_short" to "अनौपचारिक उपभोक्ता सहयोग एप • आन्तरिक राजस्व विभाग (IRD) सँग प्रत्यक्ष सम्बद्ध छैन",

        // Invoices / Transactions List Screen
        "invoices.title" to "रसिद तथा कारोबारहरू",
        "invoices.subtitle" to "दर्ता भएका बिलहरू तथा कुपन स्थिति (%d वटा)",
        "invoices.search_placeholder" to "पसल, PAN, बिल वा कुपन नम्बर खोज्नुहोस्...",
        "invoices.filter_all" to "सबै",
        "invoices.filter_coupon_linked" to "कुपन जोडिएको",
        "invoices.filter_awaiting" to "कुपन पर्खिएको",
        "invoices.filter_digital" to "QR / डिजिटल",
        "invoices.filter_cash" to "नगद",
        "invoices.filter_with_pan" to "PAN सहित",
        "invoices.total_filtered_amount" to "जम्मा: %s",
        "invoices.empty_title" to "कुनै कारोबार फेला परेन",
        "invoices.empty_desc" to "तपाईंको खोजी वा फिल्टर अनुसार कुनै रसिद भेटिएन । कुपन सुरक्षित राख्न नयाँ कारोबार थप्नुहोस् ।",
        "invoices.add_button" to "+ नयाँ रसिद",

        // Add Transaction Screen
        "add_tx.title" to "नयाँ कारोबार थप्नुहोस्",
        "add_tx.subtitle" to "खरिद रसिद दर्ता तथा १२-अंकको लटरी कुपन लिंक",
        "add_tx.sec_purchase" to "१. खरिद विवरण",
        "add_tx.merchant_label" to "पसल वा बिक्रेताको नाम *",
        "add_tx.merchant_placeholder" to "जस्तै: सगरमाथा बेकरी, भाटभटेनी",
        "add_tx.amount_label" to "जम्मा बिल रकम (रु) *",
        "add_tx.amount_placeholder" to "जस्तै: 1250.00",
        "add_tx.payment_method_label" to "भुक्तानी माध्यम *",
        "add_tx.date_label" to "कारोबार मिति (YYYY-MM-DD) *",
        "add_tx.draw_period_detected" to "लटरी अवधि: %s",
        "add_tx.sec_tax" to "२. बिल तथा कर विवरण (ऐच्छिक)",
        "add_tx.pan_label" to "बिक्रेताको PAN / VAT नम्बर",
        "add_tx.pan_placeholder" to "जस्तै: 601234567 (९ अंक)",
        "add_tx.invoice_num_label" to "बिल वा बिजक नम्बर",
        "add_tx.invoice_num_placeholder" to "जस्तै: INV-2083-0941",
        "add_tx.sec_coupon" to "३. १२-अंकको लटरी कुपन कोड (ऐच्छिक)",
        "add_tx.coupon_label" to "पुरस्कार कुपन कोड",
        "add_tx.coupon_placeholder" to "जस्तै: 007315254493 (१२ अंक)",
        "add_tx.coupon_helper" to "डिजिटल बिल वा SMS मा प्राप्त १२-अंकको कोड लेख्नुहोस् । यो पछि पनि थप्न सकिन्छ ।",
        "add_tx.notes_label" to "थप विवरण वा वस्तुको नाम",
        "add_tx.notes_placeholder" to "जस्तै: खाद्यान्न तथा लत्ताकपडा",
        "add_tx.live_preview_title" to "योजना योग्यता पूर्वावलोकन",
        "add_tx.save_button" to "कारोबार सुरक्षित गर्नुहोस्",
        "add_tx.validation_error" to "कृपया पसलको नाम र मान्य बिल रकम प्रविष्ट गर्नुहोस् ।",

        // Transaction Detail Screen
        "tx_detail.title" to "कारोबार पूर्ण विवरण",
        "tx_detail.subtitle" to "खरिद रसिद तथा जोडिएको कुपन स्थिति",
        "tx_detail.merchant" to "पसल वा बिक्रेता",
        "tx_detail.amount" to "बिल रकम",
        "tx_detail.date" to "कारोबार मिति",
        "tx_detail.payment_method" to "भुक्तानी माध्यम",
        "tx_detail.pan_vat" to "बिक्रेताको PAN/VAT",
        "tx_detail.invoice_no" to "बिल नम्बर",
        "tx_detail.created_at" to "दर्ता मिति",
        "tx_detail.coupon_section" to "जोडिएको IRD लटरी कुपन",
        "tx_detail.no_coupon" to "यसमा अझै कुपन जोडिएको छैन । लटरीमा सहभागी हुन डिजिटल बिलमा प्राप्त १२-अंकको कुपन कोड लिंक गर्नुहोस् ।",
        "tx_detail.link_coupon_btn" to "१२-अंकको कुपन जोड्नुहोस्",
        "tx_detail.dialog_link_title" to "१२-अंकको पुरस्कार कुपन जोड्नुहोस्",
        "tx_detail.dialog_link_desc" to "आफ्नो बिल वा SMS मा प्राप्त ठ्याक्कै १२-अंकको कुपन नम्बर प्रविष्ट गर्नुहोस्:",
        "tx_detail.dialog_save_btn" to "कुपन लिंक गर्नुहोस्",
        "tx_detail.eligibility_analysis" to "योजना योग्यता विश्लेषण",
        "tx_detail.reasons_heading" to "मूल्याङ्कनका आधारहरू:",
        "tx_detail.notes_section" to "व्यक्तिगत टिप्पणी",
        "tx_detail.delete_invoice_btn" to "यो रसिद मेटाउनुहोस्",
        "tx_detail.delete_confirm_title" to "यो कारोबार मेटाउने हो?",
        "tx_detail.delete_confirm_desc" to "यसले तपाईंको फोनबाट यो रसिदको अभिलेख स्थायी रूपमा हटाउनेछ ।",

        // Coupons Screen
        "coupons.title" to "मेरा लटरी कुपनहरू",
        "coupons.subtitle" to "IRD गोलाप्रथाका लागि १२-अंकका कुपनहरू (%d वटा)",
        "coupons.search_placeholder" to "कुपन नम्बर, पसल वा अवधि खोज्नुहोस्...",
        "coupons.add_single" to "+ कुपन थप्नुहोस्",
        "coupons.add_bulk" to "एकमुष्ट (Bulk) आयात",
        "coupons.empty_title" to "कुनै कुपन दर्ता छैन",
        "coupons.empty_desc" to "डिजिटल भुक्तानी रसिदमा प्राप्त १२-अंकका कुपन कोडहरू यहाँ सुरक्षित राखी पाक्षिक लटरी नतिजा जाँच्नुहोस् ।",
        "coupons.check_winners_cta" to "लटरी नतिजा जाँच्नुहोस्",
        "coupons.card_cycle" to "लटरी अवधि",
        "coupons.card_merchant" to "पसल",
        "coupons.card_invoice" to "रसिद नं.",
        "coupons.delete_confirm" to "कुपन %s मेटाउने हो?",

        // Add Coupon Screen
        "add_coupon.title" to "लटरी कुपन थप्नुहोस्",
        "add_coupon.subtitle" to "१२-अंकको IRD प्रोत्साहन कुपन दर्ता",
        "add_coupon.number_label" to "१२-अंकको कुपन नम्बर *",
        "add_coupon.number_placeholder" to "जस्तै: 007315254493",
        "add_coupon.number_helper" to "ठ्याक्कै १२ अंकको हुनुपर्छ । अगाडिका शून्य (०) सुरक्षित रहन्छन् ।",
        "add_coupon.sec_details" to "कारोबार तथा चक्र विवरण (ऐच्छिक)",
        "add_coupon.date_label" to "खरिद मिति (YYYY-MM-DD)",
        "add_coupon.cycle_label" to "तोकिएको लटरी अवधि",
        "add_coupon.merchant_label" to "पसलको नाम",
        "add_coupon.merchant_placeholder" to "जस्तै: QFX सिनेमा",
        "add_coupon.amount_label" to "भुक्तान रकम (रु)",
        "add_coupon.invoice_label" to "बिल नम्बर",
        "add_coupon.notes_label" to "टिप्पणी",
        "add_coupon.save_btn" to "कुपन सुरक्षित गर्नुहोस्",

        // Bulk Add Coupons Screen
        "bulk_coupons.title" to "एकमुष्ट कुपन आयात",
        "bulk_coupons.subtitle" to "SMS वा बिलबाट धेरै १२-अंकका नम्बरहरू एकैपटक पेस्ट गर्नुहोस्",
        "bulk_coupons.input_label" to "कुपन नम्बर वा पाठ यहाँ पेस्ट गर्नुहोस्",
        "bulk_coupons.input_placeholder" to "कुपन कोडहरू भएको पाठ यहाँ टाँस्नुहोस्, जस्तै:\n007315254493\n007755590670\n002928817811",
        "bulk_coupons.paste_helper" to "स्मार्ट पार्सरले अनावश्यक शब्दहरू, अल्पविराम वा विराम चिह्न हटाएर मान्य १२-अंकका कुपन कोडहरू स्वतः पहिचान गर्छ ।",
        "bulk_coupons.sample_btn" to "नमुना कोडहरू लोड गर्नुहोस्",
        "bulk_coupons.clear_btn" to "पाठ हटाउनुहोस्",
        "bulk_coupons.summary_heading" to "पहिचान सारांश",
        "bulk_coupons.total_found" to "भेटिएका कुल कोड: %d",
        "bulk_coupons.valid_new" to "आयात गर्न योग्य (नयाँ): %d",
        "bulk_coupons.already_saved" to "पहिले नै सुरक्षित: %d",
        "bulk_coupons.duplicates_in_text" to "दोहोरिएका कोडहरू: %d",
        "bulk_coupons.import_btn" to "%d मान्य कुपनहरू आयात गर्नुहोस्",

        // Winner Checker Screen
        "winner.title" to "विजेता नम्बर जाँच",
        "winner.subtitle" to "आफ्ना कुपनहरू आधिकारिक IRD नतिजासँग भिडाउनुहोस्",
        "winner.tab_official" to "आधिकारिक IRD नतिजाहरू",
        "winner.tab_custom" to "आफ्नै विजेता नम्बर सूची",
        "winner.select_draw_label" to "गोलाप्रथा नतिजा छनोट गर्नुहोस्:",
        "winner.check_now_btn" to "मेरा %d कुपनहरू जाँच्नुहोस्",
        "winner.custom_input_label" to "विजेता नम्बरहरू पेस्ट गर्नुहोस्",
        "winner.custom_input_placeholder" to "आधिकारिक १२-अंकका विजेता नम्बरहरू खाली ठाउँ, अल्पविराम वा नयाँ लाइन दिएर पेस्ट गर्नुहोस्...",
        "winner.custom_input_helper" to "जाँचका लागि %d वटा मान्य विजेता कोडहरू पहिचान गरियो ।",
        "winner.check_custom_btn" to "यी नम्बरहरूसँग जाँच्नुहोस् (%d)",
        "winner.no_coupons_warning" to "तपाईंसँग अझै कुनै सुरक्षित कुपन छैन । नतिजा जाँच्न पहिले आफ्ना रसिदबाट कुपन थप्नुहोस् ।",
        "winner.match_found_title" to "🎉 बधाई छ! विजेता कुपन भेटियो!",
        "winner.match_found_desc" to "यस गोलाप्रथामा तपाईंका %d वटा कुपन विजयी भएका छन्! तुरुन्त पुरस्कार दाबी कागजात तयार गर्नुहोस् ।",
        "winner.no_match_title" to "यसपटक कुनै कुपन परेन",
        "winner.no_match_desc" to "तपाईंका %d कुपनहरूलाई %d विजेता नम्बरहरूसँग जाँचियो । यस चक्रमा कुनै पनि कुपन मेल खाएन ।",
        "winner.dossier_btn" to "आधिकारिक दाबी कागजात तयार गर्नुहोस्",
        "winner.matched_card_title" to "विजयी कुपन #%s",
        "winner.draw_cycle_tag" to "गोलाप्रथा: %s • नतिजा: %s",

        // Draw History Screen
        "draw_hist.title" to "IRD गोलाप्रथा नतिजाहरू",
        "draw_hist.subtitle" to "पाक्षिक उपभोक्ता लटरी नतिजाहरूको अभिलेख",
        "draw_hist.add_custom_btn" to "+ नयाँ नतिजा सूचना थप्नुहोस्",
        "draw_hist.card_period" to "लटरी अवधि",
        "draw_hist.card_date" to "प्रकाशन मिति",
        "draw_hist.card_winning_count" to "%d विजयी नम्बरहरू प्रकाशित",
        "draw_hist.view_winning_numbers" to "सबै विजेता नम्बरहरू हेर्नुहोस्",
        "draw_hist.check_coupons_btn" to "यस नतिजासँग मेरा कुपन जाँच्नुहोस्",
        "draw_hist.source_label" to "स्रोत: %s",
        "draw_hist.dialog_title" to "नयाँ आधिकारिक नतिजा थप्नुहोस्",
        "draw_hist.dialog_title_field" to "नतिजा शीर्षक *",
        "draw_hist.dialog_period_field" to "लटरी अवधि (जस्तै: भाद्र १–१५, २०८३) *",
        "draw_hist.dialog_date_field" to "प्रकाशन मिति (YYYY-MM-DD) *",
        "draw_hist.dialog_numbers_field" to "१२-अंकका विजेता नम्बरहरू (खाली ठाउँ वा नयाँ लाइनले छुट्याउनुहोस्) *",
        "draw_hist.dialog_save_btn" to "नतिजा सुरक्षित गर्नुहोस्",

        // Check Eligibility Screen
        "eligibility.title" to "योग्यता क्यालकुलेटर",
        "eligibility.subtitle" to "आधिकारिक IRD नियम अनुसार रसिदको योग्यता जाँच्नुहोस्",
        "eligibility.step1_amount" to "१. कारोबारको कुल रकम",
        "eligibility.amount_field" to "खरिद रकम (रु)",
        "eligibility.amount_warning_low" to "रकम रु १०० वा सोभन्दा कम छ । IRD योजना अनुसार रु १०० भन्दा बढीको बिल हुनुपर्छ ।",
        "eligibility.step2_payment" to "२. भुक्तानीको माध्यम",
        "eligibility.payment_cash_warning" to "नगद भुक्तानीले IRD विद्युतीय पुरस्कार कुपन प्राप्त गर्न सक्दैन ।",
        "eligibility.step3_purpose" to "३. खरिदको उद्देश्य",
        "eligibility.purpose_biz_warning" to "व्यापारिक वा संस्थागत खर्चहरू यस उपभोक्ता प्रोत्साहन योजनामा समावेश छैनन् ।",
        "eligibility.step4_pan" to "४. बिक्रेताको कर दर्ता (PAN/VAT)",
        "eligibility.step5_category" to "५. वस्तु तथा सेवाको वर्ग",
        "eligibility.result_heading" to "योग्यता नतिजा",
        "eligibility.digital_warning_title" to "डिजिटल भुक्तानी सम्बन्धी महत्वपूर्ण सूचना:",
        "eligibility.reasons_title" to "नियम विश्लेषण:",
        "eligibility.next_steps_title" to "सिफारिस गरिएका आगामी कदमहरू:",
        "eligibility.disclaimer_title" to "कानूनी तथा प्राविधिक बुँदाहरू:",

        // IRD Info & Guidelines Screen
        "ird_info.title" to "IRD निर्देशिका तथा सूचनाहरू",
        "ird_info.subtitle" to "उपभोक्ता प्रोत्साहन योजनाको आधिकारिक कार्यविधि र FAQ",
        "ird_info.guide_heading" to "उपभोक्ता लटरी योजना कसरी सञ्चालन हुन्छ?",
        "ird_info.step1_title" to "१. डिजिटल खरिद गर्नुहोस्",
        "ird_info.step1_desc" to "PAN दर्ता भएको पसलमा रु १०० भन्दा बढीको व्यक्तिगत वस्तु वा सेवा खरिद गरी QR कोड, डिजिटल वालेट (eSewa, Khalti), मोबाइल बैंकिङ वा कार्डमार्फत भुक्तानी गर्नुहोस् ।",
        "ird_info.step2_title" to "२. विद्युतीय कर बिजक प्राप्त गर्नुहोस्",
        "ird_info.step2_desc" to "बिक्रेताले जारी गरेको विद्युतीय कर बिल सिधै आन्तरिक राजस्व विभागको केन्द्रीय प्रणाली (CBMS) मा प्रविष्ट हुन्छ ।",
        "ird_info.step3_title" to "३. १२-अंकको लटरी कुपन प्राप्त गर्नुहोस्",
        "ird_info.step3_desc" to "प्रणालीबाट स्वतः सिर्जना भएको १२-अंकको कुपन कोड बिलमा वा भुक्तानी एप/SMS मार्फत उपलब्ध हुन्छ ।",
        "ird_info.step4_title" to "४. पाक्षिक गोलाप्रथा (Lottery Draw)",
        "ird_info.step4_desc" to "आन्तरिक राजस्व विभागले महिनाको दुई पटक कम्प्युटर प्रणालीबाट गोलाप्रथा गरी विजेता नम्बरहरू ird.gov.np मा सार्वजनिक गर्छ ।",
        "ird_info.step5_title" to "५. पुरस्कार दाबी गर्नुहोस्",
        "ird_info.step5_desc" to "विजेताहरूले सक्कल बिल, डिजिटल भुक्तानी प्रमाण, नागरिकता र PAN कार्डसहित १५ दिनभित्र नजिकको कर कार्यालय (IRO/TSO) मा दाबी पेस गर्नुपर्छ ।",
        "ird_info.notices_heading" to "आधिकारिक परिपत्र तथा कानूनी सूचनाहरू",
        "ird_info.portal_link" to "आधिकारिक IRD पोर्टल हेर्नुहोस् (ird.gov.np)",

        // IRD Info Screen Additional Keys
        "info.title" to "IRD कानूनी निर्देशिका तथा ५-चरण जानकारी",
        "info.subtitle" to "उपभोक्ता प्रोत्साहन योजना, योग्यता तथा लटरी नियमहरू",
        "info.how_it_works_header" to "उपभोक्ता लटरी योजनाले कसरी काम गर्छ?",
        "info.step_1" to "१. वस्तु वा सेवा खरिद गर्नुहोस्",
        "info.step_1_sub" to "PAN/भ्याट दर्ता पसलबाट खरिद गर्नुहोस्",
        "info.step_2" to "२. विद्युतीय माध्यमबाट भुक्तानी गर्नुहोस्",
        "info.step_2_sub" to "QR वा डिजिटल वालेटबाट भुक्तानी गर्नुहोस्",
        "info.step_3" to "३. १२-अंकको लटरी कुपन प्राप्त गर्नुहोस्",
        "info.step_3_sub" to "१२-अंकको Prize Coupon प्राप्त गर्नुहोस्",
        "info.step_4" to "४. पाक्षिक गोलाप्रथा (Lottery Draw)",
        "info.step_4_sub" to "आन्तरिक राजस्व विभागको पाक्षिक लटरी",
        "info.step_5" to "५. नतिजा जाँच तथा पुरस्कार दाबी",
        "info.step_5_sub" to "रसिद खातामा १-ट्यापमा नतिजा जाँच्नुहोस् र १५ दिनभित्र दाबी गर्नुहोस्",
        "info.scheme_title" to "नेपाल सरकार उपभोक्ता प्रोत्साहन कार्यक्रम",
        "info.scheme_desc" to "मूल्य अभिवृद्धि कर तथा विद्युतीय बिलिङ निर्देशिका बमोजिम दर्ता भएका पसलमा डिजिटल भुक्तानी गर्ने उपभोक्ताहरूलाई पाक्षिक रूपमा रु. ५०,००० सम्मका नगद पुरस्कारसहितको गोलाप्रथामा सहभागी गराइन्छ ।",
        "info.conditions_header" to "योजनाका मुख्य सर्त तथा योग्यता",
        "info.cond_1" to "खरिद रकम रु. १०० भन्दा बढी हुनुपर्ने",
        "info.cond_2" to "व्यक्तिगत तथा घरायसी उपभोगका लागि हुनुपर्ने (व्यापारिक नहुने)",
        "info.cond_3" to "स्वीकृत डिजिटल माध्यम (QR, वालेट, मोबाइल बैंकिङ, कार्ड) बाट भुक्तानी हुनुपर्ने",
        "info.cond_4" to "बिक्रेता प्यान/भ्याटमा दर्ता भई विद्युतीय बिल जारी गर्ने हुनुपर्ने",
        "info.cond_5" to "पुरस्कार रकम दाबी गर्न दाबीकर्ताको व्यक्तिगत PAN अनिवार्य हुने",
        "info.prize_structure_header" to "पाक्षिक पुरस्कार संरचना",
        "info.prize_1st_label" to "प्रथम पुरस्कार (१ जना)",
        "info.prize_2nd_label" to "दोस्रो पुरस्कार (१ जना)",
        "info.prize_3rd_label" to "तेस्रो पुरस्कार (१ जना)",
        "info.prize_cons_label" to "सान्त्वना पुरस्कार (१० जना)",
        "info.open_calculator_btn" to "मेरो बिलको योग्यता जाँच्नुहोस् (क्याल्कुलेटर)",

        // IRD Info - Foreign Visitors & Residents Section
        "info.foreign.header" to "विदेशी नागरिक तथा पर्यटकहरूका लागि जानकारी",
        "info.foreign.badge" to "योग्यता तथा PAN मार्गदर्शन",
        "info.foreign.intro" to "नेपालमा रहेका विदेशी नागरिक, पर्यटक तथा गैर-नेपाली बासिन्दाहरूका लागि लटरी सहभागिता, व्यक्तिगत PAN को अनिवार्यता, परिचयपत्र र कर सम्बन्धी जानकारी ।",
        "info.foreign.pan_title" to "१. पुरस्कार दाबीका लागि व्यक्तिगत PAN अनिवार्य",
        "info.foreign.pan_desc" to "दर्ता भएको पसलमा रु. १०० भन्दा माथिको डिजिटल भुक्तानी गर्दा लटरी कुपन प्राप्त हुन सक्छ । तर पुरस्कार रकम प्राप्त गर्न आन्तरिक राजस्व विभागको नियम अनुसार दाबीकर्ताको आफ्नै नामको व्यक्तिगत PAN अनिवार्य हुन्छ । नेपाली PAN विना पुरस्कार रकम निकासा हुन सक्दैन ।",
        "info.foreign.docs_title" to "२. मान्य परिचयपत्रहरू र १५-दिने म्याद",
        "info.foreign.docs_desc" to "लटरी नतिजा प्रकाशित भएको १५ दिनभित्र नजिकको आन्तरिक राजस्व कार्यालय वा करदाता सेवा कार्यालयमा दाबी पेस गर्नुपर्छ । नेपाली PAN भएका विदेशी नागरिकले परिचयपत्रका रूपमा आफ्नो राहदानी (Passport), PAN कार्ड, सक्कल बिल, भुक्तानी प्रमाण र बैंक खाताको विवरण पेस गर्न सक्नुहुन्छ ।",
        "info.foreign.invoice_title" to "३. सक्कल भौतिक बिल (Invoice) अनिवार्य",
        "info.foreign.invoice_desc" to "डिजिटल वालेट वा QR भुक्तानीबाट कुपन स्वतः प्राप्त भए पनि, दाबी रुजुका बेला बिक्रेताले दिएको सक्कल भौतिक कर बिजक (Original Invoice) पेस गर्नैपर्छ । बिल हराएमा वा च्यातिएमा पुरस्कार दाबी रद्द हुन सक्छ ।",
        "info.foreign.tax_title" to "४. २५% आकस्मिक लाभकर (Windfall Tax)",
        "info.foreign.tax_desc" to "नेपालको कर कानून बमोजिम लटरी तथा चिठ्ठाको पुरस्कारमा २५% आकस्मिक लाभकर लाग्दछ । यो कर रकम भुक्तानी हुनु अगावै कट्टी गरिने हुँदा विजेताले कर कट्टीपछिको खुद रकम प्राप्त गर्नुहुन्छ र थप कर विवरण बुझाउनु पर्दैन ।",
        "info.foreign.inquiry_title" to "५. आधिकारिक सोधपुछ तथा थप जानकारी",
        "info.foreign.inquiry_desc" to "पर्यटक वा अल्पकालीन भिसा वाहकले व्यक्तिगत PAN लिन पाउने वा नपाउने विषय आवासीय तथा अध्यागमन नियमहरूमा निर्भर हुन्छ । व्यक्तिगत यकिनका लागि कृपया नजिकको आन्तरिक राजस्व कार्यालय (IRO) मा सम्पर्क गर्नुहोला वा ird.gov.np हेर्नुहोला ।",

        // Welcome / Onboarding Screen
        "welcome.tag" to "छोटो जानकारी तथा मार्गदर्शन",
        "welcome.skip" to "छोड्नुहोस्",
        "welcome.next" to "अगाडि",
        "welcome.back" to "पछाडि",
        "welcome.get_started" to "सुरु गर्नुहोस्",
        "welcome.step_indicator" to "चरण %d / %d",
        "welcome.card1.title" to "रसिद खाता के हो?",
        "welcome.card1.subtitle" to "उपभोक्ता बिल ट्र्याकर तथा लटरी सहयोगी",
        "welcome.card1.body" to "रसिद खाताले तपाईंलाई खरिद बिलहरू दर्ता गर्न, १२-अंकका पुरस्कार कुपनहरू सुरक्षित राख्न र नेपाल सरकारको उपभोक्ता प्रोत्साहन लटरीमा जिते नजितेको जाँच्न मद्दत गर्दछ।",
        "welcome.card1.point1" to "QR तथा डिजिटल भुक्तानीका बिलहरू ट्र्याक गर्नुहोस्",
        "welcome.card1.point2" to "आन्तरिक राजस्व विभागको पाक्षिक लटरी नतिजा १ ट्यापमा जाँच्नुहोस्",
        "welcome.card2.title" to "के म सहभागी हुन सक्छु?",
        "welcome.card2.subtitle" to "सहभागिता र पुरस्कार दाबीका नियमहरू",
        "welcome.card2.body" to "प्यान दर्ता पसलमा रु. १०० भन्दा माथिको बिल वा डिजिटल भुक्तानी गर्दा गोलाप्रथामा स्वतः प्रवेश हुन्छ । तर जितेको पुरस्कार दाबी गर्न तपाईंको आफ्नै नामको व्यक्तिगत प्यान (Personal PAN) अनिवार्य हुन्छ — यो ऐच्छिक होइन, अनिवार्य हो ।",
        "welcome.card2.point1" to "पुरस्कार रकम दाबी गर्न आफ्नै नाममा जारी भएको व्यक्तिगत PAN अनिवार्य छ ।",
        "welcome.card2.point2" to "विदेशी नागरिक वा पर्यटकले व्यक्तिगत PAN लिन सक्ने नसक्ने भिसा र आवासीय स्थितिमा निर्भर गर्दछ । यो एपले पुष्टि गर्न सक्दैन — यकिन गर्न नजिकको आन्तरिक राजस्व कार्यालय (IRO) मा बुझ्नुहोला ।",
        "welcome.card2.point3" to "नेपाली नागरिक तथा बासिन्दाहरू: यदि तपाईंसँग पहिले नै PAN छ भने यो प्रक्रिया एकदम सहज छ ।",
        "welcome.card3.title" to "अरू कसैलाई मद्दत गर्दै हुनुहुन्छ?",
        "welcome.card3.subtitle" to "परिवार वा साथीभाइका लागि कुपन ट्र्याक गर्नुहोस्",
        "welcome.card3.body" to "यदि तपाईं स्वयं पुरस्कार दाबी गर्न सक्नुहुन्न भने पनि, वैध PAN भएका आफ्ना नेपाली परिवार, साथीभाइ वा सहयोगीहरूका लागि कुपनहरू ट्र्याक गर्न र नतिजा जाँच्न यो एप प्रयोग गर्न सक्नुहुन्छ ।",
        "welcome.card3.point1" to "सबैका डिजिटल रसिद र पुरस्कार कुपनहरू सुरक्षित राख्नुहोस्",
        "welcome.card3.point2" to "कुपनले पुरस्कार जित्दा आधिकारिक दाबी विवरण तयार गर्नुहोस्",

        // Data & Backup Screen
        "backup.title" to "डेटा तथा ब्याकअप",
        "backup.subtitle" to "भाषा, स्थानीय भण्डारण, ब्याकअप र रिस्टोर",
        "backup.lang_card_title" to "एपको भाषा / App Language",
        "backup.lang_card_desc" to "नेपाली वा अंग्रेजी भाषा छनोट गर्नुहोस् । यो प्राथमिकता तपाईंको फोनमै सुरक्षित रहन्छ ।",
        "backup.storage_card_title" to "स्थानीय भण्डारण स्थिति (Offline Storage)",
        "backup.storage_card_desc" to "सबै कारोबार, कुपन र नतिजाहरू तपाईंको आफ्नै फोनमा १००% सुरक्षित छन् । कुनै बाह्य सर्भरमा डेटा पठाइँदैन ।",
        "backup.invoices_pill" to "रसिदहरू",
        "backup.coupons_pill" to "कुपनहरू",
        "backup.export_heading" to "ब्याकअप तथा निर्यात विकल्पहरू",
        "backup.export_json_title" to "पूर्ण ब्याकअप (JSON)",
        "backup.export_json_desc" to "सबै कारोबार, कुपन र नतिजाको पूर्ण JSON ब्याकअप प्रतिलिपि लिनुहोस् ।",
        "backup.copy_json_btn" to "JSON क्लिपबोर्डमा कपी गर्नुहोस्",
        "backup.export_csv_invoices" to "रसिदहरू CSV मा निर्यात गर्नुहोस्",
        "backup.export_csv_coupons" to "कुपनहरू CSV मा निर्यात गर्नुहोस्",
        "backup.restore_heading" to "JSON बाट डेटा रिस्टोर गर्नुहोस्",
        "backup.restore_input_label" to "ब्याकअप JSON यहाँ पेस्ट गर्नुहोस्",
        "backup.restore_merge_btn" to "हालको डेटामा थप्नुहोस् (Merge)",
        "backup.restore_replace_btn" to "सबै डेटा बदल्नुहोस् (Replace)",
        "backup.danger_heading" to "डेटा मेटाउने तथा परीक्षण",
        "backup.load_demo_btn" to "नमुना परीक्षण डेटा लोड गर्नुहोस्",
        "backup.clear_all_btn" to "सबै स्थानीय डेटा खाली गर्नुहोस्",
        "backup.clear_dialog_title" to "सबै डेटा मेटाउने पक्का हुनुहुन्छ?",
        "backup.clear_dialog_desc" to "यसले तपाईंको फोनबाट सबै रसिद, लटरी कुपन र नतिजाहरू सधैंका लागि मेटाउनेछ । यो कार्य उल्टाउन सकिँदैन ।",

        // Claim Report Screen
        "claim.title" to "दाबी तयारी कागजात",
        "claim.subtitle" to "आधिकारिक IRD पुरस्कार दाबी विवरण तथा आवश्यक कागजात सूची",
        "claim.copy_dossier_btn" to "दाबी विवरण कपी गर्नुहोस्",
        "claim.dossier_copied" to "दाबी विवरण क्लिपबोर्डमा कपी भयो!",
        "claim.winner_card_title" to "विजयी लटरी कुपन",
        "claim.draw_details_title" to "गोलाप्रथा तथा कारोबार विवरण",
        "claim.docs_heading" to "कर कार्यालयमा पेस गर्नुपर्ने अनिवार्य कागजातहरू",
        "claim.doc1" to "सक्कल कर बिजक वा डिजिटल रसिदको प्रतिलिपि",
        "claim.doc2" to "डिजिटल भुक्तानी पुष्टि स्लिप / कारोबार नम्बर (Reference)",
        "claim.doc3" to "नेपाली नागरिकताको प्रमाणपत्रको प्रतिलिपि",
        "claim.doc4" to "व्यक्तिगत स्थायी लेखा नम्बर (Personal PAN) कार्डको प्रतिलिपि",
        "claim.doc5" to "बैंक खाताको चेक वा स्टेटमेन्ट प्रतिलिपि",
        "claim.deadline_heading" to "वैधानिक १५-दिने दाबी म्याद",
        "claim.deadline_desc" to "आन्तरिक राजस्व विभागको उपभोक्ता प्रोत्साहन कार्यविधि अनुसार गोलाप्रथा नतिजा प्रकाशित भएको मितिले १५ दिनभित्र नजिकको आन्तरिक राजस्व कार्यालय (IRO) वा करदाता सेवा कार्यालय (TSO) मा सक्कल कागजातसहित दाबी पेस गर्नुपर्नेछ ।",

        // Status badges
        "status.coupon_added" to "कुपन जोडिएको",
        "status.awaiting_coupon" to "कुपन पर्खिएको",
        "status.likely_eligible" to "योग्य हुने सम्भावना",
        "status.needs_verification" to "पुष्टि आवश्यक",
        "status.likely_not_eligible" to "अयोग्य हुने सम्भावना",
        "status.not_checked" to "जाँच हुन बाँकी",

        // Enums & Option Labels
        "payment.digital_wallet" to "डिजिटल वालेट (eSewa / Khalti)",
        "payment.qr_payment" to "QR / डिजिटल भुक्तानी (Fonepay)",
        "payment.mobile_banking" to "मोबाइल बैंकिङ एप",
        "payment.card" to "डेबिट / क्रेडिट कार्ड",
        "payment.cash" to "नगद (योजनामा समावेश छैन)",
        "payment.bank_transfer" to "बैंक ट्रान्सफर (ConnectIPS)",
        "payment.other" to "अन्य भुक्तानी माध्यम",

        "purpose.personal" to "व्यक्तिगत / उपभोक्ता उपभोग (योग्य)",
        "purpose.business" to "व्यापारिक / व्यावसायिक खर्च (अयोग्य)",
        "purpose.government" to "सरकारी / संस्थागत खर्च (अयोग्य)",
        "purpose.unknown" to "अस्पष्ट / अन्य",

        "pan.yes" to "हो (९-अंकको दर्ता भएको PAN/VAT)",
        "pan.no" to "होइन (दर्ता नभएको / सादा नगद बिल)",
        "pan.dont_know" to "यकिन छैन / पुष्टि गर्न बाँकी",

        "category.normal_goods" to "सामान्य खुद्रा वस्तु तथा किनमेल",
        "category.food_restaurant" to "रेस्टुरेन्ट तथा क्याफे खानपान",
        "category.electronics" to "इलेक्ट्रोनिक्स तथा घरायसी उपकरण",
        "category.clothing" to "लत्ताकपडा तथा फेसन",
        "category.electricity" to "विद्युत महसुल (NEA - योजनामा छैन)",
        "category.telephone_internet" to "टेलिफोन तथा इन्टरनेट महसुल (योजनामा छैन)",
        "category.airline" to "हवाई टिकट तथा उड्डयन (योजनामा छैन)",
        "category.transport_freight" to "सार्वजनिक यातायात तथा ढुवानी (योजनामा छैन)",
        "category.vehicle" to "सवारी साधन तथा मेशिनरी",
        "category.other" to "अन्य उपभोक्ता वस्तुहरू",
        "category.dont_know" to "खुल्न नसकेको वर्ग"
    )

    fun get(key: String, lang: AppLanguage, vararg args: Any): String {
        val map = if (lang == AppLanguage.NEPALI) neMap else enMap
        val template = map[key] ?: enMap[key] ?: key
        return if (args.isEmpty()) {
            template
        } else {
            try {
                String.format(Locale.US, template, *args)
            } catch (e: Exception) {
                template
            }
        }
    }

    fun getPaymentMethodLabel(method: PaymentMethod, lang: AppLanguage): String {
        return when (method) {
            PaymentMethod.DIGITAL_WALLET -> get("payment.digital_wallet", lang)
            PaymentMethod.QR_PAYMENT -> get("payment.qr_payment", lang)
            PaymentMethod.MOBILE_BANKING -> get("payment.mobile_banking", lang)
            PaymentMethod.CARD -> get("payment.card", lang)
            PaymentMethod.CASH -> get("payment.cash", lang)
            PaymentMethod.BANK_TRANSFER -> get("payment.bank_transfer", lang)
            PaymentMethod.OTHER -> get("payment.other", lang)
        }
    }

    fun getPurchasePurposeLabel(purpose: PurchasePurpose, lang: AppLanguage): String {
        return when (purpose) {
            PurchasePurpose.PERSONAL -> get("purpose.personal", lang)
            PurchasePurpose.BUSINESS -> get("purpose.business", lang)
            PurchasePurpose.GOVERNMENT -> get("purpose.government", lang)
            PurchasePurpose.UNKNOWN -> get("purpose.unknown", lang)
        }
    }

    fun getSellerPanLabel(option: SellerPanOption, lang: AppLanguage): String {
        return when (option) {
            SellerPanOption.YES -> get("pan.yes", lang)
            SellerPanOption.NO -> get("pan.no", lang)
            SellerPanOption.DONT_KNOW -> get("pan.dont_know", lang)
        }
    }

    fun getCategoryLabel(category: TransactionCategory, lang: AppLanguage): String {
        return when (category) {
            TransactionCategory.NORMAL_GOODS -> get("category.normal_goods", lang)
            TransactionCategory.FOOD_RESTAURANT -> get("category.food_restaurant", lang)
            TransactionCategory.ELECTRONICS -> get("category.electronics", lang)
            TransactionCategory.CLOTHING -> get("category.clothing", lang)
            TransactionCategory.ELECTRICITY -> get("category.electricity", lang)
            TransactionCategory.TELEPHONE_INTERNET -> get("category.telephone_internet", lang)
            TransactionCategory.AIRLINE -> get("category.airline", lang)
            TransactionCategory.TRANSPORT_FREIGHT -> get("category.transport_freight", lang)
            TransactionCategory.VEHICLE -> get("category.vehicle", lang)
            TransactionCategory.OTHER -> get("category.other", lang)
            TransactionCategory.DONT_KNOW -> get("category.dont_know", lang)
        }
    }

    fun getStatusLabel(status: EligibilityStatus, lang: AppLanguage): String {
        return when (status) {
            EligibilityStatus.COUPON_ADDED -> get("status.coupon_added", lang)
            EligibilityStatus.AWAITING_COUPON -> get("status.awaiting_coupon", lang)
            EligibilityStatus.LIKELY_ELIGIBLE -> get("status.likely_eligible", lang)
            EligibilityStatus.NEEDS_VERIFICATION -> get("status.needs_verification", lang)
            EligibilityStatus.LIKELY_NOT_ELIGIBLE -> get("status.likely_not_eligible", lang)
            EligibilityStatus.NOT_CHECKED -> get("status.not_checked", lang)
        }
    }

    fun formatCurrency(amount: Double, lang: AppLanguage): String {
        val formattedNumber = String.format(Locale.US, "%,.2f", amount)
        return if (lang == AppLanguage.NEPALI) {
            "रु $formattedNumber"
        } else {
            "NPR $formattedNumber"
        }
    }
}
