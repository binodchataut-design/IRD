package com.example.data.localization

import java.util.Locale

enum class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String
) {
    ENGLISH("en", "English", "English"),
    NEPALI("ne", "Nepali", "नेपाली");

    companion object {
        fun fromCode(code: String?): AppLanguage {
            return when (code?.lowercase()) {
                "ne", "nep", "nepali" -> NEPALI
                else -> ENGLISH
            }
        }

        fun defaultFromSystem(): AppLanguage {
            val lang = Locale.getDefault().language.lowercase()
            return if (lang.startsWith("ne")) NEPALI else ENGLISH
        }
    }
}
