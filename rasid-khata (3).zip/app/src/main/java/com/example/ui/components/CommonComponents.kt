package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.data.models.EligibilityStatus
import com.example.data.utils.CouponUtils
import com.example.ui.Screen
import com.example.ui.theme.*

// =========================================================================
// 1. APP TOP BAR / HEADER
// =========================================================================
@Composable
fun RasidKhataHeader(
    title: String,
    subtitle: String? = null,
    nepaliTitle: String? = null,
    showBack: Boolean = false,
    onBack: () -> Unit = {},
    rightAction: (@Composable () -> Unit)? = null
) {
    val lang = LocalAppLanguage.current

    Surface(
        color = BackgroundCanvas,
        shadowElevation = 0.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (showBack) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(42.dp)
                            .background(SurfaceMuted, shape = RoundedCornerShape(12.dp))
                            .testTag("header_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = AppStrings.get("common.back", lang),
                            tint = NavyPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(NavyContainer, shape = RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = AppStrings.get("app.name", lang),
                            tint = NavyPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = AppStrings.get("app.scheme_tag", lang),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary,
                        letterSpacing = 0.6.sp
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = title,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (!nepaliTitle.isNullOrBlank() && lang == AppLanguage.ENGLISH) {
                            Text(
                                text = "($nepaliTitle)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NavyPrimaryLight
                            )
                        }
                    }
                    if (!subtitle.isNullOrBlank()) {
                        Text(
                            text = subtitle,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (rightAction != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    rightAction()
                }
            }
        }
    }
}

// =========================================================================
// 2. MODERN BOTTOM NAVIGATION BAR
// =========================================================================
data class NavItem(
    val screen: Screen,
    val titleKey: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun RasidKhataBottomNav(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current

    val items = listOf(
        NavItem(
            screen = Screen.Home,
            titleKey = "nav.home",
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            testTag = "nav_home"
        ),
        NavItem(
            screen = Screen.Invoices,
            titleKey = "nav.invoices",
            selectedIcon = Icons.Filled.ReceiptLong,
            unselectedIcon = Icons.Outlined.ReceiptLong,
            testTag = "nav_invoices"
        ),
        NavItem(
            screen = Screen.Coupons,
            titleKey = "nav.coupons",
            selectedIcon = Icons.Filled.ConfirmationNumber,
            unselectedIcon = Icons.Outlined.ConfirmationNumber,
            testTag = "nav_coupons"
        ),
        NavItem(
            screen = Screen.WinnerChecker,
            titleKey = "nav.winner",
            selectedIcon = Icons.Filled.EmojiEvents,
            unselectedIcon = Icons.Outlined.EmojiEvents,
            testTag = "nav_winner"
        ),
        NavItem(
            screen = Screen.IRDInfo,
            titleKey = "nav.guide",
            selectedIcon = Icons.Filled.Info,
            unselectedIcon = Icons.Outlined.Info,
            testTag = "nav_info"
        )
    )

    Surface(
        color = SurfaceMuted,
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier
    ) {
        NavigationBar(
            containerColor = SurfaceMuted,
            tonalElevation = 0.dp,
            modifier = Modifier.navigationBarsPadding()
        ) {
            items.forEach { item ->
                val isSelected = currentScreen == item.screen
                val label = AppStrings.get(item.titleKey, lang)
                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onNavigate(item.screen) },
                    icon = {
                        Icon(
                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = label,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = OnNavyContainer,
                        selectedTextColor = TextPrimary,
                        indicatorColor = NavyContainer,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag(item.testTag)
                )
            }
        }
    }
}

// =========================================================================
// 3. UNIFIED STATUS BADGE SYSTEM
// =========================================================================
@Composable
fun EligibilityBadge(
    status: EligibilityStatus,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current
    val (bgColor, textColor, borderColor, icon) = when (status) {
        EligibilityStatus.COUPON_ADDED -> Tuple4(
            StatusSuccessBg, StatusSuccess, StatusSuccessBorder, Icons.Default.CheckCircle
        )
        EligibilityStatus.AWAITING_COUPON -> Tuple4(
            StatusPendingBg, StatusPending, StatusPendingBorder, Icons.Default.HourglassTop
        )
        EligibilityStatus.LIKELY_ELIGIBLE -> Tuple4(
            StatusSuccessBg, StatusSuccess, StatusSuccessBorder, Icons.Default.CheckCircleOutline
        )
        EligibilityStatus.NEEDS_VERIFICATION -> Tuple4(
            StatusPendingBg, StatusPending, StatusPendingBorder, Icons.Default.HelpOutline
        )
        EligibilityStatus.LIKELY_NOT_ELIGIBLE -> Tuple4(
            StatusErrorBg, StatusError, StatusErrorBorder, Icons.Default.Cancel
        )
        EligibilityStatus.NOT_CHECKED -> Tuple4(
            SurfaceMuted, TextSecondary, BorderSubtle, Icons.Default.HelpOutline
        )
    }

    val label = AppStrings.getStatusLabel(status, lang)

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = label,
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private data class Tuple4<A, B, C, D>(
    val a: A, val b: B, val c: C, val d: D
)

// =========================================================================
// 4. COUPON NUMBER DISPLAY (Monospaced, Preserves Leading Zeros)
// =========================================================================
@Composable
fun CouponNumberDisplay(
    couponNumber: String,
    modifier: Modifier = Modifier,
    showCopyButton: Boolean = true,
    fontSize: Int = 16
) {
    val context = LocalContext.current
    val lang = LocalAppLanguage.current
    val formatted = CouponUtils.formatCouponNumber(couponNumber)

    Surface(
        color = SurfaceMuted,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ConfirmationNumber,
                    contentDescription = null,
                    tint = NavyPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = formatted,
                    fontSize = fontSize.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    letterSpacing = 1.sp
                )
            }

            if (showCopyButton) {
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Coupon Number", couponNumber))
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = AppStrings.get("common.copy", lang),
                        tint = NavyPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

// =========================================================================
// 5. EMPTY STATE COMPONENT
// =========================================================================
@Composable
fun EmptyStateView(
    icon: ImageVector,
    title: String,
    description: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(NavyContainer, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NavyPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = description,
                fontSize = 13.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )

            if (actionLabel != null && onAction != null) {
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NavyPrimary,
                        contentColor = SurfaceCard
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    Text(
                        text = actionLabel,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// =========================================================================
// 6. SECTION HEADER
// =========================================================================
@Composable
fun SectionHeader(
    title: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )

        if (actionLabel != null && onAction != null) {
            TextButton(
                onClick = onAction,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = actionLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimaryLight
                )
            }
        }
    }
}

// =========================================================================
// 7. INDEPENDENT APP DISCLAIMER BANNER
// =========================================================================
@Composable
fun DisclaimerBanner(modifier: Modifier = Modifier) {
    val lang = LocalAppLanguage.current
    Surface(
        color = SurfaceMuted,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.VerifiedUser,
                contentDescription = null,
                tint = NavyPrimary,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = AppStrings.get("app.disclaimer_full", lang),
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 15.sp
            )
        }
    }
}

