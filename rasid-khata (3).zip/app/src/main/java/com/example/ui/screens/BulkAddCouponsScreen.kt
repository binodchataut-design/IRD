package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.data.models.BulkParseResult
import com.example.data.services.NepaliDateService
import com.example.data.utils.CouponUtils
import com.example.ui.RasidKhataViewModel
import com.example.ui.components.RasidKhataHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BulkAddCouponsScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current
    val existingCoupons by viewModel.coupons.collectAsState()
    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val defaultDrawPeriod = remember { NepaliDateService.getDrawPeriodInfo(todayStr).drawPeriod }

    var rawInputText by remember { mutableStateOf("") }
    var defaultMerchant by remember { mutableStateOf("") }
    var defaultPeriod by remember { mutableStateOf(defaultDrawPeriod) }

    val importAnalysis: BulkParseResult = remember(rawInputText, existingCoupons) {
        val existingSet = existingCoupons.map { it.couponNumber }.toSet()
        CouponUtils.parseBulkCouponsText(rawInputText, existingSet)
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = AppStrings.get("bulk.title", lang),
                subtitle = AppStrings.get("bulk.subtitle", lang),
                showBack = true,
                onBack = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = AppStrings.get("bulk.card_title", lang),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Text(
                            text = AppStrings.get("bulk.instruction", lang),
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 15.sp
                        )

                        OutlinedTextField(
                            value = rawInputText,
                            onValueChange = { rawInputText = it },
                            placeholder = {
                                Text(
                                    "007 315 254 493\n007 315 254 494\n007-315-254-495\n...",
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            },
                            minLines = 6,
                            maxLines = 10,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("bulk_coupons_textarea")
                        )

                        // Real-time Breakdown Badges
                        if (rawInputText.isNotBlank()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                StatChip(
                                    label = AppStrings.get("bulk.total_found", lang),
                                    count = importAnalysis.totalExtracted,
                                    bgColor = SurfaceMuted,
                                    textColor = TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                StatChip(
                                    label = AppStrings.get("bulk.valid_new", lang),
                                    count = importAnalysis.validNew.size,
                                    bgColor = StatusSuccessBg,
                                    textColor = StatusSuccess,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                StatChip(
                                    label = AppStrings.get("bulk.duplicates", lang),
                                    count = importAnalysis.duplicateInBatch.size,
                                    bgColor = StatusPendingBg,
                                    textColor = StatusPending,
                                    modifier = Modifier.weight(1f)
                                )
                                StatChip(
                                    label = AppStrings.get("bulk.already_saved", lang),
                                    count = importAnalysis.alreadySaved.size,
                                    bgColor = NavyContainer,
                                    textColor = NavyPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                StatChip(
                                    label = AppStrings.get("bulk.invalid", lang),
                                    count = importAnalysis.invalidTokens.size,
                                    bgColor = StatusErrorBg,
                                    textColor = StatusError,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        HorizontalDivider(color = BorderDivider)

                        OutlinedTextField(
                            value = defaultMerchant,
                            onValueChange = { defaultMerchant = it },
                            label = { Text(AppStrings.get("bulk.merchant_label", lang)) },
                            placeholder = { Text(AppStrings.get("add_coupon.merchant_placeholder", lang)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = defaultPeriod,
                            onValueChange = { defaultPeriod = it },
                            label = { Text(AppStrings.get("add_coupon.draw_period", lang)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        if (importAnalysis.validNew.isNotEmpty()) {
                            viewModel.addBulkCoupons(importAnalysis.validNew)
                            viewModel.showSnackbar("${importAnalysis.validNew.size} ${AppStrings.get("bulk.save_success", lang)}")
                            viewModel.navigateBack()
                        }
                    },
                    enabled = importAnalysis.validNew.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NavyPrimary,
                        contentColor = SurfaceCard
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("bulk_import_confirm_button")
                ) {
                    Text(
                        text = "${AppStrings.get("common.save", lang)} ${importAnalysis.validNew.size} ${AppStrings.get("coupons.title", lang)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun StatChip(
    label: String,
    count: Int,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$count",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
            Text(
                text = label,
                fontSize = 9.sp,
                color = textColor
            )
        }
    }
}
