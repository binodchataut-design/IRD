package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.data.models.DrawAnnouncement
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.CouponNumberDisplay
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.EmptyStateView
import com.example.ui.components.RasidKhataHeader
import com.example.ui.theme.*

@Composable
fun DrawHistoryScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current
    val draws by viewModel.drawAnnouncements.collectAsState()

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = AppStrings.get("history.title", lang),
                subtitle = AppStrings.get("history.subtitle", lang),
                showBack = true,
                onBack = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (draws.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.History,
                        title = AppStrings.get("history.empty_title", lang),
                        description = AppStrings.get("history.empty_desc", lang),
                        actionLabel = AppStrings.get("winner.title", lang),
                        onAction = { viewModel.navigateTo(Screen.WinnerChecker) }
                    )
                }
            } else {
                item {
                    Text(
                        text = AppStrings.get("history.desc", lang),
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                items(draws, key = { it.id }) { draw ->
                    DrawHistoryCard(draw = draw)
                }
            }

            item {
                DisclaimerBanner()
            }
        }
    }
}

@Composable
private fun DrawHistoryCard(draw: DrawAnnouncement) {
    val lang = LocalAppLanguage.current

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = draw.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${AppStrings.get("coupons.draw_period_label", lang)}: ${draw.drawPeriod} • ${draw.announcementDate}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
                Surface(
                    color = GoldWinnerContainer,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${draw.winningNumbers.size} ${AppStrings.get("winner.matched_found", lang)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = OnGoldWinner,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            HorizontalDivider(color = BorderDivider)

            draw.winningNumbers.forEachIndexed { index, winningNumber ->
                val prizeLabel = when (index) {
                    0 -> AppStrings.get("history.prize_1st", lang)
                    1 -> AppStrings.get("history.prize_2nd", lang)
                    2 -> AppStrings.get("history.prize_3rd", lang)
                    else -> "${AppStrings.get("history.prize_consolation", lang)} ${index - 2}"
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = prizeLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    CouponNumberDisplay(
                        couponNumber = winningNumber,
                        fontSize = 13,
                        showCopyButton = false
                    )
                }
            }
        }
    }
}
