package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.ui.RasidKhataViewModel
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.RasidKhataHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun DataBackupScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang = LocalAppLanguage.current
    val transactions by viewModel.transactions.collectAsState()
    val coupons by viewModel.coupons.collectAsState()

    var jsonRestoreText by remember { mutableStateOf("") }
    var isResetDialogOpen by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = AppStrings.get("backup.title", lang),
                subtitle = AppStrings.get("backup.subtitle", lang),
                showBack = true,
                onBack = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // =========================================================================
            // 0. LANGUAGE PREFERENCE (ENGLISH / नेपाली)
            // =========================================================================
            item {
                SectionHeader(title = AppStrings.get("lang.title", lang))
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = AppStrings.get("lang.subtitle", lang),
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val isEnglish = lang == AppLanguage.ENGLISH
                            val isNepali = lang == AppLanguage.NEPALI

                            Button(
                                onClick = { viewModel.setLanguage(AppLanguage.ENGLISH) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isEnglish) NavyPrimary else SurfaceMuted,
                                    contentColor = if (isEnglish) Color.White else TextPrimary
                                ),
                                border = if (!isEnglish) BorderStroke(1.dp, BorderSubtle) else null,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("lang_select_en")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (isEnglish) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                    Text(
                                        text = AppStrings.get("lang.english", lang),
                                        fontSize = 13.sp,
                                        fontWeight = if (isEnglish) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }

                            Button(
                                onClick = { viewModel.setLanguage(AppLanguage.NEPALI) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isNepali) NavyPrimary else SurfaceMuted,
                                    contentColor = if (isNepali) Color.White else TextPrimary
                                ),
                                border = if (!isNepali) BorderStroke(1.dp, BorderSubtle) else null,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("lang_select_ne")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (isNepali) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                    Text(
                                        text = AppStrings.get("lang.nepali", lang),
                                        fontSize = 13.sp,
                                        fontWeight = if (isNepali) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 1. DATA SUMMARY CARD
            // =========================================================================
            item {
                SectionHeader(title = AppStrings.get("backup.storage_title", lang))
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = AppStrings.get("backup.storage_desc", lang),
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            DataMetricPill(
                                label = AppStrings.get("nav.invoices", lang),
                                count = transactions.size,
                                modifier = Modifier.weight(1f)
                            )
                            DataMetricPill(
                                label = AppStrings.get("nav.coupons", lang),
                                count = coupons.size,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // =========================================================================
            // 2. JSON BACKUP EXPORT
            // =========================================================================
            item {
                SectionHeader(title = AppStrings.get("backup.export_json_title", lang))
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = AppStrings.get("backup.export_json_desc", lang),
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        Button(
                            onClick = {
                                val json = viewModel.exportBackupJson()
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("RasidKhata Backup", json))
                                viewModel.showSnackbar(AppStrings.get("backup.json_copied", lang))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_export_json")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text(
                                    text = AppStrings.get("backup.copy_json_btn", lang),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 3. RESTORE FROM JSON
            // =========================================================================
            item {
                SectionHeader(title = AppStrings.get("backup.restore_json_title", lang))
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = AppStrings.get("backup.restore_json_desc", lang),
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        OutlinedTextField(
                            value = jsonRestoreText,
                            onValueChange = { jsonRestoreText = it },
                            placeholder = { Text("{\"version\":1,\"transactions\":[...],\"coupons\":[...]}", fontSize = 11.sp) },
                            minLines = 3,
                            maxLines = 6,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("restore_json_input")
                        )

                        Button(
                            onClick = {
                                if (jsonRestoreText.isNotBlank()) {
                                    val success = viewModel.restoreBackupJson(jsonRestoreText, "merge")
                                    if (success) {
                                        jsonRestoreText = ""
                                        viewModel.showSnackbar(AppStrings.get("backup.restore_success", lang))
                                    } else {
                                        viewModel.showSnackbar(AppStrings.get("backup.restore_failed", lang))
                                    }
                                }
                            },
                            enabled = jsonRestoreText.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_confirm_restore")
                        ) {
                            Text(
                                text = AppStrings.get("backup.restore_btn", lang),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // =========================================================================
            // 4. CSV EXPORT
            // =========================================================================
            item {
                SectionHeader(title = AppStrings.get("backup.csv_title", lang))
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val csv = viewModel.exportInvoicesCsv()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Invoices CSV", csv))
                                    viewModel.showSnackbar(AppStrings.get("backup.invoices_csv_copied", lang))
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyContainer, contentColor = NavyPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_export_invoices_csv")
                            ) {
                                Text(AppStrings.get("backup.invoices_csv_btn", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    val csv = viewModel.exportCouponsCsv()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Coupons CSV", csv))
                                    viewModel.showSnackbar(AppStrings.get("backup.coupons_csv_copied", lang))
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyContainer, contentColor = NavyPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_export_coupons_csv")
                            ) {
                                Text(AppStrings.get("backup.coupons_csv_btn", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 5. TESTING TOOLS (DEMO DATA)
            // =========================================================================
            item {
                SectionHeader(title = AppStrings.get("backup.tools_title", lang))
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WarningAmber,
                                    contentDescription = null,
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(18.dp)
                                )
                                Column {
                                    Text(
                                        text = AppStrings.get("backup.demo_banner_title", lang),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF92400E)
                                    )
                                    Text(
                                        text = AppStrings.get("backup.demo_banner_desc", lang),
                                        fontSize = 11.sp,
                                        color = Color(0xFFB45309)
                                    )
                                }
                            }
                        }

                        Text(
                            text = AppStrings.get("backup.demo_desc", lang),
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        OutlinedButton(
                            onClick = {
                                viewModel.loadDemoData()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = NavyPrimary
                            ),
                            border = BorderStroke(1.5.dp, NavyPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_load_demo_data")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text(
                                    text = AppStrings.get("backup.load_demo_btn", lang),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 6. RESET / DANGER ZONE
            // =========================================================================
            item {
                SectionHeader(title = AppStrings.get("backup.danger_title", lang))
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusErrorBg),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, StatusErrorBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = AppStrings.get("backup.danger_desc", lang),
                            fontSize = 12.sp,
                            color = StatusError
                        )

                        Button(
                            onClick = { isResetDialogOpen = true },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_reset_all_data")
                        ) {
                            Text(
                                text = AppStrings.get("backup.clear_all_btn", lang),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // DISCLAIMER
            item {
                DisclaimerBanner()
            }
        }
    }

    // Reset Confirmation Dialog
    if (isResetDialogOpen) {
        AlertDialog(
            onDismissRequest = { isResetDialogOpen = false },
            title = { Text(AppStrings.get("backup.dialog_clear_title", lang), fontWeight = FontWeight.Bold) },
            text = {
                Text(AppStrings.get("backup.dialog_clear_desc", lang))
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetToEmpty()
                        isResetDialogOpen = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text(AppStrings.get("backup.dialog_confirm_clear", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { isResetDialogOpen = false }) {
                    Text(AppStrings.get("common.cancel", lang))
                }
            }
        )
    }
}

@Composable
private fun DataMetricPill(
    label: String,
    count: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SurfaceMuted,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontSize = 12.sp, color = TextSecondary)
            Text(text = "$count", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
        }
    }
}
