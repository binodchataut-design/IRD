package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.data.models.EligibilityStatus
import com.example.data.models.PaymentMethod
import com.example.data.models.Transaction
import com.example.data.utils.CouponUtils
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.EligibilityBadge
import com.example.ui.components.EmptyStateView
import com.example.ui.components.RasidKhataHeader
import com.example.ui.theme.*
import java.util.Locale

enum class InvoiceFilter(val key: String) {
    ALL("filter.all"),
    COUPON_LINKED("filter.coupon_linked"),
    AWAITING_COUPON("filter.awaiting_coupon"),
    DIGITAL_PAYMENT("filter.digital_payment"),
    CASH("filter.cash"),
    WITH_PAN("filter.with_pan")
}

@Composable
fun TransactionsScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current
    val transactions by viewModel.transactions.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(InvoiceFilter.ALL) }

    val filteredTransactions = remember(transactions, searchQuery, selectedFilter) {
        transactions.filter { tx ->
            val matchesQuery = searchQuery.isBlank() ||
                tx.sellerName.contains(searchQuery, ignoreCase = true) ||
                (tx.panVat ?: "").contains(searchQuery) ||
                (tx.invoiceNumber ?: "").contains(searchQuery, ignoreCase = true) ||
                (tx.couponNumber ?: "").contains(searchQuery)

            val matchesFilter = when (selectedFilter) {
                InvoiceFilter.ALL -> true
                InvoiceFilter.COUPON_LINKED -> tx.eligibilityStatus == EligibilityStatus.COUPON_ADDED || !tx.couponNumber.isNullOrBlank()
                InvoiceFilter.AWAITING_COUPON -> tx.eligibilityStatus == EligibilityStatus.AWAITING_COUPON
                InvoiceFilter.DIGITAL_PAYMENT -> tx.paymentMethod in listOf(
                    PaymentMethod.DIGITAL_WALLET,
                    PaymentMethod.QR_PAYMENT,
                    PaymentMethod.MOBILE_BANKING,
                    PaymentMethod.CARD,
                    PaymentMethod.BANK_TRANSFER
                )
                InvoiceFilter.CASH -> tx.paymentMethod == PaymentMethod.CASH
                InvoiceFilter.WITH_PAN -> !tx.panVat.isNullOrBlank()
            }

            matchesQuery && matchesFilter
        }
    }

    val totalAmount = remember(filteredTransactions) {
        filteredTransactions.sumOf { it.amount }
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = AppStrings.get("invoices.title", lang),
                subtitle = "${AppStrings.get("invoices.subtitle", lang)} • ${transactions.size}",
                rightAction = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.AddInvoice) },
                        modifier = Modifier.testTag("invoices_add_header_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = AppStrings.get("invoices.add_btn", lang),
                            tint = NavyPrimary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(Screen.AddInvoice) },
                containerColor = NavyPrimary,
                contentColor = SurfaceCard,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("invoices_fab_add")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = AppStrings.get("invoices.add_btn", lang)
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(AppStrings.get("invoices.search_placeholder", lang), fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = AppStrings.get("common.clear", lang))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NavyPrimary,
                        unfocusedBorderColor = BorderSubtle,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("invoices_search_input")
                )
            }

            // Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(InvoiceFilter.entries.toTypedArray()) { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = {
                                Text(AppStrings.get(filter.key, lang), fontSize = 12.sp)
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NavyContainer,
                                selectedLabelColor = NavyPrimary
                            ),
                            modifier = Modifier.testTag("filter_chip_${filter.name}")
                        )
                    }
                }
            }

            // Totals Summary Strip
            item {
                Surface(
                    color = SurfaceMuted,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${filteredTransactions.size} ${AppStrings.get("invoices.records_count", lang)}",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "NPR ${String.format(Locale.US, "%,.2f", totalAmount)}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = NavyPrimary
                        )
                    }
                }
            }

            // Empty State
            if (filteredTransactions.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.ReceiptLong,
                        title = if (searchQuery.isNotEmpty()) AppStrings.get("invoices.empty_search_title", lang) else AppStrings.get("invoices.empty_title", lang),
                        description = if (searchQuery.isNotEmpty()) AppStrings.get("invoices.empty_search_desc", lang) else AppStrings.get("invoices.empty_desc", lang),
                        actionLabel = AppStrings.get("invoices.add_first_btn", lang),
                        onAction = { viewModel.navigateTo(Screen.AddInvoice) }
                    )
                }
            } else {
                // Invoices List
                items(filteredTransactions, key = { it.id }) { tx ->
                    InvoiceCard(
                        transaction = tx,
                        onClick = { viewModel.viewTransactionDetail(tx.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun InvoiceCard(
    transaction: Transaction,
    onClick: () -> Unit
) {
    val lang = LocalAppLanguage.current

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("invoice_card_${transaction.id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = transaction.sellerName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${AppStrings.get("invoices.detail_date", lang)}: ${transaction.date}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
                Text(
                    text = "NPR ${String.format(Locale.US, "%,.2f", transaction.amount)}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = NavyPrimary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = SurfaceMuted,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = AppStrings.getPaymentMethodLabel(transaction.paymentMethod, lang),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (!transaction.panVat.isNullOrBlank()) {
                        Surface(
                            color = NavyContainer,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "PAN: ${CouponUtils.formatPanNumber(transaction.panVat)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                EligibilityBadge(status = transaction.eligibilityStatus)
            }

            if (!transaction.couponNumber.isNullOrBlank()) {
                Surface(
                    color = TealContainer,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, Color(0xFFCCFBF1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ConfirmationNumber,
                            contentDescription = null,
                            tint = TealAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "${AppStrings.get("invoices.detail_coupon", lang)}: ${CouponUtils.formatCouponNumber(transaction.couponNumber)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = OnTealContainer
                        )
                    }
                }
            }
        }
    }
}
