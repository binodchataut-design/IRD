package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.data.models.*
import com.example.data.services.EligibilityService
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.EligibilityBadge
import com.example.ui.components.RasidKhataHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckEligibilityScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current

    var amountText by remember { mutableStateOf("") }
    var selectedMethod by remember { mutableStateOf(PaymentMethod.QR_PAYMENT) }
    var selectedPurpose by remember { mutableStateOf(PurchasePurpose.PERSONAL) }
    var selectedPanOption by remember { mutableStateOf(SellerPanOption.YES) }
    var selectedCategory by remember { mutableStateOf(TransactionCategory.NORMAL_GOODS) }

    var expandedMethod by remember { mutableStateOf(false) }
    var expandedPurpose by remember { mutableStateOf(false) }
    var expandedCategory by remember { mutableStateOf(false) }
    var expandedPan by remember { mutableStateOf(false) }

    val amountDouble = amountText.toDoubleOrNull() ?: 0.0

    val eligibilityResult: TransactionEligibilityResult? = remember(
        amountDouble, selectedMethod, selectedPurpose, selectedPanOption, selectedCategory, lang
    ) {
        if (amountDouble > 0) {
            val input = TransactionEligibilityInput(
                amount = amountDouble,
                paymentMethod = selectedMethod,
                purpose = selectedPurpose,
                sellerPan = selectedPanOption,
                category = selectedCategory
            )
            EligibilityService.checkEligibility(input, lang)
        } else {
            null
        }
    }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = AppStrings.get("calculator.title", lang),
                subtitle = AppStrings.get("calculator.subtitle", lang),
                showBack = true,
                onBack = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // STEP 1: BILL AMOUNT
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = AppStrings.get("calculator.step1_title", lang),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text(AppStrings.get("calculator.step1_label", lang)) },
                            placeholder = { Text("1500") },
                            leadingIcon = {
                                Text("NPR", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("calc_amount_input")
                        )

                        if (amountDouble > 0 && amountDouble <= 100) {
                            Text(
                                text = "⚠️ ${AppStrings.get("calculator.amount_warning", lang)}",
                                fontSize = 11.sp,
                                color = StatusError
                            )
                        }
                    }
                }
            }

            // STEP 2: PAYMENT METHOD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = AppStrings.get("calculator.step2_title", lang),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        ExposedDropdownMenuBox(
                            expanded = expandedMethod,
                            onExpandedChange = { expandedMethod = !expandedMethod }
                        ) {
                            OutlinedTextField(
                                value = selectedMethod.getLocalizedName(lang),
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedMethod) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = expandedMethod,
                                onDismissRequest = { expandedMethod = false }
                            ) {
                                PaymentMethod.entries.forEach { method ->
                                    DropdownMenuItem(
                                        text = { Text(method.getLocalizedName(lang)) },
                                        onClick = {
                                            selectedMethod = method
                                            expandedMethod = false
                                        }
                                    )
                                }
                            }
                        }

                        if (selectedMethod == PaymentMethod.CASH) {
                            Text(
                                text = "⚠️ ${AppStrings.get("calculator.cash_warning", lang)}",
                                fontSize = 11.sp,
                                color = StatusError
                            )
                        }
                    }
                }
            }

            // STEP 3: SELLER PAN/VAT STATUS
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = AppStrings.get("calculator.step3_title", lang),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        ExposedDropdownMenuBox(
                            expanded = expandedPan,
                            onExpandedChange = { expandedPan = !expandedPan }
                        ) {
                            OutlinedTextField(
                                value = selectedPanOption.getLocalizedName(lang),
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPan) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = expandedPan,
                                onDismissRequest = { expandedPan = false }
                            ) {
                                SellerPanOption.entries.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.getLocalizedName(lang)) },
                                        onClick = {
                                            selectedPanOption = option
                                            expandedPan = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // STEP 4: PURCHASE PURPOSE & CATEGORY
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = AppStrings.get("calculator.step4_title", lang),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        ExposedDropdownMenuBox(
                            expanded = expandedPurpose,
                            onExpandedChange = { expandedPurpose = !expandedPurpose }
                        ) {
                            OutlinedTextField(
                                value = selectedPurpose.getLocalizedName(lang),
                                onValueChange = {},
                                readOnly = true,
                                label = { Text(AppStrings.get("calculator.purpose_label", lang)) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPurpose) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = expandedPurpose,
                                onDismissRequest = { expandedPurpose = false }
                            ) {
                                PurchasePurpose.entries.forEach { purpose ->
                                    DropdownMenuItem(
                                        text = { Text(purpose.getLocalizedName(lang)) },
                                        onClick = {
                                            selectedPurpose = purpose
                                            expandedPurpose = false
                                        }
                                    )
                                }
                            }
                        }

                        ExposedDropdownMenuBox(
                            expanded = expandedCategory,
                            onExpandedChange = { expandedCategory = !expandedCategory }
                        ) {
                            OutlinedTextField(
                                value = selectedCategory.getLocalizedName(lang),
                                onValueChange = {},
                                readOnly = true,
                                label = { Text(AppStrings.get("calculator.category_label", lang)) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCategory) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = expandedCategory,
                                onDismissRequest = { expandedCategory = false }
                            ) {
                                TransactionCategory.entries.forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category.getLocalizedName(lang)) },
                                        onClick = {
                                            selectedCategory = category
                                            expandedCategory = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // STEP 5: LIVE RESULT CARD
            if (eligibilityResult != null) {
                item {
                    SectionHeader(
                        title = AppStrings.get("calculator.result_header", lang)
                    )
                }

                item {
                    val statusCardBorder = when (eligibilityResult.status) {
                        EligibilityStatus.LIKELY_ELIGIBLE, EligibilityStatus.COUPON_ADDED -> StatusSuccessBorder
                        EligibilityStatus.NEEDS_VERIFICATION, EligibilityStatus.AWAITING_COUPON -> StatusPendingBorder
                        EligibilityStatus.LIKELY_NOT_ELIGIBLE -> StatusErrorBorder
                        EligibilityStatus.NOT_CHECKED -> BorderSubtle
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.5.dp, statusCardBorder),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                EligibilityBadge(status = eligibilityResult.status)
                            }

                            Text(
                                text = eligibilityResult.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )

                            eligibilityResult.reasons.forEach { reason ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = NavyPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = reason,
                                        fontSize = 11.sp,
                                        color = TextPrimary,
                                        lineHeight = 15.sp
                                    )
                                }
                            }

                            if (eligibilityResult.status == EligibilityStatus.LIKELY_ELIGIBLE) {
                                Button(
                                    onClick = {
                                        viewModel.navigateTo(Screen.AddInvoice)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 6.dp)
                                ) {
                                    Text(
                                        text = AppStrings.get("calculator.save_invoice_btn", lang),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // DISCLAIMER
            item {
                DisclaimerBanner()
            }
        }
    }
}
