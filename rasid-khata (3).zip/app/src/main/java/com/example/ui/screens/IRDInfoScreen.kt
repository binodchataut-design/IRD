package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.ui.RasidKhataViewModel
import com.example.ui.Screen
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.RasidKhataHeader
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun IRDInfoScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current
    var isForeignSectionExpanded by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = AppStrings.get("info.title", lang),
                subtitle = AppStrings.get("info.subtitle", lang),
                rightAction = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.DataBackup) },
                        modifier = Modifier.testTag("info_backup_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudSync,
                            contentDescription = AppStrings.get("backup.title", lang),
                            tint = NavyPrimary
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. OPENING SECTION: HOW THE IRD SCHEME WORKS (5-STEP GUIDE)
            item {
                SectionHeader(
                    title = AppStrings.get("info.how_it_works_header", lang)
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        InfoStepRow(
                            stepNumber = if (lang == AppLanguage.NEPALI) "१" else "1",
                            title = AppStrings.get("info.step_1", lang),
                            subtitle = AppStrings.get("info.step_1_sub", lang)
                        )
                        InfoStepRow(
                            stepNumber = if (lang == AppLanguage.NEPALI) "२" else "2",
                            title = AppStrings.get("info.step_2", lang),
                            subtitle = AppStrings.get("info.step_2_sub", lang)
                        )
                        InfoStepRow(
                            stepNumber = if (lang == AppLanguage.NEPALI) "३" else "3",
                            title = AppStrings.get("info.step_3", lang),
                            subtitle = AppStrings.get("info.step_3_sub", lang)
                        )
                        InfoStepRow(
                            stepNumber = if (lang == AppLanguage.NEPALI) "४" else "4",
                            title = AppStrings.get("info.step_4", lang),
                            subtitle = AppStrings.get("info.step_4_sub", lang)
                        )
                        InfoStepRow(
                            stepNumber = if (lang == AppLanguage.NEPALI) "५" else "5",
                            title = AppStrings.get("info.step_5", lang),
                            subtitle = AppStrings.get("info.step_5_sub", lang)
                        )
                    }
                }
            }

            // 2. IRD CONSUMER INCENTIVE SCHEME OVERVIEW CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Gavel,
                                contentDescription = null,
                                tint = NavyPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = AppStrings.get("info.scheme_title", lang),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Text(
                            text = AppStrings.get("info.scheme_desc", lang),
                            fontSize = 13.sp,
                            color = TextSecondary,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // 3. NEW SECTION: FOR FOREIGN VISITORS & RESIDENTS (COLLAPSIBLE EXPLAINER)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("foreign_explainer_header"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(NavyContainer, shape = RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Public,
                                        contentDescription = null,
                                        tint = NavyPrimary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Column {
                                    Text(
                                        text = AppStrings.get("info.foreign.header", lang),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = AppStrings.get("info.foreign.badge", lang),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TealAccent
                                    )
                                }
                            }

                            IconButton(
                                onClick = { isForeignSectionExpanded = !isForeignSectionExpanded },
                                modifier = Modifier.testTag("foreign_explainer_toggle")
                            ) {
                                Icon(
                                    imageVector = if (isForeignSectionExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = TextSecondary
                                )
                            }
                        }

                        if (isForeignSectionExpanded) {
                            HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

                            Text(
                                text = AppStrings.get("info.foreign.intro", lang),
                                fontSize = 13.sp,
                                color = TextSecondary,
                                lineHeight = 19.sp
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                ForeignGuideItem(
                                    icon = Icons.Default.Badge,
                                    iconColor = StatusPending,
                                    title = AppStrings.get("info.foreign.pan_title", lang),
                                    description = AppStrings.get("info.foreign.pan_desc", lang)
                                )

                                ForeignGuideItem(
                                    icon = Icons.Default.Timer,
                                    iconColor = NavyPrimary,
                                    title = AppStrings.get("info.foreign.docs_title", lang),
                                    description = AppStrings.get("info.foreign.docs_desc", lang)
                                )

                                ForeignGuideItem(
                                    icon = Icons.Default.Receipt,
                                    iconColor = StatusPending,
                                    title = AppStrings.get("info.foreign.invoice_title", lang),
                                    description = AppStrings.get("info.foreign.invoice_desc", lang)
                                )

                                ForeignGuideItem(
                                    icon = Icons.Default.AccountBalance,
                                    iconColor = TealAccent,
                                    title = AppStrings.get("info.foreign.tax_title", lang),
                                    description = AppStrings.get("info.foreign.tax_desc", lang)
                                )

                                ForeignGuideItem(
                                    icon = Icons.Default.HelpOutline,
                                    iconColor = NavyPrimary,
                                    title = AppStrings.get("info.foreign.inquiry_title", lang),
                                    description = AppStrings.get("info.foreign.inquiry_desc", lang)
                                )
                            }
                        }
                    }
                }
            }

            // 3. ELIGIBILITY CRITERIA
            item {
                SectionHeader(
                    title = AppStrings.get("info.conditions_header", lang)
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ConditionItem(AppStrings.get("info.cond_1", lang))
                        ConditionItem(AppStrings.get("info.cond_2", lang))
                        ConditionItem(AppStrings.get("info.cond_3", lang))
                        ConditionItem(AppStrings.get("info.cond_4", lang))
                        ConditionItem(AppStrings.get("info.cond_5", lang))
                    }
                }
            }

            // 4. PRIZE LOTTERY TIERS
            item {
                SectionHeader(
                    title = AppStrings.get("info.prize_structure_header", lang)
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PrizeRow(tier = AppStrings.get("info.prize_1st_label", lang), amount = if (lang == AppLanguage.NEPALI) "रु. ५०,०००" else "NPR 50,000")
                        PrizeRow(tier = AppStrings.get("info.prize_2nd_label", lang), amount = if (lang == AppLanguage.NEPALI) "रु. ३०,०००" else "NPR 30,000")
                        PrizeRow(tier = AppStrings.get("info.prize_3rd_label", lang), amount = if (lang == AppLanguage.NEPALI) "रु. २०,०००" else "NPR 20,000")
                        PrizeRow(tier = AppStrings.get("info.prize_cons_label", lang), amount = if (lang == AppLanguage.NEPALI) "रु. ५,००० (१० जना)" else "NPR 5,000 (10 Winners)")
                    }
                }
            }

            // 5. ACTION BUTTON TO ELIGIBILITY SIMULATOR
            item {
                Button(
                    onClick = { viewModel.navigateTo(Screen.CheckEligibility) },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "✓ ${AppStrings.get("info.open_calculator_btn", lang)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }

            // 6. DISCLAIMER
            item {
                DisclaimerBanner()
            }
        }
    }
}

@Composable
private fun InfoStepRow(
    stepNumber: String,
    title: String,
    subtitle: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .background(NavyContainer, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNumber,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
        }

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun ConditionItem(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = null,
            tint = TealAccent,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = text,
            fontSize = 13.sp,
            color = TextPrimary,
            lineHeight = 18.sp
        )
    }
}

@Composable
private fun PrizeRow(tier: String, amount: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = tier, fontSize = 13.sp, color = TextPrimary)
        Text(text = amount, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldWinner)
    }
}

@Composable
private fun ForeignGuideItem(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconColor,
            modifier = Modifier
                .size(18.dp)
                .padding(top = 2.dp)
        )
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Text(
                text = description,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 17.sp
            )
        }
    }
}
