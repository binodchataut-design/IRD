package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.localization.AppLanguage
import com.example.data.models.*
import com.example.data.repository.AppRepository
import com.example.data.services.IRDInfoService
import com.example.data.services.NepaliDateService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn

sealed class Screen(val route: String) {
    data object Welcome : Screen("welcome")
    data object Home : Screen("home")
    data object Invoices : Screen("invoices")
    data object AddInvoice : Screen("add_invoice")
    data object InvoiceDetail : Screen("invoice_detail")
    data object Coupons : Screen("coupons")
    data object AddCoupon : Screen("add_coupon")
    data object BulkAddCoupons : Screen("bulk_add_coupons")
    data object WinnerChecker : Screen("winner_checker")
    data object ClaimReport : Screen("claim_report")
    data object DrawHistory : Screen("draw_history")
    data object CheckEligibility : Screen("check_eligibility")
    data object IRDInfo : Screen("ird_info")
    data object DataBackup : Screen("data_backup")
}

class RasidKhataViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)

    val transactions: StateFlow<List<Transaction>> = repository.transactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val coupons: StateFlow<List<Coupon>> = repository.coupons
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val drawAnnouncements: StateFlow<List<DrawAnnouncement>> = repository.drawAnnouncements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val language: StateFlow<AppLanguage> = repository.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppLanguage.ENGLISH)

    val notices: List<IRDNotice> = IRDInfoService.getAll()

    // Navigation Stack
    private val initialScreen = if (repository.hasSeenWelcome()) Screen.Home else Screen.Welcome
    private val _currentScreen = MutableStateFlow<Screen>(initialScreen)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf<Screen>(initialScreen)

    // Selection States
    private val _selectedTransaction = MutableStateFlow<Transaction?>(null)
    val selectedTransaction: StateFlow<Transaction?> = _selectedTransaction.asStateFlow()

    private val _selectedNoticeId = MutableStateFlow<String?>(null)
    val selectedNoticeId: StateFlow<String?> = _selectedNoticeId.asStateFlow()

    private val _winnerCheckResult = MutableStateFlow<WinnerCheckResult?>(null)
    val winnerCheckResult: StateFlow<WinnerCheckResult?> = _winnerCheckResult.asStateFlow()

    private val _activeClaimReport = MutableStateFlow<ClaimReportData?>(null)
    val activeClaimReport: StateFlow<ClaimReportData?> = _activeClaimReport.asStateFlow()

    private val _prefillCouponNumber = MutableStateFlow<String?>(null)
    val prefillCouponNumber: StateFlow<String?> = _prefillCouponNumber.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    fun completeWelcome() {
        repository.setHasSeenWelcome(true)
        screenStack.clear()
        screenStack.add(Screen.Home)
        _currentScreen.value = Screen.Home
    }

    fun navigateTo(screen: Screen) {
        screenStack.add(screen)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.size - 1)
            _currentScreen.value = screenStack.last()
            return true
        }
        return false
    }

    fun showSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun viewTransactionDetail(transactionId: String) {
        val tx = repository.getTransactionById(transactionId)
        _selectedTransaction.value = tx
        navigateTo(Screen.InvoiceDetail)
    }

    fun openClaimReport(data: ClaimReportData) {
        _activeClaimReport.value = data
        navigateTo(Screen.ClaimReport)
    }

    fun openAddCouponWithPrefill(couponNum: String? = null) {
        _prefillCouponNumber.value = couponNum
        navigateTo(Screen.AddCoupon)
    }

    fun selectNotice(noticeId: String) {
        _selectedNoticeId.value = noticeId
        navigateTo(Screen.IRDInfo)
    }

    // --- Actions ---

    fun addTransaction(
        date: String,
        sellerName: String,
        amount: Double,
        paymentMethod: PaymentMethod,
        panVat: String?,
        invoiceNumber: String?,
        couponNumber: String?,
        notes: String?
    ): Transaction {
        val created = repository.addTransaction(
            date = date,
            sellerName = sellerName,
            amount = amount,
            paymentMethod = paymentMethod,
            panVat = panVat,
            invoiceNumber = invoiceNumber,
            couponNumber = couponNumber,
            notes = notes
        )
        showSnackbar("Invoice saved successfully!")
        return created
    }

    fun deleteTransaction(id: String) {
        if (repository.deleteTransaction(id)) {
            showSnackbar("Invoice deleted.")
            if (_currentScreen.value == Screen.InvoiceDetail) {
                navigateBack()
            }
        }
    }

    fun linkCouponToTransaction(transactionId: String, couponNumber: String) {
        repository.updateTransactionCoupon(transactionId, couponNumber)
        _selectedTransaction.value = repository.getTransactionById(transactionId)
        showSnackbar("12-digit Coupon linked to invoice!")
    }

    fun addCoupon(
        couponNumber: String,
        date: String? = null,
        drawPeriod: String? = null,
        merchantName: String? = null,
        amount: Double? = null,
        paymentMethod: String? = null,
        invoiceNumber: String? = null,
        notes: String? = null
    ): Boolean {
        val created = repository.addCoupon(
            couponNumber = couponNumber,
            date = date,
            drawPeriod = drawPeriod,
            merchantName = merchantName,
            amount = amount,
            paymentMethod = paymentMethod,
            invoiceNumber = invoiceNumber,
            notes = notes
        )
        return if (created != null) {
            showSnackbar("Coupon added successfully!")
            true
        } else {
            showSnackbar("Invalid 12-digit coupon number.")
            false
        }
    }

    fun addBulkCoupons(numbers: List<String>): Int {
        val count = repository.addBulkCoupons(numbers)
        showSnackbar("Imported $count valid prize coupons!")
        return count
    }

    fun deleteCoupon(id: String) {
        if (repository.deleteCoupon(id)) {
            showSnackbar("Coupon removed.")
        }
    }

    fun addCustomDraw(
        title: String,
        drawPeriod: String,
        announcementDate: String,
        winningNumbers: List<String>,
        notes: String? = null
    ) {
        repository.addDrawAnnouncement(
            title = title,
            drawPeriod = drawPeriod,
            announcementDate = announcementDate,
            winningNumbers = winningNumbers,
            notes = notes
        )
        showSnackbar("Draw announcement added!")
    }

    fun runWinnerCheck(
        winningNumbers: List<String>,
        drawTitle: String? = null,
        drawPeriod: String? = null,
        announcementDate: String? = null
    ): WinnerCheckResult {
        val result = repository.checkWinners(
            winningNumbers = winningNumbers,
            drawTitle = drawTitle,
            drawPeriod = drawPeriod,
            announcementDate = announcementDate
        )
        _winnerCheckResult.value = result
        return result
    }

    fun exportBackupJson(): String = repository.exportBackupJson()

    fun restoreBackupJson(json: String, mode: String): Boolean {
        val ok = repository.restoreBackupJson(json, mode)
        if (ok) {
            showSnackbar("Data restored successfully!")
        } else {
            showSnackbar("Failed to restore backup: invalid JSON.")
        }
        return ok
    }

    fun exportInvoicesCsv(): String = repository.exportTransactionsCsv()
    fun exportCouponsCsv(): String = repository.exportCouponsCsv()

    fun setLanguage(lang: AppLanguage) {
        repository.setLanguage(lang)
    }

    fun resetToEmpty() {
        repository.resetToEmpty()
        _winnerCheckResult.value = null
        showSnackbar("सबै डेटा खाली गरियो (All data cleared).")
    }

    fun loadDemoData() {
        repository.loadDemoData()
        _winnerCheckResult.value = null
        showSnackbar("परीक्षण नमुना डेटा लोड भयो (Demo sample data loaded).")
    }

    fun resetToDefaults() {
        resetToEmpty()
    }
}
