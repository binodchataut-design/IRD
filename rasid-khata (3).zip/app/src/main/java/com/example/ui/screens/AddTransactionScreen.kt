package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppLanguage
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.data.models.*
import com.example.data.services.EligibilityService
import com.example.data.services.NepaliDateService
import com.example.data.utils.CouponUtils
import com.example.ui.RasidKhataViewModel
import com.example.ui.components.EligibilityBadge
import com.example.ui.components.RasidKhataHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current
    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    var date by remember { mutableStateOf(todayStr) }
    var sellerName by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.DIGITAL_WALLET) }
    var panVat by remember { mutableStateOf("") }
    var invoiceNumber by remember { mutableStateOf("") }
    var couponNumber by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var isPaymentDropdownExpanded by remember { mutableStateOf(false) }

    val amountValue = amountText.toDoubleOrNull() ?: 0.0
    val normalizedCoupon = CouponUtils.normalizeCouponNumber(couponNumber)
    val drawPeriodInfo = remember(date) { NepaliDateService.getDrawPeriodInfo(date) }

    // Live Eligibility Preview
    val liveResult = remember(amountValue, paymentMethod, panVat, date) {
        val input = TransactionEligibilityInput(
            amount = amountValue,
            paymentMethod = paymentMethod,
            purpose = PurchasePurpose.PERSONAL,
            sellerPan = if (panVat.isNotBlank()) SellerPanOption.YES else SellerPanOption.DONT_KNOW,
            sellerPanNumber = panVat,
            sellerName = sellerName,
            category = TransactionCategory.NORMAL_GOODS,
            date = date,
            invoiceNumber = invoiceNumber
        )
        EligibilityService.checkEligibility(input)
    }

    val isValid = sellerName.isNotBlank() && amountValue > 0.0

    Scaffold(
        topBar = {
            RasidKhataHeader(
                title = AppStrings.get("add_invoice.title", lang),
                subtitle = AppStrings.get("add_invoice.subtitle", lang),
                showBack = true,
                onBack = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. PURCHASE DETAILS
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = null,
                                tint = NavyPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = AppStrings.get("add_invoice.section_purchase", lang),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        OutlinedTextField(
                            value = sellerName,
                            onValueChange = { sellerName = it },
                            label = { Text("${AppStrings.get("add_invoice.merchant_name", lang)} *") },
                            placeholder = { Text(AppStrings.get("add_invoice.merchant_placeholder", lang)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_invoice_merchant_input")
                        )

                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("${AppStrings.get("add_invoice.amount_npr", lang)} *") },
                            placeholder = { Text(AppStrings.get("add_invoice.amount_placeholder", lang)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            leadingIcon = {
                                Text(
                                    text = "NPR",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = NavyPrimary,
                                    modifier = Modifier.padding(start = 12.dp, end = 4.dp)
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_invoice_amount_input")
                        )

                        OutlinedTextField(
                            value = date,
                            onValueChange = { date = it },
                            label = { Text(AppStrings.get("add_invoice.date_label", lang)) },
                            singleLine = true,
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = TextSecondary)
                            },
                            supportingText = {
                                Text("${AppStrings.get("add_invoice.draw_cycle_estimate", lang)}: ${drawPeriodInfo.drawPeriod}", fontSize = 10.sp)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_invoice_date_input")
                        )
                    }
                }
            }

            // 2. PAYMENT METHOD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Payment,
                                contentDescription = null,
                                tint = NavyPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = AppStrings.get("add_invoice.section_payment", lang),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        ExposedDropdownMenuBox(
                            expanded = isPaymentDropdownExpanded,
                            onExpandedChange = { isPaymentDropdownExpanded = !isPaymentDropdownExpanded }
                        ) {
                            OutlinedTextField(
                                value = AppStrings.getPaymentMethodLabel(paymentMethod, lang),
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("${AppStrings.get("add_invoice.payment_mode", lang)} *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isPaymentDropdownExpanded) },
                                leadingIcon = { Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = NavyPrimary) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                                    .testTag("add_invoice_payment_dropdown")
                            )

                            ExposedDropdownMenu(
                                expanded = isPaymentDropdownExpanded,
                                onDismissRequest = { isPaymentDropdownExpanded = false }
                            ) {
                                PaymentMethod.entries.forEach { method ->
                                    DropdownMenuItem(
                                        text = { Text(AppStrings.getPaymentMethodLabel(method, lang)) },
                                        onClick = {
                                            paymentMethod = method
                                            isPaymentDropdownExpanded = false
                                        },
                                        modifier = Modifier.testTag("payment_method_${method.name}")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. INVOICE & PAN METADATA
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderSubtle),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Receipt,
                                contentDescription = null,
                                tint = NavyPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = AppStrings.get("add_invoice.section_tax_coupon", lang),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        OutlinedTextField(
                            value = panVat,
                            onValueChange = { panVat = it },
                            label = { Text(AppStrings.get("add_invoice.pan_vat", lang)) },
                            placeholder = { Text("601928374") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            trailingIcon = {
                                if (panVat.isNotBlank()) {
                                    val is9Digits = panVat.filter { it.isDigit() }.length == 9
                                    Icon(
                                        imageVector = if (is9Digits) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                        contentDescription = null,
                                        tint = if (is9Digits) StatusSuccess else StatusPending
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_invoice_pan_input")
                        )

                        OutlinedTextField(
                            value = invoiceNumber,
                            onValueChange = { invoiceNumber = it },
                            label = { Text(AppStrings.get("add_invoice.invoice_ref", lang)) },
                            placeholder = { Text("INV-2083-9910") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_invoice_number_input")
                        )

                        OutlinedTextField(
                            value = couponNumber,
                            onValueChange = { couponNumber = it },
                            label = { Text(AppStrings.get("add_invoice.coupon_label", lang)) },
                            placeholder = { Text("007 315 254 493") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.ConfirmationNumber, contentDescription = null, tint = NavyPrimary)
                            },
                            supportingText = {
                                Text(
                                    text = if (normalizedCoupon.isNotEmpty()) {
                                        "${normalizedCoupon.length}/12 • ${CouponUtils.formatCouponNumber(normalizedCoupon)}"
                                    } else AppStrings.get("add_invoice.coupon_hint", lang),
                                    fontSize = 10.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_invoice_coupon_input")
                        )

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text(AppStrings.get("add_invoice.notes_label", lang)) },
                            placeholder = { Text(AppStrings.get("add_invoice.notes_placeholder", lang)) },
                            maxLines = 2,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_invoice_notes_input")
                        )
                    }
                }
            }

            // 4. LIVE ELIGIBILITY PREVIEW
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (liveResult.status == EligibilityStatus.LIKELY_ELIGIBLE) StatusSuccessBg else StatusPendingBg
                    ),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        1.dp,
                        if (liveResult.status == EligibilityStatus.LIKELY_ELIGIBLE) StatusSuccessBorder else StatusPendingBorder
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = AppStrings.get("add_invoice.eligibility_preview", lang),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            EligibilityBadge(status = liveResult.status)
                        }

                        Text(
                            text = liveResult.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        liveResult.reasons.take(2).forEach { reason ->
                            Text(
                                text = "• $reason",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            // 5. SAVE BUTTON
            item {
                Button(
                    onClick = {
                        if (isValid) {
                            viewModel.addTransaction(
                                date = date,
                                sellerName = sellerName,
                                amount = amountValue,
                                paymentMethod = paymentMethod,
                                panVat = panVat,
                                invoiceNumber = invoiceNumber,
                                couponNumber = normalizedCoupon,
                                notes = notes
                            )
                            viewModel.showSnackbar(AppStrings.get("add_invoice.save_success", lang))
                            viewModel.navigateBack()
                        }
                    },
                    enabled = isValid,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NavyPrimary,
                        contentColor = SurfaceCard
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("add_invoice_save_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Text(
                            text = AppStrings.get("add_invoice.save_btn", lang),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
