package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// RASID KHATA DESIGN SYSTEM (रसिद खाता)
// Modern Nepali Consumer Fintech Palette
// ==========================================

// Primary Palette: Trust Navy & Action Blue
val NavyPrimary = Color(0xFF1E3A8A)        // Deep Trust Navy
val NavyPrimaryDark = Color(0xFF0F2459)    // Dark Navy
val NavyPrimaryLight = Color(0xFF2563EB)   // Action Blue
val NavyContainer = Color(0xFFEFF6FF)      // Light Tint Container
val OnNavyContainer = Color(0xFF1E3A8A)

// Secondary Accent: Modern Himalayan Teal
val TealAccent = Color(0xFF0D9488)         // Teal Accent
val TealContainer = Color(0xFFF0FDFA)      // Light Teal Container
val OnTealContainer = Color(0xFF115E59)

// Semantic Status Colors (Strictly purposeful)
// Green -> Success, Eligible, Match Found, Completed
val StatusSuccess = Color(0xFF059669)
val StatusSuccessBg = Color(0xFFECFDF5)
val StatusSuccessBorder = Color(0xFFA7F3D0)

// Amber -> Pending, Awaiting Coupon, Needs Verification
val StatusPending = Color(0xFFD97706)
val StatusPendingBg = Color(0xFFFFFBEB)
val StatusPendingBorder = Color(0xFFFDE68A)

// Red -> Ineligible, Important Warning, Error
val StatusError = Color(0xFFDC2626)
val StatusErrorBg = Color(0xFFFEF2F2)
val StatusErrorBorder = Color(0xFFFECACA)

// Blue -> Info, Educational, Official Notes
val StatusInfo = Color(0xFF2563EB)
val StatusInfoBg = Color(0xFFEFF6FF)
val StatusInfoBorder = Color(0xFFBFDBFE)

// Tertiary Accent: Warm Gold (Used strictly for Winner Highlights & Celebrations)
val GoldWinner = Color(0xFFD97706)
val GoldWinnerContainer = Color(0xFFFEF3C7)
val OnGoldWinner = Color(0xFF78350F)

// Neutral Canvas & Surface Colors
val BackgroundCanvas = Color(0xFFF8FAFC)   // Slate-50 Soft Neutral
val SurfaceCard = Color(0xFFFFFFFF)        // Pure White Surface
val SurfaceMuted = Color(0xFFF1F5F9)       // Slate-100 Chip/Container
val BorderSubtle = Color(0xFFE2E8F0)       // Slate-200 Border
val BorderDivider = Color(0xFFE2E8F0)      // Slate-200 Divider

// Typography Hierarchy Colors
val TextPrimary = Color(0xFF0F172A)        // Slate-900 High Contrast
val TextSecondary = Color(0xFF475569)      // Slate-600 Medium
val TextMuted = Color(0xFF94A3B8)          // Slate-400 Subtle

// Dark Theme Variants
val DarkBackground = Color(0xFF0B1120)     // Slate-950
val DarkSurface = Color(0xFF1E293B)        // Slate-800
val DarkSurfaceMuted = Color(0xFF334155)   // Slate-700
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF334155)
