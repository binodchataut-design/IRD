package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.localization.AppStrings
import com.example.data.localization.LocalAppLanguage
import com.example.ui.RasidKhataViewModel
import com.example.ui.theme.*

@Composable
fun WelcomeScreen(
    viewModel: RasidKhataViewModel,
    modifier: Modifier = Modifier
) {
    val lang = LocalAppLanguage.current
    var currentStep by remember { mutableIntStateOf(0) }
    val totalSteps = 3

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = AppStrings.get("app.name", lang),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                        Text(
                            text = AppStrings.get("welcome.tag", lang),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TealAccent,
                            letterSpacing = 0.5.sp
                        )
                    }

                    TextButton(
                        onClick = { viewModel.completeWelcome() },
                        modifier = Modifier.testTag("welcome_skip_button")
                    ) {
                        Text(
                            text = AppStrings.get("welcome.skip", lang),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentStep > 0) {
                        OutlinedButton(
                            onClick = { currentStep -= 1 },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, BorderSubtle),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("welcome_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = AppStrings.get("welcome.back", lang),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    val isLastStep = currentStep == totalSteps - 1
                    Button(
                        onClick = {
                            if (isLastStep) {
                                viewModel.completeWelcome()
                            } else {
                                currentStep += 1
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        modifier = Modifier
                            .weight(if (currentStep > 0) 1.6f else 1f)
                            .height(48.dp)
                            .testTag(if (isLastStep) "welcome_get_started_button" else "welcome_next_button")
                    ) {
                        Text(
                            text = if (isLastStep) {
                                AppStrings.get("welcome.get_started", lang)
                            } else {
                                AppStrings.get("welcome.next", lang)
                            },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        if (!isLastStep) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Step Indicator Dots & Label
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AppStrings.get("welcome.step_indicator", lang, currentStep + 1, totalSteps),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until totalSteps) {
                        Box(
                            modifier = Modifier
                                .size(
                                    width = if (i == currentStep) 24.dp else 8.dp,
                                    height = 8.dp
                                )
                                .background(
                                    color = if (i == currentStep) NavyPrimary else BorderSubtle,
                                    shape = CircleShape
                                )
                        )
                    }
                }
            }

            AnimatedContent(
                targetState = currentStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "welcome_step_card"
            ) { step ->
                when (step) {
                    0 -> WelcomeCard1(lang = lang)
                    1 -> WelcomeCard2(lang = lang)
                    2 -> WelcomeCard3(lang = lang)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun WelcomeCard1(lang: com.example.data.localization.AppLanguage) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(NavyContainer, shape = RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ReceiptLong,
                    contentDescription = null,
                    tint = NavyPrimary,
                    modifier = Modifier.size(30.dp)
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = AppStrings.get("welcome.card1.title", lang),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = AppStrings.get("welcome.card1.subtitle", lang),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = TealAccent
                )
            }

            Text(
                text = AppStrings.get("welcome.card1.body", lang),
                fontSize = 14.sp,
                color = TextSecondary,
                lineHeight = 21.sp
            )

            HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                WelcomeBulletPoint(
                    icon = Icons.Default.QrCodeScanner,
                    iconTint = NavyPrimary,
                    text = AppStrings.get("welcome.card1.point1", lang)
                )
                WelcomeBulletPoint(
                    icon = Icons.Default.CheckCircle,
                    iconTint = TealAccent,
                    text = AppStrings.get("welcome.card1.point2", lang)
                )
            }
        }
    }
}

@Composable
private fun WelcomeCard2(lang: com.example.data.localization.AppLanguage) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(StatusPendingBg, shape = RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Badge,
                    contentDescription = null,
                    tint = StatusPending,
                    modifier = Modifier.size(30.dp)
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = AppStrings.get("welcome.card2.title", lang),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = AppStrings.get("welcome.card2.subtitle", lang),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = StatusPending
                )
            }

            Text(
                text = AppStrings.get("welcome.card2.body", lang),
                fontSize = 14.sp,
                color = TextSecondary,
                lineHeight = 21.sp
            )

            HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                WelcomeBulletPoint(
                    icon = Icons.Default.Lock,
                    iconTint = StatusPending,
                    text = AppStrings.get("welcome.card2.point1", lang)
                )
                WelcomeBulletPoint(
                    icon = Icons.Default.HelpOutline,
                    iconTint = NavyPrimary,
                    text = AppStrings.get("welcome.card2.point2", lang)
                )
                WelcomeBulletPoint(
                    icon = Icons.Default.CheckCircle,
                    iconTint = TealAccent,
                    text = AppStrings.get("welcome.card2.point3", lang)
                )
            }
        }
    }
}

@Composable
private fun WelcomeCard3(lang: com.example.data.localization.AppLanguage) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(NavyContainer, shape = RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Groups,
                    contentDescription = null,
                    tint = NavyPrimary,
                    modifier = Modifier.size(30.dp)
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = AppStrings.get("welcome.card3.title", lang),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = AppStrings.get("welcome.card3.subtitle", lang),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = TealAccent
                )
            }

            Text(
                text = AppStrings.get("welcome.card3.body", lang),
                fontSize = 14.sp,
                color = TextSecondary,
                lineHeight = 21.sp
            )

            HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                WelcomeBulletPoint(
                    icon = Icons.Default.ConfirmationNumber,
                    iconTint = NavyPrimary,
                    text = AppStrings.get("welcome.card3.point1", lang)
                )
                WelcomeBulletPoint(
                    icon = Icons.Default.Description,
                    iconTint = TealAccent,
                    text = AppStrings.get("welcome.card3.point2", lang)
                )
            }
        }
    }
}

@Composable
private fun WelcomeBulletPoint(
    icon: ImageVector,
    iconTint: Color,
    text: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier
                .size(18.dp)
                .padding(top = 2.dp)
        )
        Text(
            text = text,
            fontSize = 13.sp,
            color = TextPrimary,
            lineHeight = 19.sp
        )
    }
}
