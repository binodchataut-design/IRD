package com.billlinus.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.service.DrawResultService
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppBottomNav
import com.billlinus.app.ui.theme.Amber100
import com.billlinus.app.ui.theme.Amber500
import com.billlinus.app.ui.theme.Amber600
import com.billlinus.app.ui.theme.BrandGreenDark
import com.billlinus.app.ui.theme.BrandGreenLight
import com.billlinus.app.ui.theme.Emerald100
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Indigo100
import com.billlinus.app.ui.theme.Indigo600
import com.billlinus.app.ui.theme.Red100
import com.billlinus.app.ui.theme.Red600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate200
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.ui.theme.Slate900

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuideAndRulesScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (lang == AppLanguage.NE) "मार्गदर्शन र नियमहरू" else "Guide & Rules",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = if (lang == AppLanguage.NE) "आन्तरिक राजस्व विभाग पुरस्कार कार्यविधि" else "IRD Prize Program Guidelines",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate500)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("btn_guide_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clickable { viewModel.toggleLanguage() }
                            .testTag("btn_guide_toggle_lang")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (lang == AppLanguage.NE) "नेपाली" else "EN",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = currentScreen,
                lang = lang,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Overview Banner
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (lang == AppLanguage.NE) "नेपाल सरकार • आन्तरिक राजस्व विभाग" else "Government of Nepal • IRD",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = if (lang == AppLanguage.NE) "करदाता प्रोत्साहन उपहार कार्यक्रम" else "Taxpayer Incentive Prize Program",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                    }

                    Text(
                        text = if (lang == AppLanguage.NE)
                            "उपभोक्ताहरूलाई वास्तविक कर बिजक लिन र डिजिटल भुक्तानी गर्न प्रोत्साहित गर्न नेपाल सरकार, आन्तरिक राजस्व विभागद्वारा सञ्चालित आधिकारिक योजना।"
                        else
                            "An official scheme by the Inland Revenue Department (IRD), Government of Nepal, to encourage genuine tax invoices and digital payments.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White.copy(alpha = 0.95f),
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )
                    )
                }
            }

            // 1. How the Draw Works
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "१. ड्र कसरी सञ्चालन हुन्छ?" else "1. How the Draw Works",
                subtitle = if (lang == AppLanguage.NE) "स्वचालित कम्प्युटर प्रणालीबाट निष्पक्ष छनोट" else "Fair computer-automated selection",
                icon = Icons.Default.Schedule,
                iconTint = Indigo600,
                iconBg = Indigo100,
                initiallyExpanded = true
            ) {
                Text(
                    text = if (lang == AppLanguage.NE)
                        "• आन्तरिक राजस्व विभाग (IRD) ले महिनाको दुई पटक (प्रत्येक महिनाको १६ गते र अन्तिम दिन) स्वचालित कम्प्युटर प्रणालीबाट ड्र सञ्चालन गर्दछ।\n• पहिलो पाक्षिक ड्र: महिनाको १ देखि १५ गतेसम्म जारी भएका कुपनहरू समावेश हुन्छन्।\n• दोस्रो पाक्षिक ड्र: महिनाको १६ गतेदेखि मसान्तसम्म जारी भएका कुपनहरू समावेश हुन्छन्।\n• सम्पूर्ण प्रक्रिया निष्पक्ष र स्वचालित प्रणालीद्वारा नियन्त्रित हुन्छ।"
                    else
                        "• The Inland Revenue Department (IRD) conducts automated computer draws twice a month (16th and final day of each Nepali month).\n• First Fortnightly Draw: Covers all coupons issued between 1st to 15th of the month.\n• Second Fortnightly Draw: Covers all coupons issued between 16th to the end of the month.\n• The entire selection process is fully automated and transparent.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                )
            }

            // 2. Who Can Participate
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "२. को सहभागी हुन सक्छ?" else "2. Who Can Participate",
                subtitle = if (lang == AppLanguage.NE) "योग्य उपभोक्ता तथा खरिद मापदण्ड" else "Eligible consumers and purchase criteria",
                icon = Icons.Default.VerifiedUser,
                iconTint = Emerald600,
                iconBg = Emerald100
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (lang == AppLanguage.NE)
                            "सहभागी हुन योग्य मापदण्ड:\n• व्यक्तिगत वा घरायसी उपभोगका लागि सामान वा सेवा खरिद गर्ने सर्वसाधारण उपभोक्ता।\n• रु १०० भन्दा माथिको कुनै पनि एकल खरिद।\n• प्यान/भ्याट दर्ता भएका बिक्रेताबाट जारी आधिकारिक कर बिजक (Tax Invoice)।"
                        else
                            "Eligible Criteria:\n• General consumers purchasing goods or services for personal or household use.\n• Any single purchase exceeding NPR 100.\n• Official computerized VAT/PAN tax invoices issued by registered sellers.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                    )

                    OutlinedCard(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.outlinedCardBorder().let { CardDefaults.outlinedCardColors(containerColor = Red100.copy(alpha = 0.3f)) }
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.Block, contentDescription = null, tint = Red600, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == AppLanguage.NE)
                                    "अयोग्य: व्यापारिक पुनःबिक्रीका खरिद, सरकारी निकायका खरिद, सवारी साधन खरिद, उपयोगिता बिल (बिजुली/पानी/इन्टरनेट) समावेश हुँदैन।"
                                else
                                    "Excluded: Commercial resale purchases, government entity purchases, motor vehicle purchases, and utility bills (electricity/water/internet).",
                                style = MaterialTheme.typography.bodySmall.copy(color = Red600, fontSize = 12.sp)
                            )
                        }
                    }
                }
            }

            // 3. Coupon / Winning Number
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "३. कुपन तथा विजयी नम्बर" else "3. Coupon / Winning Number",
                subtitle = if (lang == AppLanguage.NE) "१२-अंकीय नम्बरको पहिचान र दर्ता" else "12-digit number identification & registration",
                icon = Icons.Default.Receipt,
                iconTint = Amber600,
                iconBg = Amber100
            ) {
                Text(
                    text = if (lang == AppLanguage.NE)
                        "• १२-अंकीय कुपन नम्बर: QR कोड, कार्ड वा मोबाइल बैंकिङबाट भुक्तानी गर्दा बिलमा १२-अंकीय कुपन स्वतः उत्पन्न हुन्छ।\n• नगद भुक्तानी: नगद तिरेको भए पसलेसँग कर बिजक लिई prize.ird.gov.np मा विवरण प्रविष्ट गरेर १२-अंकीय कुपन लिन सकिन्छ।\n• कुपन सुरक्षित गर्नुहोस्: बिल लिनुहोस् एपमा आफ्नो कुपन नम्बरहरू सुरक्षित राख्नुहोस्।"
                    else
                        "• 12-Digit Coupon Number: When paying via QR, card, or mobile banking, a unique 12-digit coupon is automatically printed on the computerized invoice.\n• Cash Purchases: If paying with cash, demand a tax invoice and register invoice details at prize.ird.gov.np to receive your 12-digit coupon.\n• Keep Safe: Save your coupons in BillLinus to track them against results.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                )
            }

            // 4. Daily Prizes
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "४. दैनिक पुरस्कार (रु १,००,०००)" else "4. Daily Prizes (NPR 1,00,000)",
                subtitle = if (lang == AppLanguage.NE) "प्रत्येक दिन १ जना भाग्यशाली विजेता" else "One lucky winner every single day",
                icon = Icons.Default.MilitaryTech,
                iconTint = Indigo600,
                iconBg = Indigo100
            ) {
                Text(
                    text = if (lang == AppLanguage.NE)
                        "• पुरस्कार राशि: प्रत्येक दिन १ जना विजेतालाई कर कट्टी पछिको नगद रु १,००,०००।\n• घोषणा: पाक्षिक ड्रको समयमा पछिल्लो १५ दिनका दैनिक विजेताहरूको सूची एकमुष्ट सार्वजनिक गरिन्छ।"
                    else
                        "• Prize Amount: Net cash NPR 1,00,000 per day (Rs. 1,33,334 gross before 25% windfall tax).\n• Declaration: Daily winners for the preceding 15-day period are announced together during fortnightly draws.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                )
            }

            // 5. Bumper Prize
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "५. बम्पर उपहार (रु १०,००,०००)" else "5. Bumper Prize (NPR 10,00,000)",
                subtitle = if (lang == AppLanguage.NE) "हरेक १५ दिनमा १ जनालाई १० लाख" else "NPR 10 Lakhs every 15 days",
                icon = Icons.Default.EmojiEvents,
                iconTint = Amber500,
                iconBg = Amber100
            ) {
                Text(
                    text = if (lang == AppLanguage.NE)
                        "• बम्पर राशि: प्रत्येक १५ दिनमा १ जना भाग्यशाली उपभोक्तालाई रु १०,००,००० (कर कट्टी पछि रु ७,५०,०००)।\n• योग्यता: उक्त १५ दिनको अवधिमा जारी भएका सबै मान्य कुपनहरू स्वतः बम्पर ड्रमा सहभागी हुन्छन्।"
                    else
                        "• Bumper Amount: Fortnightly bumper prize of NPR 10,00,000 (net NPR 7,50,000 after 25% windfall tax).\n• Eligibility: All valid coupons issued during the 15-day period automatically enter the Bumper Draw.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                )
            }

            // 6. How to Check Your Result
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "६. नतिजा कसरी जाँच्ने?" else "6. How to Check Your Result",
                subtitle = if (lang == AppLanguage.NE) "आधिकारिक पोर्टल तथा बिल लिनुहोस् एप मार्फत" else "Via official portal & BillLinus",
                icon = Icons.Default.Search,
                iconTint = MaterialTheme.colorScheme.primary,
                iconBg = Slate100
            ) {
                Text(
                    text = if (lang == AppLanguage.NE)
                        "१. आधिकारिक वेबसाइट: prize.ird.gov.np वा ird.gov.np/category/prize-program मा प्रकाशित नतिजा हेर्नुहोस्।\n२. विजेता जाँचकर्ता: आधिकारिक पोर्टलमा प्रकाशित विजयी नम्बरहरू BillLinus को 'विजेता जाँच' स्क्रिनमा राखेर आफ्ना कुपनहरूसँग एकैपटक जाँच्नुहोस्।"
                    else
                        "1. Official Website: View the published winners list directly on prize.ird.gov.np or ird.gov.np/category/prize-program.\n2. Winner Checker: Copy/paste the published numbers into BillLinus 'Winner Checker' to instantly compare with all your saved coupons.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                )
            }

            // 7. What To Do If You Match
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "७. म्याच भएमा के गर्ने?" else "7. What To Do If You Match",
                subtitle = if (lang == AppLanguage.NE) "सम्भावित मिलानपछि गर्नुपर्ने कदमहरू" else "Next steps upon finding a match",
                icon = Icons.Default.CheckCircle,
                iconTint = Emerald600,
                iconBg = Emerald100
            ) {
                Text(
                    text = if (lang == AppLanguage.NE)
                        "• आधिकारिक IRD पोर्टल (prize.ird.gov.np) मा आफ्नो कुपन नम्बर अन्तिम रूपमा रुजु गर्नुहोस्।\n• सक्कल (Original) कर बिजक सुरक्षित राख्नुहोस् — यो दाबीका लागि अनिवार्य छ।\n• BillLinus बाट 'दाबी प्रतिवेदन' (Claim Report) तयार गर्नुहोस् र प्रिन्ट वा सुरक्षित गर्नुहोस्।"
                    else
                        "• Confirm the match directly on the official IRD portal (prize.ird.gov.np).\n• Keep your original tax invoice completely safe — it is strictly mandatory for claiming.\n• Generate a Claim Report from BillLinus for your submission file.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                )
            }

            // 8. Claiming a Prize
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "८. पुरस्कार दाबी प्रक्रिया (१५ दिनको म्याद)" else "8. Claiming a Prize (15-Day Limit)",
                subtitle = if (lang == AppLanguage.NE) "कागजात तथा कार्यालय पेश गर्ने तरिका" else "Required documents & submission timeline",
                icon = Icons.Default.Description,
                iconTint = Indigo600,
                iconBg = Indigo100
            ) {
                Text(
                    text = if (lang == AppLanguage.NE)
                        "• म्याद: नतिजा घोषणा भएको मितिले १५ दिन भित्र दाबी पेश गर्नुपर्छ।\n• पेश गर्ने स्थान: नजिकको आन्तरिक राजस्व कार्यालय (IRO), करदाता सेवा कार्यालय (TSO) वा prize.ird.gov.np अनलाइन।\n• आवश्यक कागजातहरू:\n  - सक्कल कम्प्युटराइज्ड कर बिजक (Original Tax Invoice)\n  - १२-अंकीय कुपन रेकर्ड\n  - नागरिकता / राष्ट्रिय परिचयपत्र प्रतिलिपि\n  - आफ्नै नामको बैंक खाता विवरण (चेक प्रतिलिपि वा स्टेटमेन्ट)\n  - व्यक्तिगत प्यान (PAN) कार्ड"
                    else
                        "• Timeline: Claims must be filed within 15 calendar days from the official draw date.\n• Where to File: Nearest Inland Revenue Office (IRO), Taxpayer Service Office (TSO), or online at prize.ird.gov.np.\n• Mandatory Documents:\n  - Original computerized Tax Invoice\n  - 12-digit Coupon Record\n  - Citizenship / National ID Copy\n  - Bank account details in your name (Cheque copy or Statement)\n  - Personal PAN Card",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                )
            }

            // 9. Important Warnings
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "९. महत्वपूर्ण चेतावनी तथा सतर्कता" else "9. Important Warnings & Rules",
                subtitle = if (lang == AppLanguage.NE) "ठगीबाट बच्ने र सही प्रक्रिया अपनाउने उपाय" else "Fraud prevention & official guidelines",
                icon = Icons.Default.Warning,
                iconTint = Amber600,
                iconBg = Amber100
            ) {
                Text(
                    text = if (lang == AppLanguage.NE)
                        "• BillLinus कुनै सरकारी निकाय होइन। यो तपाईंको कुपन व्यवस्थापनमा सहयोग गर्ने व्यक्तिगत एप हो।\n• पुरस्कार दाबीका लागि कुनै पनि शुल्क लाग्दैन। कसैले पुरस्कार दिने नाममा अग्रिम रकम मागेमा नदिनुहोस्।\n• आधिकारिक पुष्टि केवल नेपाल सरकार, आन्तरिक राजस्व विभागबाट मात्र हुन्छ।"
                    else
                        "• BillLinus is an independent personal helper app and not an official government agency.\n• Official prize claims never require paying any advance fee. Beware of lottery fraud or suspicious calls.\n• Only the Inland Revenue Department of Nepal can officially confirm prize winners.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate700, lineHeight = 20.sp, fontSize = 13.sp)
                )
            }

            // 10. Official IRD Links
            CollapsibleGuideSection(
                title = if (lang == AppLanguage.NE) "१०. आधिकारिक IRD लिङ्क तथा सम्पर्कहरू" else "10. Official IRD Links & Contacts",
                subtitle = if (lang == AppLanguage.NE) "वेबसाइट, पोर्टल र हटलाइन" else "Official websites, portal & hotline",
                icon = Icons.AutoMirrored.Filled.OpenInNew,
                iconTint = BrandGreenDark,
                iconBg = BrandGreenLight
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DrawResultService.IRD_PRIZE_PORTAL_URL))
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth().testTag("btn_guide_open_prize_portal"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandGreenDark)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("prize.ird.gov.np", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://ird.gov.np/category/prize-program/"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth().testTag("btn_guide_open_directives"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == AppLanguage.NE) "कार्यविधि तथा निर्देशिका (ird.gov.np)" else "Official Directives (ird.gov.np)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate100),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (lang == AppLanguage.NE)
                                    "IRD टोल-फ्री हटलाइन: 16600100260\nईमेल: info@ird.gov.np | लाजिम्पाट, काठमाडौँ"
                                else
                                    "IRD Toll-Free Hotline: 16600100260\nEmail: info@ird.gov.np | Lazimpat, Kathmandu",
                                style = MaterialTheme.typography.bodySmall.copy(color = Slate700, lineHeight = 16.sp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun CollapsibleGuideSection(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    initiallyExpanded: Boolean = false,
    content: @Composable () -> Unit
) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = iconBg,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = iconTint,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 12.sp)
                        )
                    }
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = Slate500,
                    modifier = Modifier.size(22.dp)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(color = Slate200, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(10.dp))
                    content()
                }
            }
        }
    }
}
