package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import com.billlinus.app.service.DrawResultService
import com.billlinus.app.ui.theme.BrandNavy
import com.billlinus.app.ui.theme.BrandGreenLight
import com.billlinus.app.ui.theme.BrandGreenDark
import com.billlinus.app.ui.theme.BrandGreen
import com.billlinus.app.ui.theme.Indigo100
import com.billlinus.app.ui.theme.Indigo600
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.model.EligibilityStatus
import com.billlinus.app.model.PaymentMethod
import com.billlinus.app.model.PurchasePurpose
import com.billlinus.app.model.SellerPanOption
import com.billlinus.app.model.TransactionCategory
import com.billlinus.app.service.EligibilityService
import com.billlinus.app.service.TransactionEligibilityInput
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.components.StatusBadge
import com.billlinus.app.ui.theme.Emerald50
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate200
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.ui.theme.Slate900
import com.billlinus.app.utils.CouponUtils
import com.billlinus.app.utils.NepaliDateUtils
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddInvoiceScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val editingInvoiceId by viewModel.editingInvoiceId.collectAsState()
    val invoicePrefill by viewModel.invoicePrefill.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    val editingTx = remember(editingInvoiceId, transactions) {
        transactions.find { it.id == editingInvoiceId }
    }

    var sellerName by remember(editingTx, invoicePrefill) {
        mutableStateOf(editingTx?.sellerName ?: invoicePrefill?.sellerName ?: "")
    }
    var amountText by remember(editingTx, invoicePrefill) {
        mutableStateOf(
            editingTx?.amount?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() }
                ?: invoicePrefill?.amount?.let { if (it > 0.0) (if (it % 1.0 == 0.0) it.toInt().toString() else it.toString()) else "" }
                ?: ""
        )
    }
    var paymentMethod by remember(editingTx, invoicePrefill) {
        mutableStateOf(editingTx?.paymentMethod ?: invoicePrefill?.paymentMethod ?: PaymentMethod.QR_PAYMENT)
    }
    var panVat by remember(editingTx, invoicePrefill) {
        mutableStateOf(editingTx?.panVat ?: invoicePrefill?.panVat ?: "")
    }
    var invoiceNumber by remember(editingTx, invoicePrefill) {
        mutableStateOf(editingTx?.invoiceNumber ?: invoicePrefill?.invoiceNumber ?: "")
    }
    var couponNumber by remember(editingTx) { mutableStateOf(editingTx?.couponNumber ?: "") }
    var dateText by remember(editingTx, invoicePrefill) {
        mutableStateOf(editingTx?.date ?: invoicePrefill?.date ?: LocalDate.now().format(DateTimeFormatter.ISO_DATE))
    }
    var notes by remember(editingTx) { mutableStateOf(editingTx?.notes ?: "") }
    var photoReference by remember(editingTx, invoicePrefill) {
        mutableStateOf(editingTx?.photoReference ?: invoicePrefill?.photoReference)
    }
    var attachPhotoToTransaction by remember(editingTx, invoicePrefill) {
        mutableStateOf(editingTx?.photoReference != null)
    }
    var category by remember(editingTx) { mutableStateOf(editingTx?.category ?: TransactionCategory.NORMAL_GOODS) }
    var hasWarranty by remember(editingTx) { mutableStateOf(editingTx?.hasWarranty ?: false) }
    var warrantyMonthsText by remember(editingTx) {
        mutableStateOf(editingTx?.warrantyMonths?.toString() ?: "")
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val amountValue = amountText.toDoubleOrNull() ?: 0.0
    val eligibilityResult = remember(amountValue, paymentMethod, panVat, sellerName, dateText, invoiceNumber, category) {
        EligibilityService.checkEligibility(
            TransactionEligibilityInput(
                amount = amountValue,
                paymentMethod = paymentMethod,
                sellerPan = if (panVat.isBlank()) SellerPanOption.DONT_KNOW else SellerPanOption.YES,
                sellerPanNumber = panVat,
                sellerName = sellerName,
                category = category,
                date = dateText,
                invoiceNumber = invoiceNumber
            )
        )
    }

    val drawInfo = remember(dateText, lang) {
        NepaliDateUtils.getDrawPeriodForDate(dateText, lang)
    }

    val screenTitle = if (editingTx != null) {
        if (lang == AppLanguage.NE) "खरिद विवरण सम्पादन" else "Edit Purchase"
    } else {
        AppStrings.get("add_invoice.title", lang)
    }

    val submitButtonText = if (editingTx != null) {
        if (lang == AppLanguage.NE) "विवरण अपडेट गर्नुहोस्" else "Update Purchase"
    } else {
        AppStrings.get("add_invoice.save_btn", lang)
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = screenTitle,
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (invoicePrefill != null) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Indigo100.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Indigo600,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (lang == AppLanguage.NE) "फोटोबाट भरिएको विवरण" else "Pre-filled from Bill Photo",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Indigo600,
                                    fontSize = 13.sp
                                )
                            )
                            Text(
                                text = if (lang == AppLanguage.NE)
                                    "कृपया बचत गर्नुअघि प्यान नम्बर र रकम सही छ भनी निश्चित गर्नुहोस्।"
                                else
                                    "Please verify the seller, PAN number, and amount before saving.",
                                style = MaterialTheme.typography.bodySmall.copy(color = Slate700, fontSize = 11.sp)
                            )
                        }
                    }
                }
            }

            // Live Eligibility preview Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = AppStrings.get("add_invoice.eligibility_preview", lang),
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        val status = if (couponNumber.isNotBlank() && CouponUtils.isValidCouponNumber(couponNumber)) {
                            EligibilityStatus.COUPON_ADDED
                        } else {
                            eligibilityResult.status
                        }
                        StatusBadge(status = status, lang = lang)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${AppStrings.get("add_invoice.draw_cycle_estimate", lang)}: ${drawInfo.drawPeriod}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Slate500,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            // Purchase Details Section
            Text(
                text = AppStrings.get("add_invoice.section_purchase", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            OutlinedTextField(
                value = sellerName,
                onValueChange = { sellerName = it },
                label = { Text(AppStrings.get("add_invoice.merchant_name", lang)) },
                placeholder = { Text(AppStrings.get("add_invoice.merchant_placeholder", lang)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_seller_name"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text(AppStrings.get("add_invoice.amount_npr", lang)) },
                placeholder = { Text(AppStrings.get("add_invoice.amount_placeholder", lang)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_amount"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = dateText,
                onValueChange = { dateText = it },
                label = { Text(AppStrings.get("add_invoice.date_label", lang) + " (YYYY-MM-DD)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_date"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Payment Mode Section
            Text(
                text = AppStrings.get("add_invoice.section_payment", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PaymentMethod.values().forEach { method ->
                    val isSelected = paymentMethod == method
                    FilterChip(
                        selected = isSelected,
                        onClick = { paymentMethod = method },
                        label = {
                            Text(
                                text = AppStrings.getPaymentMethodLabel(method, lang),
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("chip_${method.name.lowercase()}")
                    )
                }
            }

            if (paymentMethod == PaymentMethod.CASH) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BrandGreenLight),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_cash_payment_info")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = BrandGreenDark,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = AppStrings.get("eligibility.cash_info_title", lang),
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = BrandGreenDark
                                )
                            )
                        }

                        Text(
                            text = AppStrings.get("eligibility.cash_info_desc", lang),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Slate700,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        )

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = BrandNavy,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DrawResultService.IRD_PRIZE_PORTAL_URL))
                                    context.startActivity(intent)
                                }
                                .testTag("btn_open_ird_cash_info")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = AppStrings.get("eligibility.open_ird_portal", lang),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Category Section
            Text(
                text = AppStrings.get("add_invoice.section_category", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TransactionCategory.values().forEach { cat ->
                    val isSelected = category == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { category = cat },
                        label = {
                            Text(
                                text = AppStrings.getCategoryLabel(cat, lang),
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("chip_category_${cat.name.lowercase()}")
                    )
                }
            }

            // Warranty Section
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = AppStrings.get("add_invoice.has_warranty", lang),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Switch(
                            checked = hasWarranty,
                            onCheckedChange = { hasWarranty = it },
                            modifier = Modifier.testTag("switch_has_warranty")
                        )
                    }

                    if (hasWarranty) {
                        OutlinedTextField(
                            value = warrantyMonthsText,
                            onValueChange = { warrantyMonthsText = it.filter { c -> c.isDigit() } },
                            label = { Text(AppStrings.get("add_invoice.warranty_months", lang)) },
                            placeholder = { Text(AppStrings.get("add_invoice.warranty_placeholder", lang)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_warranty_months"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            // Tax & Coupon Details Section
            Text(
                text = AppStrings.get("add_invoice.section_tax_coupon", lang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            OutlinedTextField(
                value = panVat,
                onValueChange = { panVat = it.filter { c -> c.isDigit() }.take(9) },
                label = { Text(AppStrings.get("add_invoice.pan_vat", lang) + " (9 digits)") },
                placeholder = { Text(AppStrings.get("add_invoice.pan_placeholder", lang)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_pan"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = invoiceNumber,
                onValueChange = { invoiceNumber = it },
                label = { Text(AppStrings.get("add_invoice.invoice_number", lang) + " (${AppStrings.get("common.optional", lang)})") },
                placeholder = { Text(AppStrings.get("add_invoice.invoice_placeholder", lang)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_invoice_number"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = couponNumber,
                onValueChange = { couponNumber = it.filter { c -> c.isDigit() }.take(12) },
                label = { Text(AppStrings.get("add_invoice.coupon_number", lang) + " (${couponNumber.length}/12 digits)") },
                placeholder = { Text(AppStrings.get("add_invoice.coupon_placeholder", lang)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_coupon_number"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(AppStrings.get("add_invoice.notes", lang) + " (${AppStrings.get("common.optional", lang)})") },
                placeholder = { Text(AppStrings.get("add_invoice.notes_placeholder", lang)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_notes"),
                minLines = 2,
                shape = RoundedCornerShape(12.dp)
            )

            if (photoReference != null) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Receipt,
                                contentDescription = null,
                                tint = Emerald600,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (lang == AppLanguage.NE) "बिल फोटो" else "Bill Photo",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                )
                                Text(
                                    text = if (lang == AppLanguage.NE) "क्यामेराबाट खिचिएको बिजकको फोटो" else "Photo captured from bill scan",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 11.sp)
                                )
                            }
                            Switch(
                                checked = attachPhotoToTransaction,
                                onCheckedChange = { attachPhotoToTransaction = it },
                                modifier = Modifier.testTag("switch_attach_photo")
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (lang == AppLanguage.NE)
                                if (attachPhotoToTransaction) "✓ यो फोटो कारोबारसँग सुरक्षित गरिनेछ।" else "✗ फोटो सुरक्षित गरिने छैन (केवल OCR का लागि प्रयोग भयो)।"
                            else
                                if (attachPhotoToTransaction) "✓ Photo will be saved with this transaction." else "✗ Photo will NOT be saved (used only for OCR parsing).",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (attachPhotoToTransaction) Emerald600 else Slate500,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Button(
                onClick = {
                    if (sellerName.isBlank()) {
                        errorMessage = if (lang == AppLanguage.NE) "कृपया विक्रेताको नाम प्रविष्ट गर्नुहोस्" else "Please enter seller/merchant name"
                        return@Button
                    }
                    if (amountValue <= 0) {
                        errorMessage = if (lang == AppLanguage.NE) "कृपया मान्य रकम प्रविष्ट गर्नुहोस्" else "Please enter a valid amount"
                        return@Button
                    }
                    errorMessage = null

                    val parsedWarrantyMonths = if (hasWarranty) warrantyMonthsText.toIntOrNull() else null
                    val finalPhotoRef = if (attachPhotoToTransaction) photoReference else null

                    if (editingTx != null) {
                        viewModel.updateTransaction(
                            id = editingTx.id,
                            sellerName = sellerName,
                            amount = amountValue,
                            paymentMethod = paymentMethod,
                            panVat = panVat.ifBlank { null },
                            invoiceNumber = invoiceNumber.ifBlank { null },
                            couponNumber = couponNumber.ifBlank { null },
                            date = dateText,
                            notes = notes.ifBlank { null },
                            category = category,
                            hasWarranty = hasWarranty,
                            warrantyMonths = parsedWarrantyMonths,
                            photoReference = finalPhotoRef
                        )
                    } else {
                        viewModel.saveTransaction(
                            sellerName = sellerName,
                            amount = amountValue,
                            paymentMethod = paymentMethod,
                            panVat = panVat.ifBlank { null },
                            invoiceNumber = invoiceNumber.ifBlank { null },
                            couponNumber = couponNumber.ifBlank { null },
                            date = dateText,
                            notes = notes.ifBlank { null },
                            category = category,
                            hasWarranty = hasWarranty,
                            warrantyMonths = parsedWarrantyMonths,
                            photoReference = finalPhotoRef
                        )
                    }
                    viewModel.navigateBack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_save_invoice"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = submitButtonText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
