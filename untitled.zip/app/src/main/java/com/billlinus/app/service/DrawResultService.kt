package com.billlinus.app.service

import com.billlinus.app.data.BillLinusRepository
import com.billlinus.app.model.Coupon
import com.billlinus.app.model.DrawAnnouncement
import com.billlinus.app.utils.CouponUtils
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object DrawResultService {
    const val IRD_PRIZE_PORTAL_URL = "https://prize.ird.gov.np/"
    const val IRD_MAIN_URL = "https://ird.gov.np"
    const val IRD_PAN_SEARCH_URL = "https://ird.gov.np/pan-search"

    fun isAutomaticResultCheckingAvailable(): Boolean {
        return true
    }

    /**
     * Shared coupon-matching logic across manual entry and background notification checks.
     * Takes a list of raw winning tokens and saved coupons, returning the list of matched coupon numbers.
     */
    fun findMatches(winningTokens: List<String>, savedCoupons: List<Coupon>): List<String> {
        val normalizedWinning = winningTokens
            .map { CouponUtils.normalizeCouponNumber(it) }
            .filter { it.length == 12 }
            .toSet()

        val savedNumbers = savedCoupons
            .map { CouponUtils.normalizeCouponNumber(it.couponNumber) }
            .filter { it.isNotEmpty() }
            .toSet()

        return normalizedWinning.filter { savedNumbers.contains(it) }
    }

    /**
     * Fetches published draw announcements from Firestore 'draws' collection.
     * Caches successful results into BillLinusRepository.
     * On failure or offline, falls back seamlessly to the cached draws or defaults.
     */
    suspend fun getAvailableDraws(repository: BillLinusRepository? = null): List<DrawAnnouncement> {
        try {
            val db = FirebaseFirestore.getInstance()
            val snapshot = suspendCancellableCoroutine { cont ->
                db.collection("draws").get()
                    .addOnSuccessListener { result ->
                        if (cont.isActive) cont.resume(result)
                    }
                    .addOnFailureListener { exception ->
                        if (cont.isActive) cont.resumeWith(Result.failure(exception))
                    }
            }

            val list = mutableListOf<DrawAnnouncement>()
            for (doc in snapshot.documents) {
                val id = doc.getString("id") ?: doc.id
                val title = doc.getString("title") ?: "IRD Prize Draw"
                val drawPeriod = doc.getString("drawPeriod") ?: ""
                val announcementDate = doc.getString("announcementDate") ?: ""
                @Suppress("UNCHECKED_CAST")
                val winningNumbers = (doc.get("winningNumbers") as? List<String>) ?: emptyList()
                val sourceUrl = doc.getString("sourceUrl") ?: IRD_PRIZE_PORTAL_URL
                val sourceName = doc.getString("sourceName") ?: "Inland Revenue Department Nepal"
                val notes = doc.getString("notes")
                val createdAt = doc.getString("createdAt") ?: ""

                list.add(
                    DrawAnnouncement(
                        id = id,
                        title = title,
                        drawPeriod = drawPeriod,
                        announcementDate = announcementDate,
                        winningNumbers = winningNumbers,
                        sourceUrl = sourceUrl,
                        sourceName = sourceName,
                        notes = notes,
                        createdAt = createdAt
                    )
                )
            }

            if (list.isNotEmpty()) {
                repository?.setDraws(list)
                return list
            }
        } catch (_: Exception) {
            // Handled gracefully below with fallback to cached results
        }

        // Fallback to local cache in repository
        val cached = repository?.draws?.value
        if (!cached.isNullOrEmpty()) {
            return cached
        }

        // Default fallback if initial run is completely offline
        val defaults = getDefaultFallbackDraws()
        repository?.saveDraws(defaults)
        return defaults
    }

    /**
     * Returns the default baseline IRD draw announcements for offline first-launch.
     */
    fun getDefaultFallbackDraws(): List<DrawAnnouncement> {
        return listOf(
            DrawAnnouncement(
                id = "draw-bhadra-2083-1",
                title = "Bhadra 1–15, 2083 Fortnightly Draw",
                drawPeriod = "Bhadra 1–15, 2083",
                announcementDate = "2026-08-16",
                winningNumbers = listOf(
                    "007315254493", // Matches sample coupon 1
                    "007315254499",
                    "007315254500",
                    "007315254505"
                ),
                sourceUrl = IRD_PRIZE_PORTAL_URL,
                sourceName = "Inland Revenue Department Nepal",
                notes = "Official Bumper and Daily prize winners list",
                createdAt = "2026-08-16T10:00:00Z"
            ),
            DrawAnnouncement(
                id = "draw-shrawan-2083-2",
                title = "Shrawan 16–31, 2083 Fortnightly Draw",
                drawPeriod = "Shrawan 16–31, 2083",
                announcementDate = "2026-08-01",
                winningNumbers = listOf(
                    "007315254495", // Matches sample coupon 3
                    "007315254480",
                    "007315254481"
                ),
                sourceUrl = IRD_PRIZE_PORTAL_URL,
                sourceName = "Inland Revenue Department Nepal",
                notes = "Fortnightly draw results",
                createdAt = "2026-08-01T10:00:00Z"
            )
        )
    }
}
