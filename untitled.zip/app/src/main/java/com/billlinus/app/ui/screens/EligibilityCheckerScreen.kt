package com.billlinus.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.ui.draw.clip
import com.billlinus.app.service.DrawResultService
import com.billlinus.app.ui.theme.BrandGreenDark
import com.billlinus.app.ui.theme.BrandGreenLight
import com.billlinus.app.ui.theme.BrandNavy
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.model.EligibilityStatus
import com.billlinus.app.model.PaymentMethod
import com.billlinus.app.model.PurchasePurpose
import com.billlinus.app.model.SellerPanOption
import com.billlinus.app.model.TransactionCategory
import com.billlinus.app.service.EligibilityService
import com.billlinus.app.service.TransactionEligibilityInput
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.components.StatusBadge
import com.billlinus.app.ui.theme.Amber100
import com.billlinus.app.ui.theme.Amber600
import com.billlinus.app.ui.theme.Emerald100
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Red100
import com.billlinus.app.ui.theme.Red600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.ui.theme.Slate950

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EligibilityCheckerScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val prefill by viewModel.eligibilityPrefill.collectAsState()

    var amountText by remember(prefill) {
        mutableStateOf(prefill?.amount?.let { it.toInt().toString() } ?: "1500")
    }
    var paymentMethod by remember(prefill) {
        mutableStateOf(prefill?.paymentMethod ?: PaymentMethod.QR_PAYMENT)
    }
    var purpose by remember { mutableStateOf(PurchasePurpose.PERSONAL) }
    var sellerPanOption by remember(prefill) {
        mutableStateOf(if (prefill?.panVat != null) SellerPanOption.YES else SellerPanOption.YES)
    }
    var panNumber by remember(prefill) { mutableStateOf(prefill?.panVat ?: "") }
    var sellerName by remember(prefill) { mutableStateOf(prefill?.sellerName ?: "") }
    var category by remember { mutableStateOf(TransactionCategory.NORMAL_GOODS) }

    val amountValue = amountText.toDoubleOrNull() ?: 0.0

    val eligibilityResult = remember(amountValue, paymentMethod, purpose, sellerPanOption, panNumber, category) {
        EligibilityService.checkEligibility(
            TransactionEligibilityInput(
                amount = amountValue,
                paymentMethod = paymentMethod,
                purpose = purpose,
                sellerPan = sellerPanOption,
                sellerPanNumber = panNumber,
                sellerName = sellerName,
                category = category
            )
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("eligibility.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Result Banner Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = when (eligibilityResult.status) {
                        EligibilityStatus.LIKELY_ELIGIBLE, EligibilityStatus.COUPON_ADDED -> Emerald100
                        EligibilityStatus.NEEDS_VERIFICATION -> Amber100
                        else -> Red100
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("eligibility_result_banner")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when (eligibilityResult.status) {
                                    EligibilityStatus.LIKELY_ELIGIBLE, EligibilityStatus.COUPON_ADDED -> Icons.Default.CheckCircle
                                    EligibilityStatus.NEEDS_VERIFICATION -> Icons.Default.Info
                                    else -> Icons.Default.Warning
                                },
                                contentDescription = null,
                                tint = when (eligibilityResult.status) {
                                    EligibilityStatus.LIKELY_ELIGIBLE, EligibilityStatus.COUPON_ADDED -> Emerald600
                                    EligibilityStatus.NEEDS_VERIFICATION -> Amber600
                                    else -> Red600
                                },
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (eligibilityResult.status) {
                                    EligibilityStatus.LIKELY_ELIGIBLE, EligibilityStatus.COUPON_ADDED -> AppStrings.get("eligibility.likely_eligible_msg", lang)
                                    EligibilityStatus.NEEDS_VERIFICATION -> AppStrings.get("eligibility.verification_msg", lang)
                                    else -> AppStrings.get("eligibility.likely_not_msg", lang)
                                },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = when (eligibilityResult.status) {
                                        EligibilityStatus.LIKELY_ELIGIBLE, EligibilityStatus.COUPON_ADDED -> Emerald600
                                        EligibilityStatus.NEEDS_VERIFICATION -> Amber600
                                        else -> Red600
                                    }
                                )
                            )
                        }
                    }

                    // Reasons List
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        eligibilityResult.reasons.forEach { reason ->
                            Text(
                                text = "• " + AppStrings.getReason(reason, lang),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 13.sp
                                )
                            )
                        }
                    }
                }
            }

            // Input Form Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = AppStrings.get("eligibility.purchase_details", lang),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text(AppStrings.get("add_invoice.amount_npr", lang)) },
                        placeholder = { Text(AppStrings.get("eligibility.amount_placeholder", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("eligibility_input_amount"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Payment Method Chips
                    Text(
                        text = AppStrings.get("eligibility.payment_method", lang),
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PaymentMethod.values().forEach { method ->
                            val isSelected = paymentMethod == method
                            FilterChip(
                                selected = isSelected,
                                onClick = { paymentMethod = method },
                                label = {
                                    Text(
                                        text = AppStrings.getPaymentMethodLabel(method, lang),
                                        fontSize = 12.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    if (paymentMethod == PaymentMethod.CASH) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = BrandGreenLight),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("card_cash_checker_info")
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = BrandGreenDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = AppStrings.get("eligibility.cash_info_title", lang),
                                        style = MaterialTheme.typography.labelLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = BrandGreenDark
                                        )
                                    )
                                }

                                Text(
                                    text = AppStrings.get("eligibility.cash_info_desc", lang),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Slate700,
                                        fontSize = 12.sp,
                                        lineHeight = 17.sp
                                    )
                                )

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = BrandNavy,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DrawResultService.IRD_PRIZE_PORTAL_URL))
                                            context.startActivity(intent)
                                        }
                                        .testTag("btn_open_ird_cash_checker")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = AppStrings.get("eligibility.open_ird_portal", lang),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        )
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // PAN option
                    Text(
                        text = "Seller VAT/PAN Status",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SellerPanOption.values().forEach { opt ->
                            val isSel = sellerPanOption == opt
                            FilterChip(
                                selected = isSel,
                                onClick = { sellerPanOption = opt },
                                label = {
                                    Text(
                                        text = when (opt) {
                                            SellerPanOption.YES -> if (lang == AppLanguage.NE) "प्यान दर्ता भएको" else "PAN Registered"
                                            SellerPanOption.NO -> if (lang == AppLanguage.NE) "प्यान दर्ता नभएको" else "No PAN"
                                            SellerPanOption.DONT_KNOW -> if (lang == AppLanguage.NE) "थाहा छैन" else "Not Sure"
                                        },
                                        fontSize = 12.sp
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    if (sellerPanOption == SellerPanOption.YES) {
                        OutlinedTextField(
                            value = panNumber,
                            onValueChange = { panNumber = it.filter { c -> c.isDigit() }.take(9) },
                            label = { Text(AppStrings.get("eligibility.seller_pan", lang)) },
                            placeholder = { Text(AppStrings.get("eligibility.pan_placeholder", lang)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("eligibility_input_pan"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            // Quick Action to Save Invoice if eligible
            Button(
                onClick = {
                    viewModel.saveTransaction(
                        sellerName = sellerName.ifBlank { "Store Purchase" },
                        amount = amountValue,
                        paymentMethod = paymentMethod,
                        panVat = panNumber.ifBlank { null },
                        invoiceNumber = null,
                        couponNumber = null,
                        date = "",
                        notes = "Saved from Eligibility Calculator"
                    )
                    viewModel.navigateTo(com.billlinus.app.model.ScreenName.HOME)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_record_eligible_invoice"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.get("home.record_purchase", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
