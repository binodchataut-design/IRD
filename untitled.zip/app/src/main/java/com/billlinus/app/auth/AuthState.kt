package com.billlinus.app.auth

import com.billlinus.app.model.UserProfile

/**
 * Authentication state representation decoupled from Firebase implementation details.
 */
sealed interface AuthState {
    /** Checking initialization or current auth status */
    data object Loading : AuthState

    /** Firebase is not configured or google-services.json is missing */
    data object FirebaseNotConfigured : AuthState

    /** Firebase is initialized and available, but no user is currently authenticated */
    data object SignedOut : AuthState

    /** Account profile setup on device with mobile number (unauthenticated/pre-passkey state) */
    data class AccountSetup(val userProfile: UserProfile) : AuthState

    /** Device authenticated via modern Android Credential Manager Passkey */
    data class PasskeyAuthenticated(val userProfile: UserProfile) : AuthState

    /** A user is currently authenticated with their profile details */
    data class SignedIn(val userProfile: UserProfile) : AuthState
}

/**
 * High-level Firebase availability status.
 */
enum class FirebaseStatus {
    CONFIGURED,
    NOT_CONFIGURED
}
