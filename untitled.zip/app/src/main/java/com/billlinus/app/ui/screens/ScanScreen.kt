package com.billlinus.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.EligibilityPrefillData
import com.billlinus.app.model.PaymentMethod
import com.billlinus.app.model.ScreenName
import com.billlinus.app.service.BillExtractionResult
import com.billlinus.app.service.BillOcrService
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppBottomNav
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.components.DetailRow
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Red600
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500
import kotlinx.coroutines.launch

@Composable
fun ScanScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isScanning by remember { mutableStateOf(false) }
    var scanResult by remember { mutableStateOf<BillExtractionResult?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isScanning = true
            errorMessage = null
            scope.launch {
                try {
                    val result = BillOcrService.processBillImage(context, uri)
                    scanResult = result
                    if (!result.isSuccess && result.rawText.isNullOrBlank()) {
                        errorMessage = "Could not extract readable text from the selected image. Please try a clearer picture."
                    }
                } catch (e: Exception) {
                    errorMessage = "Error processing bill: ${e.localizedMessage ?: "Unknown error"}"
                } finally {
                    isScanning = false
                }
            }
        }
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("scan.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = ScreenName.SCAN,
                onNavigate = { viewModel.navigateTo(it) },
                lang = lang
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Scanner Header Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.DocumentScanner,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Smart Bill Scanner",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Scan or upload a picture of your Nepali physical or digital invoice. We automatically extract Seller Name, PAN/VAT, Total Amount, and Bill Number.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = Slate500),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            // Pick Image Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { photoPickerLauncher.launch("image/*") },
                    enabled = !isScanning,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("btn_select_bill_photo"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Choose Image", fontWeight = FontWeight.Bold)
                }
            }

            if (isScanning) {
                Spacer(modifier = Modifier.height(16.dp))
                CircularProgressIndicator(modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Analyzing bill details with AI OCR...",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Slate500)
                )
            }

            if (errorMessage != null) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Red600)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodyMedium.copy(color = Red600)
                        )
                    }
                }
            }

            // Results Display
            scanResult?.let { result ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Emerald600)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Extracted Information",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(
                            label = "Seller Name",
                            value = result.sellerName ?: "Not detected"
                        )
                        DetailRow(
                            label = "PAN / VAT",
                            value = result.panVat ?: "Not detected"
                        )
                        DetailRow(
                            label = "Total Amount",
                            value = if (result.totalAmount != null) "NPR ${result.totalAmount.toInt()}" else "Not detected"
                        )
                        DetailRow(
                            label = "Invoice #",
                            value = result.invoiceNumber ?: "Not detected"
                        )
                        DetailRow(
                            label = "Date",
                            value = result.date ?: "Not detected"
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.openAddInvoice(
                                    prefill = EligibilityPrefillData(
                                        sellerName = result.sellerName ?: "",
                                        panVat = result.panVat,
                                        amount = result.totalAmount ?: 0.0,
                                        paymentMethod = PaymentMethod.QR_PAYMENT,
                                        invoiceNumber = result.invoiceNumber,
                                        date = result.date
                                    )
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_save_scanned_invoice"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "Save as Bill", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
