package com.billlinus.app.ui.components

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.ui.screens.KeypadIconButton
import com.billlinus.app.ui.screens.KeypadNumberButton
import com.billlinus.app.ui.theme.BrandNavy
import com.billlinus.app.ui.theme.BrandNavyLight
import com.billlinus.app.ui.theme.Red600
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500

@Composable
fun SetPinDialog(
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onPinSet: (String) -> Unit
) {
    var step by remember { mutableStateOf(1) } // 1: enter PIN, 2: confirm PIN
    var firstPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    fun onNumber(num: String) {
        if (step == 1) {
            if (firstPin.length < 4) {
                firstPin += num
                errorMsg = null
                if (firstPin.length == 4) {
                    step = 2
                }
            }
        } else {
            if (confirmPin.length < 4) {
                confirmPin += num
                errorMsg = null
                if (confirmPin.length == 4) {
                    if (confirmPin == firstPin) {
                        onPinSet(confirmPin)
                    } else {
                        errorMsg = AppStrings.get("profile.pin_mismatch", lang)
                        confirmPin = ""
                        firstPin = ""
                        step = 1
                    }
                }
            }
        }
    }

    fun onDelete() {
        if (step == 1) {
            if (firstPin.isNotEmpty()) firstPin = firstPin.dropLast(1)
        } else {
            if (confirmPin.isNotEmpty()) {
                confirmPin = confirmPin.dropLast(1)
            } else {
                step = 1
                firstPin = firstPin.dropLast(1)
            }
        }
        errorMsg = null
    }

    val currentPin = if (step == 1) firstPin else confirmPin
    val title = if (step == 1) {
        AppStrings.get("profile.set_pin_title", lang)
    } else {
        AppStrings.get("profile.confirm_pin_title", lang)
    }
    val subtitle = if (step == 1) {
        AppStrings.get("profile.set_pin_desc", lang)
    } else {
        AppStrings.get("profile.confirm_pin_desc", lang)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(BrandNavyLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = BrandNavy,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Slate500,
                        textAlign = TextAlign.Center
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // PIN dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until 4) {
                        val isFilled = i < currentPin.length
                        val dotColor = when {
                            errorMsg != null -> Red600
                            isFilled -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(dotColor)
                                .border(
                                    1.dp,
                                    if (isFilled || errorMsg != null) dotColor else MaterialTheme.colorScheme.outline,
                                    CircleShape
                                )
                        )
                    }
                }

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMsg ?: "",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Red600,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Compact Keypad
                CompactKeypad(
                    onNumber = { onNumber(it) },
                    onDelete = { onDelete() }
                )
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_dismiss_set_pin")
            ) {
                Text(AppStrings.get("common.cancel", lang))
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun AuthenticatePinDialog(
    title: String,
    subtitle: String,
    lang: AppLanguage,
    verifyPin: (String) -> Boolean,
    onDismiss: () -> Unit,
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    var enteredPin by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var canUseBiometrics by remember { mutableStateOf(false) }

    fun authenticateWithBiometrics() {
        val activity = context as? FragmentActivity ?: return
        val biometricManager = BiometricManager.from(context)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (biometricManager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS) {
            val executor = ContextCompat.getMainExecutor(context)
            val prompt = BiometricPrompt(
                activity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        onSuccess()
                    }
                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        errorMsg = AppStrings.get("lock.invalid_pin", lang)
                    }
                }
            )
            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setNegativeButtonText(AppStrings.get("lock.biometric_negative", lang))
                .build()
            prompt.authenticate(promptInfo)
        }
    }

    LaunchedEffect(Unit) {
        val biometricManager = BiometricManager.from(context)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        canUseBiometrics = (biometricManager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS)
    }

    fun onNumber(num: String) {
        if (enteredPin.length < 4) {
            val next = enteredPin + num
            enteredPin = next
            errorMsg = null
            if (next.length == 4) {
                if (verifyPin(next)) {
                    onSuccess()
                } else {
                    errorMsg = AppStrings.get("lock.invalid_pin", lang)
                    enteredPin = ""
                }
            }
        }
    }

    fun onDelete() {
        if (enteredPin.isNotEmpty()) {
            enteredPin = enteredPin.dropLast(1)
            errorMsg = null
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(BrandNavyLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = BrandNavy,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Slate500,
                        textAlign = TextAlign.Center
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // PIN dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until 4) {
                        val isFilled = i < enteredPin.length
                        val dotColor = when {
                            errorMsg != null -> Red600
                            isFilled -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(dotColor)
                                .border(
                                    1.dp,
                                    if (isFilled || errorMsg != null) dotColor else MaterialTheme.colorScheme.outline,
                                    CircleShape
                                )
                        )
                    }
                }

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMsg ?: "",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Red600,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Keypad with optional biometric
                CompactKeypad(
                    onNumber = { onNumber(it) },
                    onDelete = { onDelete() },
                    canUseBiometrics = canUseBiometrics,
                    onBiometricClick = { authenticateWithBiometrics() }
                )
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_dismiss_auth_pin")
            ) {
                Text(AppStrings.get("common.cancel", lang))
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun CompactKeypad(
    onNumber: (String) -> Unit,
    onDelete: () -> Unit,
    canUseBiometrics: Boolean = false,
    onBiometricClick: () -> Unit = {}
) {
    val keys = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("BIO", "0", "DEL")
    )

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        for (row in keys) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                for (key in row) {
                    when (key) {
                        "BIO" -> {
                            if (canUseBiometrics) {
                                KeypadIconButton(
                                    icon = Icons.Default.Fingerprint,
                                    testTag = "btn_dialog_bio",
                                    tint = MaterialTheme.colorScheme.primary,
                                    onClick = onBiometricClick
                                )
                            } else {
                                Spacer(modifier = Modifier.size(56.dp))
                            }
                        }
                        "DEL" -> {
                            KeypadIconButton(
                                icon = Icons.AutoMirrored.Filled.Backspace,
                                testTag = "btn_dialog_del",
                                tint = Slate500,
                                onClick = onDelete
                            )
                        }
                        else -> {
                            KeypadNumberButton(
                                number = key,
                                testTag = "btn_dialog_$key",
                                onClick = { onNumber(key) }
                            )
                        }
                    }
                }
            }
        }
    }
}
