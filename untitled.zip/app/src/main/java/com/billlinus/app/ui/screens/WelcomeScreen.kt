package com.billlinus.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.R
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.theme.Emerald100
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Indigo100
import com.billlinus.app.ui.theme.Indigo600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.ui.theme.Slate800

@Composable
fun WelcomeScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val hasCompletedWelcome by viewModel.hasCompletedWelcome.collectAsState()

    Scaffold { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Header Row: Back button (if returning) + Language Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (hasCompletedWelcome) Arrangement.SpaceBetween else Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (hasCompletedWelcome) {
                        IconButton(
                            onClick = {
                                if (!viewModel.navigateBack()) {
                                    viewModel.completeWelcome()
                                }
                            },
                            modifier = Modifier.testTag("btn_welcome_back")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = lang == AppLanguage.NE,
                            onClick = { viewModel.setLanguage(AppLanguage.NE) },
                            label = { Text("नेपाली", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("welcome_lang_ne")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        FilterChip(
                            selected = lang == AppLanguage.EN,
                            onClick = { viewModel.setLanguage(AppLanguage.EN) },
                            label = { Text("English", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("welcome_lang_en")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Brand Header: Logo + App Name + Subtitle
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(88.dp),
                        shadowElevation = 2.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Image(
                                painter = painterResource(R.drawable.app_logo),
                                contentDescription = "BillLinus Logo",
                                modifier = Modifier
                                    .size(76.dp)
                                    .clip(RoundedCornerShape(16.dp))
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = AppStrings.get("welcome.title", lang),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 30.sp,
                            letterSpacing = (-0.5).sp
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = AppStrings.get("welcome.subtitle", lang),
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = Slate500,
                            fontWeight = FontWeight.Medium,
                            fontSize = 16.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Core Features Vertical List
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    WelcomeFeatureItem(
                        icon = Icons.Default.Receipt,
                        iconBg = Indigo100,
                        iconColor = Indigo600,
                        title = AppStrings.get("welcome.feature_1_title", lang),
                        description = AppStrings.get("welcome.feature_1_desc", lang)
                    )
                    WelcomeFeatureItem(
                        icon = Icons.Default.CardGiftcard,
                        iconBg = Emerald100,
                        iconColor = Emerald600,
                        title = AppStrings.get("welcome.feature_2_title", lang),
                        description = AppStrings.get("welcome.feature_2_desc", lang)
                    )
                    WelcomeFeatureItem(
                        icon = Icons.Default.VerifiedUser,
                        iconBg = Indigo100,
                        iconColor = Indigo600,
                        title = AppStrings.get("welcome.feature_3_title", lang),
                        description = AppStrings.get("welcome.feature_3_desc", lang)
                    )
                    WelcomeFeatureItem(
                        icon = Icons.Default.Folder,
                        iconBg = Slate100,
                        iconColor = Slate700,
                        title = AppStrings.get("welcome.feature_4_title", lang),
                        description = AppStrings.get("welcome.feature_4_desc", lang)
                    )
                    WelcomeFeatureItem(
                        icon = Icons.Default.PieChart,
                        iconBg = Emerald100,
                        iconColor = Emerald600,
                        title = AppStrings.get("welcome.feature_5_title", lang),
                        description = AppStrings.get("welcome.feature_5_desc", lang)
                    )
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Get Started Button
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(
                        onClick = { viewModel.onWelcomeGetStarted() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("btn_welcome_get_started"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = AppStrings.get("welcome.get_started", lang),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun WelcomeFeatureItem(
    icon: ImageVector,
    iconBg: Color,
    iconColor: Color,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = iconBg,
            modifier = Modifier.size(42.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = Slate800,
                    fontSize = 15.sp,
                    lineHeight = 20.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Slate500,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            )
        }
    }
}
