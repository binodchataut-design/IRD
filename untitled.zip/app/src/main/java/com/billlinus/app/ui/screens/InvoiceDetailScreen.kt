package com.billlinus.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.CouponPrefillData
import com.billlinus.app.model.EligibilityStatus
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.components.DetailRow
import com.billlinus.app.ui.components.StatusBadge
import com.billlinus.app.ui.theme.Red600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.utils.CouponUtils
import com.billlinus.app.utils.NepaliDateUtils

@Composable
fun InvoiceDetailScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val selectedId by viewModel.selectedInvoiceId.collectAsState()
    val context = LocalContext.current

    val tx = transactions.find { it.id == selectedId }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (tx == null) {
        Scaffold(
            topBar = {
                AppHeader(
                    title = AppStrings.get("invoice_detail.title", lang),
                    lang = lang,
                    onToggleLanguage = { viewModel.toggleLanguage() },
                    showBackButton = true,
                    onBackClick = { viewModel.navigateBack() }
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Invoice not found.", style = MaterialTheme.typography.bodyLarge)
            }
        }
        return
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("invoice_detail.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() },
                actions = {
                    IconButton(
                        onClick = { viewModel.openEditInvoice(tx.id) },
                        modifier = Modifier.testTag("btn_edit_invoice")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.testTag("btn_delete_invoice")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Red600)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Amount Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = tx.sellerName,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.testTag("invoice_detail_seller")
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "NPR ${tx.amount.toInt()}",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    StatusBadge(status = tx.eligibilityStatus, lang = lang)
                }
            }

            // Particulars Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = AppStrings.get("invoice_detail.details_header", lang),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    DetailRow(
                        label = AppStrings.get("invoice_detail.date", lang),
                        value = NepaliDateUtils.formatNepaliDate(tx.date, lang)
                    )
                    DetailRow(
                        label = AppStrings.get("invoice_detail.payment_method", lang),
                        value = AppStrings.getPaymentMethodLabel(tx.paymentMethod, lang)
                    )
                    if (!tx.panVat.isNullOrBlank()) {
                        DetailRow(
                            label = AppStrings.get("invoice_detail.pan", lang),
                            value = tx.panVat
                        )
                    }
                    if (!tx.invoiceNumber.isNullOrBlank()) {
                        DetailRow(
                            label = AppStrings.get("invoice_detail.invoice_no", lang),
                            value = tx.invoiceNumber
                        )
                    }
                    if (!tx.couponNumber.isNullOrBlank()) {
                        DetailRow(
                            label = AppStrings.get("invoice_detail.coupon_no", lang),
                            value = CouponUtils.formatCoupon(tx.couponNumber)
                        )
                    }
                    if (tx.hasWarranty && tx.warrantyMonths != null) {
                        DetailRow(
                            label = "Warranty",
                            value = "${tx.warrantyMonths} Months"
                        )
                    }
                    if (!tx.notes.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = Slate100)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Notes:",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate500)
                        )
                        Text(
                            text = tx.notes,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // Action: Link/Add Coupon if not added
            if (tx.couponNumber.isNullOrBlank()) {
                Button(
                    onClick = {
                        val drawInfo = NepaliDateUtils.getDrawPeriodForDate(tx.date, lang)
                        viewModel.openAddCoupon(
                            prefill = CouponPrefillData(
                                merchantName = tx.sellerName,
                                drawPeriod = drawInfo.drawPeriod,
                                invoiceNumber = tx.invoiceNumber,
                                amount = tx.amount
                            ),
                            linkedInvoiceId = tx.id
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_link_coupon_to_invoice"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = AppStrings.get("invoice_detail.add_coupon", lang),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Action: Verify Vendor PAN if available
            if (!tx.panVat.isNullOrBlank()) {
                OutlinedButton(
                    onClick = { viewModel.openVerifyVendor(tx.panVat) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_verify_vendor_from_detail"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = AppStrings.get("invoice_detail.verify_vendor", lang),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Share Summary
            OutlinedButton(
                onClick = {
                    val shareText = buildString {
                        appendLine("🧾 BillLinus Invoice Summary")
                        appendLine("Seller: ${tx.sellerName}")
                        appendLine("Amount: NPR ${tx.amount.toInt()}")
                        appendLine("Date: ${tx.date}")
                        if (!tx.panVat.isNullOrBlank()) appendLine("PAN: ${tx.panVat}")
                        if (!tx.invoiceNumber.isNullOrBlank()) appendLine("Bill No: ${tx.invoiceNumber}")
                        if (!tx.couponNumber.isNullOrBlank()) appendLine("Coupon: ${tx.couponNumber}")
                    }
                    val sendIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, shareText)
                        type = "text/plain"
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Share Bill Summary"))
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_share_invoice"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Share Bill Details",
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(text = "Delete Invoice") },
            text = { Text(text = "Are you sure you want to delete this invoice record?") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        viewModel.deleteTransaction(tx.id)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Red600)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
