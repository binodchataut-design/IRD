package com.billlinus.app.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.billlinus.app.utils.BillDataUtils
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import kotlin.math.max

data class BillExtractionResult(
    val sellerName: String? = null,
    val panVat: String? = null,
    val invoiceNumber: String? = null,
    val date: String? = null,
    val totalAmount: Double? = null,
    val rawText: String? = null,
    val isSuccess: Boolean = false,
    val isGeminiPowered: Boolean = false,
    val errorMessage: String? = null
)

object BillOcrService {

    private const val OCR_PROMPT = """
You are an expert Nepalese tax invoice and receipt parser.
Extract the following information from this bill image:
1. sellerName: Name of the business, store, company, or merchant.
2. panVat: The 9-digit PAN (Permanent Account Number) or VAT number of the seller. Return digits only.
3. invoiceNumber: The invoice/bill/receipt number (e.g. INV-1002, 080/81-542).
4. date: Date of purchase/bill in YYYY-MM-DD format.
5. totalAmount: Final grand total payable amount as a numeric float/double (e.g. 1250.0).

Return strictly a JSON object with keys: "sellerName", "panVat", "invoiceNumber", "date", "totalAmount".
If any value is missing or unreadable, set its value to null.
Do NOT include markdown formatting or backticks, just the raw JSON object.
"""

    suspend fun processBillImage(
        context: Context,
        uri: Uri
    ): BillExtractionResult = withContext(Dispatchers.IO) {
        val tempFile = File.createTempFile("ocr_bill_", ".jpg", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                tempFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            processBillImage(context, tempFile)
        } catch (e: Exception) {
            BillExtractionResult(
                isSuccess = false,
                errorMessage = e.localizedMessage ?: "Failed to read image"
            )
        } finally {
            tempFile.delete()
        }
    }

    suspend fun processBillImage(
        context: Context,
        imageFile: File
    ): BillExtractionResult = withContext(Dispatchers.IO) {
        val bitmap = try {
            decodeSampledBitmap(imageFile.absolutePath, maxDimension = 1280)
        } catch (_: Exception) {
            null
        }

        if (bitmap == null) {
            return@withContext BillExtractionResult(
                isSuccess = false,
                errorMessage = "Failed to load image file."
            )
        }

        // 1. Try Gemini via Firebase AI
        try {
            val generativeModel = Firebase.ai.generativeModel(modelName = "gemini-2.5-flash")
            val content = content {
                image(bitmap)
                text(OCR_PROMPT)
            }
            val response = generativeModel.generateContent(content)
            val responseText = response.text
            if (!responseText.isNullOrBlank()) {
                val parsed = parseGeminiJsonResponse(responseText)
                if (parsed != null && parsed.isSuccess) {
                    return@withContext parsed.copy(isGeminiPowered = true)
                }
            }
        } catch (_: Exception) {
            // Fall back to on-device ML Kit OCR
        }

        // 2. Fallback to ML Kit Text Recognition
        try {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            try {
                val visionText = recognizer.process(inputImage).await()
                val rawText = visionText.text
                if (rawText.isNotBlank()) {
                    val billData = BillDataUtils.extractFromText(rawText)
                    val hasAnyData = billData.pan.isNotBlank() ||
                            billData.amount.isNotBlank() ||
                            billData.sellerName.isNotBlank() ||
                            billData.invoiceNumber.isNotBlank()

                    if (hasAnyData || rawText.length >= 20) {
                        return@withContext BillExtractionResult(
                            sellerName = billData.sellerName.takeIf { it.isNotBlank() },
                            panVat = billData.pan.takeIf { it.isNotBlank() },
                            invoiceNumber = billData.invoiceNumber.takeIf { it.isNotBlank() },
                            date = billData.date.takeIf { it.isNotBlank() },
                            totalAmount = billData.amount.toDoubleOrNull(),
                            rawText = rawText,
                            isSuccess = hasAnyData,
                            isGeminiPowered = false
                        )
                    }
                }
            } finally {
                recognizer.close()
            }
        } catch (_: Exception) {
        }

        return@withContext BillExtractionResult(
            isSuccess = false,
            errorMessage = "Could not extract fields from image."
        )
    }

    private fun decodeSampledBitmap(path: String, maxDimension: Int): Bitmap? {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(path, options)

        val height = options.outHeight
        val width = options.outWidth
        if (height <= 0 || width <= 0) return null

        var inSampleSize = 1
        val maxSide = max(height, width)
        if (maxSide > maxDimension) {
            inSampleSize = maxSide / maxDimension
        }

        val decodeOptions = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(path, decodeOptions)
    }

    fun parseGeminiJsonResponse(rawResponse: String): BillExtractionResult? {
        val clean = rawResponse
            .replace("```json", "")
            .replace("```", "")
            .trim()

        val jsonStart = clean.indexOf('{')
        val jsonEnd = clean.lastIndexOf('}')
        if (jsonStart == -1 || jsonEnd == -1 || jsonEnd <= jsonStart) {
            return null
        }

        val jsonSubstring = clean.substring(jsonStart, jsonEnd + 1)
        return try {
            val obj = JSONObject(jsonSubstring)
            val sellerName = obj.optString("sellerName").takeIf { it.isNotBlank() && it != "null" }
            val rawPan = obj.optString("panVat").takeIf { it.isNotBlank() && it != "null" }
            val panVat = rawPan?.filter { it.isDigit() }?.takeIf { it.length == 9 } ?: rawPan?.filter { it.isDigit() }
            val invoiceNumber = obj.optString("invoiceNumber").takeIf { it.isNotBlank() && it != "null" }
            val date = obj.optString("date").takeIf { it.isNotBlank() && it != "null" }
            val amountVal = if (obj.has("totalAmount") && !obj.isNull("totalAmount")) {
                obj.optDouble("totalAmount", 0.0).takeIf { it > 0.0 }
            } else null

            val hasExtractedField = !sellerName.isNullOrBlank() ||
                    !panVat.isNullOrBlank() ||
                    !invoiceNumber.isNullOrBlank() ||
                    amountVal != null

            BillExtractionResult(
                sellerName = sellerName,
                panVat = panVat,
                invoiceNumber = invoiceNumber,
                date = date,
                totalAmount = amountVal,
                rawText = clean,
                isSuccess = hasExtractedField
            )
        } catch (_: Exception) {
            null
        }
    }
}
