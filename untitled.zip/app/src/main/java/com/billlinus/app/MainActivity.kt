package com.billlinus.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.billlinus.app.model.DarkModePreference
import com.billlinus.app.model.ScreenName
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.screens.AccountSetupScreen
import com.billlinus.app.ui.screens.AddCouponScreen
import com.billlinus.app.ui.screens.AddInvoiceScreen
import com.billlinus.app.ui.screens.BulkAddCouponsScreen
import com.billlinus.app.ui.screens.ClaimReportScreen
import com.billlinus.app.ui.screens.CouponsScreen
import com.billlinus.app.ui.screens.DataBackupScreen
import com.billlinus.app.ui.screens.EligibilityCheckerScreen
import com.billlinus.app.ui.screens.ExpensesScreen
import com.billlinus.app.ui.screens.HomeScreen
import com.billlinus.app.ui.screens.InvoiceDetailScreen
import com.billlinus.app.ui.screens.InvoicesScreen
import com.billlinus.app.ui.screens.IrdInfoScreen
import com.billlinus.app.ui.screens.LockScreen
import com.billlinus.app.ui.screens.ProfileScreen
import com.billlinus.app.ui.screens.ScanScreen
import com.billlinus.app.ui.screens.VerifyVendorScreen
import com.billlinus.app.ui.screens.WelcomeScreen
import com.billlinus.app.ui.screens.WinnerCheckerScreen
import com.billlinus.app.ui.theme.BillLinusTheme

class MainActivity : FragmentActivity() {
    private val viewModel: MainViewModel by viewModels()
    private var backgroundTimestamp: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleNotificationIntent(intent)
        setContent {
            val darkModePref by viewModel.darkMode.collectAsState()
            val fontScalePref by viewModel.fontScale.collectAsState()
            val isDark = when (darkModePref) {
                DarkModePreference.DARK -> true
                DarkModePreference.LIGHT -> false
                DarkModePreference.SYSTEM -> isSystemInDarkTheme()
            }

            BillLinusTheme(
                darkTheme = isDark,
                fontScale = fontScalePref.factor
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BillLinusApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        backgroundTimestamp = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        if (backgroundTimestamp > 0L) {
            val elapsed = System.currentTimeMillis() - backgroundTimestamp
            val lockTimeoutMillis = 2 * 60 * 1000L // 2 minutes
            if (elapsed >= lockTimeoutMillis) {
                viewModel.checkAndLockIfEnabled()
            }
            backgroundTimestamp = 0L
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkForWinningAnnouncements()
    }

    private fun handleNotificationIntent(intent: Intent?) {
        if (intent?.getStringExtra("destination") == "WINNER_CHECKER") {
            viewModel.navigateTo(ScreenName.WINNER_CHECKER)
        }
    }
}

@Composable
fun BillLinusApp(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val hasCompletedWelcome by viewModel.hasCompletedWelcome.collectAsState()
    val isAppLockEnabled by viewModel.isAppLockEnabled.collectAsState()
    val isAppLocked by viewModel.isAppLocked.collectAsState()
    val context = LocalContext.current

    // Request notification permission once after Welcome is completed (Android 13+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { _ ->
            viewModel.markNotificationPermissionPrompted()
        }

        LaunchedEffect(hasCompletedWelcome) {
            if (hasCompletedWelcome && !viewModel.hasPromptedNotificationPermission()) {
                val isGranted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!isGranted) {
                    viewModel.markNotificationPermissionPrompted()
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    viewModel.markNotificationPermissionPrompted()
                }
            }
        }
    }

    // Handle system back button for in-app navigation stack
    BackHandler(enabled = currentScreen != ScreenName.HOME && hasCompletedWelcome) {
        viewModel.navigateBack()
    }

    if (!hasCompletedWelcome) {
        WelcomeScreen(viewModel = viewModel)
    } else if (isAppLockEnabled && isAppLocked) {
        LockScreen(viewModel = viewModel)
    } else {
        when (currentScreen) {
            ScreenName.WELCOME -> WelcomeScreen(viewModel = viewModel)
            ScreenName.ACCOUNT_SETUP -> AccountSetupScreen(viewModel = viewModel)
            ScreenName.HOME -> HomeScreen(viewModel = viewModel)
            ScreenName.INVOICES -> InvoicesScreen(viewModel = viewModel)
            ScreenName.ADD_INVOICE -> AddInvoiceScreen(viewModel = viewModel)
            ScreenName.INVOICE_DETAIL -> InvoiceDetailScreen(viewModel = viewModel)
            ScreenName.COUPONS -> CouponsScreen(viewModel = viewModel)
            ScreenName.ADD_COUPON -> AddCouponScreen(viewModel = viewModel)
            ScreenName.BULK_ADD_COUPONS -> BulkAddCouponsScreen(viewModel = viewModel)
            ScreenName.WINNER_CHECKER -> WinnerCheckerScreen(viewModel = viewModel)
            ScreenName.CLAIM_REPORT -> ClaimReportScreen(viewModel = viewModel)
            ScreenName.CHECK_ELIGIBILITY -> EligibilityCheckerScreen(viewModel = viewModel)
            ScreenName.VERIFY_VENDOR -> VerifyVendorScreen(viewModel = viewModel)
            ScreenName.IRD_INFO -> IrdInfoScreen(viewModel = viewModel)
            ScreenName.SCAN -> ScanScreen(viewModel = viewModel)
            ScreenName.EXPENSES -> ExpensesScreen(viewModel = viewModel)
            ScreenName.PROFILE -> ProfileScreen(viewModel = viewModel)
            ScreenName.DATA_BACKUP -> DataBackupScreen(viewModel = viewModel)
            ScreenName.WELCOME -> WelcomeScreen(viewModel = viewModel)
        }
    }
}

