package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.theme.Amber100
import com.billlinus.app.ui.theme.Amber600
import com.billlinus.app.ui.theme.Emerald100
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Indigo100
import com.billlinus.app.ui.theme.Indigo600
import com.billlinus.app.ui.theme.Red100
import com.billlinus.app.ui.theme.Red600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.utils.CouponUtils

@Composable
fun BulkAddCouponsScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val existingCoupons by viewModel.coupons.collectAsState()

    var rawText by remember { mutableStateOf("") }
    var defaultMerchant by remember { mutableStateOf("") }
    var savedCount by remember { mutableStateOf<Int?>(null) }

    val existingSet = remember(existingCoupons) {
        existingCoupons.map { it.couponNumber }.toSet()
    }

    val parseResult = remember(rawText, existingSet) {
        CouponUtils.parseBulkCouponsText(rawText, existingSet)
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("bulk.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = AppStrings.get("bulk.instruction", lang),
                        style = MaterialTheme.typography.bodyMedium.copy(color = Slate700)
                    )

                    OutlinedTextField(
                        value = rawText,
                        onValueChange = {
                            rawText = it
                            savedCount = null
                        },
                        placeholder = { Text(AppStrings.get("bulk.placeholder", lang)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .testTag("input_bulk_coupons_textarea"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = defaultMerchant,
                        onValueChange = { defaultMerchant = it },
                        label = { Text(AppStrings.get("bulk.merchant_label", lang)) },
                        placeholder = { Text(AppStrings.get("bulk.merchant_placeholder", lang)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_bulk_merchant"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            // Real-time Parsing Statistics
            if (rawText.isNotBlank()) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Parsed Coupon Summary",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StatChip(
                                label = AppStrings.get("bulk.valid_new", lang),
                                count = parseResult.validNew.size,
                                bgColor = Emerald100,
                                textColor = Emerald600,
                                modifier = Modifier.weight(1f)
                            )
                            StatChip(
                                label = AppStrings.get("bulk.duplicates", lang),
                                count = parseResult.duplicateInBatch.size,
                                bgColor = Amber100,
                                textColor = Amber600,
                                modifier = Modifier.weight(1f)
                            )
                            StatChip(
                                label = AppStrings.get("bulk.already_saved", lang),
                                count = parseResult.alreadySaved.size,
                                bgColor = Indigo100,
                                textColor = Indigo600,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (parseResult.invalidTokens.isNotEmpty()) {
                            Text(
                                text = "${AppStrings.get("bulk.invalid", lang)}: ${parseResult.invalidTokens.size} entries (must be 12 digits)",
                                style = MaterialTheme.typography.labelSmall.copy(color = Red600)
                            )
                        }
                    }
                }
            }

            if (savedCount != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Emerald100,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Emerald600,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "$savedCount ${AppStrings.get("bulk.save_success", lang)}",
                            color = Emerald600,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Button(
                onClick = {
                    if (parseResult.validNew.isNotEmpty()) {
                        val count = viewModel.saveBulkCoupons(
                            couponNumbers = parseResult.validNew,
                            defaultMerchant = defaultMerchant.ifBlank { null }
                        )
                        savedCount = count
                        rawText = ""
                    }
                },
                enabled = parseResult.validNew.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_save_bulk_coupons"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = "${AppStrings.get("bulk.save_btn", lang)} ${parseResult.validNew.size} ${AppStrings.get("bulk.coupons_word", lang)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun StatChip(
    label: String,
    count: Int,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = textColor,
                    fontSize = 10.sp
                )
            )
        }
    }
}
