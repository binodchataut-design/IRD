package com.billlinus.app.utils

import com.billlinus.app.model.Coupon
import com.billlinus.app.model.DrawAnnouncement
import com.billlinus.app.model.EligibilityStatus
import com.billlinus.app.model.PaymentMethod
import com.billlinus.app.model.Transaction
import com.billlinus.app.model.TransactionCategory
import java.time.LocalDate
import java.util.UUID

object SampleData {

    fun generateId(): String {
        return UUID.randomUUID().toString().replace("-", "").take(12)
    }

    fun getSampleTransactions(): List<Transaction> {
        val today = LocalDate.now().toString()
        val yesterday = LocalDate.now().minusDays(1).toString()
        val twoDaysAgo = LocalDate.now().minusDays(2).toString()

        return listOf(
            Transaction(
                id = "tx-sample-1",
                date = today,
                sellerName = "Bhatbhateni Supermarket",
                amount = 1450.0,
                paymentMethod = PaymentMethod.QR_PAYMENT,
                panVat = "300054891",
                invoiceNumber = "BBSM-89412",
                couponNumber = "007315254493",
                eligibilityStatus = EligibilityStatus.COUPON_ADDED,
                notes = "Groceries and household essentials",
                photoReference = null,
                createdAt = today,
                category = TransactionCategory.NORMAL_GOODS,
                hasWarranty = false
            ),
            Transaction(
                id = "tx-sample-2",
                date = yesterday,
                sellerName = "Himalayan Java Coffee",
                amount = 680.0,
                paymentMethod = PaymentMethod.DIGITAL_WALLET,
                panVat = "601248902",
                invoiceNumber = "HJC-4412",
                couponNumber = null,
                eligibilityStatus = EligibilityStatus.LIKELY_ELIGIBLE,
                notes = "Coffee and snacks with friends",
                photoReference = null,
                createdAt = yesterday,
                category = TransactionCategory.FOOD_RESTAURANT,
                hasWarranty = false
            ),
            Transaction(
                id = "tx-sample-3",
                date = twoDaysAgo,
                sellerName = "CG Digital Electronics",
                amount = 18500.0,
                paymentMethod = PaymentMethod.CARD,
                panVat = "301984512",
                invoiceNumber = "CG-9921",
                couponNumber = "007315254495",
                eligibilityStatus = EligibilityStatus.COUPON_ADDED,
                notes = "Microwave Oven with 1 year warranty",
                photoReference = null,
                createdAt = twoDaysAgo,
                category = TransactionCategory.ELECTRONICS,
                hasWarranty = true,
                warrantyMonths = 12
            )
        )
    }

    fun getSampleCoupons(): List<Coupon> {
        val today = LocalDate.now().toString()
        val yesterday = LocalDate.now().minusDays(1).toString()
        val twoDaysAgo = LocalDate.now().minusDays(2).toString()

        return listOf(
            Coupon(
                id = "cp-sample-1",
                couponNumber = "007315254493",
                date = today,
                drawPeriod = "Bhadra 1–15, 2083",
                merchantName = "Bhatbhateni Supermarket",
                amount = 1450.0,
                paymentMethod = "QR Payment",
                invoiceNumber = "BBSM-89412",
                notes = "Official IRD e-billing coupon",
                createdAt = today
            ),
            Coupon(
                id = "cp-sample-2",
                couponNumber = "007315254494",
                date = yesterday,
                drawPeriod = "Bhadra 1–15, 2083",
                merchantName = "Big Mart",
                amount = 890.0,
                paymentMethod = "Fonepay QR",
                invoiceNumber = "BM-2041",
                notes = "Daily grocery shopping",
                createdAt = yesterday
            ),
            Coupon(
                id = "cp-sample-3",
                couponNumber = "007315254495",
                date = twoDaysAgo,
                drawPeriod = "Shrawan 16–31, 2083",
                merchantName = "CG Digital Electronics",
                amount = 18500.0,
                paymentMethod = "Visa Card",
                invoiceNumber = "CG-9921",
                notes = "Appliance purchase coupon",
                createdAt = twoDaysAgo
            )
        )
    }

    fun getSampleDraws(): List<DrawAnnouncement> {
        return listOf(
            DrawAnnouncement(
                id = "draw-bhadra-2083-1",
                title = "Bhadra 1–15, 2083 Fortnightly Draw",
                drawPeriod = "Bhadra 1–15, 2083",
                announcementDate = "2026-08-16",
                winningNumbers = listOf(
                    "007315254493",
                    "007315254499",
                    "007315254500",
                    "007315254505"
                ),
                sourceUrl = "https://prize.ird.gov.np/",
                sourceName = "Inland Revenue Department Nepal",
                notes = "Official Bumper and Daily prize winners list",
                createdAt = "2026-08-16T10:00:00Z"
            )
        )
    }
}
