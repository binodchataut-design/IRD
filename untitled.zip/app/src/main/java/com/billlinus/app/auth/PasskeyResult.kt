package com.billlinus.app.auth

/**
 * Result representation for Credential Manager passkey operations.
 * Raw credentials or keys are never exposed directly to the UI layer.
 */
sealed interface PasskeyResult {
    /** Passkey successfully created or authenticated */
    data class Success(val responseJson: String) : PasskeyResult

    /** User dismissed or cancelled the biometric / passkey prompt */
    data object Cancelled : PasskeyResult

    /** No saved passkey was found on the device for this account */
    data object NoPasskeyFound : PasskeyResult

    /** Device does not have Credential Manager or passkey provider support */
    data class NotSupported(val message: String) : PasskeyResult

    /** An error occurred during the credential operation */
    data class Error(val message: String, val throwable: Throwable? = null) : PasskeyResult
}
