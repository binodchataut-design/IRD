package com.billlinus.app.utils

import com.billlinus.app.model.AppLanguage
import java.time.LocalDate

data class BSDate(
    val year: Int,
    val month: Int,
    val day: Int
)

data class DrawPeriodInfo(
    val cycleName: String,
    val drawPeriod: String,
    val expectedAnnouncement: String
)

object NepaliDateUtils {

    private val NEPALI_MONTHS_EN = listOf(
        "Baisakh", "Jestha", "Ashadh", "Shrawan", "Bhadra", "Ashwin",
        "Kartik", "Mangsir", "Poush", "Magh", "Falgun", "Chaitra"
    )

    private val NEPALI_MONTHS_NE = listOf(
        "बैशाख", "जेठ", "असार", "श्रावण", "भाद्र", "आश्विन",
        "कार्तिक", "मंसिर", "पौष", "माघ", "फाल्गुन", "चैत्र"
    )

    fun getCurrentDrawPeriod(lang: AppLanguage = AppLanguage.EN): DrawPeriodInfo {
        return getDrawPeriodForDate(LocalDate.now().toString(), lang)
    }

    fun getCurrentDrawPeriodInfo(): DrawPeriodInfo {
        return getCurrentDrawPeriod(AppLanguage.EN)
    }

    fun dateStrToBS(dateIso: String?): BSDate? {
        if (dateIso.isNullOrBlank()) return null
        return try {
            val date = LocalDate.parse(dateIso)
            val bsYear = date.year + 57
            val monthIdx = (date.monthValue + 8) % 12
            BSDate(year = bsYear, month = monthIdx + 1, day = date.dayOfMonth)
        } catch (_: Exception) {
            null
        }
    }

    fun getDrawPeriodForDate(dateIso: String?, lang: AppLanguage = AppLanguage.EN): DrawPeriodInfo {
        val date = try {
            if (dateIso.isNullOrBlank()) LocalDate.now() else LocalDate.parse(dateIso)
        } catch (_: Exception) {
            LocalDate.now()
        }

        val bsYear = date.year + 57
        val day = date.dayOfMonth
        val month = date.monthValue
        val monthIdx = (month + 8) % 12

        val isFirstHalf = day <= 15
        val monthName = if (lang == AppLanguage.NE) NEPALI_MONTHS_NE[monthIdx] else NEPALI_MONTHS_EN[monthIdx]

        val period = if (lang == AppLanguage.NE) {
            if (isFirstHalf) "$monthName १–१५, $bsYear" else "$monthName १६–महिनान्त, $bsYear"
        } else {
            if (isFirstHalf) "$monthName 1–15, $bsYear" else "$monthName 16–End, $bsYear"
        }

        val cycle = if (lang == AppLanguage.NE) {
            if (isFirstHalf) "पाक्षिक (पहिलो पन्ध्र दिन)" else "पाक्षिक (दोस्रो पन्ध्र दिन)"
        } else {
            if (isFirstHalf) "Fortnightly (1st Half)" else "Fortnightly (2nd Half)"
        }

        val announcement = if (lang == AppLanguage.NE) {
            if (isFirstHalf) "$monthName १६, $bsYear" else "आगामी महिना १, $bsYear"
        } else {
            if (isFirstHalf) "$monthName 16, $bsYear" else "Next Month 1st, $bsYear"
        }

        return DrawPeriodInfo(
            cycleName = cycle,
            drawPeriod = period,
            expectedAnnouncement = announcement
        )
    }

    fun formatNepaliDate(dateIso: String?, lang: AppLanguage = AppLanguage.EN): String {
        if (dateIso.isNullOrBlank()) return ""
        return try {
            val date = LocalDate.parse(dateIso)
            val bsYear = date.year + 57
            val monthIdx = (date.monthValue + 8) % 12
            val monthName = if (lang == AppLanguage.NE) NEPALI_MONTHS_NE[monthIdx] else NEPALI_MONTHS_EN[monthIdx]
            "$monthName ${date.dayOfMonth}, $bsYear BS"
        } catch (_: Exception) {
            dateIso
        }
    }

    fun toBikramSambat(dateIso: String?): String {
        return formatNepaliDate(dateIso, AppLanguage.EN)
    }

    fun adToBs(date: LocalDate): String {
        val bsYear = date.year + 57
        val bsMonth = NEPALI_MONTHS_EN[(date.monthValue + 8) % 12]
        return "$bsMonth ${date.dayOfMonth}, $bsYear BS"
    }

    fun getNepaliMonthName(monthIndex: Int, lang: AppLanguage = AppLanguage.EN): String {
        return if (lang == AppLanguage.NE) {
            NEPALI_MONTHS_NE.getOrElse(monthIndex % NEPALI_MONTHS_NE.size) { "बैशाख" }
        } else {
            NEPALI_MONTHS_EN.getOrElse(monthIndex % NEPALI_MONTHS_EN.size) { "Baisakh" }
        }
    }
}
