package com.billlinus.app.model

import kotlinx.serialization.Serializable

@Serializable
data class UserProfile(
    val uid: String = "",
    val mobileNumber: String? = null,
    val displayName: String? = null,
    val mobileVerificationStatus: String = "NOT_VERIFIED",
    val createdAt: String,
    val updatedAt: String
)
