package com.billlinus.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.ScreenName
import com.billlinus.app.model.Transaction
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppBottomNav
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.components.EmptyStateView
import com.billlinus.app.ui.components.StatusBadge
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.utils.NepaliDateUtils

@Composable
fun InvoicesScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val filteredTransactions = remember(transactions, searchQuery) {
        if (searchQuery.isBlank()) {
            transactions.sortedByDescending { it.date }
        } else {
            val query = searchQuery.trim().lowercase()
            transactions.filter {
                it.sellerName.lowercase().contains(query) ||
                        (it.invoiceNumber?.lowercase()?.contains(query) == true) ||
                        (it.panVat?.lowercase()?.contains(query) == true) ||
                        (it.couponNumber?.lowercase()?.contains(query) == true)
            }.sortedByDescending { it.date }
        }
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("invoices.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = false
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = ScreenName.INVOICES,
                onNavigate = { viewModel.navigateTo(it) },
                lang = lang
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddInvoice() },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_invoice")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Invoice")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("search_invoices_input"),
                placeholder = {
                    Text(
                        text = AppStrings.get("invoices.search_placeholder", lang),
                        style = MaterialTheme.typography.bodyMedium.copy(color = Slate400)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = Slate400
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear Search",
                                tint = Slate400
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Slate100,
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )

            if (filteredTransactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        icon = Icons.Default.Receipt,
                        title = if (searchQuery.isBlank()) AppStrings.get("invoices.empty_title", lang) else "No matching bills found",
                        description = if (searchQuery.isBlank()) AppStrings.get("invoices.empty_desc", lang) else "Try searching with a different seller, bill number or PAN.",
                        actionText = if (searchQuery.isBlank()) AppStrings.get("invoices.add_first", lang) else null,
                        onActionClick = { viewModel.openAddInvoice() }
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    items(filteredTransactions, key = { it.id }) { tx ->
                        InvoiceListItemCard(
                            transaction = tx,
                            lang = lang,
                            onClick = { viewModel.selectInvoice(tx.id) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun InvoiceListItemCard(
    transaction: Transaction,
    lang: com.billlinus.app.model.AppLanguage,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("invoice_item_${transaction.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = transaction.sellerName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "NPR ${transaction.amount.toInt()}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = NepaliDateUtils.formatNepaliDate(transaction.date, lang),
                        style = MaterialTheme.typography.bodySmall.copy(color = Slate500)
                    )
                    if (!transaction.invoiceNumber.isNullOrBlank()) {
                        Text(
                            text = "Bill #${transaction.invoiceNumber}",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate400)
                        )
                    }
                }

                StatusBadge(status = transaction.eligibilityStatus, lang = lang)
            }
        }
    }
}
