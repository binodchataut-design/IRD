package com.billlinus.app.utils

data class ExtractedBillData(
    val sellerName: String = "",
    val pan: String = "",
    val invoiceNumber: String = "",
    val date: String = "",
    val amount: String = ""
)

object BillDataUtils {

    fun extractFromText(rawText: String): ExtractedBillData {
        var sellerName = ""
        var pan = ""
        var invoiceNumber = ""
        var date = ""
        var amount = ""

        val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }

        // Find PAN / VAT: 9 digit number
        val panRegex = Regex("""(?:PAN|VAT|प्यान|भ्याट)[:\s]*([0-9]{9})\b""", RegexOption.IGNORE_CASE)
        val standalonePanRegex = Regex("""\b([0-9]{9})\b""")

        for (line in lines) {
            val panMatch = panRegex.find(line)
            if (panMatch != null && pan.isBlank()) {
                pan = panMatch.groupValues[1]
                continue
            }
            if (pan.isBlank()) {
                val match9 = standalonePanRegex.find(line)
                if (match9 != null) {
                    pan = match9.groupValues[1]
                }
            }
        }

        // Find Total Amount: Rs. / NPR / Total / जम्मा
        val amountRegex = Regex("""(?:Total|Grand Total|Net Total|Amount|जम्मा|कुल)[:\s]*(?:Rs\.?|NPR)?\s*([0-9,]+(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
        for (line in lines) {
            val match = amountRegex.find(line)
            if (match != null && amount.isBlank()) {
                amount = match.groupValues[1].replace(",", "")
                break
            }
        }

        // Find Invoice Number: Inv No, Bill No, Invoice #
        val invRegex = Regex("""(?:Inv(?:oice)?|Bill)\s*(?:No|#|\.)?[:\s]*([A-Za-z0-9\-_/]+)""", RegexOption.IGNORE_CASE)
        for (line in lines) {
            val match = invRegex.find(line)
            if (match != null && invoiceNumber.isBlank()) {
                invoiceNumber = match.groupValues[1]
                break
            }
        }

        // Seller name is typically first non-empty header line
        if (lines.isNotEmpty()) {
            sellerName = lines.firstOrNull { it.length > 3 && !it.contains(Regex("""\d{4}""")) } ?: lines[0]
        }

        return ExtractedBillData(
            sellerName = sellerName,
            pan = pan,
            invoiceNumber = invoiceNumber,
            date = date,
            amount = amount
        )
    }
}
