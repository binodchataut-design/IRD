package com.billlinus.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.auth.PasskeyResult
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.theme.Amber100
import com.billlinus.app.ui.theme.Amber600
import com.billlinus.app.ui.theme.Emerald100
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Indigo100
import com.billlinus.app.ui.theme.Indigo600
import com.billlinus.app.ui.theme.Red600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate200
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.ui.theme.Slate800
import com.billlinus.app.ui.theme.Slate900
import com.billlinus.app.utils.PhoneUtils

private enum class SetupStep {
    MOBILE_INPUT,
    PASSKEY_PROMPT
}

@Composable
fun AccountSetupScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val isPasskeyEnabled by viewModel.isPasskeyEnabled.collectAsState()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    // If the user already has a mobile number and no passkey, default to passkey step
    var currentStep by remember {
        mutableStateOf(
            if (!userProfile?.mobileNumber.isNullOrBlank() && !isPasskeyEnabled) {
                SetupStep.PASSKEY_PROMPT
            } else {
                SetupStep.MOBILE_INPUT
            }
        )
    }

    var mobileInput by remember(userProfile) {
        mutableStateOf(userProfile?.mobileNumber ?: "")
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var passkeyNoticeMessage by remember { mutableStateOf<String?>(null) }
    var isPasskeyLoading by remember { mutableStateOf(false) }

    fun submitMobile() {
        focusManager.clearFocus()
        val normalized = PhoneUtils.normalizeNepalMobile(mobileInput)
        if (PhoneUtils.isValidNepalMobile(normalized)) {
            errorMessage = null
            viewModel.saveAccountProfile(mobileNumber = normalized)
            currentStep = SetupStep.PASSKEY_PROMPT
        } else {
            errorMessage = AppStrings.get("account_setup.error_invalid_mobile", lang)
        }
    }

    fun handleCreatePasskey() {
        if (isPasskeyLoading) return
        isPasskeyLoading = true
        passkeyNoticeMessage = null

        viewModel.createPasskey(context) { result ->
            isPasskeyLoading = false
            when (result) {
                is PasskeyResult.Success -> {
                    Toast.makeText(
                        context,
                        AppStrings.get("passkey.success_created", lang),
                        Toast.LENGTH_SHORT
                    ).show()
                    viewModel.completeAccountSetup()
                }
                is PasskeyResult.Cancelled -> {
                    passkeyNoticeMessage = AppStrings.get("passkey.cancelled_message", lang)
                }
                is PasskeyResult.NotSupported -> {
                    passkeyNoticeMessage = AppStrings.get("passkey.not_supported", lang)
                }
                is PasskeyResult.Error -> {
                    passkeyNoticeMessage = result.message.ifBlank {
                        AppStrings.get("passkey.cancelled_message", lang)
                    }
                }
                is PasskeyResult.NoPasskeyFound -> {
                    passkeyNoticeMessage = AppStrings.get("passkey.no_passkey_found", lang)
                }
            }
        }
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = if (currentStep == SetupStep.PASSKEY_PROMPT) {
                    AppStrings.get("passkey.create_title", lang)
                } else {
                    AppStrings.get("account_setup.title", lang)
                },
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() },
                showBackButton = true,
                onBackClick = {
                    if (currentStep == SetupStep.PASSKEY_PROMPT) {
                        currentStep = SetupStep.MOBILE_INPUT
                    } else {
                        viewModel.completeAccountSetup()
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.TopCenter
        ) {
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "account_setup_step_transition"
            ) { step ->
                when (step) {
                    SetupStep.MOBILE_INPUT -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 560.dp)
                                .verticalScroll(rememberScrollState())
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            Spacer(modifier = Modifier.height(6.dp))

                            // Hero Illustration / Icon Badge
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(72.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.PhoneAndroid,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                            }

                            // Title and Subtitle
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = AppStrings.get("account_setup.title", lang),
                                    style = MaterialTheme.typography.headlineSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 22.sp,
                                        color = Slate900
                                    ),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = AppStrings.get("account_setup.subtitle", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 14.sp,
                                        lineHeight = 20.sp
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }

                            // Input Card
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp)
                                ) {
                                    Text(
                                        text = AppStrings.get("account_setup.field_mobile", lang),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Slate800
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    OutlinedTextField(
                                        value = mobileInput,
                                        onValueChange = {
                                            mobileInput = it
                                            if (errorMessage != null) {
                                                errorMessage = null
                                            }
                                        },
                                        placeholder = {
                                            Text(
                                                text = AppStrings.get("account_setup.field_placeholder", lang),
                                                color = Slate400
                                            )
                                        },
                                        leadingIcon = {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(start = 12.dp, end = 6.dp)
                                            ) {
                                                Text(
                                                    text = "🇳🇵 +977",
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = Slate700
                                                    )
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .width(1.dp)
                                                        .height(20.dp)
                                                        .background(Slate200)
                                                )
                                            }
                                        },
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Phone,
                                            imeAction = ImeAction.Done
                                        ),
                                        keyboardActions = KeyboardActions(
                                            onDone = { submitMobile() }
                                        ),
                                        singleLine = true,
                                        isError = errorMessage != null,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("account_setup_mobile_input"),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                                            unfocusedBorderColor = Slate200,
                                            errorBorderColor = Red600
                                        )
                                    )

                                    if (errorMessage != null) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = errorMessage ?: "",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = Red600,
                                                fontSize = 12.sp
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(18.dp))

                                    // Continue Button
                                    Button(
                                        onClick = { submitMobile() },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(50.dp)
                                            .testTag("btn_account_setup_continue"),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary
                                        )
                                    ) {
                                        Text(
                                            text = AppStrings.get("account_setup.button_continue", lang),
                                            style = MaterialTheme.typography.labelLarge.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            // Information & Privacy Card
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = Slate500,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = AppStrings.get("account_setup.notice", lang),
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = Slate500,
                                            fontSize = 12.sp,
                                            lineHeight = 17.sp
                                        )
                                    )
                                }
                            }

                            // Skip Button
                            TextButton(
                                onClick = {
                                    viewModel.completeAccountSetup()
                                },
                                modifier = Modifier.testTag("btn_account_setup_skip")
                            ) {
                                Text(
                                    text = AppStrings.get("account_setup.button_skip", lang),
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        color = Slate500,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    SetupStep.PASSKEY_PROMPT -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 560.dp)
                                .verticalScroll(rememberScrollState())
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            Spacer(modifier = Modifier.height(6.dp))

                            // Hero Passkey Badge
                            Surface(
                                shape = CircleShape,
                                color = Indigo100,
                                modifier = Modifier.size(76.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Key,
                                        contentDescription = null,
                                        tint = Indigo600,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }

                            // Title and Subtitle
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = AppStrings.get("passkey.create_title", lang),
                                    style = MaterialTheme.typography.headlineSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 22.sp,
                                        color = Slate900
                                    ),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = AppStrings.get("passkey.create_subtitle", lang),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Slate500,
                                        fontSize = 14.sp,
                                        lineHeight = 20.sp
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }

                            // Biometric/Device Authentication Card (Task 6 wording compliance)
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = Slate100,
                                            modifier = Modifier.size(44.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Default.Fingerprint,
                                                    contentDescription = null,
                                                    tint = Slate700,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = AppStrings.get("passkey.biometric_notice", lang),
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    color = Slate700,
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 14.sp,
                                                    lineHeight = 19.sp
                                                )
                                            )
                                        }
                                    }

                                    // Display message if user cancelled or error occurred
                                    if (passkeyNoticeMessage != null) {
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = Amber100.copy(alpha = 0.6f),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.Top
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Info,
                                                    contentDescription = null,
                                                    tint = Amber600,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = passkeyNoticeMessage ?: "",
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        color = Slate800,
                                                        fontSize = 13.sp,
                                                        lineHeight = 18.sp
                                                    )
                                                )
                                            }
                                        }
                                    }

                                    // Create Passkey Button
                                    Button(
                                        onClick = { handleCreatePasskey() },
                                        enabled = !isPasskeyLoading,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp)
                                            .testTag("btn_create_passkey"),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary
                                        )
                                    ) {
                                        if (isPasskeyLoading) {
                                            CircularProgressIndicator(
                                                color = Color.White,
                                                strokeWidth = 2.dp,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                        }
                                        Icon(
                                            imageVector = Icons.Default.Key,
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = AppStrings.get("passkey.create_button", lang),
                                            style = MaterialTheme.typography.labelLarge.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp
                                            )
                                        )
                                    }
                                }
                            }

                            // Fallback Option (Task 10 — never lock out user)
                            OutlinedButton(
                                onClick = {
                                    viewModel.completeAccountSetup()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("btn_continue_without_passkey"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Slate700
                                )
                            ) {
                                Text(
                                    text = AppStrings.get("passkey.continue_without", lang),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                }
            }
        }
    }
}
