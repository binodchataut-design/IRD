package com.billlinus.app.auth

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.credentials.CreatePublicKeyCredentialRequest
import androidx.credentials.CreatePublicKeyCredentialResponse
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetPublicKeyCredentialOption
import androidx.credentials.PublicKeyCredential
import androidx.credentials.exceptions.CreateCredentialCancellationException
import androidx.credentials.exceptions.CreateCredentialNoCreateOptionException
import androidx.credentials.exceptions.CreateCredentialProviderConfigurationException
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialProviderConfigurationException
import androidx.credentials.exceptions.NoCredentialException
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.billlinus.app.data.FirestoreCollections
import com.billlinus.app.model.UserProfile
import com.billlinus.app.utils.PhoneUtils
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.SecureRandom
import java.time.Instant

/**
 * Concrete implementation of [AuthRepository] backed by AndroidX Credential Manager (Passkeys)
 * and Firebase Authentication / Firestore, combined with secure local profile persistence.
 *
 * Security guarantees:
 * - Passkey private keys and biometric templates are NEVER handled or stored by the app.
 * - Biometric and device authentication are handled exclusively by the OS Credential Manager.
 * - Does NOT invent fake Firebase sessions or fake Firebase UIDs.
 */
class FirebaseAuthRepository(
    private val context: Context,
    private val coroutineScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
) : AuthRepository {

    private val prefs: SharedPreferences = try {
        val masterKey: MasterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "bill_linus_auth_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        context.getSharedPreferences("bill_linus_auth_prefs", Context.MODE_PRIVATE)
    }

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = false
        encodeDefaults = true
    }

    private var firebaseAuth: FirebaseAuth? = null
    private var firestore: FirebaseFirestore? = null

    private val _authState = MutableStateFlow<AuthState>(AuthState.Loading)
    override val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _userProfile = MutableStateFlow<UserProfile?>(loadLocalProfile())
    override val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    private val _isPasskeyEnabled = MutableStateFlow(prefs.getBoolean("passkey_setup_state", false))
    override val isPasskeyEnabled: StateFlow<Boolean> = _isPasskeyEnabled.asStateFlow()

    override val currentUserId: String?
        get() = firebaseAuth?.currentUser?.uid

    override val isFirebaseConfigured: Boolean
        get() = firebaseAuth != null

    init {
        initializeFirebase()
    }

    private fun loadLocalProfile(): UserProfile? {
        val str = prefs.getString("local_user_profile_json", null) ?: return null
        return try {
            json.decodeFromString<UserProfile>(str)
        } catch (_: Exception) {
            null
        }
    }

    private fun saveLocalProfile(profile: UserProfile?) {
        if (profile == null) {
            prefs.edit().remove("local_user_profile_json").apply()
        } else {
            try {
                val str = json.encodeToString(profile)
                prefs.edit().putString("local_user_profile_json", str).apply()
            } catch (_: Exception) {
                // Ignore storage errors gracefully
            }
        }
    }

    private fun initializeFirebase() {
        try {
            val app = try {
                val existing = FirebaseApp.getApps(context)
                if (existing.isNotEmpty()) {
                    FirebaseApp.getInstance()
                } else {
                    FirebaseApp.initializeApp(context)
                }
            } catch (_: Exception) {
                null
            }

            if (app != null) {
                val auth = FirebaseAuth.getInstance(app)
                val db = FirebaseFirestore.getInstance(app)
                firebaseAuth = auth
                firestore = db

                auth.addAuthStateListener { fa ->
                    val user = fa.currentUser
                    if (user != null) {
                        handleUserSignedIn(user)
                    } else {
                        handleSignedOutOrLocalSetup(isConfigured = true)
                    }
                }
            } else {
                handleSignedOutOrLocalSetup(isConfigured = false)
            }
        } catch (_: Exception) {
            handleSignedOutOrLocalSetup(isConfigured = false)
        }
    }

    private fun handleSignedOutOrLocalSetup(isConfigured: Boolean) {
        val localProfile = _userProfile.value
        val passkeyConfigured = _isPasskeyEnabled.value
        if (localProfile != null && !localProfile.mobileNumber.isNullOrBlank()) {
            if (passkeyConfigured) {
                _authState.value = AuthState.PasskeyAuthenticated(localProfile)
            } else {
                _authState.value = AuthState.AccountSetup(localProfile)
            }
        } else {
            _authState.value = if (isConfigured) AuthState.SignedOut else AuthState.FirebaseNotConfigured
        }
    }

    private fun handleUserSignedIn(user: FirebaseUser) {
        val uid = user.uid
        val mobileNumber = user.phoneNumber ?: _userProfile.value?.mobileNumber
        val displayName = user.displayName ?: _userProfile.value?.displayName
        val nowIso = Instant.now().toString()

        val initialProfile = UserProfile(
            uid = uid,
            mobileNumber = mobileNumber,
            displayName = displayName,
            mobileVerificationStatus = "AUTHENTICATED",
            createdAt = _userProfile.value?.createdAt ?: nowIso,
            updatedAt = nowIso
        )
        _userProfile.value = initialProfile
        saveLocalProfile(initialProfile)
        _authState.value = AuthState.SignedIn(initialProfile)

        // Asynchronously check and sync Firestore profile at users/{uid}
        coroutineScope.launch {
            try {
                val db = firestore ?: return@launch
                val userDocRef = db.collection(FirestoreCollections.USERS).document(uid)
                val snapshot = userDocRef.get().await()

                if (snapshot.exists()) {
                    val dbMobile = snapshot.getString("mobileNumber") ?: mobileNumber
                    val dbDisplayName = snapshot.getString("displayName") ?: displayName
                    val dbCreatedAt = snapshot.getString("createdAt") ?: initialProfile.createdAt
                    val dbUpdatedAt = snapshot.getString("updatedAt") ?: initialProfile.updatedAt

                    val syncedProfile = UserProfile(
                        uid = uid,
                        mobileNumber = dbMobile,
                        displayName = dbDisplayName,
                        mobileVerificationStatus = "AUTHENTICATED",
                        createdAt = dbCreatedAt,
                        updatedAt = dbUpdatedAt
                    )
                    _userProfile.value = syncedProfile
                    saveLocalProfile(syncedProfile)
                    _authState.value = AuthState.SignedIn(syncedProfile)
                } else {
                    // Initialize the users/{uid} document with minimal profile fields
                    val initialData = hashMapOf(
                        "uid" to uid,
                        "mobileNumber" to (mobileNumber ?: ""),
                        "displayName" to (displayName ?: ""),
                        "createdAt" to initialProfile.createdAt,
                        "updatedAt" to initialProfile.updatedAt
                    )
                    userDocRef.set(initialData, SetOptions.merge()).await()
                }
            } catch (_: Exception) {
                // If offline or Firestore is temporarily unreachable, maintain signed-in auth profile
            }
        }
    }

    override suspend fun createPasskey(context: Context): PasskeyResult {
        return try {
            val credentialManager = CredentialManager.create(context)
            val requestJson = generateCreatePasskeyJson(_userProfile.value)
            val createRequest = CreatePublicKeyCredentialRequest(requestJson)

            val result = credentialManager.createCredential(context, createRequest)
            if (result is CreatePublicKeyCredentialResponse) {
                prefs.edit().putBoolean("passkey_setup_state", true).apply()
                _isPasskeyEnabled.value = true

                val profile = _userProfile.value
                if (profile != null) {
                    _authState.value = AuthState.PasskeyAuthenticated(profile)
                }

                // Note: The WebAuthn registration JSON response contains clientDataJSON and attestationObject.
                // In a production setup with a backend server, this response is sent to the server to verify the signature
                // and mint a Firebase Custom Auth token for user sign-in.
                PasskeyResult.Success(result.registrationResponseJson)
            } else {
                PasskeyResult.Error("Unexpected response type from Credential Manager")
            }
        } catch (e: CreateCredentialCancellationException) {
            PasskeyResult.Cancelled
        } catch (e: CreateCredentialNoCreateOptionException) {
            PasskeyResult.NotSupported(e.message ?: "No passkey creation option available on this device")
        } catch (e: CreateCredentialProviderConfigurationException) {
            PasskeyResult.NotSupported(e.message ?: "Credential provider configuration error")
        } catch (e: Exception) {
            PasskeyResult.Error(e.message ?: "Passkey creation failed", e)
        }
    }

    override suspend fun signInWithPasskey(context: Context): PasskeyResult {
        return try {
            val credentialManager = CredentialManager.create(context)
            val requestJson = generateGetPasskeyJson()
            val getPublicKeyCredentialOption = GetPublicKeyCredentialOption(requestJson)
            val getCredRequest = GetCredentialRequest(listOf(getPublicKeyCredentialOption))

            val result = credentialManager.getCredential(context, getCredRequest)
            val credential = result.credential
            if (credential is PublicKeyCredential) {
                prefs.edit().putBoolean("passkey_setup_state", true).apply()
                _isPasskeyEnabled.value = true

                val profile = _userProfile.value
                if (profile != null) {
                    _authState.value = AuthState.PasskeyAuthenticated(profile)
                }

                // Note: The WebAuthn authentication JSON response contains authenticatorData, clientDataJSON, and signature.
                // When connected to a backend server, this payload validates the assertion and exchanges for a Firebase token.
                PasskeyResult.Success(credential.authenticationResponseJson)
            } else {
                PasskeyResult.Error("Unexpected credential type returned")
            }
        } catch (e: GetCredentialCancellationException) {
            PasskeyResult.Cancelled
        } catch (e: NoCredentialException) {
            PasskeyResult.NoPasskeyFound
        } catch (e: GetCredentialProviderConfigurationException) {
            PasskeyResult.NotSupported(e.message ?: "Credential provider configuration error")
        } catch (e: Exception) {
            PasskeyResult.Error(e.message ?: "Passkey sign-in failed", e)
        }
    }

    override suspend fun clearPasskey() {
        prefs.edit().remove("passkey_setup_state").apply()
        _isPasskeyEnabled.value = false
        val profile = _userProfile.value
        if (profile != null) {
            _authState.value = AuthState.AccountSetup(profile)
        }
    }

    private fun generateCreatePasskeyJson(profile: UserProfile?): String {
        val challengeBytes = ByteArray(32)
        SecureRandom().nextBytes(challengeBytes)
        val challengeBase64 = Base64.encodeToString(
            challengeBytes,
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )

        val rawId = profile?.mobileNumber?.takeIf { it.isNotBlank() } ?: "user_${System.currentTimeMillis()}"
        val userIdBase64 = Base64.encodeToString(
            rawId.toByteArray(),
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )
        val username = profile?.mobileNumber?.takeIf { it.isNotBlank() } ?: "billlinus_user"
        val displayName = profile?.displayName?.takeIf { it.isNotBlank() } ?: username

        return """
        {
          "challenge": "$challengeBase64",
          "rp": {
            "name": "BillLinus",
            "id": "billlinus.app"
          },
          "user": {
            "id": "$userIdBase64",
            "name": "$username",
            "displayName": "$displayName"
          },
          "pubKeyCredParams": [
            {"type": "public-key", "alg": -7},
            {"type": "public-key", "alg": -257}
          ],
          "timeout": 60000,
          "attestation": "none",
          "authenticatorSelection": {
            "authenticatorAttachment": "platform",
            "residentKey": "required",
            "requireResidentKey": true,
            "userVerification": "required"
          }
        }
        """.trimIndent()
    }

    private fun generateGetPasskeyJson(): String {
        val challengeBytes = ByteArray(32)
        SecureRandom().nextBytes(challengeBytes)
        val challengeBase64 = Base64.encodeToString(
            challengeBytes,
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )

        return """
        {
          "challenge": "$challengeBase64",
          "timeout": 60000,
          "rpId": "billlinus.app",
          "userVerification": "required"
        }
        """.trimIndent()
    }

    override suspend fun saveAccountSetupProfile(
        mobileNumber: String,
        displayName: String?
    ): UserProfile {
        val normalized = PhoneUtils.normalizeNepalMobile(mobileNumber)
        val nowIso = Instant.now().toString()
        val existing = _userProfile.value

        val profile = UserProfile(
            uid = existing?.uid ?: "",
            mobileNumber = normalized,
            displayName = displayName ?: existing?.displayName,
            mobileVerificationStatus = "NOT_VERIFIED",
            createdAt = existing?.createdAt ?: nowIso,
            updatedAt = nowIso
        )

        saveLocalProfile(profile)
        _userProfile.value = profile

        if (firebaseAuth?.currentUser == null) {
            if (_isPasskeyEnabled.value) {
                _authState.value = AuthState.PasskeyAuthenticated(profile)
            } else {
                _authState.value = AuthState.AccountSetup(profile)
            }
        }

        return profile
    }

    override suspend fun clearAccountProfile() {
        saveLocalProfile(null)
        _userProfile.value = null
        if (firebaseAuth?.currentUser == null) {
            _authState.value = if (firebaseAuth != null) AuthState.SignedOut else AuthState.FirebaseNotConfigured
        }
    }

    override suspend fun signOut() {
        try {
            firebaseAuth?.signOut()
            val localProfile = _userProfile.value
            if (localProfile != null && !localProfile.mobileNumber.isNullOrBlank()) {
                _authState.value = AuthState.AccountSetup(localProfile)
            } else {
                _authState.value = if (firebaseAuth != null) AuthState.SignedOut else AuthState.FirebaseNotConfigured
            }
        } catch (_: Exception) {
            // Gracefully handle signOut errors
        }
    }
}
