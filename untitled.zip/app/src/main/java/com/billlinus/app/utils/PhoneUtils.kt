package com.billlinus.app.utils

/**
 * Utility functions for normalizing, validating, and formatting Nepalese mobile numbers.
 */
object PhoneUtils {

    /**
     * Normalizes a Nepal mobile number to a clean 10-digit format (e.g., "9812345678").
     * Handles common user input variations including:
     * - Standard 10-digit: "98XXXXXXXX", "97XXXXXXXX", "96XXXXXXXX"
     * - International prefixes: "+97798XXXXXXXX", "+977 98XXXXXXXX", "+977-98XXXXXXXX"
     * - Trunk prefixes: "00977 98XXXXXXXX", "0097798XXXXXXXX"
     * - Formatting delimiters: spaces, hyphens, parentheses, etc.
     */
    fun normalizeNepalMobile(input: String?): String {
        if (input.isNullOrBlank()) return ""
        var digits = input.filter { it.isDigit() }

        // Remove international exit code + Nepal country code 00977
        if (digits.startsWith("00977") && digits.length >= 15) {
            digits = digits.removePrefix("00977")
        } else if (digits.startsWith("977") && digits.length >= 13) {
            digits = digits.removePrefix("977")
        }

        return digits
    }

    /**
     * Validates whether the given string represents a structurally valid 10-digit Nepalese mobile number.
     * Accepted mobile prefixes:
     * - 98 (NTC GSM, Ncell)
     * - 97 (NTC CDMA/GSM, Ncell)
     * - 96 (Smart Cell / other licensed mobile services)
     */
    fun isValidNepalMobile(input: String?): Boolean {
        val normalized = normalizeNepalMobile(input)
        if (normalized.length != 10) return false
        val prefix = normalized.take(2)
        return prefix == "98" || prefix == "97" || prefix == "96"
    }

    /**
     * Formats normalized mobile numbers for clear, readable display (e.g., "9812 345 678").
     */
    fun formatDisplay(input: String?): String {
        val normalized = normalizeNepalMobile(input)
        return if (normalized.length == 10) {
            "${normalized.substring(0, 4)} ${normalized.substring(4, 7)} ${normalized.substring(7, 10)}"
        } else {
            input ?: ""
        }
    }
}
