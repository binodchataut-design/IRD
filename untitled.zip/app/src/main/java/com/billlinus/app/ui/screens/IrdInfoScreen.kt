package com.billlinus.app.ui.screens

import androidx.compose.runtime.Composable
import com.billlinus.app.ui.MainViewModel

@Composable
fun IrdInfoScreen(viewModel: MainViewModel) {
    GuideAndRulesScreen(viewModel = viewModel)
}
