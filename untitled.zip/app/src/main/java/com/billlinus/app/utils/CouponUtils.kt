package com.billlinus.app.utils

import com.billlinus.app.model.BulkParseResult

object CouponUtils {

    fun normalizeCouponNumber(input: String?): String {
        if (input.isNullOrBlank()) return ""
        // Remove spaces, hyphens, and non-digit characters
        return input.filter { it.isDigit() }
    }

    fun isValidCouponNumber(input: String?): Boolean {
        val normalized = normalizeCouponNumber(input)
        return normalized.length == 12
    }

    fun formatCoupon(input: String?): String {
        val normalized = normalizeCouponNumber(input)
        return if (normalized.length == 12) {
            "${normalized.substring(0, 4)}-${normalized.substring(4, 8)}-${normalized.substring(8, 12)}"
        } else {
            normalized
        }
    }

    fun formatCouponNumber(input: String?): String {
        return formatCoupon(input)
    }

    fun extractCoupons(rawText: String): List<String> {
        val regex = Regex("""\b\d{12}\b|\b\d{4}[-\s]\d{4}[-\s]\d{4}\b""")
        return regex.findAll(rawText)
            .map { normalizeCouponNumber(it.value) }
            .filter { it.length == 12 }
            .distinct()
            .toList()
    }

    fun parseBulkCouponsText(rawText: String, existingNumbers: Set<String>): BulkParseResult {
        if (rawText.isBlank()) {
            return BulkParseResult(
                totalExtracted = 0,
                validNew = emptyList(),
                duplicateInBatch = emptyList(),
                alreadySaved = emptyList(),
                invalidTokens = emptyList()
            )
        }

        val tokens = rawText.split(Regex("[\\r\\n;,\\s]+")).map { it.trim() }.filter { it.isNotEmpty() }
        val validNew = mutableListOf<String>()
        val duplicateInBatch = mutableListOf<String>()
        val alreadySaved = mutableListOf<String>()
        val invalidTokens = mutableListOf<String>()
        val seenInBatch = mutableSetOf<String>()

        val normalizedExisting = existingNumbers.map { normalizeCouponNumber(it) }.toSet()

        for (token in tokens) {
            val normalized = normalizeCouponNumber(token)
            if (normalized.length == 12) {
                if (seenInBatch.contains(normalized)) {
                    duplicateInBatch.add(normalized)
                } else {
                    seenInBatch.add(normalized)
                    if (normalizedExisting.contains(normalized)) {
                        alreadySaved.add(normalized)
                    } else {
                        validNew.add(normalized)
                    }
                }
            } else {
                invalidTokens.add(token)
            }
        }

        return BulkParseResult(
            totalExtracted = tokens.size,
            validNew = validNew,
            duplicateInBatch = duplicateInBatch,
            alreadySaved = alreadySaved,
            invalidTokens = invalidTokens
        )
    }
}
