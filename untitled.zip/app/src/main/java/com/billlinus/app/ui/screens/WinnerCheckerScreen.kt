package com.billlinus.app.ui.screens

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billlinus.app.i18n.AppStrings
import com.billlinus.app.model.AppLanguage
import com.billlinus.app.model.Coupon
import com.billlinus.app.model.ManualResultCheck
import com.billlinus.app.model.ScreenName
import com.billlinus.app.service.DrawResultService
import com.billlinus.app.ui.MainViewModel
import com.billlinus.app.ui.components.AppBottomNav
import com.billlinus.app.ui.components.AppHeader
import com.billlinus.app.ui.theme.BrandGreenDark
import com.billlinus.app.ui.theme.Emerald100
import com.billlinus.app.ui.theme.Emerald600
import com.billlinus.app.ui.theme.Indigo100
import com.billlinus.app.ui.theme.Indigo600
import com.billlinus.app.ui.theme.Slate100
import com.billlinus.app.ui.theme.Slate200
import com.billlinus.app.ui.theme.Slate400
import com.billlinus.app.ui.theme.Slate500
import com.billlinus.app.ui.theme.Slate700
import com.billlinus.app.ui.theme.Slate900
import com.billlinus.app.utils.CouponUtils
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun WinnerCheckerScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    val resultChecks by viewModel.resultChecks.collectAsState()
    val lastCheckResult by viewModel.lastCheckResult.collectAsState()

    var drawTitleInput by remember { mutableStateOf("") }
    var winningInputText by remember { mutableStateOf("") }
    var inputError by remember { mutableStateOf<String?>(null) }
    var showClearHistoryDialog by remember { mutableStateOf(false) }

    // Count recognized 12-digit coupons in current input
    val recognizedTokens = remember(winningInputText) {
        winningInputText.split(Regex("[\\r\\n;,\\s]+"))
            .map { CouponUtils.normalizeCouponNumber(it) }
            .filter { it.length == 12 }
            .distinct()
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("winner.title", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = currentScreen,
                lang = lang,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
            }

            // 1. Header Subtitle
            item {
                Text(
                    text = AppStrings.get("winner.subtitle", lang),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Slate500,
                        fontSize = 14.sp
                    )
                )
            }

            // 2. Official IRD Results Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_official_ird_results")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = BrandGreenDark.copy(alpha = 0.12f),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AccountBalance,
                                        contentDescription = null,
                                        tint = BrandGreenDark,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppStrings.get("winner.official_ird_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = AppStrings.get("winner.official_ird_desc", lang),
                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 12.sp)
                                )
                            }
                        }

                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DrawResultService.IRD_PRIZE_PORTAL_URL))
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    // Handle safely if browser is not available
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_open_official_results"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandGreenDark)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.get("winner.open_official_results", lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Slate400,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = AppStrings.get("winner.ird_source", lang),
                                style = MaterialTheme.typography.labelSmall.copy(color = Slate500, fontSize = 11.sp)
                            )
                        }
                    }
                }
            }

            // 3. Check My Coupon Section
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_check_my_coupon")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Indigo100,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = Indigo600,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = AppStrings.get("winner.check_my_coupon_title", lang),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = AppStrings.get("winner.check_my_coupon_desc", lang),
                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 12.sp)
                                )
                            }
                        }

                        // Draw Title Input (Optional)
                        OutlinedTextField(
                            value = drawTitleInput,
                            onValueChange = { drawTitleInput = it },
                            label = { Text(AppStrings.get("winner.draw_title", lang)) },
                            placeholder = { Text(AppStrings.get("winner.draw_title_placeholder", lang)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_draw_title"),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        // Winning Numbers Input Area
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = AppStrings.get("winner.winning_numbers_label", lang),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = Slate700
                                    )
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    if (winningInputText.isNotEmpty()) {
                                        TextButton(
                                            onClick = {
                                                winningInputText = ""
                                                inputError = null
                                            },
                                            modifier = Modifier.height(32.dp).testTag("btn_clear_input")
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(AppStrings.get("winner.clear_input", lang), fontSize = 11.sp)
                                        }
                                    }

                                    TextButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                            if (clipboard != null && clipboard.hasPrimaryClip()) {
                                                val clip = clipboard.primaryClip
                                                if (clip != null && clip.itemCount > 0) {
                                                    val text = clip.getItemAt(0).text?.toString() ?: ""
                                                    if (text.isNotBlank()) {
                                                        winningInputText = if (winningInputText.isBlank()) text else "$winningInputText\n$text"
                                                        inputError = null
                                                    }
                                                }
                                            }
                                        },
                                        modifier = Modifier.height(32.dp).testTag("btn_paste_clipboard")
                                    ) {
                                        Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(AppStrings.get("winner.paste_from_clipboard", lang), fontSize = 11.sp)
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = winningInputText,
                                onValueChange = {
                                    winningInputText = it
                                    if (inputError != null) inputError = null
                                },
                                placeholder = {
                                    Text(
                                        text = AppStrings.get("winner.paste_placeholder", lang),
                                        style = MaterialTheme.typography.bodySmall.copy(color = Slate400)
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .testTag("input_winning_numbers"),
                                shape = RoundedCornerShape(10.dp),
                                textStyle = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp
                                )
                            )

                            if (recognizedTokens.isNotEmpty()) {
                                val countMsg = AppStrings.get("winner.found_numbers_count", lang)
                                    .replace("{count}", recognizedTokens.size.toString())
                                Text(
                                    text = "✓ $countMsg",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Emerald600,
                                        fontWeight = FontWeight.Medium
                                    ),
                                    modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                                )
                            }

                            if (inputError != null) {
                                Text(
                                    text = inputError!!,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.error,
                                        fontSize = 12.sp
                                    ),
                                    modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                                )
                            }
                        }

                        // Submit Button
                        Button(
                            onClick = {
                                if (recognizedTokens.isEmpty()) {
                                    inputError = AppStrings.get("winner.invalid_result", lang)
                                    return@Button
                                }
                                inputError = null
                                viewModel.checkWinners(winningInputText, drawTitleInput)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_check_winning_numbers"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.get("winner.check_winning_numbers", lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        // Check Results (if executed)
                        if (lastCheckResult != null) {
                            val check = lastCheckResult!!
                            HorizontalDivider(color = Slate200, thickness = 1.dp)

                            if (check.matchedCouponNumbers.isNotEmpty()) {
                                // Match Result Card
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Emerald100.copy(alpha = 0.6f),
                                    border = CardDefaults.outlinedCardBorder(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("card_match_result_success")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Emerald600,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = AppStrings.get("winner.possible_match_title", lang),
                                                    style = MaterialTheme.typography.titleMedium.copy(
                                                        fontWeight = FontWeight.Bold,
                                                        color = Emerald600
                                                    )
                                                )
                                                Text(
                                                    text = AppStrings.get("winner.possible_match_desc", lang),
                                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate700)
                                                )
                                            }
                                        }

                                        // Matched coupons detail list
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            check.matchedCouponNumbers.forEach { matchedNum ->
                                                val matchedCoupon = coupons.find { it.couponNumber == matchedNum }
                                                MatchedCouponCard(
                                                    couponNumber = matchedNum,
                                                    coupon = matchedCoupon,
                                                    lang = lang,
                                                    onGenerateClaimReport = { c ->
                                                        viewModel.openClaimReport(c, check.drawTitle, check.checkedAt)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            } else {
                                // No Match Result Card
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Slate100,
                                    border = CardDefaults.outlinedCardBorder(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("card_match_result_none")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Info,
                                            contentDescription = null,
                                            tint = Slate500,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = AppStrings.get("winner.no_match_title", lang),
                                                style = MaterialTheme.typography.titleSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = Slate900
                                                )
                                            )
                                            Text(
                                                text = AppStrings.get("winner.no_match_desc", lang),
                                                style = MaterialTheme.typography.bodySmall.copy(color = Slate500)
                                            )
                                        }
                                    }
                                }
                            }

                            // Small Disclaimer
                            Text(
                                text = AppStrings.get("winner.disclaimer_text", lang),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Slate500,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                ),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }
                    }
                }
            }

            // 4. Previous Checks Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.get("winner.previous_checks", lang),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    if (resultChecks.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearHistoryDialog = true },
                            modifier = Modifier.testTag("btn_clear_history")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = AppStrings.get("winner.clear_history", lang),
                                tint = Slate400,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            if (resultChecks.isEmpty()) {
                item {
                    OutlinedCard(
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = AppStrings.get("winner.history_empty", lang),
                                style = MaterialTheme.typography.bodyMedium.copy(color = Slate500, fontSize = 13.sp)
                            )
                        }
                    }
                }
            } else {
                items(resultChecks) { check ->
                    PreviousCheckItemCard(
                        check = check,
                        coupons = coupons,
                        lang = lang,
                        onOpenClaimReport = { coupon, drawTitle, date ->
                            viewModel.openClaimReport(coupon, drawTitle, date)
                        }
                    )
                }
            }

            // 5. Guide & Rules Button
            item {
                OutlinedCard(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(ScreenName.IRD_INFO) }
                        .testTag("btn_open_guide_and_rules")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.HelpOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = AppStrings.get("winner.guide_and_rules_title", lang),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = AppStrings.get("winner.guide_and_rules_desc", lang),
                                style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 12.sp)
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Slate400,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Confirmation Dialog for Clearing History
    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = {
                Text(
                    text = AppStrings.get("winner.clear_history", lang),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(AppStrings.get("winner.clear_history_confirm", lang))
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearResultChecks()
                        showClearHistoryDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_clear_history")
                ) {
                    Text(AppStrings.get("winner.clear_history", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text(if (lang == AppLanguage.NE) "रद्द गर्नुहोस्" else "Cancel")
                }
            }
        )
    }
}

@Composable
private fun MatchedCouponCard(
    couponNumber: String,
    coupon: Coupon?,
    lang: AppLanguage,
    onGenerateClaimReport: (Coupon) -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = couponNumber,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = Emerald600
                    )
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Emerald100
                ) {
                    Text(
                        text = AppStrings.get("winner.matched_coupon", lang),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Emerald600
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            if (coupon != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (!coupon.merchantName.isNullOrBlank()) {
                        Text(
                            text = coupon.merchantName,
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate700, fontWeight = FontWeight.Medium)
                        )
                    }
                    if (coupon.amount != null) {
                        Text(
                            text = "NPR ${coupon.amount.toInt()}",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate900, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Button(
                    onClick = { onGenerateClaimReport(coupon) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("btn_claim_report_$couponNumber"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald600)
                ) {
                    Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = AppStrings.get("winner.claim_report_btn", lang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PreviousCheckItemCard(
    check: ManualResultCheck,
    coupons: List<Coupon>,
    lang: AppLanguage,
    onOpenClaimReport: (Coupon, String?, String?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val formattedDate = remember(check.checkedAt) {
        try {
            val instant = Instant.parse(check.checkedAt)
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
                .withZone(ZoneId.systemDefault())
                .format(instant)
        } catch (_: Exception) {
            check.checkedAt
        }
    }

    val displayTitle = if (!check.drawTitle.isNullOrBlank()) {
        check.drawTitle
    } else {
        AppStrings.get("winner.entered_manually", lang)
    }

    val matchText = if (check.matchedCouponNumbers.isNotEmpty()) {
        if (check.matchedCouponNumbers.size == 1) {
            if (lang == AppLanguage.NE) "१ मिलान फेला पर्यो" else "1 match found"
        } else {
            if (lang == AppLanguage.NE) "${check.matchedCouponNumbers.size} मिलान फेला परे" else "${check.matchedCouponNumbers.size} matches found"
        }
    } else {
        AppStrings.get("winner.not_matched_coupon", lang)
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = displayTitle,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 11.sp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (check.matchedCouponNumbers.isNotEmpty()) Emerald100 else Slate100
                    ) {
                        Text(
                            text = matchText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (check.matchedCouponNumbers.isNotEmpty()) Emerald600 else Slate700
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = Slate400,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Summary row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${check.enteredResults.size} ${if (lang == AppLanguage.NE) "नम्बर जाँचियो" else "numbers checked"}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 12.sp)
                )
                Text(
                    text = "${AppStrings.get("winner.result_source", lang)}: ${AppStrings.get("winner.entered_manually_source", lang)}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 11.sp)
                )
            }

            // Expanded details
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier.padding(top = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HorizontalDivider(color = Slate200, thickness = 1.dp)

                    if (check.matchedCouponNumbers.isNotEmpty()) {
                        Text(
                            text = if (lang == AppLanguage.NE) "सम्भावित मिलान भएका कुपनहरू:" else "Matched Coupons:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = Emerald600)
                        )
                        check.matchedCouponNumbers.forEach { matchedNum ->
                            val coupon = coupons.find { it.couponNumber == matchedNum }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = matchedNum,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                if (coupon != null) {
                                    OutlinedButton(
                                        onClick = { onOpenClaimReport(coupon, check.drawTitle, check.checkedAt) },
                                        modifier = Modifier.height(32.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(AppStrings.get("claim.title", lang), fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            text = if (lang == AppLanguage.NE) "यस जाँचमा कुनै पनि कुपन मिलेको थिएन।" else "No matching coupons in this check.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate500)
                        )
                    }
                }
            }
        }
    }
}
