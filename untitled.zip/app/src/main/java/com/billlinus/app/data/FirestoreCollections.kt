package com.billlinus.app.data

/**
 * Defines the Firestore collection schema and path architecture for user data isolation.
 *
 * Primary user document:
 *   users/{uid}
 *
 * Future sub-collection architecture for cloud synchronization (Phase 10B+):
 *   users/{uid}/transactions/{transactionId}
 *   users/{uid}/coupons/{couponId}
 *   users/{uid}/resultChecks/{checkId}
 *   users/{uid}/draws/{drawId}
 */
object FirestoreCollections {
    const val USERS = "users"
    const val TRANSACTIONS = "transactions"
    const val COUPONS = "coupons"
    const val RESULT_CHECKS = "resultChecks"
    const val DRAWS = "draws"

    /**
     * Path to the root user profile document.
     */
    fun userDocPath(uid: String): String = "$USERS/$uid"

    /**
     * Path to the user's transactions sub-collection.
     */
    fun userTransactionsPath(uid: String): String = "$USERS/$uid/$TRANSACTIONS"

    /**
     * Path to the user's coupons sub-collection.
     */
    fun userCouponsPath(uid: String): String = "$USERS/$uid/$COUPONS"

    /**
     * Path to the user's manual result checks sub-collection.
     */
    fun userResultChecksPath(uid: String): String = "$USERS/$uid/$RESULT_CHECKS"

    /**
     * Path to the user's draw announcements sub-collection.
     */
    fun userDrawsPath(uid: String): String = "$USERS/$uid/$DRAWS"
}
