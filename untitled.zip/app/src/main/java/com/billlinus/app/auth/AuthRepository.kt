package com.billlinus.app.auth

import com.billlinus.app.model.UserProfile
import kotlinx.coroutines.flow.StateFlow

/**
 * Clean authentication contract decoupling UI and ViewModel layers from direct Firebase APIs.
 */
interface AuthRepository {
    /** Observable authentication state */
    val authState: StateFlow<AuthState>

    /** Current Firebase UID if signed in */
    val currentUserId: String?

    /** Whether Firebase core and auth services are available */
    val isFirebaseConfigured: Boolean

    /** Observable local or remote user profile */
    val userProfile: StateFlow<UserProfile?>

    /** Observable state whether a passkey has been successfully created on this device */
    val isPasskeyEnabled: StateFlow<Boolean>

    /**
     * Initiates passkey creation via AndroidX Credential Manager.
     * Biometric/device lock authentication is handled securely by the OS/credential provider.
     */
    suspend fun createPasskey(context: android.content.Context): PasskeyResult

    /**
     * Initiates passkey authentication via AndroidX Credential Manager.
     */
    suspend fun signInWithPasskey(context: android.content.Context): PasskeyResult

    /**
     * Clears local passkey state (without deleting keys on provider).
     */
    suspend fun clearPasskey()

    /**
     * Saves or updates the local user profile during account setup with a mobile number.
     * Note: Does NOT perform Firebase authentication or mark the number as verified.
     */
    suspend fun saveAccountSetupProfile(mobileNumber: String, displayName: String? = null): UserProfile

    /** Clears the local account setup profile */
    suspend fun clearAccountProfile()

    /** Signs out the current user if signed in */
    suspend fun signOut()
}
