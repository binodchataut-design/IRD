package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.Coupon
import com.example.model.EligibilityStatus
import com.example.model.ScreenName
import com.example.model.Transaction
import com.example.ui.MainViewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppHeader
import com.example.ui.components.DrawPeriodBanner
import com.example.ui.components.StatCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.utils.CouponUtils

@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val coupons by viewModel.coupons.collectAsState()
    val currentDrawInfo by viewModel.currentDrawInfo.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()

    val totalSpent = transactions.sumOf { it.amount }
    val eligibleCount = transactions.count {
        it.eligibilityStatus == EligibilityStatus.COUPON_ADDED ||
                it.eligibilityStatus == EligibilityStatus.LIKELY_ELIGIBLE
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = AppStrings.get("app.name", lang),
                lang = lang,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentScreen = currentScreen,
                lang = lang,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Draw Period Hero Banner
                DrawPeriodBanner(
                    drawInfo = currentDrawInfo,
                    lang = lang,
                    onLearnMoreClick = { viewModel.navigateTo(ScreenName.WINNER_CHECKER) }
                )
            }

            // Stat Cards Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            title = AppStrings.get("home.stat_invoices", lang),
                            value = transactions.size.toString(),
                            icon = Icons.Default.Receipt,
                            iconBgColor = Indigo100,
                            iconTint = Indigo600,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(ScreenName.INVOICES) }
                        )
                        StatCard(
                            title = AppStrings.get("home.stat_coupons", lang),
                            value = coupons.size.toString(),
                            icon = Icons.Default.CardGiftcard,
                            iconBgColor = Emerald100,
                            iconTint = Emerald600,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(ScreenName.COUPONS) }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            title = AppStrings.get("home.stat_eligible", lang),
                            value = eligibleCount.toString(),
                            icon = Icons.Default.CheckCircle,
                            iconBgColor = Amber100,
                            iconTint = Amber600,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = AppStrings.get("home.stat_total_spent", lang),
                            value = "NPR ${totalSpent.toInt()}",
                            icon = Icons.Default.Paid,
                            iconBgColor = Blue100,
                            iconTint = Blue600,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Record a Purchase CTA Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.openAddInvoice() }
                        .testTag("record_purchase_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = AppStrings.get("home.record_purchase", lang),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = AppStrings.get("home.record_purchase_desc", lang),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Slate500,
                                    fontSize = 12.sp
                                )
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Slate400,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Quick Actions Section
            item {
                Column {
                    Text(
                        text = AppStrings.get("home.quick_actions", lang),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuickActionButton(
                            label = AppStrings.get("home.add_coupon", lang),
                            icon = Icons.Default.CardGiftcard,
                            modifier = Modifier.weight(1f),
                            testTag = "quick_add_coupon",
                            onClick = { viewModel.openAddCoupon() }
                        )
                        QuickActionButton(
                            label = AppStrings.get("home.check_winner", lang),
                            icon = Icons.Default.EmojiEvents,
                            modifier = Modifier.weight(1f),
                            testTag = "quick_check_winner",
                            onClick = { viewModel.navigateTo(ScreenName.WINNER_CHECKER) }
                        )
                        QuickActionButton(
                            label = AppStrings.get("home.verify_vendor", lang),
                            icon = Icons.Default.VerifiedUser,
                            modifier = Modifier.weight(1f),
                            testTag = "quick_verify_vendor",
                            onClick = { viewModel.openVerifyVendor() }
                        )
                    }
                }
            }

            // Recent Invoices Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.get("home.recent_invoices", lang),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            if (transactions.isEmpty()) {
                item {
                    EmptyRecentItem(
                        title = AppStrings.get("invoices.empty_title", lang),
                        desc = AppStrings.get("invoices.empty_desc", lang)
                    )
                }
            } else {
                items(transactions.take(3)) { tx ->
                    InvoiceCardItem(
                        transaction = tx,
                        lang = lang,
                        onClick = { viewModel.selectInvoice(tx.id) }
                    )
                }
            }

            // Recent Coupons Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.get("home.recent_coupons", lang),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            if (coupons.isEmpty()) {
                item {
                    EmptyRecentItem(
                        title = AppStrings.get("coupons.empty_title", lang),
                        desc = AppStrings.get("coupons.empty_desc", lang)
                    )
                }
            } else {
                items(coupons.take(3)) { cp ->
                    CouponCardItem(
                        coupon = cp,
                        lang = lang,
                        onClaimClick = { viewModel.openClaimReport(cp) },
                        onDeleteClick = { viewModel.deleteCoupon(cp.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun QuickActionButton(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    testTag: String = "",
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
fun InvoiceCardItem(
    transaction: Transaction,
    lang: AppLanguage,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("invoice_card_${transaction.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Indigo100),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Receipt,
                    contentDescription = null,
                    tint = Indigo600,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.sellerName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    ),
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${transaction.date} • ${AppStrings.getPaymentMethodLabel(transaction.paymentMethod, lang)}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Slate500,
                        fontSize = 12.sp
                    ),
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "NPR ${transaction.amount.toInt()}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                StatusBadge(status = transaction.eligibilityStatus, lang = lang)
            }
        }
    }
}

@Composable
fun CouponCardItem(
    coupon: Coupon,
    lang: AppLanguage,
    onClaimClick: (() -> Unit)? = null,
    onEditClick: (() -> Unit)? = null,
    onDeleteClick: (() -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = onEditClick != null) { onEditClick?.invoke() }
            .testTag("coupon_card_${coupon.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Emerald100),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CardGiftcard,
                    contentDescription = null,
                    tint = Emerald600,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = CouponUtils.formatCouponNumber(coupon.couponNumber),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${coupon.merchantName ?: AppStrings.get("coupon.no_merchant", lang)} • ${coupon.drawPeriod ?: AppStrings.get("coupon.current_draw", lang)}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Slate500,
                        fontSize = 12.sp
                    ),
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            if (onEditClick != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Slate100,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onEditClick() }
                        .testTag("edit_coupon_${coupon.id}")
                ) {
                    Text(
                        text = if (lang == AppLanguage.NE) "सम्पादन" else "Edit",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Slate700,
                            fontSize = 11.sp
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
            }
            if (onClaimClick != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = BrandGreen,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onClaimClick() }
                        .testTag("claim_coupon_${coupon.id}")
                ) {
                    Text(
                        text = AppStrings.get("common.claim_report", lang),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyRecentItem(title: String, desc: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Slate100),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = Slate700
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.labelSmall.copy(color = Slate500)
            )
        }
    }
}
