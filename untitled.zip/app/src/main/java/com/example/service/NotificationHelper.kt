package com.example.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.i18n.AppStrings
import com.example.model.AppLanguage

object NotificationHelper {

    const val CHANNEL_ID = "draw_results_channel"
    private const val NOTIFICATION_ID_BASE = 1001

    fun createNotificationChannel(context: Context, lang: AppLanguage = AppLanguage.EN) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = AppStrings.get("notification.channel_name", lang)
            val descriptionText = AppStrings.get("notification.channel_desc", lang)
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showWinnerNotification(
        context: Context,
        lang: AppLanguage,
        drawTitle: String,
        matchedCouponNumbers: List<String>,
        customNotificationId: Int? = null
    ) {
        // Check runtime permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
        }

        createNotificationChannel(context, lang)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("destination", "WINNER_CHECKER")
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = AppStrings.get("notification.winner_title", lang)
        val body = if (matchedCouponNumbers.size > 1) {
            String.format(
                AppStrings.get("notification.winner_body_multiple", lang),
                matchedCouponNumbers.size,
                drawTitle
            )
        } else {
            String.format(
                AppStrings.get("notification.winner_body", lang),
                drawTitle
            )
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationId = customNotificationId ?: (NOTIFICATION_ID_BASE + (drawTitle.hashCode() % 1000))
        NotificationManagerCompat.from(context).notify(notificationId, notification)
    }
}
