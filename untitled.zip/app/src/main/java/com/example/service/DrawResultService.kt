package com.example.service

import com.example.model.Coupon
import com.example.model.DrawAnnouncement
import com.example.utils.CouponUtils

object DrawResultService {
    const val IRD_PRIZE_PORTAL_URL = "https://prize.ird.gov.np/"
    const val IRD_MAIN_URL = "https://ird.gov.np"
    const val IRD_PAN_SEARCH_URL = "https://ird.gov.np/pan-search"

    fun isAutomaticResultCheckingAvailable(): Boolean {
        return false
    }

    /**
     * Shared coupon-matching logic across manual entry and background notification checks.
     * Takes a list of raw winning tokens and saved coupons, returning the list of matched coupon numbers.
     */
    fun findMatches(winningTokens: List<String>, savedCoupons: List<Coupon>): List<String> {
        val normalizedWinning = winningTokens
            .map { CouponUtils.normalizeCouponNumber(it) }
            .filter { it.length == 12 }
            .toSet()

        val savedNumbers = savedCoupons
            .map { CouponUtils.normalizeCouponNumber(it.couponNumber) }
            .filter { it.isNotEmpty() }
            .toSet()

        return normalizedWinning.filter { savedNumbers.contains(it) }
    }

    /**
     * Returns known IRD draw announcements or published results.
     */
    fun getAvailableDraws(): List<DrawAnnouncement> {
        return listOf(
            DrawAnnouncement(
                id = "draw-bhadra-2083-1",
                title = "Bhadra 1–15, 2083 Fortnightly Draw",
                drawPeriod = "Bhadra 1–15, 2083",
                announcementDate = "2026-08-16",
                winningNumbers = listOf(
                    "007315254493", // Matches sample coupon 1
                    "007315254499",
                    "007315254500",
                    "007315254505"
                ),
                sourceUrl = IRD_PRIZE_PORTAL_URL,
                sourceName = "Inland Revenue Department Nepal",
                notes = "Official Bumper and Daily prize winners list",
                createdAt = "2026-08-16T10:00:00Z"
            ),
            DrawAnnouncement(
                id = "draw-shrawan-2083-2",
                title = "Shrawan 16–31, 2083 Fortnightly Draw",
                drawPeriod = "Shrawan 16–31, 2083",
                announcementDate = "2026-08-01",
                winningNumbers = listOf(
                    "007315254495", // Matches sample coupon 3
                    "007315254480",
                    "007315254481"
                ),
                sourceUrl = IRD_PRIZE_PORTAL_URL,
                sourceName = "Inland Revenue Department Nepal",
                notes = "Fortnightly draw results",
                createdAt = "2026-08-01T10:00:00Z"
            )
        )
    }
}
