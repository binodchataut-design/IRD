package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.model.DarkModePreference
import com.example.model.ScreenName
import com.example.ui.MainViewModel
import com.example.ui.screens.AddCouponScreen
import com.example.ui.screens.AddInvoiceScreen
import com.example.ui.screens.BulkAddCouponsScreen
import com.example.ui.screens.ClaimReportScreen
import com.example.ui.screens.CouponsScreen
import com.example.ui.screens.DataBackupScreen
import com.example.ui.screens.EligibilityCheckerScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InvoiceDetailScreen
import com.example.ui.screens.InvoicesScreen
import com.example.ui.screens.IrdInfoScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ScanScreen
import com.example.ui.screens.VerifyVendorScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.screens.WinnerCheckerScreen
import com.example.ui.theme.BillLinusTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleNotificationIntent(intent)
        setContent {
            val darkModePref by viewModel.darkMode.collectAsState()
            val fontScalePref by viewModel.fontScale.collectAsState()
            val isDark = when (darkModePref) {
                DarkModePreference.DARK -> true
                DarkModePreference.LIGHT -> false
                DarkModePreference.SYSTEM -> isSystemInDarkTheme()
            }

            BillLinusTheme(
                darkTheme = isDark,
                fontScale = fontScalePref.factor
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BillLinusApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkForWinningAnnouncements()
    }

    private fun handleNotificationIntent(intent: Intent?) {
        if (intent?.getStringExtra("destination") == "WINNER_CHECKER") {
            viewModel.navigateTo(ScreenName.WINNER_CHECKER)
        }
    }
}

@Composable
fun BillLinusApp(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val hasCompletedWelcome by viewModel.hasCompletedWelcome.collectAsState()
    val context = LocalContext.current

    // Request notification permission once after Welcome is completed (Android 13+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { _ ->
            viewModel.markNotificationPermissionPrompted()
        }

        LaunchedEffect(hasCompletedWelcome) {
            if (hasCompletedWelcome && !viewModel.hasPromptedNotificationPermission()) {
                val isGranted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!isGranted) {
                    viewModel.markNotificationPermissionPrompted()
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    viewModel.markNotificationPermissionPrompted()
                }
            }
        }
    }

    // Handle system back button for in-app navigation stack
    BackHandler(enabled = currentScreen != ScreenName.HOME && hasCompletedWelcome) {
        viewModel.navigateBack()
    }

    if (!hasCompletedWelcome) {
        WelcomeScreen(viewModel = viewModel)
    } else {
        when (currentScreen) {
            ScreenName.HOME -> HomeScreen(viewModel = viewModel)
            ScreenName.INVOICES -> InvoicesScreen(viewModel = viewModel)
            ScreenName.ADD_INVOICE -> AddInvoiceScreen(viewModel = viewModel)
            ScreenName.INVOICE_DETAIL -> InvoiceDetailScreen(viewModel = viewModel)
            ScreenName.COUPONS -> CouponsScreen(viewModel = viewModel)
            ScreenName.ADD_COUPON -> AddCouponScreen(viewModel = viewModel)
            ScreenName.BULK_ADD_COUPONS -> BulkAddCouponsScreen(viewModel = viewModel)
            ScreenName.WINNER_CHECKER -> WinnerCheckerScreen(viewModel = viewModel)
            ScreenName.CLAIM_REPORT -> ClaimReportScreen(viewModel = viewModel)
            ScreenName.CHECK_ELIGIBILITY -> EligibilityCheckerScreen(viewModel = viewModel)
            ScreenName.VERIFY_VENDOR -> VerifyVendorScreen(viewModel = viewModel)
            ScreenName.IRD_INFO -> IrdInfoScreen(viewModel = viewModel)
            ScreenName.SCAN -> ScanScreen(viewModel = viewModel)
            ScreenName.EXPENSES -> ExpensesScreen(viewModel = viewModel)
            ScreenName.PROFILE -> ProfileScreen(viewModel = viewModel)
            ScreenName.DATA_BACKUP -> DataBackupScreen(viewModel = viewModel)
            ScreenName.WELCOME -> WelcomeScreen(viewModel = viewModel)
        }
    }
}

