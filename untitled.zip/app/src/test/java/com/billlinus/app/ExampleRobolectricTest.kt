package com.billlinus.app

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.billlinus.app.data.BillLinusRepository
import com.billlinus.app.model.Coupon
import com.billlinus.app.model.DarkModePreference
import com.billlinus.app.model.ScreenName
import com.billlinus.app.service.BillOcrService
import com.billlinus.app.service.DrawResultService
import com.billlinus.app.ui.MainViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Bill Linus", appName)
    }

    @Test
    fun `default dark mode preference is LIGHT on clean install`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        // Clear prefs to simulate clean install
        context.getSharedPreferences("bill_linus_prefs", Context.MODE_PRIVATE).edit().clear().commit()

        val repo = BillLinusRepository(context)
        assertEquals(DarkModePreference.LIGHT, repo.darkMode.value)
    }

    @Test
    fun `draw result matching logic finds matching coupon numbers`() {
        val coupons = listOf(
            Coupon(
                id = "c1",
                couponNumber = "007315254493",
                createdAt = "2026-08-15T00:00:00Z"
            ),
            Coupon(
                id = "c2",
                couponNumber = "007315254494",
                createdAt = "2026-08-15T00:00:00Z"
            )
        )

        val winningNumbers = listOf("007315254493", "999999999999", "007 315 254 494")
        val matches = DrawResultService.findMatches(winningNumbers, coupons)

        assertEquals(2, matches.size)
        assertTrue(matches.contains("007315254493"))
        assertTrue(matches.contains("007315254494"))
        assertFalse(matches.contains("999999999999"))
    }

    @Test
    fun `notified matches tracking prevents duplicate alerts`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = BillLinusRepository(context)

        val matchKey = "draw-1_007315254493"
        assertFalse(repo.isMatchNotified(matchKey))

        repo.markMatchNotified(matchKey)
        assertTrue(repo.isMatchNotified(matchKey))
    }

    @Test
    fun `navigation to invoices and coupons and back works correctly`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = MainViewModel(app)

        assertEquals(ScreenName.HOME, vm.currentScreen.value)

        vm.navigateTo(ScreenName.INVOICES)
        assertEquals(ScreenName.INVOICES, vm.currentScreen.value)

        assertTrue(vm.navigateBack())
        assertEquals(ScreenName.HOME, vm.currentScreen.value)

        vm.navigateTo(ScreenName.COUPONS)
        assertEquals(ScreenName.COUPONS, vm.currentScreen.value)

        assertTrue(vm.navigateBack())
        assertEquals(ScreenName.HOME, vm.currentScreen.value)
    }

    @Test
    fun `gemini json response parsing correctly extracts seller, pan, invoice number and amount`() {
        val sampleJson = """
            ```json
            {
              "sellerName": "Bhatbhateni Supermarket Pvt. Ltd.",
              "panVat": "300054321",
              "invoiceNumber": "INV-2083-0982",
              "date": "2026-08-19",
              "totalAmount": 2450.50
            }
            ```
        """.trimIndent()

        val result = BillOcrService.parseGeminiJsonResponse(sampleJson)
        assertTrue(result != null)
        assertTrue(result!!.isSuccess)
        assertEquals("Bhatbhateni Supermarket Pvt. Ltd.", result.sellerName)
        assertEquals("300054321", result.panVat)
        assertEquals("INV-2083-0982", result.invoiceNumber)
        assertEquals("2026-08-19", result.date)
        assertEquals(2450.50, result.totalAmount!!, 0.01)
    }

    @Test
    fun `gemini json response parsing handles partial or invalid json gracefully`() {
        val brokenJson = "Sorry, I couldn't read the image clearly."
        val result = BillOcrService.parseGeminiJsonResponse(brokenJson)
        assertEquals(null, result)
    }
}
