package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.RasidKhataRepository
import com.example.model.Coupon
import com.example.model.DarkModePreference
import com.example.model.ScreenName
import com.example.service.DrawResultService
import com.example.ui.MainViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Bill Linus", appName)
    }

    @Test
    fun `default dark mode preference is LIGHT on clean install`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        // Clear prefs to simulate clean install
        context.getSharedPreferences("rasid_khata_prefs", Context.MODE_PRIVATE).edit().clear().commit()

        val repo = RasidKhataRepository(context)
        assertEquals(DarkModePreference.LIGHT, repo.darkMode.value)
    }

    @Test
    fun `draw result matching logic finds matching coupon numbers`() {
        val coupons = listOf(
            Coupon(
                id = "c1",
                couponNumber = "007315254493",
                createdAt = "2026-08-15T00:00:00Z"
            ),
            Coupon(
                id = "c2",
                couponNumber = "007315254494",
                createdAt = "2026-08-15T00:00:00Z"
            )
        )

        val winningNumbers = listOf("007315254493", "999999999999", "007 315 254 494")
        val matches = DrawResultService.findMatches(winningNumbers, coupons)

        assertEquals(2, matches.size)
        assertTrue(matches.contains("007315254493"))
        assertTrue(matches.contains("007315254494"))
        assertFalse(matches.contains("999999999999"))
    }

    @Test
    fun `notified matches tracking prevents duplicate alerts`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = RasidKhataRepository(context)

        val matchKey = "draw-1_007315254493"
        assertFalse(repo.isMatchNotified(matchKey))

        repo.markMatchNotified(matchKey)
        assertTrue(repo.isMatchNotified(matchKey))
    }

    @Test
    fun `navigation to invoices and coupons and back works correctly`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = MainViewModel(app)

        assertEquals(ScreenName.HOME, vm.currentScreen.value)

        vm.navigateTo(ScreenName.INVOICES)
        assertEquals(ScreenName.INVOICES, vm.currentScreen.value)

        assertTrue(vm.navigateBack())
        assertEquals(ScreenName.HOME, vm.currentScreen.value)

        vm.navigateTo(ScreenName.COUPONS)
        assertEquals(ScreenName.COUPONS, vm.currentScreen.value)

        assertTrue(vm.navigateBack())
        assertEquals(ScreenName.HOME, vm.currentScreen.value)
    }
}
