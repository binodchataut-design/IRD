# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# Keep kotlinx.serialization models and serializers
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
    @kotlinx.serialization.SerialName <fields>;
}

-keep class com.billlinus.app.model.** { *; }
-keepclassmembers class com.billlinus.app.model.** { *; }

-keepclassmembers class com.billlinus.app.model.**$Companion {
    public kotlinx.serialization.KSerializer serializer();
}

-keepclasseswithmembers class com.billlinus.app.model.** {
    public kotlinx.serialization.KSerializer serializer();
}

